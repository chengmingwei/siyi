/*
Navicat MySQL Data Transfer

Source Server         : jn-server
Source Server Version : 50621
Source Host           : 122.114.76.140:3306
Source Database       : smartplatform

Target Server Type    : MYSQL
Target Server Version : 50621
File Encoding         : 65001

Date: 2019-03-26 15:44:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for act_ge_bytearray
-- ----------------------------
DROP TABLE IF EXISTS `act_ge_bytearray`;
CREATE TABLE `act_ge_bytearray` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `REV_` int(11) DEFAULT NULL,
  `NAME_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `DEPLOYMENT_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `BYTES_` longblob,
  `GENERATED_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  KEY `ACT_FK_BYTEARR_DEPL` (`DEPLOYMENT_ID_`),
  CONSTRAINT `ACT_FK_BYTEARR_DEPL` FOREIGN KEY (`DEPLOYMENT_ID_`) REFERENCES `act_re_deployment` (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_ge_bytearray
-- ----------------------------

-- ----------------------------
-- Table structure for act_ge_property
-- ----------------------------
DROP TABLE IF EXISTS `act_ge_property`;
CREATE TABLE `act_ge_property` (
  `NAME_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `VALUE_` varchar(300) COLLATE utf8_bin DEFAULT NULL,
  `REV_` int(11) DEFAULT NULL,
  PRIMARY KEY (`NAME_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_ge_property
-- ----------------------------
INSERT INTO `act_ge_property` VALUES ('historyLevel', '2', '1');
INSERT INTO `act_ge_property` VALUES ('next.dbid', '1', '1');
INSERT INTO `act_ge_property` VALUES ('schema.history', 'create(5.10)', '1');
INSERT INTO `act_ge_property` VALUES ('schema.version', '5.10', '1');

-- ----------------------------
-- Table structure for act_hi_actinst
-- ----------------------------
DROP TABLE IF EXISTS `act_hi_actinst`;
CREATE TABLE `act_hi_actinst` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `PROC_DEF_ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `EXECUTION_ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `ACT_ID_` varchar(255) COLLATE utf8_bin NOT NULL,
  `ACT_NAME_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `ACT_TYPE_` varchar(255) COLLATE utf8_bin NOT NULL,
  `ASSIGNEE_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `START_TIME_` datetime NOT NULL,
  `END_TIME_` datetime DEFAULT NULL,
  `DURATION_` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  KEY `ACT_IDX_HI_ACT_INST_START` (`START_TIME_`),
  KEY `ACT_IDX_HI_ACT_INST_END` (`END_TIME_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_hi_actinst
-- ----------------------------

-- ----------------------------
-- Table structure for act_hi_attachment
-- ----------------------------
DROP TABLE IF EXISTS `act_hi_attachment`;
CREATE TABLE `act_hi_attachment` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `REV_` int(11) DEFAULT NULL,
  `USER_ID_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `NAME_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `DESCRIPTION_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `TYPE_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `TASK_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `URL_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `CONTENT_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_hi_attachment
-- ----------------------------

-- ----------------------------
-- Table structure for act_hi_comment
-- ----------------------------
DROP TABLE IF EXISTS `act_hi_comment`;
CREATE TABLE `act_hi_comment` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `TYPE_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `TIME_` datetime NOT NULL,
  `USER_ID_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `TASK_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `ACTION_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `MESSAGE_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `FULL_MSG_` longblob,
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_hi_comment
-- ----------------------------

-- ----------------------------
-- Table structure for act_hi_detail
-- ----------------------------
DROP TABLE IF EXISTS `act_hi_detail`;
CREATE TABLE `act_hi_detail` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `TYPE_` varchar(255) COLLATE utf8_bin NOT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `EXECUTION_ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `TASK_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `ACT_INST_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `NAME_` varchar(255) COLLATE utf8_bin NOT NULL,
  `VAR_TYPE_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `REV_` int(11) DEFAULT NULL,
  `TIME_` datetime NOT NULL,
  `BYTEARRAY_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `DOUBLE_` double DEFAULT NULL,
  `LONG_` bigint(20) DEFAULT NULL,
  `TEXT_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `TEXT2_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  KEY `ACT_IDX_HI_DETAIL_PROC_INST` (`PROC_INST_ID_`),
  KEY `ACT_IDX_HI_DETAIL_ACT_INST` (`ACT_INST_ID_`),
  KEY `ACT_IDX_HI_DETAIL_TIME` (`TIME_`),
  KEY `ACT_IDX_HI_DETAIL_NAME` (`NAME_`),
  KEY `ACT_IDX_HI_DETAIL_TASK_ID` (`TASK_ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_hi_detail
-- ----------------------------

-- ----------------------------
-- Table structure for act_hi_procinst
-- ----------------------------
DROP TABLE IF EXISTS `act_hi_procinst`;
CREATE TABLE `act_hi_procinst` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `BUSINESS_KEY_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `PROC_DEF_ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `START_TIME_` datetime NOT NULL,
  `END_TIME_` datetime DEFAULT NULL,
  `DURATION_` bigint(20) DEFAULT NULL,
  `START_USER_ID_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `START_ACT_ID_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `END_ACT_ID_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `SUPER_PROCESS_INSTANCE_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `DELETE_REASON_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  UNIQUE KEY `PROC_INST_ID_` (`PROC_INST_ID_`),
  UNIQUE KEY `ACT_UNIQ_HI_BUS_KEY` (`PROC_DEF_ID_`,`BUSINESS_KEY_`),
  KEY `ACT_IDX_HI_PRO_INST_END` (`END_TIME_`),
  KEY `ACT_IDX_HI_PRO_I_BUSKEY` (`BUSINESS_KEY_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_hi_procinst
-- ----------------------------

-- ----------------------------
-- Table structure for act_hi_taskinst
-- ----------------------------
DROP TABLE IF EXISTS `act_hi_taskinst`;
CREATE TABLE `act_hi_taskinst` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `PROC_DEF_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `TASK_DEF_KEY_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `EXECUTION_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `NAME_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `PARENT_TASK_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `DESCRIPTION_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `OWNER_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `ASSIGNEE_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `START_TIME_` datetime NOT NULL,
  `END_TIME_` datetime DEFAULT NULL,
  `DURATION_` bigint(20) DEFAULT NULL,
  `DELETE_REASON_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `PRIORITY_` int(11) DEFAULT NULL,
  `DUE_DATE_` datetime DEFAULT NULL,
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_hi_taskinst
-- ----------------------------

-- ----------------------------
-- Table structure for act_id_group
-- ----------------------------
DROP TABLE IF EXISTS `act_id_group`;
CREATE TABLE `act_id_group` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `REV_` int(11) DEFAULT NULL,
  `NAME_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `TYPE_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_id_group
-- ----------------------------

-- ----------------------------
-- Table structure for act_id_info
-- ----------------------------
DROP TABLE IF EXISTS `act_id_info`;
CREATE TABLE `act_id_info` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `REV_` int(11) DEFAULT NULL,
  `USER_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `TYPE_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `KEY_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `VALUE_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `PASSWORD_` longblob,
  `PARENT_ID_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_id_info
-- ----------------------------

-- ----------------------------
-- Table structure for act_id_membership
-- ----------------------------
DROP TABLE IF EXISTS `act_id_membership`;
CREATE TABLE `act_id_membership` (
  `USER_ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `GROUP_ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`USER_ID_`,`GROUP_ID_`),
  KEY `ACT_FK_MEMB_GROUP` (`GROUP_ID_`),
  CONSTRAINT `ACT_FK_MEMB_GROUP` FOREIGN KEY (`GROUP_ID_`) REFERENCES `act_id_group` (`ID_`),
  CONSTRAINT `ACT_FK_MEMB_USER` FOREIGN KEY (`USER_ID_`) REFERENCES `act_id_user` (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_id_membership
-- ----------------------------

-- ----------------------------
-- Table structure for act_id_user
-- ----------------------------
DROP TABLE IF EXISTS `act_id_user`;
CREATE TABLE `act_id_user` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `REV_` int(11) DEFAULT NULL,
  `FIRST_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `LAST_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `EMAIL_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `PWD_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `PICTURE_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_id_user
-- ----------------------------

-- ----------------------------
-- Table structure for act_re_deployment
-- ----------------------------
DROP TABLE IF EXISTS `act_re_deployment`;
CREATE TABLE `act_re_deployment` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `NAME_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `DEPLOY_TIME_` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_re_deployment
-- ----------------------------

-- ----------------------------
-- Table structure for act_re_procdef
-- ----------------------------
DROP TABLE IF EXISTS `act_re_procdef`;
CREATE TABLE `act_re_procdef` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `REV_` int(11) DEFAULT NULL,
  `CATEGORY_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `NAME_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `KEY_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `VERSION_` int(11) DEFAULT NULL,
  `DEPLOYMENT_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `RESOURCE_NAME_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `DGRM_RESOURCE_NAME_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `HAS_START_FORM_KEY_` tinyint(4) DEFAULT NULL,
  `SUSPENSION_STATE_` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  UNIQUE KEY `ACT_UNIQ_PROCDEF` (`KEY_`,`VERSION_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_re_procdef
-- ----------------------------

-- ----------------------------
-- Table structure for act_ru_event_subscr
-- ----------------------------
DROP TABLE IF EXISTS `act_ru_event_subscr`;
CREATE TABLE `act_ru_event_subscr` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `REV_` int(11) DEFAULT NULL,
  `EVENT_TYPE_` varchar(255) COLLATE utf8_bin NOT NULL,
  `EVENT_NAME_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `EXECUTION_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `ACTIVITY_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `CONFIGURATION_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `CREATED_` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID_`),
  KEY `ACT_IDX_EVENT_SUBSCR_CONFIG_` (`CONFIGURATION_`),
  KEY `ACT_FK_EVENT_EXEC` (`EXECUTION_ID_`),
  CONSTRAINT `ACT_FK_EVENT_EXEC` FOREIGN KEY (`EXECUTION_ID_`) REFERENCES `act_ru_execution` (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_ru_event_subscr
-- ----------------------------

-- ----------------------------
-- Table structure for act_ru_execution
-- ----------------------------
DROP TABLE IF EXISTS `act_ru_execution`;
CREATE TABLE `act_ru_execution` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `REV_` int(11) DEFAULT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `BUSINESS_KEY_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `PARENT_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PROC_DEF_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `SUPER_EXEC_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `ACT_ID_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `IS_ACTIVE_` tinyint(4) DEFAULT NULL,
  `IS_CONCURRENT_` tinyint(4) DEFAULT NULL,
  `IS_SCOPE_` tinyint(4) DEFAULT NULL,
  `IS_EVENT_SCOPE_` tinyint(4) DEFAULT NULL,
  `SUSPENSION_STATE_` int(11) DEFAULT NULL,
  `CACHED_ENT_STATE_` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  UNIQUE KEY `ACT_UNIQ_RU_BUS_KEY` (`PROC_DEF_ID_`,`BUSINESS_KEY_`),
  KEY `ACT_IDX_EXEC_BUSKEY` (`BUSINESS_KEY_`),
  KEY `ACT_FK_EXE_PROCINST` (`PROC_INST_ID_`),
  KEY `ACT_FK_EXE_PARENT` (`PARENT_ID_`),
  KEY `ACT_FK_EXE_SUPER` (`SUPER_EXEC_`),
  CONSTRAINT `ACT_FK_EXE_PARENT` FOREIGN KEY (`PARENT_ID_`) REFERENCES `act_ru_execution` (`ID_`),
  CONSTRAINT `ACT_FK_EXE_PROCINST` FOREIGN KEY (`PROC_INST_ID_`) REFERENCES `act_ru_execution` (`ID_`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ACT_FK_EXE_SUPER` FOREIGN KEY (`SUPER_EXEC_`) REFERENCES `act_ru_execution` (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_ru_execution
-- ----------------------------

-- ----------------------------
-- Table structure for act_ru_identitylink
-- ----------------------------
DROP TABLE IF EXISTS `act_ru_identitylink`;
CREATE TABLE `act_ru_identitylink` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `REV_` int(11) DEFAULT NULL,
  `GROUP_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `TYPE_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `USER_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `TASK_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PROC_DEF_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  KEY `ACT_IDX_IDENT_LNK_USER` (`USER_ID_`),
  KEY `ACT_IDX_IDENT_LNK_GROUP` (`GROUP_ID_`),
  KEY `ACT_IDX_ATHRZ_PROCEDEF` (`PROC_DEF_ID_`),
  KEY `ACT_FK_TSKASS_TASK` (`TASK_ID_`),
  CONSTRAINT `ACT_FK_ATHRZ_PROCEDEF` FOREIGN KEY (`PROC_DEF_ID_`) REFERENCES `act_re_procdef` (`ID_`),
  CONSTRAINT `ACT_FK_TSKASS_TASK` FOREIGN KEY (`TASK_ID_`) REFERENCES `act_ru_task` (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_ru_identitylink
-- ----------------------------

-- ----------------------------
-- Table structure for act_ru_job
-- ----------------------------
DROP TABLE IF EXISTS `act_ru_job`;
CREATE TABLE `act_ru_job` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `REV_` int(11) DEFAULT NULL,
  `TYPE_` varchar(255) COLLATE utf8_bin NOT NULL,
  `LOCK_EXP_TIME_` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LOCK_OWNER_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `EXCLUSIVE_` tinyint(1) DEFAULT NULL,
  `EXECUTION_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PROCESS_INSTANCE_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `RETRIES_` int(11) DEFAULT NULL,
  `EXCEPTION_STACK_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `EXCEPTION_MSG_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `DUEDATE_` timestamp NULL DEFAULT NULL,
  `REPEAT_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `HANDLER_TYPE_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `HANDLER_CFG_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  KEY `ACT_FK_JOB_EXCEPTION` (`EXCEPTION_STACK_ID_`),
  CONSTRAINT `ACT_FK_JOB_EXCEPTION` FOREIGN KEY (`EXCEPTION_STACK_ID_`) REFERENCES `act_ge_bytearray` (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_ru_job
-- ----------------------------

-- ----------------------------
-- Table structure for act_ru_task
-- ----------------------------
DROP TABLE IF EXISTS `act_ru_task`;
CREATE TABLE `act_ru_task` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `REV_` int(11) DEFAULT NULL,
  `EXECUTION_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PROC_DEF_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `NAME_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `PARENT_TASK_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `DESCRIPTION_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `TASK_DEF_KEY_` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `OWNER_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `ASSIGNEE_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `DELEGATION_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PRIORITY_` int(11) DEFAULT NULL,
  `CREATE_TIME_` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DUE_DATE_` datetime DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  KEY `ACT_IDX_TASK_CREATE` (`CREATE_TIME_`),
  KEY `ACT_FK_TASK_EXE` (`EXECUTION_ID_`),
  KEY `ACT_FK_TASK_PROCINST` (`PROC_INST_ID_`),
  KEY `ACT_FK_TASK_PROCDEF` (`PROC_DEF_ID_`),
  CONSTRAINT `ACT_FK_TASK_EXE` FOREIGN KEY (`EXECUTION_ID_`) REFERENCES `act_ru_execution` (`ID_`),
  CONSTRAINT `ACT_FK_TASK_PROCDEF` FOREIGN KEY (`PROC_DEF_ID_`) REFERENCES `act_re_procdef` (`ID_`),
  CONSTRAINT `ACT_FK_TASK_PROCINST` FOREIGN KEY (`PROC_INST_ID_`) REFERENCES `act_ru_execution` (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_ru_task
-- ----------------------------

-- ----------------------------
-- Table structure for act_ru_variable
-- ----------------------------
DROP TABLE IF EXISTS `act_ru_variable`;
CREATE TABLE `act_ru_variable` (
  `ID_` varchar(64) COLLATE utf8_bin NOT NULL,
  `REV_` int(11) DEFAULT NULL,
  `TYPE_` varchar(255) COLLATE utf8_bin NOT NULL,
  `NAME_` varchar(255) COLLATE utf8_bin NOT NULL,
  `EXECUTION_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `TASK_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `BYTEARRAY_ID_` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `DOUBLE_` double DEFAULT NULL,
  `LONG_` bigint(20) DEFAULT NULL,
  `TEXT_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `TEXT2_` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  KEY `ACT_IDX_VARIABLE_TASK_ID` (`TASK_ID_`),
  KEY `ACT_FK_VAR_EXE` (`EXECUTION_ID_`),
  KEY `ACT_FK_VAR_PROCINST` (`PROC_INST_ID_`),
  KEY `ACT_FK_VAR_BYTEARRAY` (`BYTEARRAY_ID_`),
  CONSTRAINT `ACT_FK_VAR_BYTEARRAY` FOREIGN KEY (`BYTEARRAY_ID_`) REFERENCES `act_ge_bytearray` (`ID_`),
  CONSTRAINT `ACT_FK_VAR_EXE` FOREIGN KEY (`EXECUTION_ID_`) REFERENCES `act_ru_execution` (`ID_`),
  CONSTRAINT `ACT_FK_VAR_PROCINST` FOREIGN KEY (`PROC_INST_ID_`) REFERENCES `act_ru_execution` (`ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of act_ru_variable
-- ----------------------------

-- ----------------------------
-- Table structure for ts_classinfo
-- ----------------------------
DROP TABLE IF EXISTS `ts_classinfo`;
CREATE TABLE `ts_classinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime NOT NULL,
  `modifyTime` datetime DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `remark` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `srcId` bigint(20) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1664 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ts_classinfo
-- ----------------------------
INSERT INTO `ts_classinfo` VALUES ('1', '2017-08-03 16:31:59', null, 'nulladd', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('2', '2017-08-03 16:31:59', null, 'nullget', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('3', '2017-08-03 16:31:59', null, 'nulllist', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('4', '2017-08-03 16:31:59', null, 'nullsave', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('5', '2017-08-03 16:31:59', null, 'nulldelete', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('6', '2017-08-03 16:31:59', null, 'nullisEnabled', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('7', '2017-08-03 16:32:00', null, 'nullenabled', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('8', '2017-08-03 16:32:00', null, 'nullenabled', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('9', '2017-08-03 16:32:00', null, 'nullnavigate', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('10', '2017-08-03 16:32:00', null, 'nullnavData', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('11', '2017-08-03 16:32:00', null, 'nulldisabled', null, '1865', '0');
INSERT INTO `ts_classinfo` VALUES ('12', '2017-08-03 16:32:00', null, 'nulladd', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('13', '2017-08-03 16:32:00', null, 'nullget', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('14', '2017-08-03 16:32:00', null, 'nullnext', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('15', '2017-08-03 16:32:00', null, 'nullprev', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('16', '2017-08-03 16:32:00', null, 'nulllist', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('17', '2017-08-03 16:32:00', null, 'nullsave', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('18', '2017-08-03 16:32:00', null, 'nulldelete', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('19', '2017-08-03 16:32:00', null, 'nullupdate', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('20', '2017-08-03 16:32:00', null, 'nullitems', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('21', '2017-08-03 16:32:00', null, 'nullenabled', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('22', '2017-08-03 16:32:00', null, 'nullenabled', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('23', '2017-08-03 16:32:00', null, 'nulldownload', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('24', '2017-08-03 16:32:00', null, 'nulllistMat', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('25', '2017-08-03 16:32:00', null, 'nullsetTop', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('26', '2017-08-03 16:32:00', null, 'nulldisabled', null, '1866', '0');
INSERT INTO `ts_classinfo` VALUES ('27', '2017-08-03 16:32:00', null, 'nulladd', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('28', '2017-08-03 16:32:00', null, 'nullget', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('29', '2017-08-03 16:32:01', null, 'nullnext', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('30', '2017-08-03 16:32:01', null, 'nullprev', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('31', '2017-08-03 16:32:01', null, 'nulllist', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('32', '2017-08-03 16:32:01', null, 'nullsave', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('33', '2017-08-03 16:32:01', null, 'nulldelete', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('34', '2017-08-03 16:32:01', null, 'nullenabled', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('35', '2017-08-03 16:32:01', null, 'nullenabled', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('36', '2017-08-03 16:32:01', null, 'nullgetEbackInfo', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('37', '2017-08-03 16:32:01', null, 'nullgetEndInfo', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('38', '2017-08-03 16:32:01', null, 'nulldisabled', null, '1867', '0');
INSERT INTO `ts_classinfo` VALUES ('39', '2017-08-03 16:32:01', null, 'nulladd', null, '1868', '0');
INSERT INTO `ts_classinfo` VALUES ('40', '2017-08-03 16:32:01', null, 'nullget', null, '1868', '0');
INSERT INTO `ts_classinfo` VALUES ('41', '2017-08-03 16:32:01', null, 'nullnext', null, '1868', '0');
INSERT INTO `ts_classinfo` VALUES ('42', '2017-08-03 16:32:01', null, 'nullprev', null, '1868', '0');
INSERT INTO `ts_classinfo` VALUES ('43', '2017-08-03 16:32:01', null, 'nulllist', null, '1868', '0');
INSERT INTO `ts_classinfo` VALUES ('44', '2017-08-03 16:32:01', null, 'nullsave', null, '1868', '0');
INSERT INTO `ts_classinfo` VALUES ('45', '2017-08-03 16:32:01', null, 'nulldelete', null, '1868', '0');
INSERT INTO `ts_classinfo` VALUES ('46', '2017-08-03 16:32:01', null, 'nulladd', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('47', '2017-08-03 16:32:01', null, 'nullget', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('48', '2017-08-03 16:32:01', null, 'nullnext', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('49', '2017-08-03 16:32:01', null, 'nullprev', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('50', '2017-08-03 16:32:01', null, 'nulllist', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('51', '2017-08-03 16:32:01', null, 'nullsave', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('52', '2017-08-03 16:32:01', null, 'nulldelete', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('53', '2017-08-03 16:32:01', null, 'nullenabled', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('54', '2017-08-03 16:32:01', null, 'nullenabled', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('55', '2017-08-03 16:32:01', null, 'nullgetExePostion', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('56', '2017-08-03 16:32:01', null, 'nullprocessImage', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('57', '2017-08-03 16:32:01', null, 'nullgetPostion', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('58', '2017-08-03 16:32:01', null, 'nullsaveCfgs', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('59', '2017-08-03 16:32:02', null, 'nulldisabled', null, '1869', '0');
INSERT INTO `ts_classinfo` VALUES ('60', '2017-08-03 16:32:02', null, 'nulladd', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('61', '2017-08-03 16:32:02', null, 'nullget', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('62', '2017-08-03 16:32:02', null, 'nullnext', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('63', '2017-08-03 16:32:02', null, 'nullprev', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('64', '2017-08-03 16:32:02', null, 'nulllist', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('65', '2017-08-03 16:32:02', null, 'nullsave', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('66', '2017-08-03 16:32:02', null, 'nulldelete', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('67', '2017-08-03 16:32:02', null, 'nullenabled', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('68', '2017-08-03 16:32:02', null, 'nullenabled', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('69', '2017-08-03 16:32:02', null, 'nulldelClause', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('70', '2017-08-03 16:32:02', null, 'nullgetClause', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('71', '2017-08-03 16:32:02', null, 'nullsaveClause', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('72', '2017-08-03 16:32:02', null, 'nullgetClauseList', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('73', '2017-08-03 16:32:02', null, 'nulldisabled', null, '1870', '0');
INSERT INTO `ts_classinfo` VALUES ('74', '2017-08-03 16:32:02', null, 'nullstart', null, '1871', '0');
INSERT INTO `ts_classinfo` VALUES ('75', '2017-08-03 16:32:02', null, 'nullgetTask', null, '1871', '0');
INSERT INTO `ts_classinfo` VALUES ('76', '2017-08-03 16:32:02', null, 'nullsubmit', null, '1871', '0');
INSERT INTO `ts_classinfo` VALUES ('77', '2017-08-03 16:32:02', null, 'nulladd', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('78', '2017-08-03 16:32:02', null, 'nullget', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('79', '2017-08-03 16:32:02', null, 'nullnext', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('80', '2017-08-03 16:32:02', null, 'nullprev', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('81', '2017-08-03 16:32:02', null, 'nulllist', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('82', '2017-08-03 16:32:02', null, 'nullsave', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('83', '2017-08-03 16:32:02', null, 'nulldelete', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('84', '2017-08-03 16:32:02', null, 'nullenabled', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('85', '2017-08-03 16:32:02', null, 'nullenabled', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('86', '2017-08-03 16:32:02', null, 'nulldisabled', null, '1872', '0');
INSERT INTO `ts_classinfo` VALUES ('87', '2017-08-03 16:32:02', null, 'nulladd', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('88', '2017-08-03 16:32:02', null, 'nullget', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('89', '2017-08-03 16:32:02', null, 'nullnext', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('90', '2017-08-03 16:32:02', null, 'nullprev', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('91', '2017-08-03 16:32:02', null, 'nulllist', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('92', '2017-08-03 16:32:03', null, 'nullsave', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('93', '2017-08-03 16:32:03', null, 'nulldelete', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('94', '2017-08-03 16:32:03', null, 'nullenabled', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('95', '2017-08-03 16:32:03', null, 'nullenabled', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('96', '2017-08-03 16:32:03', null, 'nullisdefault', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('97', '2017-08-03 16:32:03', null, 'nulldisabled', null, '1873', '0');
INSERT INTO `ts_classinfo` VALUES ('98', '2017-08-03 16:32:03', null, 'nulladd', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('99', '2017-08-03 16:32:03', null, 'nullget', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('100', '2017-08-03 16:32:03', null, 'nullnext', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('101', '2017-08-03 16:32:03', null, 'nullprev', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('102', '2017-08-03 16:32:03', null, 'nulllist', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('103', '2017-08-03 16:32:03', null, 'nullsave', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('104', '2017-08-03 16:32:03', null, 'nulldelete', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('105', '2017-08-03 16:32:03', null, 'nullenabled', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('106', '2017-08-03 16:32:03', null, 'nullenabled', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('107', '2017-08-03 16:32:03', null, 'nulldisabled', null, '1874', '0');
INSERT INTO `ts_classinfo` VALUES ('108', '2017-08-03 16:32:03', null, 'nulladd', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('109', '2017-08-03 16:32:03', null, 'nullget', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('110', '2017-08-03 16:32:03', null, 'nullnext', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('111', '2017-08-03 16:32:03', null, 'nullprev', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('112', '2017-08-03 16:32:03', null, 'nulllist', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('113', '2017-08-03 16:32:03', null, 'nullsave', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('114', '2017-08-03 16:32:03', null, 'nulldelete', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('115', '2017-08-03 16:32:03', null, 'nullenabled', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('116', '2017-08-03 16:32:03', null, 'nullenabled', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('117', '2017-08-03 16:32:03', null, 'nulldisabled', null, '1875', '0');
INSERT INTO `ts_classinfo` VALUES ('118', '2017-08-03 16:32:03', null, 'nulladd', null, '1876', '0');
INSERT INTO `ts_classinfo` VALUES ('119', '2017-08-03 16:32:03', null, 'nullget', null, '1876', '0');
INSERT INTO `ts_classinfo` VALUES ('120', '2017-08-03 16:32:03', null, 'nullnext', null, '1876', '0');
INSERT INTO `ts_classinfo` VALUES ('121', '2017-08-03 16:32:03', null, 'nullprev', null, '1876', '0');
INSERT INTO `ts_classinfo` VALUES ('122', '2017-08-03 16:32:03', null, 'nulllist', null, '1876', '0');
INSERT INTO `ts_classinfo` VALUES ('123', '2017-08-03 16:32:03', null, 'nullsave', null, '1876', '0');
INSERT INTO `ts_classinfo` VALUES ('124', '2017-08-03 16:32:03', null, 'nulldelete', null, '1876', '0');
INSERT INTO `ts_classinfo` VALUES ('125', '2017-08-03 16:32:03', null, 'nullenabled', null, '1876', '0');
INSERT INTO `ts_classinfo` VALUES ('126', '2017-08-03 16:32:04', null, 'nulldisabled', null, '1876', '0');
INSERT INTO `ts_classinfo` VALUES ('127', '2017-08-03 16:32:04', null, 'nulladd', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('128', '2017-08-03 16:32:04', null, 'nullget', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('129', '2017-08-03 16:32:04', null, 'nullnext', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('130', '2017-08-03 16:32:04', null, 'nullprev', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('131', '2017-08-03 16:32:04', null, 'nulllist', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('132', '2017-08-03 16:32:04', null, 'nullsave', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('133', '2017-08-03 16:32:04', null, 'nulldelete', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('134', '2017-08-03 16:32:04', null, 'nullenabled', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('135', '2017-08-03 16:32:04', null, 'nullenabled', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('136', '2017-08-03 16:32:04', null, 'nulldisabled', null, '1877', '0');
INSERT INTO `ts_classinfo` VALUES ('137', '2017-08-03 16:32:04', null, 'nulladd', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('138', '2017-08-03 16:32:04', null, 'nullget', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('139', '2017-08-03 16:32:04', null, 'nullnext', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('140', '2017-08-03 16:32:04', null, 'nullprev', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('141', '2017-08-03 16:32:04', null, 'nulllist', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('142', '2017-08-03 16:32:04', null, 'nullsave', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('143', '2017-08-03 16:32:04', null, 'nulldelete', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('144', '2017-08-03 16:32:04', null, 'nullenabled', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('145', '2017-08-03 16:32:04', null, 'nullenabled', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('146', '2017-08-03 16:32:04', null, 'nulldisabled', null, '1878', '0');
INSERT INTO `ts_classinfo` VALUES ('147', '2017-08-03 16:32:04', null, 'nulladd', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('148', '2017-08-03 16:32:04', null, 'nullget', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('149', '2017-08-03 16:32:04', null, 'nullnext', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('150', '2017-08-03 16:32:04', null, 'nullprev', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('151', '2017-08-03 16:32:04', null, 'nulllist', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('152', '2017-08-03 16:32:04', null, 'nullsave', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('153', '2017-08-03 16:32:04', null, 'nulldelete', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('154', '2017-08-03 16:32:04', null, 'nullenabled', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('155', '2017-08-03 16:32:04', null, 'nullenabled', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('156', '2017-08-03 16:32:04', null, 'nullisdefault', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('157', '2017-08-03 16:32:04', null, 'nulldisabled', null, '1879', '0');
INSERT INTO `ts_classinfo` VALUES ('158', '2017-08-03 16:32:04', null, 'nulladd', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('159', '2017-08-03 16:32:04', null, 'nullget', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('160', '2017-08-03 16:32:05', null, 'nullnext', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('161', '2017-08-03 16:32:05', null, 'nullprev', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('162', '2017-08-03 16:32:05', null, 'nulllist', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('163', '2017-08-03 16:32:05', null, 'nullsave', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('164', '2017-08-03 16:32:05', null, 'nulldelete', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('165', '2017-08-03 16:32:05', null, 'nullenabled', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('166', '2017-08-03 16:32:05', null, 'nullenabled', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('167', '2017-08-03 16:32:05', null, 'nulldisabled', null, '1880', '0');
INSERT INTO `ts_classinfo` VALUES ('168', '2017-08-03 16:32:05', null, 'nulladd', null, '1881', '0');
INSERT INTO `ts_classinfo` VALUES ('169', '2017-08-03 16:32:05', null, 'nullget', null, '1881', '0');
INSERT INTO `ts_classinfo` VALUES ('170', '2017-08-03 16:32:05', null, 'nullnext', null, '1881', '0');
INSERT INTO `ts_classinfo` VALUES ('171', '2017-08-03 16:32:05', null, 'nullprev', null, '1881', '0');
INSERT INTO `ts_classinfo` VALUES ('172', '2017-08-03 16:32:05', null, 'nulllist', null, '1881', '0');
INSERT INTO `ts_classinfo` VALUES ('173', '2017-08-03 16:32:05', null, 'nullsave', null, '1881', '0');
INSERT INTO `ts_classinfo` VALUES ('174', '2017-08-03 16:32:05', null, 'nulldelete', null, '1881', '0');
INSERT INTO `ts_classinfo` VALUES ('175', '2017-08-03 16:32:05', null, 'nullenabled', null, '1881', '0');
INSERT INTO `ts_classinfo` VALUES ('176', '2017-08-03 16:32:05', null, 'nulldisabled', null, '1881', '0');
INSERT INTO `ts_classinfo` VALUES ('177', '2017-08-03 16:32:05', null, 'nulladd', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('178', '2017-08-03 16:32:05', null, 'nullget', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('179', '2017-08-03 16:32:05', null, 'nullnext', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('180', '2017-08-03 16:32:05', null, 'nullprev', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('181', '2017-08-03 16:32:05', null, 'nulllist', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('182', '2017-08-03 16:32:06', null, 'nullsave', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('183', '2017-08-03 16:32:06', null, 'nulldelete', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('184', '2017-08-03 16:32:06', null, 'nullenabled', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('185', '2017-08-03 16:32:06', null, 'nullenabled', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('186', '2017-08-03 16:32:06', null, 'nulldisabled', null, '1882', '0');
INSERT INTO `ts_classinfo` VALUES ('187', '2017-08-03 16:32:06', null, 'nulladd', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('188', '2017-08-03 16:32:06', null, 'nullget', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('189', '2017-08-03 16:32:06', null, 'nullnext', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('190', '2017-08-03 16:32:06', null, 'nullprev', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('191', '2017-08-03 16:32:06', null, 'nulllist', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('192', '2017-08-03 16:32:06', null, 'nullsave', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('193', '2017-08-03 16:32:06', null, 'nulldelete', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('194', '2017-08-03 16:32:06', null, 'nullenabled', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('195', '2017-08-03 16:32:06', null, 'nullenabled', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('196', '2017-08-03 16:32:06', null, 'nulldisabled', null, '1883', '0');
INSERT INTO `ts_classinfo` VALUES ('197', '2017-08-03 16:32:06', null, 'nulladd', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('198', '2017-08-03 16:32:06', null, 'nullget', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('199', '2017-08-03 16:32:06', null, 'nullnext', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('200', '2017-08-03 16:32:06', null, 'nullprev', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('201', '2017-08-03 16:32:06', null, 'nulllist', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('202', '2017-08-03 16:32:06', null, 'nullsave', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('203', '2017-08-03 16:32:06', null, 'nulldelete', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('204', '2017-08-03 16:32:06', null, 'nullenabled', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('205', '2017-08-03 16:32:06', null, 'nullenabled', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('206', '2017-08-03 16:32:06', null, 'nulldisabled', null, '1884', '0');
INSERT INTO `ts_classinfo` VALUES ('207', '2017-08-03 16:32:06', null, 'nulladd', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('208', '2017-08-03 16:32:06', null, 'nullget', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('209', '2017-08-03 16:32:06', null, 'nullnext', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('210', '2017-08-03 16:32:06', null, 'nullprev', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('211', '2017-08-03 16:32:06', null, 'nulllist', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('212', '2017-08-03 16:32:07', null, 'nullsave', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('213', '2017-08-03 16:32:07', null, 'nulldelete', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('214', '2017-08-03 16:32:07', null, 'nullenabled', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('215', '2017-08-03 16:32:07', null, 'nullenabled', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('216', '2017-08-03 16:32:07', null, 'nulldisabled', null, '1885', '0');
INSERT INTO `ts_classinfo` VALUES ('217', '2017-08-03 16:32:07', null, 'nulladd', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('218', '2017-08-03 16:32:07', null, 'nullget', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('219', '2017-08-03 16:32:07', null, 'nullnext', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('220', '2017-08-03 16:32:07', null, 'nullprev', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('221', '2017-08-03 16:32:07', null, 'nulllist', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('222', '2017-08-03 16:32:07', null, 'nullsave', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('223', '2017-08-03 16:32:07', null, 'nulldelete', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('224', '2017-08-03 16:32:07', null, 'nullenabled', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('225', '2017-08-03 16:32:07', null, 'nullenabled', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('226', '2017-08-03 16:32:07', null, 'nulldisabled', null, '1886', '0');
INSERT INTO `ts_classinfo` VALUES ('227', '2017-08-03 16:32:07', null, 'nulladd', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('228', '2017-08-03 16:32:07', null, 'nullget', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('229', '2017-08-03 16:32:07', null, 'nullnext', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('230', '2017-08-03 16:32:07', null, 'nullprev', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('231', '2017-08-03 16:32:07', null, 'nulllist', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('232', '2017-08-03 16:32:07', null, 'nullsave', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('233', '2017-08-03 16:32:07', null, 'nulldelete', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('234', '2017-08-03 16:32:07', null, 'nullenabled', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('235', '2017-08-03 16:32:07', null, 'nullenabled', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('236', '2017-08-03 16:32:07', null, 'nullsavefile', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('237', '2017-08-03 16:32:07', null, 'nulldisabled', null, '1887', '0');
INSERT INTO `ts_classinfo` VALUES ('238', '2017-08-03 16:32:07', null, 'nulladd', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('239', '2017-08-03 16:32:07', null, 'nullget', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('240', '2017-08-03 16:32:07', null, 'nullnext', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('241', '2017-08-03 16:32:07', null, 'nullprev', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('242', '2017-08-03 16:32:07', null, 'nulllist', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('243', '2017-08-03 16:32:07', null, 'nullsave', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('244', '2017-08-03 16:32:07', null, 'nulldelete', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('245', '2017-08-03 16:32:07', null, 'nullenabled', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('246', '2017-08-03 16:32:08', null, 'nullenabled', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('247', '2017-08-03 16:32:08', null, 'nulldisabled', null, '1888', '0');
INSERT INTO `ts_classinfo` VALUES ('248', '2017-08-03 16:32:08', null, 'nulladd', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('249', '2017-08-03 16:32:08', null, 'nullget', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('250', '2017-08-03 16:32:08', null, 'nullnext', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('251', '2017-08-03 16:32:08', null, 'nullprev', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('252', '2017-08-03 16:32:08', null, 'nulllist', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('253', '2017-08-03 16:32:08', null, 'nullsave', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('254', '2017-08-03 16:32:08', null, 'nulldelete', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('255', '2017-08-03 16:32:08', null, 'nullenabled', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('256', '2017-08-03 16:32:08', null, 'nullenabled', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('257', '2017-08-03 16:32:08', null, 'nullcbodatas', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('258', '2017-08-03 16:32:08', null, 'nulldisabled', null, '1889', '0');
INSERT INTO `ts_classinfo` VALUES ('259', '2017-08-03 16:32:08', null, 'nulladd', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('260', '2017-08-03 16:32:08', null, 'nullget', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('261', '2017-08-03 16:32:08', null, 'nullnext', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('262', '2017-08-03 16:32:08', null, 'nullprev', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('263', '2017-08-03 16:32:08', null, 'nulllist', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('264', '2017-08-03 16:32:08', null, 'nullsave', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('265', '2017-08-03 16:32:08', null, 'nulldelete', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('266', '2017-08-03 16:32:08', null, 'nullenabled', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('267', '2017-08-03 16:32:08', null, 'nullenabled', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('268', '2017-08-03 16:32:08', null, 'nullcal', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('269', '2017-08-03 16:32:08', null, 'nullattscs', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('270', '2017-08-03 16:32:08', null, 'nulldisabled', null, '1890', '0');
INSERT INTO `ts_classinfo` VALUES ('271', '2017-08-03 16:32:08', null, 'nullsave', null, '1891', '0');
INSERT INTO `ts_classinfo` VALUES ('272', '2017-08-03 16:32:08', null, 'nulladd', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('273', '2017-08-03 16:32:08', null, 'nullget', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('274', '2017-08-03 16:32:08', null, 'nullnext', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('275', '2017-08-03 16:32:08', null, 'nullprev', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('276', '2017-08-03 16:32:08', null, 'nulllist', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('277', '2017-08-03 16:32:08', null, 'nullsave', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('278', '2017-08-03 16:32:08', null, 'nulldelete', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('279', '2017-08-03 16:32:08', null, 'nullenabled', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('280', '2017-08-03 16:32:09', null, 'nullenabled', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('281', '2017-08-03 16:32:09', null, 'nullrebuild', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('282', '2017-08-03 16:32:09', null, 'nulldisabled', null, '1892', '0');
INSERT INTO `ts_classinfo` VALUES ('283', '2017-08-03 16:32:09', null, 'nulladd', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('284', '2017-08-03 16:32:09', null, 'nullget', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('285', '2017-08-03 16:32:09', null, 'nullnext', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('286', '2017-08-03 16:32:09', null, 'nullprev', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('287', '2017-08-03 16:32:09', null, 'nulllist', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('288', '2017-08-03 16:32:09', null, 'nullsave', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('289', '2017-08-03 16:32:09', null, 'nulldelete', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('290', '2017-08-03 16:32:09', null, 'nullenabled', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('291', '2017-08-03 16:32:09', null, 'nullenabled', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('292', '2017-08-03 16:32:09', null, 'nulldisabled', null, '1893', '0');
INSERT INTO `ts_classinfo` VALUES ('293', '2017-08-03 16:32:09', null, 'nulladd', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('294', '2017-08-03 16:32:09', null, 'nullget', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('295', '2017-08-03 16:32:09', null, 'nullnext', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('296', '2017-08-03 16:32:09', null, 'nullprev', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('297', '2017-08-03 16:32:09', null, 'nulllist', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('298', '2017-08-03 16:32:09', null, 'nullsave', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('299', '2017-08-03 16:32:09', null, 'nullcopy', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('300', '2017-08-03 16:32:09', null, 'nulldelete', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('301', '2017-08-03 16:32:09', null, 'nullenabled', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('302', '2017-08-03 16:32:09', null, 'nullenabled', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('303', '2017-08-03 16:32:09', null, 'nullgetMat', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('304', '2017-08-03 16:32:09', null, 'nullgetTemp', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('305', '2017-08-03 16:32:09', null, 'nulldisabled', null, '1894', '0');
INSERT INTO `ts_classinfo` VALUES ('306', '2017-08-03 16:32:09', null, 'nulladd', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('307', '2017-08-03 16:32:09', null, 'nullget', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('308', '2017-08-03 16:32:09', null, 'nullnext', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('309', '2017-08-03 16:32:09', null, 'nullprev', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('310', '2017-08-03 16:32:09', null, 'nulllist', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('311', '2017-08-03 16:32:09', null, 'nullsave', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('312', '2017-08-03 16:32:09', null, 'nulldelete', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('313', '2017-08-03 16:32:09', null, 'nullenabled', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('314', '2017-08-03 16:32:09', null, 'nullsingle', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('315', '2017-08-03 16:32:09', null, 'nullmenuData', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('316', '2017-08-03 16:32:10', null, 'nullaccordions', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('317', '2017-08-03 16:32:10', null, 'nullsysmenus', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('318', '2017-08-03 16:32:10', null, 'nulldisabled', null, '1895', '0');
INSERT INTO `ts_classinfo` VALUES ('319', '2017-08-03 16:32:10', null, 'nulladd', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('320', '2017-08-03 16:32:10', null, 'nullget', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('321', '2017-08-03 16:32:10', null, 'nullnext', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('322', '2017-08-03 16:32:10', null, 'nullprev', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('323', '2017-08-03 16:32:10', null, 'nulllist', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('324', '2017-08-03 16:32:10', null, 'nullsave', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('325', '2017-08-03 16:32:10', null, 'nulldelete', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('326', '2017-08-03 16:32:10', null, 'nullenabled', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('327', '2017-08-03 16:32:10', null, 'nullbatchsave', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('328', '2017-08-03 16:32:10', null, 'nulldisabled', null, '1896', '0');
INSERT INTO `ts_classinfo` VALUES ('329', '2017-08-03 16:32:10', null, 'nulladd', null, '1897', '0');
INSERT INTO `ts_classinfo` VALUES ('330', '2017-08-03 16:32:10', null, 'nullnext', null, '1897', '0');
INSERT INTO `ts_classinfo` VALUES ('331', '2017-08-03 16:32:10', null, 'nullprev', null, '1897', '0');
INSERT INTO `ts_classinfo` VALUES ('332', '2017-08-03 16:32:10', null, 'nulllist', null, '1897', '0');
INSERT INTO `ts_classinfo` VALUES ('333', '2017-08-03 16:32:10', null, 'nullsave', null, '1897', '0');
INSERT INTO `ts_classinfo` VALUES ('334', '2017-08-03 16:32:10', null, 'nulldelete', null, '1897', '0');
INSERT INTO `ts_classinfo` VALUES ('335', '2017-08-03 16:32:10', null, 'nullenabled', null, '1897', '0');
INSERT INTO `ts_classinfo` VALUES ('336', '2017-08-03 16:32:10', null, 'nullenabled', null, '1897', '0');
INSERT INTO `ts_classinfo` VALUES ('337', '2017-08-03 16:32:10', null, 'nulldisabled', null, '1897', '0');
INSERT INTO `ts_classinfo` VALUES ('338', '2017-08-03 16:32:10', null, 'nulladd', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('339', '2017-08-03 16:32:10', null, 'nullget', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('340', '2017-08-03 16:32:10', null, 'nullnext', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('341', '2017-08-03 16:32:10', null, 'nullprev', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('342', '2017-08-03 16:32:10', null, 'nulllist', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('343', '2017-08-03 16:32:10', null, 'nullsave', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('344', '2017-08-03 16:32:10', null, 'nulldelete', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('345', '2017-08-03 16:32:10', null, 'nullenabled', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('346', '2017-08-03 16:32:10', null, 'nullenabled', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('347', '2017-08-03 16:32:10', null, 'nulldisabled', null, '1898', '0');
INSERT INTO `ts_classinfo` VALUES ('348', '2017-08-03 16:32:11', null, 'nulladd', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('349', '2017-08-03 16:32:11', null, 'nullget', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('350', '2017-08-03 16:32:11', null, 'nullnext', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('351', '2017-08-03 16:32:11', null, 'nullprev', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('352', '2017-08-03 16:32:11', null, 'nulllist', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('353', '2017-08-03 16:32:11', null, 'nullsave', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('354', '2017-08-03 16:32:11', null, 'nulldelete', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('355', '2017-08-03 16:32:11', null, 'nullenabled', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('356', '2017-08-03 16:32:11', null, 'nullenabled', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('357', '2017-08-03 16:32:11', null, 'nulldisabled', null, '1899', '0');
INSERT INTO `ts_classinfo` VALUES ('358', '2017-08-03 16:32:11', null, 'nulladd', null, '1900', '0');
INSERT INTO `ts_classinfo` VALUES ('359', '2017-08-03 16:32:11', null, 'nullget', null, '1900', '0');
INSERT INTO `ts_classinfo` VALUES ('360', '2017-08-03 16:32:11', null, 'nulllist', null, '1900', '0');
INSERT INTO `ts_classinfo` VALUES ('361', '2017-08-03 16:32:11', null, 'nullsave', null, '1900', '0');
INSERT INTO `ts_classinfo` VALUES ('362', '2017-08-03 16:32:11', null, 'nulldelete', null, '1900', '0');
INSERT INTO `ts_classinfo` VALUES ('363', '2017-08-03 16:32:11', null, 'nullenabled', null, '1900', '0');
INSERT INTO `ts_classinfo` VALUES ('364', '2017-08-03 16:32:11', null, 'nulldisabled', null, '1900', '0');
INSERT INTO `ts_classinfo` VALUES ('365', '2017-08-03 16:32:11', null, 'nulladd', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('366', '2017-08-03 16:32:11', null, 'nullget', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('367', '2017-08-03 16:32:11', null, 'nullnext', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('368', '2017-08-03 16:32:11', null, 'nullprev', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('369', '2017-08-03 16:32:11', null, 'nulllist', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('370', '2017-08-03 16:32:11', null, 'nullsave', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('371', '2017-08-03 16:32:11', null, 'nulldelete', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('372', '2017-08-03 16:32:11', null, 'nullenabled', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('373', '2017-08-03 16:32:11', null, 'nullenabled', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('374', '2017-08-03 16:32:11', null, 'nullisdefault', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('375', '2017-08-03 16:32:11', null, 'nulldisabled', null, '1901', '0');
INSERT INTO `ts_classinfo` VALUES ('376', '2017-08-03 16:32:11', null, 'nulladd', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('377', '2017-08-03 16:32:12', null, 'nullget', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('378', '2017-08-03 16:32:12', null, 'nullnext', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('379', '2017-08-03 16:32:12', null, 'nullprev', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('380', '2017-08-03 16:32:12', null, 'nulllist', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('381', '2017-08-03 16:32:12', null, 'nullsave', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('382', '2017-08-03 16:32:12', null, 'nulldelete', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('383', '2017-08-03 16:32:12', null, 'nullenabled', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('384', '2017-08-03 16:32:12', null, 'nullenabled', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('385', '2017-08-03 16:32:12', null, 'nullisdefault', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('386', '2017-08-03 16:32:12', null, 'nulldisabled', null, '1902', '0');
INSERT INTO `ts_classinfo` VALUES ('387', '2017-08-03 16:32:12', null, 'nulladd', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('388', '2017-08-03 16:32:12', null, 'nullget', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('389', '2017-08-03 16:32:12', null, 'nullnext', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('390', '2017-08-03 16:32:12', null, 'nullprev', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('391', '2017-08-03 16:32:12', null, 'nulllist', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('392', '2017-08-03 16:32:12', null, 'nullsave', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('393', '2017-08-03 16:32:12', null, 'nulldelete', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('394', '2017-08-03 16:32:12', null, 'nullenabled', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('395', '2017-08-03 16:32:12', null, 'nullenabled', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('396', '2017-08-03 16:32:12', null, 'nulldisabled', null, '1903', '0');
INSERT INTO `ts_classinfo` VALUES ('397', '2017-08-03 16:32:12', null, 'nulladd', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('398', '2017-08-03 16:32:12', null, 'nullget', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('399', '2017-08-03 16:32:12', null, 'nullnext', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('400', '2017-08-03 16:32:12', null, 'nullprev', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('401', '2017-08-03 16:32:12', null, 'nulllist', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('402', '2017-08-03 16:32:12', null, 'nullsave', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('403', '2017-08-03 16:32:12', null, 'nulldelete', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('404', '2017-08-03 16:32:12', null, 'nullenabled', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('405', '2017-08-03 16:32:12', null, 'nullsavefile', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('406', '2017-08-03 16:32:12', null, 'nulldisabled', null, '1904', '0');
INSERT INTO `ts_classinfo` VALUES ('407', '2017-08-03 16:32:12', null, 'nulladd', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('408', '2017-08-03 16:32:12', null, 'nullget', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('409', '2017-08-03 16:32:12', null, 'nullnext', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('410', '2017-08-03 16:32:12', null, 'nullprev', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('411', '2017-08-03 16:32:12', null, 'nulllist', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('412', '2017-08-03 16:32:12', null, 'nullsave', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('413', '2017-08-03 16:32:13', null, 'nulldelete', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('414', '2017-08-03 16:32:13', null, 'nullenabled', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('415', '2017-08-03 16:32:13', null, 'nullenabled', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('416', '2017-08-03 16:32:13', null, 'nullcancel', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('417', '2017-08-03 16:32:13', null, 'nulldisabled', null, '1905', '0');
INSERT INTO `ts_classinfo` VALUES ('418', '2017-08-03 16:32:13', null, 'nulladd', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('419', '2017-08-03 16:32:13', null, 'nullget', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('420', '2017-08-03 16:32:13', null, 'nullnext', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('421', '2017-08-03 16:32:13', null, 'nullprev', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('422', '2017-08-03 16:32:13', null, 'nulllist', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('423', '2017-08-03 16:32:13', null, 'nullsave', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('424', '2017-08-03 16:32:13', null, 'nullcopy', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('425', '2017-08-03 16:32:13', null, 'nulldelete', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('426', '2017-08-03 16:32:13', null, 'nullenabled', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('427', '2017-08-03 16:32:13', null, 'nullenabled', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('428', '2017-08-03 16:32:13', null, 'nullruList', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('429', '2017-08-03 16:32:13', null, 'nulldisabled', null, '1906', '0');
INSERT INTO `ts_classinfo` VALUES ('430', '2017-08-03 16:32:13', null, 'nulladd', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('431', '2017-08-03 16:32:13', null, 'nullget', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('432', '2017-08-03 16:32:13', null, 'nullnext', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('433', '2017-08-03 16:32:13', null, 'nullprev', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('434', '2017-08-03 16:32:13', null, 'nulllist', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('435', '2017-08-03 16:32:13', null, 'nullsave', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('436', '2017-08-03 16:32:13', null, 'nulldelete', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('437', '2017-08-03 16:32:13', null, 'nullenabled', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('438', '2017-08-03 16:32:13', null, 'nullenabled', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('439', '2017-08-03 16:32:13', null, 'nulldisabled', null, '1907', '0');
INSERT INTO `ts_classinfo` VALUES ('440', '2017-08-03 16:32:13', null, 'nulladd', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('441', '2017-08-03 16:32:13', null, 'nullget', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('442', '2017-08-03 16:32:13', null, 'nullnext', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('443', '2017-08-03 16:32:13', null, 'nullprev', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('444', '2017-08-03 16:32:13', null, 'nulllist', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('445', '2017-08-03 16:32:13', null, 'nullsave', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('446', '2017-08-03 16:32:13', null, 'nulldelete', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('447', '2017-08-03 16:32:13', null, 'nullisEnabled', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('448', '2017-08-03 16:32:13', null, 'nullgetParamsName', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('449', '2017-08-03 16:32:14', null, 'nullgetInitDatas', null, '1908', '0');
INSERT INTO `ts_classinfo` VALUES ('450', '2017-08-03 16:32:14', null, 'nulladd', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('451', '2017-08-03 16:32:14', null, 'nullget', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('452', '2017-08-03 16:32:14', null, 'nullnext', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('453', '2017-08-03 16:32:14', null, 'nullprev', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('454', '2017-08-03 16:32:14', null, 'nulllist', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('455', '2017-08-03 16:32:14', null, 'nullsave', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('456', '2017-08-03 16:32:14', null, 'nulldelete', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('457', '2017-08-03 16:32:14', null, 'nullenabled', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('458', '2017-08-03 16:32:14', null, 'nullenabled', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('459', '2017-08-03 16:32:14', null, 'nulldisabled', null, '1909', '0');
INSERT INTO `ts_classinfo` VALUES ('460', '2017-08-03 16:32:14', null, 'nulladd', null, '1910', '0');
INSERT INTO `ts_classinfo` VALUES ('461', '2017-08-03 16:32:14', null, 'nullget', null, '1910', '0');
INSERT INTO `ts_classinfo` VALUES ('462', '2017-08-03 16:32:14', null, 'nullnext', null, '1910', '0');
INSERT INTO `ts_classinfo` VALUES ('463', '2017-08-03 16:32:14', null, 'nullprev', null, '1910', '0');
INSERT INTO `ts_classinfo` VALUES ('464', '2017-08-03 16:32:14', null, 'nullsave', null, '1910', '0');
INSERT INTO `ts_classinfo` VALUES ('465', '2017-08-03 16:32:14', null, 'nulldelete', null, '1910', '0');
INSERT INTO `ts_classinfo` VALUES ('466', '2017-08-03 16:32:14', null, 'nullenabled', null, '1910', '0');
INSERT INTO `ts_classinfo` VALUES ('467', '2017-08-03 16:32:14', null, 'nulldesklist', null, '1910', '0');
INSERT INTO `ts_classinfo` VALUES ('468', '2017-08-03 16:32:14', null, 'nulldisabled', null, '1910', '0');
INSERT INTO `ts_classinfo` VALUES ('469', '2017-08-03 16:32:14', null, 'nulladd', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('470', '2017-08-03 16:32:14', null, 'nullget', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('471', '2017-08-03 16:32:14', null, 'nullnext', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('472', '2017-08-03 16:32:14', null, 'nullprev', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('473', '2017-08-03 16:32:14', null, 'nulllist', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('474', '2017-08-03 16:32:14', null, 'nullsave', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('475', '2017-08-03 16:32:14', null, 'nulldelete', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('476', '2017-08-03 16:32:14', null, 'nullenabled', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('477', '2017-08-03 16:32:14', null, 'nullenabled', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('478', '2017-08-03 16:32:14', null, 'nulldisabled', null, '1911', '0');
INSERT INTO `ts_classinfo` VALUES ('479', '2017-08-03 16:32:14', null, 'nulladd', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('480', '2017-08-03 16:32:14', null, 'nullget', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('481', '2017-08-03 16:32:14', null, 'nullnext', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('482', '2017-08-03 16:32:14', null, 'nullprev', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('483', '2017-08-03 16:32:14', null, 'nulllist', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('484', '2017-08-03 16:32:15', null, 'nullsave', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('485', '2017-08-03 16:32:15', null, 'nulldelete', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('486', '2017-08-03 16:32:15', null, 'nullenabled', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('487', '2017-08-03 16:32:15', null, 'nullenabled', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('488', '2017-08-03 16:32:15', null, 'nulldisabled', null, '1912', '0');
INSERT INTO `ts_classinfo` VALUES ('489', '2017-08-03 16:32:15', null, 'nulllist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('490', '2017-08-03 16:32:15', null, 'nullsavefile', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('491', '2017-08-03 16:32:15', null, 'nullformlist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('492', '2017-08-03 16:32:15', null, 'nullroleright', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('493', '2017-08-03 16:32:15', null, 'nullorglist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('494', '2017-08-03 16:32:15', null, 'nullpostlist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('495', '2017-08-03 16:32:15', null, 'nullcustorglist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('496', '2017-08-03 16:32:15', null, 'nullrolelist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('497', '2017-08-03 16:32:15', null, 'nullreslist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('498', '2017-08-03 16:32:15', null, 'nullfdlist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('499', '2017-08-03 16:32:15', null, 'nullfmulalist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('500', '2017-08-03 16:32:15', null, 'nullarealist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('501', '2017-08-03 16:32:15', null, 'nulluseRolelist', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('502', '2017-08-03 16:32:15', null, 'nullmatTempList', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('503', '2017-08-03 16:32:15', null, 'nullimgFolider', null, '1913', '0');
INSERT INTO `ts_classinfo` VALUES ('504', '2017-08-03 16:32:15', null, 'nulladd', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('505', '2017-08-03 16:32:15', null, 'nullget', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('506', '2017-08-03 16:32:15', null, 'nullnext', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('507', '2017-08-03 16:32:15', null, 'nullprev', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('508', '2017-08-03 16:32:15', null, 'nulllist', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('509', '2017-08-03 16:32:15', null, 'nullsave', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('510', '2017-08-03 16:32:15', null, 'nulldelete', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('511', '2017-08-03 16:32:15', null, 'nullrole', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('512', '2017-08-03 16:32:15', null, 'nullenabled', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('513', '2017-08-03 16:32:15', null, 'nulldisabled', null, '1914', '0');
INSERT INTO `ts_classinfo` VALUES ('514', '2017-08-03 16:32:15', null, 'nulladd', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('515', '2017-08-03 16:32:15', null, 'nullget', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('516', '2017-08-03 16:32:15', null, 'nullnext', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('517', '2017-08-03 16:32:15', null, 'nullprev', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('518', '2017-08-03 16:32:15', null, 'nulllist', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('519', '2017-08-03 16:32:16', null, 'nullsave', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('520', '2017-08-03 16:32:16', null, 'nulldelete', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('521', '2017-08-03 16:32:16', null, 'nulllogin', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('522', '2017-08-03 16:32:16', null, 'nulllogout', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('523', '2017-08-03 16:32:16', null, 'nullenabled', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('524', '2017-08-03 16:32:16', null, 'nullenabled', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('525', '2017-08-03 16:32:16', null, 'nullcbodatas', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('526', '2017-08-03 16:32:16', null, 'nullsavePassWord', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('527', '2017-08-03 16:32:16', null, 'nulleditPassWord', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('528', '2017-08-03 16:32:16', null, 'nullgetLeaders', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('529', '2017-08-03 16:32:16', null, 'nullcashierlist', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('530', '2017-08-03 16:32:16', null, 'nullchangePost', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('531', '2017-08-03 16:32:16', null, 'nullgotoLogin', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('532', '2017-08-03 16:32:16', null, 'nullregotoLogin', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('533', '2017-08-03 16:32:16', null, 'nulldisabled', null, '1915', '0');
INSERT INTO `ts_classinfo` VALUES ('534', '2017-08-03 16:32:16', null, 'nullget', null, '1916', '0');
INSERT INTO `ts_classinfo` VALUES ('535', '2017-08-03 16:32:16', null, 'nulllist', null, '1916', '0');
INSERT INTO `ts_classinfo` VALUES ('536', '2017-08-03 16:32:16', null, 'nulldelete', null, '1916', '0');
INSERT INTO `ts_classinfo` VALUES ('537', '2017-08-03 16:32:16', null, 'nullenabled', null, '1916', '0');
INSERT INTO `ts_classinfo` VALUES ('538', '2017-08-03 16:32:16', null, 'nullgetContents', null, '1916', '0');
INSERT INTO `ts_classinfo` VALUES ('539', '2017-08-03 16:32:16', null, 'nullgetDatas', null, '1916', '0');
INSERT INTO `ts_classinfo` VALUES ('540', '2017-08-03 16:32:16', null, 'nulladd', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('541', '2017-08-03 16:32:16', null, 'nullget', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('542', '2017-08-03 16:32:16', null, 'nullnext', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('543', '2017-08-03 16:32:16', null, 'nullprev', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('544', '2017-08-03 16:32:16', null, 'nulllist', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('545', '2017-08-03 16:32:16', null, 'nullsave', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('546', '2017-08-03 16:32:16', null, 'nulldelete', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('547', '2017-08-03 16:32:16', null, 'nullenabled', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('548', '2017-08-03 16:32:16', null, 'nullenabled', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('549', '2017-08-03 16:32:16', null, 'nullcbolist', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('550', '2017-08-03 16:32:16', null, 'nullenablelist', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('551', '2017-08-03 16:32:16', null, 'nulldisabled', null, '1917', '0');
INSERT INTO `ts_classinfo` VALUES ('552', '2017-08-03 17:41:03', null, 'nulladd', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('553', '2017-08-03 17:41:03', null, 'nullget', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('554', '2017-08-03 17:41:03', null, 'nulllist', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('555', '2017-08-03 17:41:03', null, 'nullsave', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('556', '2017-08-03 17:41:03', null, 'nulldelete', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('557', '2017-08-03 17:41:03', null, 'nullisEnabled', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('558', '2017-08-03 17:41:03', null, 'nullenabled', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('559', '2017-08-03 17:41:03', null, 'nullenabled', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('560', '2017-08-03 17:41:03', null, 'nullnavigate', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('561', '2017-08-03 17:41:03', null, 'nullnavData', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('562', '2017-08-03 17:41:03', null, 'nulldisabled', null, '2249', '0');
INSERT INTO `ts_classinfo` VALUES ('563', '2017-08-03 17:41:03', null, 'nulladd', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('564', '2017-08-03 17:41:03', null, 'nullget', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('565', '2017-08-03 17:41:03', null, 'nullnext', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('566', '2017-08-03 17:41:03', null, 'nullprev', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('567', '2017-08-03 17:41:03', null, 'nulllist', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('568', '2017-08-03 17:41:03', null, 'nullsave', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('569', '2017-08-03 17:41:03', null, 'nulldelete', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('570', '2017-08-03 17:41:03', null, 'nullupdate', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('571', '2017-08-03 17:41:03', null, 'nullitems', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('572', '2017-08-03 17:41:03', null, 'nullenabled', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('573', '2017-08-03 17:41:03', null, 'nullenabled', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('574', '2017-08-03 17:41:03', null, 'nulldownload', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('575', '2017-08-03 17:41:03', null, 'nulllistMat', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('576', '2017-08-03 17:41:03', null, 'nullsetTop', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('577', '2017-08-03 17:41:04', null, 'nulldisabled', null, '2250', '0');
INSERT INTO `ts_classinfo` VALUES ('578', '2017-08-03 17:41:04', null, 'nulladd', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('579', '2017-08-03 17:41:04', null, 'nullget', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('580', '2017-08-03 17:41:04', null, 'nullnext', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('581', '2017-08-03 17:41:04', null, 'nullprev', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('582', '2017-08-03 17:41:04', null, 'nulllist', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('583', '2017-08-03 17:41:04', null, 'nullsave', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('584', '2017-08-03 17:41:04', null, 'nulldelete', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('585', '2017-08-03 17:41:04', null, 'nullenabled', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('586', '2017-08-03 17:41:04', null, 'nullenabled', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('587', '2017-08-03 17:41:04', null, 'nullgetEbackInfo', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('588', '2017-08-03 17:41:04', null, 'nullgetEndInfo', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('589', '2017-08-03 17:41:04', null, 'nulldisabled', null, '2251', '0');
INSERT INTO `ts_classinfo` VALUES ('590', '2017-08-03 17:41:04', null, 'nulladd', null, '2252', '0');
INSERT INTO `ts_classinfo` VALUES ('591', '2017-08-03 17:41:04', null, 'nullget', null, '2252', '0');
INSERT INTO `ts_classinfo` VALUES ('592', '2017-08-03 17:41:04', null, 'nullnext', null, '2252', '0');
INSERT INTO `ts_classinfo` VALUES ('593', '2017-08-03 17:41:04', null, 'nullprev', null, '2252', '0');
INSERT INTO `ts_classinfo` VALUES ('594', '2017-08-03 17:41:04', null, 'nulllist', null, '2252', '0');
INSERT INTO `ts_classinfo` VALUES ('595', '2017-08-03 17:41:04', null, 'nullsave', null, '2252', '0');
INSERT INTO `ts_classinfo` VALUES ('596', '2017-08-03 17:41:04', null, 'nulldelete', null, '2252', '0');
INSERT INTO `ts_classinfo` VALUES ('597', '2017-08-03 17:41:04', null, 'nulladd', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('598', '2017-08-03 17:41:04', null, 'nullget', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('599', '2017-08-03 17:41:04', null, 'nullnext', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('600', '2017-08-03 17:41:04', null, 'nullprev', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('601', '2017-08-03 17:41:04', null, 'nulllist', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('602', '2017-08-03 17:41:04', null, 'nullsave', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('603', '2017-08-03 17:41:04', null, 'nulldelete', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('604', '2017-08-03 17:41:04', null, 'nullenabled', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('605', '2017-08-03 17:41:04', null, 'nullenabled', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('606', '2017-08-03 17:41:04', null, 'nullgetExePostion', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('607', '2017-08-03 17:41:04', null, 'nullprocessImage', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('608', '2017-08-03 17:41:04', null, 'nullgetPostion', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('609', '2017-08-03 17:41:04', null, 'nullsaveCfgs', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('610', '2017-08-03 17:41:04', null, 'nulldisabled', null, '2253', '0');
INSERT INTO `ts_classinfo` VALUES ('611', '2017-08-03 17:41:04', null, 'nulladd', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('612', '2017-08-03 17:41:04', null, 'nullget', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('613', '2017-08-03 17:41:04', null, 'nullnext', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('614', '2017-08-03 17:41:04', null, 'nullprev', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('615', '2017-08-03 17:41:04', null, 'nulllist', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('616', '2017-08-03 17:41:05', null, 'nullsave', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('617', '2017-08-03 17:41:05', null, 'nulldelete', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('618', '2017-08-03 17:41:05', null, 'nullenabled', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('619', '2017-08-03 17:41:05', null, 'nullenabled', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('620', '2017-08-03 17:41:05', null, 'nulldelClause', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('621', '2017-08-03 17:41:05', null, 'nullgetClause', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('622', '2017-08-03 17:41:05', null, 'nullsaveClause', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('623', '2017-08-03 17:41:05', null, 'nullgetClauseList', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('624', '2017-08-03 17:41:05', null, 'nulldisabled', null, '2254', '0');
INSERT INTO `ts_classinfo` VALUES ('625', '2017-08-03 17:41:05', null, 'nullstart', null, '2255', '0');
INSERT INTO `ts_classinfo` VALUES ('626', '2017-08-03 17:41:05', null, 'nullgetTask', null, '2255', '0');
INSERT INTO `ts_classinfo` VALUES ('627', '2017-08-03 17:41:05', null, 'nullsubmit', null, '2255', '0');
INSERT INTO `ts_classinfo` VALUES ('628', '2017-08-03 17:41:05', null, 'nulladd', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('629', '2017-08-03 17:41:05', null, 'nullget', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('630', '2017-08-03 17:41:05', null, 'nullnext', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('631', '2017-08-03 17:41:05', null, 'nullprev', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('632', '2017-08-03 17:41:05', null, 'nulllist', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('633', '2017-08-03 17:41:05', null, 'nullsave', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('634', '2017-08-03 17:41:05', null, 'nulldelete', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('635', '2017-08-03 17:41:05', null, 'nullenabled', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('636', '2017-08-03 17:41:05', null, 'nullenabled', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('637', '2017-08-03 17:41:05', null, 'nulldisabled', null, '2256', '0');
INSERT INTO `ts_classinfo` VALUES ('638', '2017-08-03 17:41:05', null, 'nulladd', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('639', '2017-08-03 17:41:05', null, 'nullget', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('640', '2017-08-03 17:41:05', null, 'nullnext', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('641', '2017-08-03 17:41:05', null, 'nullprev', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('642', '2017-08-03 17:41:05', null, 'nulllist', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('643', '2017-08-03 17:41:05', null, 'nullsave', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('644', '2017-08-03 17:41:05', null, 'nulldelete', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('645', '2017-08-03 17:41:05', null, 'nullenabled', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('646', '2017-08-03 17:41:05', null, 'nullenabled', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('647', '2017-08-03 17:41:05', null, 'nullisdefault', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('648', '2017-08-03 17:41:05', null, 'nulldisabled', null, '2257', '0');
INSERT INTO `ts_classinfo` VALUES ('649', '2017-08-03 17:41:05', null, 'nulladd', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('650', '2017-08-03 17:41:05', null, 'nullget', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('651', '2017-08-03 17:41:05', null, 'nullnext', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('652', '2017-08-03 17:41:06', null, 'nullprev', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('653', '2017-08-03 17:41:06', null, 'nulllist', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('654', '2017-08-03 17:41:06', null, 'nullsave', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('655', '2017-08-03 17:41:06', null, 'nulldelete', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('656', '2017-08-03 17:41:06', null, 'nullenabled', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('657', '2017-08-03 17:41:06', null, 'nullenabled', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('658', '2017-08-03 17:41:06', null, 'nulldisabled', null, '2258', '0');
INSERT INTO `ts_classinfo` VALUES ('659', '2017-08-03 17:41:06', null, 'nulladd', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('660', '2017-08-03 17:41:06', null, 'nullget', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('661', '2017-08-03 17:41:06', null, 'nullnext', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('662', '2017-08-03 17:41:06', null, 'nullprev', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('663', '2017-08-03 17:41:06', null, 'nulllist', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('664', '2017-08-03 17:41:06', null, 'nullsave', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('665', '2017-08-03 17:41:06', null, 'nulldelete', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('666', '2017-08-03 17:41:06', null, 'nullenabled', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('667', '2017-08-03 17:41:06', null, 'nullenabled', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('668', '2017-08-03 17:41:06', null, 'nulldisabled', null, '2259', '0');
INSERT INTO `ts_classinfo` VALUES ('669', '2017-08-03 17:41:06', null, 'nulladd', null, '2260', '0');
INSERT INTO `ts_classinfo` VALUES ('670', '2017-08-03 17:41:06', null, 'nullget', null, '2260', '0');
INSERT INTO `ts_classinfo` VALUES ('671', '2017-08-03 17:41:06', null, 'nullnext', null, '2260', '0');
INSERT INTO `ts_classinfo` VALUES ('672', '2017-08-03 17:41:06', null, 'nullprev', null, '2260', '0');
INSERT INTO `ts_classinfo` VALUES ('673', '2017-08-03 17:41:06', null, 'nulllist', null, '2260', '0');
INSERT INTO `ts_classinfo` VALUES ('674', '2017-08-03 17:41:06', null, 'nullsave', null, '2260', '0');
INSERT INTO `ts_classinfo` VALUES ('675', '2017-08-03 17:41:06', null, 'nulldelete', null, '2260', '0');
INSERT INTO `ts_classinfo` VALUES ('676', '2017-08-03 17:41:06', null, 'nullenabled', null, '2260', '0');
INSERT INTO `ts_classinfo` VALUES ('677', '2017-08-03 17:41:06', null, 'nulldisabled', null, '2260', '0');
INSERT INTO `ts_classinfo` VALUES ('678', '2017-08-03 17:41:06', null, 'nulladd', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('679', '2017-08-03 17:41:06', null, 'nullget', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('680', '2017-08-03 17:41:06', null, 'nullnext', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('681', '2017-08-03 17:41:06', null, 'nullprev', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('682', '2017-08-03 17:41:06', null, 'nulllist', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('683', '2017-08-03 17:41:06', null, 'nullsave', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('684', '2017-08-03 17:41:06', null, 'nulldelete', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('685', '2017-08-03 17:41:06', null, 'nullenabled', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('686', '2017-08-03 17:41:06', null, 'nullenabled', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('687', '2017-08-03 17:41:06', null, 'nulldisabled', null, '2261', '0');
INSERT INTO `ts_classinfo` VALUES ('688', '2017-08-03 17:41:06', null, 'nulladd', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('689', '2017-08-03 17:41:06', null, 'nullget', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('690', '2017-08-03 17:41:06', null, 'nullnext', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('691', '2017-08-03 17:41:06', null, 'nullprev', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('692', '2017-08-03 17:41:06', null, 'nulllist', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('693', '2017-08-03 17:41:06', null, 'nullsave', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('694', '2017-08-03 17:41:07', null, 'nulldelete', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('695', '2017-08-03 17:41:07', null, 'nullenabled', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('696', '2017-08-03 17:41:07', null, 'nullenabled', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('697', '2017-08-03 17:41:07', null, 'nulldisabled', null, '2262', '0');
INSERT INTO `ts_classinfo` VALUES ('698', '2017-08-03 17:41:07', null, 'nulladd', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('699', '2017-08-03 17:41:07', null, 'nullget', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('700', '2017-08-03 17:41:07', null, 'nullnext', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('701', '2017-08-03 17:41:07', null, 'nullprev', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('702', '2017-08-03 17:41:07', null, 'nulllist', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('703', '2017-08-03 17:41:07', null, 'nullsave', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('704', '2017-08-03 17:41:07', null, 'nulldelete', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('705', '2017-08-03 17:41:07', null, 'nullenabled', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('706', '2017-08-03 17:41:07', null, 'nullenabled', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('707', '2017-08-03 17:41:07', null, 'nullisdefault', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('708', '2017-08-03 17:41:07', null, 'nulldisabled', null, '2263', '0');
INSERT INTO `ts_classinfo` VALUES ('709', '2017-08-03 17:41:07', null, 'nulladd', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('710', '2017-08-03 17:41:07', null, 'nullget', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('711', '2017-08-03 17:41:07', null, 'nullnext', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('712', '2017-08-03 17:41:07', null, 'nullprev', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('713', '2017-08-03 17:41:07', null, 'nulllist', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('714', '2017-08-03 17:41:07', null, 'nullsave', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('715', '2017-08-03 17:41:07', null, 'nulldelete', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('716', '2017-08-03 17:41:07', null, 'nullenabled', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('717', '2017-08-03 17:41:07', null, 'nullenabled', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('718', '2017-08-03 17:41:07', null, 'nulldisabled', null, '2264', '0');
INSERT INTO `ts_classinfo` VALUES ('719', '2017-08-03 17:41:07', null, 'nulladd', null, '2265', '0');
INSERT INTO `ts_classinfo` VALUES ('720', '2017-08-03 17:41:07', null, 'nullget', null, '2265', '0');
INSERT INTO `ts_classinfo` VALUES ('721', '2017-08-03 17:41:07', null, 'nullnext', null, '2265', '0');
INSERT INTO `ts_classinfo` VALUES ('722', '2017-08-03 17:41:07', null, 'nullprev', null, '2265', '0');
INSERT INTO `ts_classinfo` VALUES ('723', '2017-08-03 17:41:07', null, 'nulllist', null, '2265', '0');
INSERT INTO `ts_classinfo` VALUES ('724', '2017-08-03 17:41:07', null, 'nullsave', null, '2265', '0');
INSERT INTO `ts_classinfo` VALUES ('725', '2017-08-03 17:41:08', null, 'nulldelete', null, '2265', '0');
INSERT INTO `ts_classinfo` VALUES ('726', '2017-08-03 17:41:08', null, 'nullenabled', null, '2265', '0');
INSERT INTO `ts_classinfo` VALUES ('727', '2017-08-03 17:41:08', null, 'nulldisabled', null, '2265', '0');
INSERT INTO `ts_classinfo` VALUES ('728', '2017-08-03 17:41:08', null, 'nulladd', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('729', '2017-08-03 17:41:08', null, 'nullget', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('730', '2017-08-03 17:41:08', null, 'nullnext', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('731', '2017-08-03 17:41:08', null, 'nullprev', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('732', '2017-08-03 17:41:08', null, 'nulllist', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('733', '2017-08-03 17:41:08', null, 'nullsave', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('734', '2017-08-03 17:41:08', null, 'nulldelete', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('735', '2017-08-03 17:41:08', null, 'nullenabled', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('736', '2017-08-03 17:41:08', null, 'nullenabled', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('737', '2017-08-03 17:41:08', null, 'nulldisabled', null, '2266', '0');
INSERT INTO `ts_classinfo` VALUES ('738', '2017-08-03 17:41:08', null, 'nulladd', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('739', '2017-08-03 17:41:08', null, 'nullget', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('740', '2017-08-03 17:41:08', null, 'nullnext', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('741', '2017-08-03 17:41:08', null, 'nullprev', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('742', '2017-08-03 17:41:08', null, 'nulllist', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('743', '2017-08-03 17:41:08', null, 'nullsave', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('744', '2017-08-03 17:41:08', null, 'nulldelete', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('745', '2017-08-03 17:41:08', null, 'nullenabled', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('746', '2017-08-03 17:41:08', null, 'nullenabled', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('747', '2017-08-03 17:41:08', null, 'nulldisabled', null, '2267', '0');
INSERT INTO `ts_classinfo` VALUES ('748', '2017-08-03 17:41:08', null, 'nulladd', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('749', '2017-08-03 17:41:08', null, 'nullget', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('750', '2017-08-03 17:41:08', null, 'nullnext', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('751', '2017-08-03 17:41:08', null, 'nullprev', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('752', '2017-08-03 17:41:08', null, 'nulllist', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('753', '2017-08-03 17:41:08', null, 'nullsave', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('754', '2017-08-03 17:41:08', null, 'nulldelete', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('755', '2017-08-03 17:41:08', null, 'nullenabled', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('756', '2017-08-03 17:41:08', null, 'nullenabled', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('757', '2017-08-03 17:41:08', null, 'nulldisabled', null, '2268', '0');
INSERT INTO `ts_classinfo` VALUES ('758', '2017-08-03 17:41:08', null, 'nulladd', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('759', '2017-08-03 17:41:08', null, 'nullget', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('760', '2017-08-03 17:41:08', null, 'nullnext', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('761', '2017-08-03 17:41:08', null, 'nullprev', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('762', '2017-08-03 17:41:08', null, 'nulllist', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('763', '2017-08-03 17:41:08', null, 'nullsave', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('764', '2017-08-03 17:41:09', null, 'nulldelete', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('765', '2017-08-03 17:41:09', null, 'nullenabled', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('766', '2017-08-03 17:41:09', null, 'nullenabled', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('767', '2017-08-03 17:41:09', null, 'nulldisabled', null, '2269', '0');
INSERT INTO `ts_classinfo` VALUES ('768', '2017-08-03 17:41:09', null, 'nulladd', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('769', '2017-08-03 17:41:09', null, 'nullget', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('770', '2017-08-03 17:41:09', null, 'nullnext', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('771', '2017-08-03 17:41:09', null, 'nullprev', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('772', '2017-08-03 17:41:09', null, 'nulllist', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('773', '2017-08-03 17:41:09', null, 'nullsave', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('774', '2017-08-03 17:41:09', null, 'nulldelete', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('775', '2017-08-03 17:41:09', null, 'nullenabled', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('776', '2017-08-03 17:41:09', null, 'nullenabled', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('777', '2017-08-03 17:41:09', null, 'nulldisabled', null, '2270', '0');
INSERT INTO `ts_classinfo` VALUES ('778', '2017-08-03 17:41:09', null, 'nulladd', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('779', '2017-08-03 17:41:09', null, 'nullget', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('780', '2017-08-03 17:41:09', null, 'nullnext', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('781', '2017-08-03 17:41:09', null, 'nullprev', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('782', '2017-08-03 17:41:09', null, 'nulllist', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('783', '2017-08-03 17:41:09', null, 'nullsave', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('784', '2017-08-03 17:41:09', null, 'nulldelete', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('785', '2017-08-03 17:41:09', null, 'nullenabled', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('786', '2017-08-03 17:41:09', null, 'nullenabled', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('787', '2017-08-03 17:41:09', null, 'nullsavefile', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('788', '2017-08-03 17:41:09', null, 'nulldisabled', null, '2271', '0');
INSERT INTO `ts_classinfo` VALUES ('789', '2017-08-03 17:41:09', null, 'nulladd', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('790', '2017-08-03 17:41:09', null, 'nullget', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('791', '2017-08-03 17:41:09', null, 'nullnext', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('792', '2017-08-03 17:41:09', null, 'nullprev', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('793', '2017-08-03 17:41:09', null, 'nulllist', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('794', '2017-08-03 17:41:09', null, 'nullsave', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('795', '2017-08-03 17:41:09', null, 'nulldelete', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('796', '2017-08-03 17:41:09', null, 'nullenabled', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('797', '2017-08-03 17:41:09', null, 'nullenabled', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('798', '2017-08-03 17:41:09', null, 'nulldisabled', null, '2272', '0');
INSERT INTO `ts_classinfo` VALUES ('799', '2017-08-03 17:41:09', null, 'nulladd', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('800', '2017-08-03 17:41:09', null, 'nullget', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('801', '2017-08-03 17:41:09', null, 'nullnext', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('802', '2017-08-03 17:41:09', null, 'nullprev', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('803', '2017-08-03 17:41:09', null, 'nulllist', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('804', '2017-08-03 17:41:09', null, 'nullsave', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('805', '2017-08-03 17:41:09', null, 'nulldelete', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('806', '2017-08-03 17:41:10', null, 'nullenabled', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('807', '2017-08-03 17:41:10', null, 'nullenabled', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('808', '2017-08-03 17:41:10', null, 'nullcbodatas', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('809', '2017-08-03 17:41:10', null, 'nulldisabled', null, '2273', '0');
INSERT INTO `ts_classinfo` VALUES ('810', '2017-08-03 17:41:10', null, 'nulladd', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('811', '2017-08-03 17:41:10', null, 'nullget', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('812', '2017-08-03 17:41:10', null, 'nullnext', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('813', '2017-08-03 17:41:10', null, 'nullprev', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('814', '2017-08-03 17:41:10', null, 'nulllist', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('815', '2017-08-03 17:41:10', null, 'nullsave', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('816', '2017-08-03 17:41:10', null, 'nulldelete', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('817', '2017-08-03 17:41:10', null, 'nullenabled', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('818', '2017-08-03 17:41:10', null, 'nullenabled', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('819', '2017-08-03 17:41:10', null, 'nullcal', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('820', '2017-08-03 17:41:10', null, 'nullattscs', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('821', '2017-08-03 17:41:10', null, 'nulldisabled', null, '2274', '0');
INSERT INTO `ts_classinfo` VALUES ('822', '2017-08-03 17:41:10', null, 'nullsave', null, '2275', '0');
INSERT INTO `ts_classinfo` VALUES ('823', '2017-08-03 17:41:10', null, 'nulladd', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('824', '2017-08-03 17:41:10', null, 'nullget', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('825', '2017-08-03 17:41:10', null, 'nullnext', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('826', '2017-08-03 17:41:10', null, 'nullprev', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('827', '2017-08-03 17:41:10', null, 'nulllist', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('828', '2017-08-03 17:41:10', null, 'nullsave', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('829', '2017-08-03 17:41:10', null, 'nulldelete', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('830', '2017-08-03 17:41:10', null, 'nullenabled', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('831', '2017-08-03 17:41:10', null, 'nullenabled', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('832', '2017-08-03 17:41:10', null, 'nullrebuild', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('833', '2017-08-03 17:41:10', null, 'nulldisabled', null, '2276', '0');
INSERT INTO `ts_classinfo` VALUES ('834', '2017-08-03 17:41:10', null, 'nulladd', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('835', '2017-08-03 17:41:10', null, 'nullget', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('836', '2017-08-03 17:41:10', null, 'nullnext', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('837', '2017-08-03 17:41:10', null, 'nullprev', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('838', '2017-08-03 17:41:10', null, 'nulllist', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('839', '2017-08-03 17:41:10', null, 'nullsave', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('840', '2017-08-03 17:41:10', null, 'nulldelete', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('841', '2017-08-03 17:41:10', null, 'nullenabled', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('842', '2017-08-03 17:41:10', null, 'nullenabled', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('843', '2017-08-03 17:41:10', null, 'nulldisabled', null, '2277', '0');
INSERT INTO `ts_classinfo` VALUES ('844', '2017-08-03 17:41:10', null, 'nulladd', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('845', '2017-08-03 17:41:10', null, 'nullget', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('846', '2017-08-03 17:41:10', null, 'nullnext', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('847', '2017-08-03 17:41:11', null, 'nullprev', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('848', '2017-08-03 17:41:11', null, 'nulllist', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('849', '2017-08-03 17:41:11', null, 'nullsave', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('850', '2017-08-03 17:41:11', null, 'nullcopy', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('851', '2017-08-03 17:41:11', null, 'nulldelete', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('852', '2017-08-03 17:41:11', null, 'nullenabled', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('853', '2017-08-03 17:41:11', null, 'nullenabled', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('854', '2017-08-03 17:41:11', null, 'nullgetMat', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('855', '2017-08-03 17:41:11', null, 'nullgetTemp', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('856', '2017-08-03 17:41:11', null, 'nulldisabled', null, '2278', '0');
INSERT INTO `ts_classinfo` VALUES ('857', '2017-08-03 17:41:11', null, 'nulladd', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('858', '2017-08-03 17:41:11', null, 'nullget', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('859', '2017-08-03 17:41:11', null, 'nullnext', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('860', '2017-08-03 17:41:11', null, 'nullprev', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('861', '2017-08-03 17:41:11', null, 'nulllist', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('862', '2017-08-03 17:41:11', null, 'nullsave', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('863', '2017-08-03 17:41:11', null, 'nulldelete', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('864', '2017-08-03 17:41:11', null, 'nullenabled', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('865', '2017-08-03 17:41:11', null, 'nullsingle', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('866', '2017-08-03 17:41:11', null, 'nullmenuData', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('867', '2017-08-03 17:41:11', null, 'nullaccordions', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('868', '2017-08-03 17:41:11', null, 'nullsysmenus', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('869', '2017-08-03 17:41:11', null, 'nulldisabled', null, '2279', '0');
INSERT INTO `ts_classinfo` VALUES ('870', '2017-08-03 17:41:11', null, 'nulladd', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('871', '2017-08-03 17:41:11', null, 'nullget', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('872', '2017-08-03 17:41:11', null, 'nullnext', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('873', '2017-08-03 17:41:11', null, 'nullprev', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('874', '2017-08-03 17:41:11', null, 'nulllist', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('875', '2017-08-03 17:41:11', null, 'nullsave', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('876', '2017-08-03 17:41:11', null, 'nulldelete', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('877', '2017-08-03 17:41:11', null, 'nullenabled', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('878', '2017-08-03 17:41:11', null, 'nullbatchsave', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('879', '2017-08-03 17:41:11', null, 'nulldisabled', null, '2280', '0');
INSERT INTO `ts_classinfo` VALUES ('880', '2017-08-03 17:41:11', null, 'nulladd', null, '2281', '0');
INSERT INTO `ts_classinfo` VALUES ('881', '2017-08-03 17:41:11', null, 'nullnext', null, '2281', '0');
INSERT INTO `ts_classinfo` VALUES ('882', '2017-08-03 17:41:11', null, 'nullprev', null, '2281', '0');
INSERT INTO `ts_classinfo` VALUES ('883', '2017-08-03 17:41:11', null, 'nulllist', null, '2281', '0');
INSERT INTO `ts_classinfo` VALUES ('884', '2017-08-03 17:41:11', null, 'nullsave', null, '2281', '0');
INSERT INTO `ts_classinfo` VALUES ('885', '2017-08-03 17:41:11', null, 'nulldelete', null, '2281', '0');
INSERT INTO `ts_classinfo` VALUES ('886', '2017-08-03 17:41:11', null, 'nullenabled', null, '2281', '0');
INSERT INTO `ts_classinfo` VALUES ('887', '2017-08-03 17:41:11', null, 'nullenabled', null, '2281', '0');
INSERT INTO `ts_classinfo` VALUES ('888', '2017-08-03 17:41:11', null, 'nulldisabled', null, '2281', '0');
INSERT INTO `ts_classinfo` VALUES ('889', '2017-08-03 17:41:12', null, 'nulladd', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('890', '2017-08-03 17:41:12', null, 'nullget', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('891', '2017-08-03 17:41:12', null, 'nullnext', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('892', '2017-08-03 17:41:12', null, 'nullprev', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('893', '2017-08-03 17:41:12', null, 'nulllist', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('894', '2017-08-03 17:41:12', null, 'nullsave', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('895', '2017-08-03 17:41:12', null, 'nulldelete', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('896', '2017-08-03 17:41:12', null, 'nullenabled', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('897', '2017-08-03 17:41:12', null, 'nullenabled', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('898', '2017-08-03 17:41:12', null, 'nulldisabled', null, '2282', '0');
INSERT INTO `ts_classinfo` VALUES ('899', '2017-08-03 17:41:12', null, 'nulladd', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('900', '2017-08-03 17:41:12', null, 'nullget', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('901', '2017-08-03 17:41:12', null, 'nullnext', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('902', '2017-08-03 17:41:12', null, 'nullprev', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('903', '2017-08-03 17:41:12', null, 'nulllist', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('904', '2017-08-03 17:41:12', null, 'nullsave', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('905', '2017-08-03 17:41:12', null, 'nulldelete', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('906', '2017-08-03 17:41:12', null, 'nullenabled', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('907', '2017-08-03 17:41:12', null, 'nullenabled', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('908', '2017-08-03 17:41:12', null, 'nulldisabled', null, '2283', '0');
INSERT INTO `ts_classinfo` VALUES ('909', '2017-08-03 17:41:12', null, 'nulladd', null, '2284', '0');
INSERT INTO `ts_classinfo` VALUES ('910', '2017-08-03 17:41:12', null, 'nullget', null, '2284', '0');
INSERT INTO `ts_classinfo` VALUES ('911', '2017-08-03 17:41:12', null, 'nulllist', null, '2284', '0');
INSERT INTO `ts_classinfo` VALUES ('912', '2017-08-03 17:41:12', null, 'nullsave', null, '2284', '0');
INSERT INTO `ts_classinfo` VALUES ('913', '2017-08-03 17:41:12', null, 'nulldelete', null, '2284', '0');
INSERT INTO `ts_classinfo` VALUES ('914', '2017-08-03 17:41:12', null, 'nullenabled', null, '2284', '0');
INSERT INTO `ts_classinfo` VALUES ('915', '2017-08-03 17:41:12', null, 'nulldisabled', null, '2284', '0');
INSERT INTO `ts_classinfo` VALUES ('916', '2017-08-03 17:41:12', null, 'nulladd', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('917', '2017-08-03 17:41:12', null, 'nullget', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('918', '2017-08-03 17:41:12', null, 'nullnext', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('919', '2017-08-03 17:41:12', null, 'nullprev', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('920', '2017-08-03 17:41:12', null, 'nulllist', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('921', '2017-08-03 17:41:12', null, 'nullsave', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('922', '2017-08-03 17:41:12', null, 'nulldelete', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('923', '2017-08-03 17:41:12', null, 'nullenabled', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('924', '2017-08-03 17:41:12', null, 'nullenabled', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('925', '2017-08-03 17:41:12', null, 'nullisdefault', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('926', '2017-08-03 17:41:12', null, 'nulldisabled', null, '2285', '0');
INSERT INTO `ts_classinfo` VALUES ('927', '2017-08-03 17:41:12', null, 'nulladd', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('928', '2017-08-03 17:41:12', null, 'nullget', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('929', '2017-08-03 17:41:12', null, 'nullnext', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('930', '2017-08-03 17:41:13', null, 'nullprev', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('931', '2017-08-03 17:41:13', null, 'nulllist', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('932', '2017-08-03 17:41:13', null, 'nullsave', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('933', '2017-08-03 17:41:13', null, 'nulldelete', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('934', '2017-08-03 17:41:13', null, 'nullenabled', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('935', '2017-08-03 17:41:13', null, 'nullenabled', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('936', '2017-08-03 17:41:13', null, 'nullisdefault', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('937', '2017-08-03 17:41:13', null, 'nulldisabled', null, '2286', '0');
INSERT INTO `ts_classinfo` VALUES ('938', '2017-08-03 17:41:13', null, 'nulladd', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('939', '2017-08-03 17:41:13', null, 'nullget', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('940', '2017-08-03 17:41:13', null, 'nullnext', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('941', '2017-08-03 17:41:13', null, 'nullprev', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('942', '2017-08-03 17:41:13', null, 'nulllist', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('943', '2017-08-03 17:41:13', null, 'nullsave', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('944', '2017-08-03 17:41:13', null, 'nulldelete', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('945', '2017-08-03 17:41:13', null, 'nullenabled', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('946', '2017-08-03 17:41:13', null, 'nullenabled', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('947', '2017-08-03 17:41:13', null, 'nulldisabled', null, '2287', '0');
INSERT INTO `ts_classinfo` VALUES ('948', '2017-08-03 17:41:13', null, 'nulladd', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('949', '2017-08-03 17:41:13', null, 'nullget', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('950', '2017-08-03 17:41:13', null, 'nullnext', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('951', '2017-08-03 17:41:13', null, 'nullprev', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('952', '2017-08-03 17:41:13', null, 'nulllist', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('953', '2017-08-03 17:41:13', null, 'nullsave', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('954', '2017-08-03 17:41:13', null, 'nulldelete', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('955', '2017-08-03 17:41:13', null, 'nullenabled', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('956', '2017-08-03 17:41:13', null, 'nullsavefile', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('957', '2017-08-03 17:41:13', null, 'nulldisabled', null, '2288', '0');
INSERT INTO `ts_classinfo` VALUES ('958', '2017-08-03 17:41:13', null, 'nulladd', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('959', '2017-08-03 17:41:13', null, 'nullget', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('960', '2017-08-03 17:41:13', null, 'nullnext', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('961', '2017-08-03 17:41:13', null, 'nullprev', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('962', '2017-08-03 17:41:13', null, 'nulllist', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('963', '2017-08-03 17:41:13', null, 'nullsave', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('964', '2017-08-03 17:41:13', null, 'nulldelete', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('965', '2017-08-03 17:41:13', null, 'nullenabled', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('966', '2017-08-03 17:41:13', null, 'nullenabled', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('967', '2017-08-03 17:41:13', null, 'nullcancel', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('968', '2017-08-03 17:41:13', null, 'nulldisabled', null, '2289', '0');
INSERT INTO `ts_classinfo` VALUES ('969', '2017-08-03 17:41:13', null, 'nulladd', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('970', '2017-08-03 17:41:13', null, 'nullget', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('971', '2017-08-03 17:41:14', null, 'nullnext', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('972', '2017-08-03 17:41:14', null, 'nullprev', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('973', '2017-08-03 17:41:14', null, 'nulllist', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('974', '2017-08-03 17:41:14', null, 'nullsave', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('975', '2017-08-03 17:41:14', null, 'nullcopy', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('976', '2017-08-03 17:41:14', null, 'nulldelete', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('977', '2017-08-03 17:41:14', null, 'nullenabled', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('978', '2017-08-03 17:41:14', null, 'nullenabled', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('979', '2017-08-03 17:41:14', null, 'nullruList', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('980', '2017-08-03 17:41:14', null, 'nulldisabled', null, '2290', '0');
INSERT INTO `ts_classinfo` VALUES ('981', '2017-08-03 17:41:14', null, 'nulladd', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('982', '2017-08-03 17:41:14', null, 'nullget', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('983', '2017-08-03 17:41:14', null, 'nullnext', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('984', '2017-08-03 17:41:14', null, 'nullprev', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('985', '2017-08-03 17:41:14', null, 'nulllist', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('986', '2017-08-03 17:41:14', null, 'nullsave', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('987', '2017-08-03 17:41:14', null, 'nulldelete', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('988', '2017-08-03 17:41:14', null, 'nullenabled', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('989', '2017-08-03 17:41:14', null, 'nullenabled', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('990', '2017-08-03 17:41:14', null, 'nulldisabled', null, '2291', '0');
INSERT INTO `ts_classinfo` VALUES ('991', '2017-08-03 17:41:14', null, 'nulladd', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('992', '2017-08-03 17:41:14', null, 'nullget', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('993', '2017-08-03 17:41:14', null, 'nullnext', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('994', '2017-08-03 17:41:14', null, 'nullprev', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('995', '2017-08-03 17:41:14', null, 'nulllist', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('996', '2017-08-03 17:41:14', null, 'nullsave', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('997', '2017-08-03 17:41:14', null, 'nulldelete', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('998', '2017-08-03 17:41:14', null, 'nullisEnabled', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('999', '2017-08-03 17:41:14', null, 'nullgetParamsName', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('1000', '2017-08-03 17:41:14', null, 'nullgetInitDatas', null, '2292', '0');
INSERT INTO `ts_classinfo` VALUES ('1001', '2017-08-03 17:41:14', null, 'nulladd', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1002', '2017-08-03 17:41:14', null, 'nullget', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1003', '2017-08-03 17:41:14', null, 'nullnext', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1004', '2017-08-03 17:41:14', null, 'nullprev', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1005', '2017-08-03 17:41:14', null, 'nulllist', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1006', '2017-08-03 17:41:14', null, 'nullsave', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1007', '2017-08-03 17:41:14', null, 'nulldelete', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1008', '2017-08-03 17:41:14', null, 'nullenabled', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1009', '2017-08-03 17:41:14', null, 'nullenabled', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1010', '2017-08-03 17:41:14', null, 'nulldisabled', null, '2293', '0');
INSERT INTO `ts_classinfo` VALUES ('1011', '2017-08-03 17:41:14', null, 'nulladd', null, '2294', '0');
INSERT INTO `ts_classinfo` VALUES ('1012', '2017-08-03 17:41:15', null, 'nullget', null, '2294', '0');
INSERT INTO `ts_classinfo` VALUES ('1013', '2017-08-03 17:41:15', null, 'nullnext', null, '2294', '0');
INSERT INTO `ts_classinfo` VALUES ('1014', '2017-08-03 17:41:15', null, 'nullprev', null, '2294', '0');
INSERT INTO `ts_classinfo` VALUES ('1015', '2017-08-03 17:41:15', null, 'nullsave', null, '2294', '0');
INSERT INTO `ts_classinfo` VALUES ('1016', '2017-08-03 17:41:15', null, 'nulldelete', null, '2294', '0');
INSERT INTO `ts_classinfo` VALUES ('1017', '2017-08-03 17:41:15', null, 'nullenabled', null, '2294', '0');
INSERT INTO `ts_classinfo` VALUES ('1018', '2017-08-03 17:41:15', null, 'nulldesklist', null, '2294', '0');
INSERT INTO `ts_classinfo` VALUES ('1019', '2017-08-03 17:41:15', null, 'nulldisabled', null, '2294', '0');
INSERT INTO `ts_classinfo` VALUES ('1020', '2017-08-03 17:41:15', null, 'nulladd', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1021', '2017-08-03 17:41:15', null, 'nullget', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1022', '2017-08-03 17:41:15', null, 'nullnext', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1023', '2017-08-03 17:41:15', null, 'nullprev', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1024', '2017-08-03 17:41:15', null, 'nulllist', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1025', '2017-08-03 17:41:15', null, 'nullsave', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1026', '2017-08-03 17:41:15', null, 'nulldelete', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1027', '2017-08-03 17:41:15', null, 'nullenabled', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1028', '2017-08-03 17:41:15', null, 'nullenabled', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1029', '2017-08-03 17:41:15', null, 'nulldisabled', null, '2295', '0');
INSERT INTO `ts_classinfo` VALUES ('1030', '2017-08-03 17:41:15', null, 'nulladd', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1031', '2017-08-03 17:41:15', null, 'nullget', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1032', '2017-08-03 17:41:15', null, 'nullnext', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1033', '2017-08-03 17:41:15', null, 'nullprev', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1034', '2017-08-03 17:41:15', null, 'nulllist', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1035', '2017-08-03 17:41:15', null, 'nullsave', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1036', '2017-08-03 17:41:15', null, 'nulldelete', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1037', '2017-08-03 17:41:15', null, 'nullenabled', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1038', '2017-08-03 17:41:15', null, 'nullenabled', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1039', '2017-08-03 17:41:15', null, 'nulldisabled', null, '2296', '0');
INSERT INTO `ts_classinfo` VALUES ('1040', '2017-08-03 17:41:15', null, 'nulllist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1041', '2017-08-03 17:41:15', null, 'nullsavefile', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1042', '2017-08-03 17:41:15', null, 'nullformlist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1043', '2017-08-03 17:41:15', null, 'nullroleright', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1044', '2017-08-03 17:41:15', null, 'nullorglist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1045', '2017-08-03 17:41:15', null, 'nullpostlist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1046', '2017-08-03 17:41:15', null, 'nullcustorglist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1047', '2017-08-03 17:41:15', null, 'nullrolelist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1048', '2017-08-03 17:41:15', null, 'nullreslist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1049', '2017-08-03 17:41:15', null, 'nullfdlist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1050', '2017-08-03 17:41:15', null, 'nullfmulalist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1051', '2017-08-03 17:41:16', null, 'nullarealist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1052', '2017-08-03 17:41:16', null, 'nulluseRolelist', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1053', '2017-08-03 17:41:16', null, 'nullmatTempList', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1054', '2017-08-03 17:41:16', null, 'nullimgFolider', null, '2297', '0');
INSERT INTO `ts_classinfo` VALUES ('1055', '2017-08-03 17:41:16', null, 'nulladd', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1056', '2017-08-03 17:41:16', null, 'nullget', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1057', '2017-08-03 17:41:16', null, 'nullnext', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1058', '2017-08-03 17:41:16', null, 'nullprev', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1059', '2017-08-03 17:41:16', null, 'nulllist', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1060', '2017-08-03 17:41:16', null, 'nullsave', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1061', '2017-08-03 17:41:16', null, 'nulldelete', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1062', '2017-08-03 17:41:16', null, 'nullrole', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1063', '2017-08-03 17:41:16', null, 'nullenabled', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1064', '2017-08-03 17:41:16', null, 'nulldisabled', null, '2298', '0');
INSERT INTO `ts_classinfo` VALUES ('1065', '2017-08-03 17:41:16', null, 'nulladd', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1066', '2017-08-03 17:41:16', null, 'nullget', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1067', '2017-08-03 17:41:16', null, 'nullnext', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1068', '2017-08-03 17:41:16', null, 'nullprev', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1069', '2017-08-03 17:41:16', null, 'nulllist', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1070', '2017-08-03 17:41:16', null, 'nullsave', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1071', '2017-08-03 17:41:16', null, 'nulldelete', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1072', '2017-08-03 17:41:16', null, 'nulllogin', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1073', '2017-08-03 17:41:16', null, 'nulllogout', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1074', '2017-08-03 17:41:16', null, 'nullenabled', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1075', '2017-08-03 17:41:16', null, 'nullenabled', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1076', '2017-08-03 17:41:16', null, 'nullcbodatas', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1077', '2017-08-03 17:41:16', null, 'nullsavePassWord', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1078', '2017-08-03 17:41:16', null, 'nulleditPassWord', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1079', '2017-08-03 17:41:16', null, 'nullgetLeaders', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1080', '2017-08-03 17:41:16', null, 'nullcashierlist', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1081', '2017-08-03 17:41:16', null, 'nullchangePost', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1082', '2017-08-03 17:41:16', null, 'nullgotoLogin', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1083', '2017-08-03 17:41:16', null, 'nullregotoLogin', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1084', '2017-08-03 17:41:16', null, 'nulldisabled', null, '2299', '0');
INSERT INTO `ts_classinfo` VALUES ('1085', '2017-08-03 17:41:16', null, 'nullget', null, '2300', '0');
INSERT INTO `ts_classinfo` VALUES ('1086', '2017-08-03 17:41:16', null, 'nulllist', null, '2300', '0');
INSERT INTO `ts_classinfo` VALUES ('1087', '2017-08-03 17:41:16', null, 'nulldelete', null, '2300', '0');
INSERT INTO `ts_classinfo` VALUES ('1088', '2017-08-03 17:41:16', null, 'nullenabled', null, '2300', '0');
INSERT INTO `ts_classinfo` VALUES ('1089', '2017-08-03 17:41:16', null, 'nullgetContents', null, '2300', '0');
INSERT INTO `ts_classinfo` VALUES ('1090', '2017-08-03 17:41:16', null, 'nullgetDatas', null, '2300', '0');
INSERT INTO `ts_classinfo` VALUES ('1091', '2017-08-03 17:41:16', null, 'nulladd', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1092', '2017-08-03 17:41:17', null, 'nullget', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1093', '2017-08-03 17:41:17', null, 'nullnext', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1094', '2017-08-03 17:41:17', null, 'nullprev', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1095', '2017-08-03 17:41:17', null, 'nulllist', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1096', '2017-08-03 17:41:17', null, 'nullsave', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1097', '2017-08-03 17:41:17', null, 'nulldelete', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1098', '2017-08-03 17:41:17', null, 'nullenabled', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1099', '2017-08-03 17:41:17', null, 'nullenabled', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1100', '2017-08-03 17:41:17', null, 'nullcbolist', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1101', '2017-08-03 17:41:17', null, 'nullenablelist', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1102', '2017-08-03 17:41:17', null, 'nulldisabled', null, '2301', '0');
INSERT INTO `ts_classinfo` VALUES ('1103', '2017-08-25 22:24:49', null, 'nullget', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1104', '2017-08-25 22:24:49', null, 'nulladd', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1105', '2017-08-25 22:24:49', null, 'nullnext', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1106', '2017-08-25 22:24:49', null, 'nulllist', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1107', '2017-08-25 22:24:49', null, 'nullsave', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1108', '2017-08-25 22:24:49', null, 'nullprev', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1109', '2017-08-25 22:24:49', null, 'nulldelete', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1110', '2017-08-25 22:24:49', null, 'nullenabled', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1111', '2017-08-25 22:24:49', null, 'nullenabled', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1112', '2017-08-25 22:24:49', null, 'nulldisabled', null, '2762', '0');
INSERT INTO `ts_classinfo` VALUES ('1113', '2017-08-25 22:24:49', null, 'nullget', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1114', '2017-08-25 22:24:50', null, 'nulladd', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1115', '2017-08-25 22:24:50', null, 'nulllist', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1116', '2017-08-25 22:24:50', null, 'nullsave', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1117', '2017-08-25 22:24:50', null, 'nulldelete', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1118', '2017-08-25 22:24:50', null, 'nullisEnabled', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1119', '2017-08-25 22:24:50', null, 'nullnavigate', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1120', '2017-08-25 22:24:50', null, 'nullnavData', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1121', '2017-08-25 22:24:50', null, 'nullenabled', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1122', '2017-08-25 22:24:50', null, 'nullenabled', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1123', '2017-08-25 22:24:50', null, 'nulldisabled', null, '2763', '0');
INSERT INTO `ts_classinfo` VALUES ('1124', '2017-08-25 22:24:50', null, 'nullget', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1125', '2017-08-25 22:24:50', null, 'nulladd', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1126', '2017-08-25 22:24:50', null, 'nullnext', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1127', '2017-08-25 22:24:50', null, 'nulllist', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1128', '2017-08-25 22:24:50', null, 'nullsave', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1129', '2017-08-25 22:24:50', null, 'nullprev', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1130', '2017-08-25 22:24:50', null, 'nulldelete', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1131', '2017-08-25 22:24:50', null, 'nullupdate', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1132', '2017-08-25 22:24:50', null, 'nullitems', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1133', '2017-08-25 22:24:50', null, 'nulldownload', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1134', '2017-08-25 22:24:50', null, 'nulllistMat', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1135', '2017-08-25 22:24:50', null, 'nullenabled', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1136', '2017-08-25 22:24:50', null, 'nullenabled', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1137', '2017-08-25 22:24:50', null, 'nullsetTop', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1138', '2017-08-25 22:24:50', null, 'nulldisabled', null, '2764', '0');
INSERT INTO `ts_classinfo` VALUES ('1139', '2017-08-25 22:24:51', null, 'nullget', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1140', '2017-08-25 22:24:51', null, 'nulladd', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1141', '2017-08-25 22:24:51', null, 'nullnext', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1142', '2017-08-25 22:24:51', null, 'nulllist', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1143', '2017-08-25 22:24:51', null, 'nullsave', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1144', '2017-08-25 22:24:51', null, 'nullprev', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1145', '2017-08-25 22:24:51', null, 'nulldelete', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1146', '2017-08-25 22:24:51', null, 'nullgetEbackInfo', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1147', '2017-08-25 22:24:51', null, 'nullgetEndInfo', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1148', '2017-08-25 22:24:51', null, 'nullenabled', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1149', '2017-08-25 22:24:51', null, 'nullenabled', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1150', '2017-08-25 22:24:51', null, 'nulldisabled', null, '2765', '0');
INSERT INTO `ts_classinfo` VALUES ('1151', '2017-08-25 22:24:51', null, 'nullget', null, '2766', '0');
INSERT INTO `ts_classinfo` VALUES ('1152', '2017-08-25 22:24:51', null, 'nulladd', null, '2766', '0');
INSERT INTO `ts_classinfo` VALUES ('1153', '2017-08-25 22:24:51', null, 'nullnext', null, '2766', '0');
INSERT INTO `ts_classinfo` VALUES ('1154', '2017-08-25 22:24:51', null, 'nulllist', null, '2766', '0');
INSERT INTO `ts_classinfo` VALUES ('1155', '2017-08-25 22:24:51', null, 'nullsave', null, '2766', '0');
INSERT INTO `ts_classinfo` VALUES ('1156', '2017-08-25 22:24:51', null, 'nullprev', null, '2766', '0');
INSERT INTO `ts_classinfo` VALUES ('1157', '2017-08-25 22:24:51', null, 'nulldelete', null, '2766', '0');
INSERT INTO `ts_classinfo` VALUES ('1158', '2017-08-25 22:24:51', null, 'nullget', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1159', '2017-08-25 22:24:51', null, 'nulladd', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1160', '2017-08-25 22:24:51', null, 'nullnext', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1161', '2017-08-25 22:24:51', null, 'nulllist', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1162', '2017-08-25 22:24:51', null, 'nullsave', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1163', '2017-08-25 22:24:51', null, 'nullprev', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1164', '2017-08-25 22:24:52', null, 'nulldelete', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1165', '2017-08-25 22:24:52', null, 'nullprocessImage', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1166', '2017-08-25 22:24:52', null, 'nullenabled', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1167', '2017-08-25 22:24:52', null, 'nullenabled', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1168', '2017-08-25 22:24:52', null, 'nullsaveCfgs', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1169', '2017-08-25 22:24:52', null, 'nullgetExePostion', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1170', '2017-08-25 22:24:52', null, 'nulldisabled', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1171', '2017-08-25 22:24:52', null, 'nullgetPostion', null, '2767', '0');
INSERT INTO `ts_classinfo` VALUES ('1172', '2017-08-25 22:24:52', null, 'nullget', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1173', '2017-08-25 22:24:52', null, 'nulladd', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1174', '2017-08-25 22:24:52', null, 'nullnext', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1175', '2017-08-25 22:24:52', null, 'nulllist', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1176', '2017-08-25 22:24:52', null, 'nullsave', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1177', '2017-08-25 22:24:52', null, 'nullprev', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1178', '2017-08-25 22:24:52', null, 'nulldelete', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1179', '2017-08-25 22:24:52', null, 'nullenabled', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1180', '2017-08-25 22:24:52', null, 'nullenabled', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1181', '2017-08-25 22:24:52', null, 'nulldelClause', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1182', '2017-08-25 22:24:52', null, 'nullsaveClause', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1183', '2017-08-25 22:24:53', null, 'nullgetClause', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1184', '2017-08-25 22:24:53', null, 'nulldisabled', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1185', '2017-08-25 22:24:53', null, 'nullgetClauseList', null, '2768', '0');
INSERT INTO `ts_classinfo` VALUES ('1186', '2017-08-25 22:24:53', null, 'nullstart', null, '2769', '0');
INSERT INTO `ts_classinfo` VALUES ('1187', '2017-08-25 22:24:53', null, 'nullsubmit', null, '2769', '0');
INSERT INTO `ts_classinfo` VALUES ('1188', '2017-08-25 22:24:53', null, 'nullgetTask', null, '2769', '0');
INSERT INTO `ts_classinfo` VALUES ('1189', '2017-08-25 22:24:53', null, 'nullget', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1190', '2017-08-25 22:24:53', null, 'nulladd', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1191', '2017-08-25 22:24:53', null, 'nullnext', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1192', '2017-08-25 22:24:53', null, 'nulllist', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1193', '2017-08-25 22:24:53', null, 'nullsave', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1194', '2017-08-25 22:24:53', null, 'nullprev', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1195', '2017-08-25 22:24:53', null, 'nulldelete', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1196', '2017-08-25 22:24:53', null, 'nullenabled', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1197', '2017-08-25 22:24:53', null, 'nullenabled', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1198', '2017-08-25 22:24:54', null, 'nulldisabled', null, '2770', '0');
INSERT INTO `ts_classinfo` VALUES ('1199', '2017-08-25 22:24:54', null, 'nullget', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1200', '2017-08-25 22:24:54', null, 'nulladd', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1201', '2017-08-25 22:24:54', null, 'nullnext', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1202', '2017-08-25 22:24:54', null, 'nulllist', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1203', '2017-08-25 22:24:54', null, 'nullsave', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1204', '2017-08-25 22:24:54', null, 'nullprev', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1205', '2017-08-25 22:24:54', null, 'nulldelete', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1206', '2017-08-25 22:24:54', null, 'nullenabled', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1207', '2017-08-25 22:24:54', null, 'nullenabled', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1208', '2017-08-25 22:24:54', null, 'nullisdefault', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1209', '2017-08-25 22:24:54', null, 'nulldisabled', null, '2771', '0');
INSERT INTO `ts_classinfo` VALUES ('1210', '2017-08-25 22:24:54', null, 'nullget', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1211', '2017-08-25 22:24:54', null, 'nulladd', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1212', '2017-08-25 22:24:54', null, 'nullnext', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1213', '2017-08-25 22:24:54', null, 'nulllist', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1214', '2017-08-25 22:24:54', null, 'nullsave', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1215', '2017-08-25 22:24:54', null, 'nullprev', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1216', '2017-08-25 22:24:54', null, 'nulldelete', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1217', '2017-08-25 22:24:54', null, 'nullenabled', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1218', '2017-08-25 22:24:54', null, 'nullenabled', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1219', '2017-08-25 22:24:54', null, 'nulldisabled', null, '2772', '0');
INSERT INTO `ts_classinfo` VALUES ('1220', '2017-08-25 22:24:55', null, 'nullget', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1221', '2017-08-25 22:24:55', null, 'nulladd', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1222', '2017-08-25 22:24:55', null, 'nullnext', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1223', '2017-08-25 22:24:55', null, 'nulllist', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1224', '2017-08-25 22:24:55', null, 'nullsave', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1225', '2017-08-25 22:24:55', null, 'nullprev', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1226', '2017-08-25 22:24:55', null, 'nulldelete', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1227', '2017-08-25 22:24:55', null, 'nullenabled', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1228', '2017-08-25 22:24:55', null, 'nullenabled', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1229', '2017-08-25 22:24:55', null, 'nulldisabled', null, '2773', '0');
INSERT INTO `ts_classinfo` VALUES ('1230', '2017-08-25 22:24:55', null, 'nullget', null, '2774', '0');
INSERT INTO `ts_classinfo` VALUES ('1231', '2017-08-25 22:24:55', null, 'nulladd', null, '2774', '0');
INSERT INTO `ts_classinfo` VALUES ('1232', '2017-08-25 22:24:55', null, 'nullnext', null, '2774', '0');
INSERT INTO `ts_classinfo` VALUES ('1233', '2017-08-25 22:24:55', null, 'nulllist', null, '2774', '0');
INSERT INTO `ts_classinfo` VALUES ('1234', '2017-08-25 22:24:55', null, 'nullsave', null, '2774', '0');
INSERT INTO `ts_classinfo` VALUES ('1235', '2017-08-25 22:24:55', null, 'nullprev', null, '2774', '0');
INSERT INTO `ts_classinfo` VALUES ('1236', '2017-08-25 22:24:55', null, 'nulldelete', null, '2774', '0');
INSERT INTO `ts_classinfo` VALUES ('1237', '2017-08-25 22:24:55', null, 'nullenabled', null, '2774', '0');
INSERT INTO `ts_classinfo` VALUES ('1238', '2017-08-25 22:24:55', null, 'nulldisabled', null, '2774', '0');
INSERT INTO `ts_classinfo` VALUES ('1239', '2017-08-25 22:24:55', null, 'nullget', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1240', '2017-08-25 22:24:55', null, 'nulladd', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1241', '2017-08-25 22:24:55', null, 'nullnext', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1242', '2017-08-25 22:24:55', null, 'nulllist', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1243', '2017-08-25 22:24:55', null, 'nullsave', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1244', '2017-08-25 22:24:56', null, 'nullprev', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1245', '2017-08-25 22:24:56', null, 'nulldelete', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1246', '2017-08-25 22:24:56', null, 'nullenabled', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1247', '2017-08-25 22:24:56', null, 'nullenabled', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1248', '2017-08-25 22:24:56', null, 'nulldisabled', null, '2775', '0');
INSERT INTO `ts_classinfo` VALUES ('1249', '2017-08-25 22:24:56', null, 'nullget', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1250', '2017-08-25 22:24:56', null, 'nulladd', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1251', '2017-08-25 22:24:56', null, 'nullnext', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1252', '2017-08-25 22:24:56', null, 'nulllist', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1253', '2017-08-25 22:24:56', null, 'nullsave', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1254', '2017-08-25 22:24:56', null, 'nullprev', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1255', '2017-08-25 22:24:56', null, 'nulldelete', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1256', '2017-08-25 22:24:56', null, 'nullenabled', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1257', '2017-08-25 22:24:56', null, 'nullenabled', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1258', '2017-08-25 22:24:56', null, 'nulldisabled', null, '2776', '0');
INSERT INTO `ts_classinfo` VALUES ('1259', '2017-08-25 22:24:56', null, 'nullget', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1260', '2017-08-25 22:24:56', null, 'nulladd', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1261', '2017-08-25 22:24:56', null, 'nullnext', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1262', '2017-08-25 22:24:56', null, 'nulllist', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1263', '2017-08-25 22:24:56', null, 'nullsave', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1264', '2017-08-25 22:24:56', null, 'nullprev', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1265', '2017-08-25 22:24:56', null, 'nulldelete', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1266', '2017-08-25 22:24:56', null, 'nullenabled', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1267', '2017-08-25 22:24:56', null, 'nullenabled', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1268', '2017-08-25 22:24:57', null, 'nullisdefault', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1269', '2017-08-25 22:24:57', null, 'nulldisabled', null, '2777', '0');
INSERT INTO `ts_classinfo` VALUES ('1270', '2017-08-25 22:24:57', null, 'nullget', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1271', '2017-08-25 22:24:57', null, 'nulladd', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1272', '2017-08-25 22:24:57', null, 'nullnext', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1273', '2017-08-25 22:24:57', null, 'nulllist', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1274', '2017-08-25 22:24:57', null, 'nullsave', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1275', '2017-08-25 22:24:57', null, 'nullprev', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1276', '2017-08-25 22:24:57', null, 'nulldelete', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1277', '2017-08-25 22:24:57', null, 'nullenabled', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1278', '2017-08-25 22:24:57', null, 'nullenabled', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1279', '2017-08-25 22:24:57', null, 'nulldisabled', null, '2778', '0');
INSERT INTO `ts_classinfo` VALUES ('1280', '2017-08-25 22:24:57', null, 'nullget', null, '2779', '0');
INSERT INTO `ts_classinfo` VALUES ('1281', '2017-08-25 22:24:57', null, 'nulladd', null, '2779', '0');
INSERT INTO `ts_classinfo` VALUES ('1282', '2017-08-25 22:24:57', null, 'nullnext', null, '2779', '0');
INSERT INTO `ts_classinfo` VALUES ('1283', '2017-08-25 22:24:57', null, 'nulllist', null, '2779', '0');
INSERT INTO `ts_classinfo` VALUES ('1284', '2017-08-25 22:24:57', null, 'nullsave', null, '2779', '0');
INSERT INTO `ts_classinfo` VALUES ('1285', '2017-08-25 22:24:57', null, 'nullprev', null, '2779', '0');
INSERT INTO `ts_classinfo` VALUES ('1286', '2017-08-25 22:24:57', null, 'nulldelete', null, '2779', '0');
INSERT INTO `ts_classinfo` VALUES ('1287', '2017-08-25 22:24:57', null, 'nullenabled', null, '2779', '0');
INSERT INTO `ts_classinfo` VALUES ('1288', '2017-08-25 22:24:57', null, 'nulldisabled', null, '2779', '0');
INSERT INTO `ts_classinfo` VALUES ('1289', '2017-08-25 22:24:57', null, 'nullget', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1290', '2017-08-25 22:24:57', null, 'nulladd', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1291', '2017-08-25 22:24:58', null, 'nullnext', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1292', '2017-08-25 22:24:58', null, 'nulllist', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1293', '2017-08-25 22:24:58', null, 'nullsave', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1294', '2017-08-25 22:24:58', null, 'nullprev', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1295', '2017-08-25 22:24:58', null, 'nulldelete', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1296', '2017-08-25 22:24:58', null, 'nullenabled', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1297', '2017-08-25 22:24:58', null, 'nullenabled', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1298', '2017-08-25 22:24:58', null, 'nulldisabled', null, '2780', '0');
INSERT INTO `ts_classinfo` VALUES ('1299', '2017-08-25 22:24:58', null, 'nullget', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1300', '2017-08-25 22:24:58', null, 'nulladd', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1301', '2017-08-25 22:24:58', null, 'nullnext', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1302', '2017-08-25 22:24:58', null, 'nulllist', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1303', '2017-08-25 22:24:58', null, 'nullsave', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1304', '2017-08-25 22:24:58', null, 'nullprev', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1305', '2017-08-25 22:24:58', null, 'nulldelete', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1306', '2017-08-25 22:24:58', null, 'nullenabled', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1307', '2017-08-25 22:24:58', null, 'nullenabled', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1308', '2017-08-25 22:24:58', null, 'nulldisabled', null, '2781', '0');
INSERT INTO `ts_classinfo` VALUES ('1309', '2017-08-25 22:24:58', null, 'nullget', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1310', '2017-08-25 22:24:58', null, 'nulladd', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1311', '2017-08-25 22:24:58', null, 'nullnext', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1312', '2017-08-25 22:24:58', null, 'nulllist', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1313', '2017-08-25 22:24:58', null, 'nullsave', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1314', '2017-08-25 22:24:58', null, 'nullprev', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1315', '2017-08-25 22:24:58', null, 'nulldelete', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1316', '2017-08-25 22:24:58', null, 'nullenabled', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1317', '2017-08-25 22:24:58', null, 'nullenabled', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1318', '2017-08-25 22:24:59', null, 'nulldisabled', null, '2782', '0');
INSERT INTO `ts_classinfo` VALUES ('1319', '2017-08-25 22:24:59', null, 'nullget', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1320', '2017-08-25 22:24:59', null, 'nulladd', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1321', '2017-08-25 22:24:59', null, 'nullnext', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1322', '2017-08-25 22:24:59', null, 'nulllist', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1323', '2017-08-25 22:24:59', null, 'nullsave', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1324', '2017-08-25 22:24:59', null, 'nullprev', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1325', '2017-08-25 22:24:59', null, 'nulldelete', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1326', '2017-08-25 22:24:59', null, 'nullenabled', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1327', '2017-08-25 22:24:59', null, 'nullenabled', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1328', '2017-08-25 22:24:59', null, 'nulldisabled', null, '2783', '0');
INSERT INTO `ts_classinfo` VALUES ('1329', '2017-08-25 22:24:59', null, 'nullget', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1330', '2017-08-25 22:24:59', null, 'nulladd', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1331', '2017-08-25 22:24:59', null, 'nullnext', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1332', '2017-08-25 22:24:59', null, 'nulllist', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1333', '2017-08-25 22:24:59', null, 'nullsave', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1334', '2017-08-25 22:24:59', null, 'nullprev', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1335', '2017-08-25 22:24:59', null, 'nulldelete', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1336', '2017-08-25 22:24:59', null, 'nullenabled', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1337', '2017-08-25 22:24:59', null, 'nullenabled', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1338', '2017-08-25 22:24:59', null, 'nulldisabled', null, '2784', '0');
INSERT INTO `ts_classinfo` VALUES ('1339', '2017-08-25 22:25:00', null, 'nullget', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1340', '2017-08-25 22:25:00', null, 'nulladd', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1341', '2017-08-25 22:25:00', null, 'nullnext', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1342', '2017-08-25 22:25:00', null, 'nulllist', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1343', '2017-08-25 22:25:00', null, 'nullsave', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1344', '2017-08-25 22:25:00', null, 'nullprev', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1345', '2017-08-25 22:25:00', null, 'nulldelete', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1346', '2017-08-25 22:25:00', null, 'nullenabled', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1347', '2017-08-25 22:25:00', null, 'nullenabled', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1348', '2017-08-25 22:25:00', null, 'nullsavefile', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1349', '2017-08-25 22:25:00', null, 'nulldisabled', null, '2785', '0');
INSERT INTO `ts_classinfo` VALUES ('1350', '2017-08-25 22:25:00', null, 'nullget', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1351', '2017-08-25 22:25:00', null, 'nulladd', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1352', '2017-08-25 22:25:00', null, 'nullnext', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1353', '2017-08-25 22:25:00', null, 'nulllist', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1354', '2017-08-25 22:25:00', null, 'nullsave', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1355', '2017-08-25 22:25:00', null, 'nullprev', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1356', '2017-08-25 22:25:00', null, 'nulldelete', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1357', '2017-08-25 22:25:00', null, 'nullenabled', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1358', '2017-08-25 22:25:00', null, 'nullenabled', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1359', '2017-08-25 22:25:00', null, 'nulldisabled', null, '2786', '0');
INSERT INTO `ts_classinfo` VALUES ('1360', '2017-08-25 22:25:00', null, 'nullget', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1361', '2017-08-25 22:25:00', null, 'nulladd', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1362', '2017-08-25 22:25:00', null, 'nullnext', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1363', '2017-08-25 22:25:00', null, 'nulllist', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1364', '2017-08-25 22:25:00', null, 'nullsave', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1365', '2017-08-25 22:25:00', null, 'nullprev', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1366', '2017-08-25 22:25:00', null, 'nulldelete', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1367', '2017-08-25 22:25:00', null, 'nullenabled', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1368', '2017-08-25 22:25:01', null, 'nullenabled', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1369', '2017-08-25 22:25:01', null, 'nullcbodatas', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1370', '2017-08-25 22:25:01', null, 'nulldisabled', null, '2787', '0');
INSERT INTO `ts_classinfo` VALUES ('1371', '2017-08-25 22:25:01', null, 'nullget', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1372', '2017-08-25 22:25:01', null, 'nulladd', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1373', '2017-08-25 22:25:01', null, 'nullnext', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1374', '2017-08-25 22:25:01', null, 'nulllist', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1375', '2017-08-25 22:25:01', null, 'nullsave', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1376', '2017-08-25 22:25:01', null, 'nullprev', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1377', '2017-08-25 22:25:01', null, 'nulldelete', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1378', '2017-08-25 22:25:01', null, 'nullenabled', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1379', '2017-08-25 22:25:01', null, 'nullenabled', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1380', '2017-08-25 22:25:01', null, 'nullattscs', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1381', '2017-08-25 22:25:01', null, 'nullcal', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1382', '2017-08-25 22:25:01', null, 'nulldisabled', null, '2788', '0');
INSERT INTO `ts_classinfo` VALUES ('1383', '2017-08-25 22:25:01', null, 'nullsave', null, '2789', '0');
INSERT INTO `ts_classinfo` VALUES ('1384', '2017-08-25 22:25:01', null, 'nullget', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1385', '2017-08-25 22:25:01', null, 'nulladd', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1386', '2017-08-25 22:25:01', null, 'nullnext', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1387', '2017-08-25 22:25:01', null, 'nulllist', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1388', '2017-08-25 22:25:01', null, 'nullsave', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1389', '2017-08-25 22:25:01', null, 'nullprev', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1390', '2017-08-25 22:25:01', null, 'nulldelete', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1391', '2017-08-25 22:25:01', null, 'nullenabled', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1392', '2017-08-25 22:25:02', null, 'nullenabled', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1393', '2017-08-25 22:25:02', null, 'nullrebuild', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1394', '2017-08-25 22:25:02', null, 'nulldisabled', null, '2790', '0');
INSERT INTO `ts_classinfo` VALUES ('1395', '2017-08-25 22:25:02', null, 'nullget', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1396', '2017-08-25 22:25:02', null, 'nulladd', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1397', '2017-08-25 22:25:02', null, 'nullnext', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1398', '2017-08-25 22:25:02', null, 'nulllist', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1399', '2017-08-25 22:25:02', null, 'nullsave', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1400', '2017-08-25 22:25:02', null, 'nullprev', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1401', '2017-08-25 22:25:02', null, 'nulldelete', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1402', '2017-08-25 22:25:02', null, 'nullenabled', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1403', '2017-08-25 22:25:02', null, 'nullenabled', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1404', '2017-08-25 22:25:02', null, 'nulldisabled', null, '2791', '0');
INSERT INTO `ts_classinfo` VALUES ('1405', '2017-08-25 22:25:02', null, 'nullget', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1406', '2017-08-25 22:25:02', null, 'nulladd', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1407', '2017-08-25 22:25:02', null, 'nullnext', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1408', '2017-08-25 22:25:02', null, 'nulllist', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1409', '2017-08-25 22:25:02', null, 'nullsave', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1410', '2017-08-25 22:25:02', null, 'nullprev', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1411', '2017-08-25 22:25:02', null, 'nullcopy', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1412', '2017-08-25 22:25:03', null, 'nulldelete', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1413', '2017-08-25 22:25:03', null, 'nullenabled', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1414', '2017-08-25 22:25:03', null, 'nullenabled', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1415', '2017-08-25 22:25:03', null, 'nullgetMat', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1416', '2017-08-25 22:25:03', null, 'nullgetTemp', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1417', '2017-08-25 22:25:03', null, 'nulldisabled', null, '2792', '0');
INSERT INTO `ts_classinfo` VALUES ('1418', '2017-08-25 22:25:03', null, 'nullget', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1419', '2017-08-25 22:25:03', null, 'nulladd', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1420', '2017-08-25 22:25:03', null, 'nullnext', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1421', '2017-08-25 22:25:03', null, 'nulllist', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1422', '2017-08-25 22:25:03', null, 'nullsave', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1423', '2017-08-25 22:25:03', null, 'nullprev', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1424', '2017-08-25 22:25:03', null, 'nulldelete', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1425', '2017-08-25 22:25:03', null, 'nullsingle', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1426', '2017-08-25 22:25:03', null, 'nullenabled', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1427', '2017-08-25 22:25:03', null, 'nullsysmenus', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1428', '2017-08-25 22:25:03', null, 'nullaccordions', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1429', '2017-08-25 22:25:03', null, 'nullmenuData', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1430', '2017-08-25 22:25:03', null, 'nulldisabled', null, '2793', '0');
INSERT INTO `ts_classinfo` VALUES ('1431', '2017-08-25 22:25:03', null, 'nullget', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1432', '2017-08-25 22:25:03', null, 'nulladd', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1433', '2017-08-25 22:25:03', null, 'nullnext', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1434', '2017-08-25 22:25:03', null, 'nulllist', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1435', '2017-08-25 22:25:03', null, 'nullsave', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1436', '2017-08-25 22:25:03', null, 'nullprev', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1437', '2017-08-25 22:25:03', null, 'nulldelete', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1438', '2017-08-25 22:25:04', null, 'nullenabled', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1439', '2017-08-25 22:25:04', null, 'nullbatchsave', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1440', '2017-08-25 22:25:04', null, 'nulldisabled', null, '2794', '0');
INSERT INTO `ts_classinfo` VALUES ('1441', '2017-08-25 22:25:04', null, 'nulladd', null, '2795', '0');
INSERT INTO `ts_classinfo` VALUES ('1442', '2017-08-25 22:25:04', null, 'nullnext', null, '2795', '0');
INSERT INTO `ts_classinfo` VALUES ('1443', '2017-08-25 22:25:04', null, 'nulllist', null, '2795', '0');
INSERT INTO `ts_classinfo` VALUES ('1444', '2017-08-25 22:25:04', null, 'nullsave', null, '2795', '0');
INSERT INTO `ts_classinfo` VALUES ('1445', '2017-08-25 22:25:04', null, 'nullprev', null, '2795', '0');
INSERT INTO `ts_classinfo` VALUES ('1446', '2017-08-25 22:25:04', null, 'nulldelete', null, '2795', '0');
INSERT INTO `ts_classinfo` VALUES ('1447', '2017-08-25 22:25:04', null, 'nullenabled', null, '2795', '0');
INSERT INTO `ts_classinfo` VALUES ('1448', '2017-08-25 22:25:04', null, 'nullenabled', null, '2795', '0');
INSERT INTO `ts_classinfo` VALUES ('1449', '2017-08-25 22:25:04', null, 'nulldisabled', null, '2795', '0');
INSERT INTO `ts_classinfo` VALUES ('1450', '2017-08-25 22:25:04', null, 'nullget', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1451', '2017-08-25 22:25:04', null, 'nulladd', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1452', '2017-08-25 22:25:04', null, 'nullnext', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1453', '2017-08-25 22:25:04', null, 'nulllist', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1454', '2017-08-25 22:25:04', null, 'nullsave', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1455', '2017-08-25 22:25:04', null, 'nullprev', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1456', '2017-08-25 22:25:04', null, 'nulldelete', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1457', '2017-08-25 22:25:04', null, 'nullenabled', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1458', '2017-08-25 22:25:04', null, 'nullenabled', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1459', '2017-08-25 22:25:04', null, 'nulldisabled', null, '2796', '0');
INSERT INTO `ts_classinfo` VALUES ('1460', '2017-08-25 22:25:04', null, 'nullget', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1461', '2017-08-25 22:25:04', null, 'nulladd', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1462', '2017-08-25 22:25:04', null, 'nullnext', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1463', '2017-08-25 22:25:05', null, 'nulllist', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1464', '2017-08-25 22:25:05', null, 'nullsave', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1465', '2017-08-25 22:25:05', null, 'nullprev', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1466', '2017-08-25 22:25:05', null, 'nulldelete', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1467', '2017-08-25 22:25:05', null, 'nullenabled', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1468', '2017-08-25 22:25:05', null, 'nullenabled', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1469', '2017-08-25 22:25:05', null, 'nulldisabled', null, '2797', '0');
INSERT INTO `ts_classinfo` VALUES ('1470', '2017-08-25 22:25:05', null, 'nullget', null, '2798', '0');
INSERT INTO `ts_classinfo` VALUES ('1471', '2017-08-25 22:25:05', null, 'nulladd', null, '2798', '0');
INSERT INTO `ts_classinfo` VALUES ('1472', '2017-08-25 22:25:05', null, 'nulllist', null, '2798', '0');
INSERT INTO `ts_classinfo` VALUES ('1473', '2017-08-25 22:25:05', null, 'nullsave', null, '2798', '0');
INSERT INTO `ts_classinfo` VALUES ('1474', '2017-08-25 22:25:05', null, 'nulldelete', null, '2798', '0');
INSERT INTO `ts_classinfo` VALUES ('1475', '2017-08-25 22:25:05', null, 'nullenabled', null, '2798', '0');
INSERT INTO `ts_classinfo` VALUES ('1476', '2017-08-25 22:25:05', null, 'nulldisabled', null, '2798', '0');
INSERT INTO `ts_classinfo` VALUES ('1477', '2017-08-25 22:25:05', null, 'nullget', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1478', '2017-08-25 22:25:05', null, 'nulladd', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1479', '2017-08-25 22:25:05', null, 'nullnext', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1480', '2017-08-25 22:25:05', null, 'nulllist', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1481', '2017-08-25 22:25:05', null, 'nullsave', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1482', '2017-08-25 22:25:05', null, 'nullprev', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1483', '2017-08-25 22:25:05', null, 'nulldelete', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1484', '2017-08-25 22:25:05', null, 'nullenabled', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1485', '2017-08-25 22:25:05', null, 'nullenabled', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1486', '2017-08-25 22:25:05', null, 'nullisdefault', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1487', '2017-08-25 22:25:05', null, 'nulldisabled', null, '2799', '0');
INSERT INTO `ts_classinfo` VALUES ('1488', '2017-08-25 22:25:05', null, 'nullget', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1489', '2017-08-25 22:25:06', null, 'nulladd', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1490', '2017-08-25 22:25:06', null, 'nullnext', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1491', '2017-08-25 22:25:06', null, 'nulllist', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1492', '2017-08-25 22:25:06', null, 'nullsave', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1493', '2017-08-25 22:25:06', null, 'nullprev', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1494', '2017-08-25 22:25:06', null, 'nulldelete', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1495', '2017-08-25 22:25:06', null, 'nullenabled', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1496', '2017-08-25 22:25:06', null, 'nullenabled', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1497', '2017-08-25 22:25:06', null, 'nullisdefault', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1498', '2017-08-25 22:25:06', null, 'nulldisabled', null, '2800', '0');
INSERT INTO `ts_classinfo` VALUES ('1499', '2017-08-25 22:25:06', null, 'nullget', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1500', '2017-08-25 22:25:06', null, 'nulladd', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1501', '2017-08-25 22:25:06', null, 'nullnext', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1502', '2017-08-25 22:25:06', null, 'nulllist', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1503', '2017-08-25 22:25:06', null, 'nullsave', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1504', '2017-08-25 22:25:06', null, 'nullprev', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1505', '2017-08-25 22:25:06', null, 'nulldelete', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1506', '2017-08-25 22:25:06', null, 'nullenabled', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1507', '2017-08-25 22:25:06', null, 'nullenabled', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1508', '2017-08-25 22:25:06', null, 'nulldisabled', null, '2801', '0');
INSERT INTO `ts_classinfo` VALUES ('1509', '2017-08-25 22:25:06', null, 'nullget', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1510', '2017-08-25 22:25:06', null, 'nulladd', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1511', '2017-08-25 22:25:06', null, 'nullnext', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1512', '2017-08-25 22:25:06', null, 'nulllist', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1513', '2017-08-25 22:25:06', null, 'nullsave', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1514', '2017-08-25 22:25:06', null, 'nullprev', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1515', '2017-08-25 22:25:07', null, 'nulldelete', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1516', '2017-08-25 22:25:07', null, 'nullenabled', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1517', '2017-08-25 22:25:07', null, 'nullsavefile', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1518', '2017-08-25 22:25:07', null, 'nulldisabled', null, '2802', '0');
INSERT INTO `ts_classinfo` VALUES ('1519', '2017-08-25 22:25:07', null, 'nullget', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1520', '2017-08-25 22:25:07', null, 'nulladd', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1521', '2017-08-25 22:25:07', null, 'nullnext', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1522', '2017-08-25 22:25:07', null, 'nulllist', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1523', '2017-08-25 22:25:07', null, 'nullsave', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1524', '2017-08-25 22:25:07', null, 'nullprev', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1525', '2017-08-25 22:25:07', null, 'nulldelete', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1526', '2017-08-25 22:25:07', null, 'nullenabled', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1527', '2017-08-25 22:25:07', null, 'nullenabled', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1528', '2017-08-25 22:25:07', null, 'nullcancel', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1529', '2017-08-25 22:25:07', null, 'nulldisabled', null, '2803', '0');
INSERT INTO `ts_classinfo` VALUES ('1530', '2017-08-25 22:25:07', null, 'nullget', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1531', '2017-08-25 22:25:07', null, 'nulladd', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1532', '2017-08-25 22:25:07', null, 'nullnext', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1533', '2017-08-25 22:25:07', null, 'nulllist', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1534', '2017-08-25 22:25:07', null, 'nullsave', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1535', '2017-08-25 22:25:07', null, 'nullprev', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1536', '2017-08-25 22:25:07', null, 'nullcopy', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1537', '2017-08-25 22:25:07', null, 'nulldelete', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1538', '2017-08-25 22:25:08', null, 'nullenabled', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1539', '2017-08-25 22:25:08', null, 'nullenabled', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1540', '2017-08-25 22:25:08', null, 'nulldisabled', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1541', '2017-08-25 22:25:08', null, 'nullruList', null, '2804', '0');
INSERT INTO `ts_classinfo` VALUES ('1542', '2017-08-25 22:25:08', null, 'nullget', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1543', '2017-08-25 22:25:08', null, 'nulladd', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1544', '2017-08-25 22:25:08', null, 'nullnext', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1545', '2017-08-25 22:25:08', null, 'nulllist', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1546', '2017-08-25 22:25:08', null, 'nullsave', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1547', '2017-08-25 22:25:08', null, 'nullprev', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1548', '2017-08-25 22:25:08', null, 'nulldelete', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1549', '2017-08-25 22:25:08', null, 'nullenabled', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1550', '2017-08-25 22:25:08', null, 'nullenabled', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1551', '2017-08-25 22:25:08', null, 'nulldisabled', null, '2805', '0');
INSERT INTO `ts_classinfo` VALUES ('1552', '2017-08-25 22:25:08', null, 'nullget', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1553', '2017-08-25 22:25:08', null, 'nulladd', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1554', '2017-08-25 22:25:08', null, 'nullnext', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1555', '2017-08-25 22:25:08', null, 'nulllist', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1556', '2017-08-25 22:25:08', null, 'nullsave', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1557', '2017-08-25 22:25:08', null, 'nullprev', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1558', '2017-08-25 22:25:08', null, 'nulldelete', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1559', '2017-08-25 22:25:08', null, 'nullisEnabled', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1560', '2017-08-25 22:25:08', null, 'nullgetInitDatas', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1561', '2017-08-25 22:25:08', null, 'nullgetParamsName', null, '2806', '0');
INSERT INTO `ts_classinfo` VALUES ('1562', '2017-08-25 22:25:08', null, 'nullget', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1563', '2017-08-25 22:25:08', null, 'nulladd', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1564', '2017-08-25 22:25:08', null, 'nullnext', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1565', '2017-08-25 22:25:09', null, 'nulllist', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1566', '2017-08-25 22:25:09', null, 'nullsave', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1567', '2017-08-25 22:25:09', null, 'nullprev', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1568', '2017-08-25 22:25:09', null, 'nulldelete', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1569', '2017-08-25 22:25:09', null, 'nullenabled', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1570', '2017-08-25 22:25:09', null, 'nullenabled', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1571', '2017-08-25 22:25:09', null, 'nulldisabled', null, '2807', '0');
INSERT INTO `ts_classinfo` VALUES ('1572', '2017-08-25 22:25:09', null, 'nullget', null, '2808', '0');
INSERT INTO `ts_classinfo` VALUES ('1573', '2017-08-25 22:25:09', null, 'nulladd', null, '2808', '0');
INSERT INTO `ts_classinfo` VALUES ('1574', '2017-08-25 22:25:09', null, 'nullnext', null, '2808', '0');
INSERT INTO `ts_classinfo` VALUES ('1575', '2017-08-25 22:25:09', null, 'nullsave', null, '2808', '0');
INSERT INTO `ts_classinfo` VALUES ('1576', '2017-08-25 22:25:09', null, 'nullprev', null, '2808', '0');
INSERT INTO `ts_classinfo` VALUES ('1577', '2017-08-25 22:25:09', null, 'nulldelete', null, '2808', '0');
INSERT INTO `ts_classinfo` VALUES ('1578', '2017-08-25 22:25:09', null, 'nullenabled', null, '2808', '0');
INSERT INTO `ts_classinfo` VALUES ('1579', '2017-08-25 22:25:09', null, 'nulldesklist', null, '2808', '0');
INSERT INTO `ts_classinfo` VALUES ('1580', '2017-08-25 22:25:09', null, 'nulldisabled', null, '2808', '0');
INSERT INTO `ts_classinfo` VALUES ('1581', '2017-08-25 22:25:09', null, 'nullget', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1582', '2017-08-25 22:25:09', null, 'nulladd', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1583', '2017-08-25 22:25:09', null, 'nullnext', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1584', '2017-08-25 22:25:09', null, 'nulllist', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1585', '2017-08-25 22:25:09', null, 'nullsave', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1586', '2017-08-25 22:25:09', null, 'nullprev', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1587', '2017-08-25 22:25:09', null, 'nulldelete', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1588', '2017-08-25 22:25:09', null, 'nullenabled', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1589', '2017-08-25 22:25:09', null, 'nullenabled', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1590', '2017-08-25 22:25:09', null, 'nulldisabled', null, '2809', '0');
INSERT INTO `ts_classinfo` VALUES ('1591', '2017-08-25 22:25:10', null, 'nullget', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1592', '2017-08-25 22:25:10', null, 'nulladd', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1593', '2017-08-25 22:25:10', null, 'nullnext', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1594', '2017-08-25 22:25:10', null, 'nulllist', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1595', '2017-08-25 22:25:10', null, 'nullsave', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1596', '2017-08-25 22:25:10', null, 'nullprev', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1597', '2017-08-25 22:25:10', null, 'nulldelete', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1598', '2017-08-25 22:25:10', null, 'nullenabled', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1599', '2017-08-25 22:25:10', null, 'nullenabled', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1600', '2017-08-25 22:25:10', null, 'nulldisabled', null, '2810', '0');
INSERT INTO `ts_classinfo` VALUES ('1601', '2017-08-25 22:25:10', null, 'nulllist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1602', '2017-08-25 22:25:10', null, 'nullsavefile', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1603', '2017-08-25 22:25:10', null, 'nullimgFolider', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1604', '2017-08-25 22:25:10', null, 'nullpostlist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1605', '2017-08-25 22:25:10', null, 'nullcustorglist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1606', '2017-08-25 22:25:10', null, 'nullformlist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1607', '2017-08-25 22:25:10', null, 'nullrolelist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1608', '2017-08-25 22:25:10', null, 'nullreslist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1609', '2017-08-25 22:25:10', null, 'nullfdlist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1610', '2017-08-25 22:25:10', null, 'nullfmulalist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1611', '2017-08-25 22:25:10', null, 'nullroleright', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1612', '2017-08-25 22:25:10', null, 'nullorglist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1613', '2017-08-25 22:25:10', null, 'nullarealist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1614', '2017-08-25 22:25:10', null, 'nulluseRolelist', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1615', '2017-08-25 22:25:10', null, 'nullmatTempList', null, '2811', '0');
INSERT INTO `ts_classinfo` VALUES ('1616', '2017-08-25 22:25:10', null, 'nullget', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1617', '2017-08-25 22:25:10', null, 'nulladd', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1618', '2017-08-25 22:25:10', null, 'nullnext', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1619', '2017-08-25 22:25:10', null, 'nulllist', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1620', '2017-08-25 22:25:11', null, 'nullsave', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1621', '2017-08-25 22:25:11', null, 'nullprev', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1622', '2017-08-25 22:25:11', null, 'nulldelete', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1623', '2017-08-25 22:25:11', null, 'nullenabled', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1624', '2017-08-25 22:25:11', null, 'nullrole', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1625', '2017-08-25 22:25:11', null, 'nulldisabled', null, '2812', '0');
INSERT INTO `ts_classinfo` VALUES ('1626', '2017-08-25 22:25:11', null, 'nullget', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1627', '2017-08-25 22:25:11', null, 'nulladd', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1628', '2017-08-25 22:25:11', null, 'nullnext', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1629', '2017-08-25 22:25:11', null, 'nulllist', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1630', '2017-08-25 22:25:11', null, 'nullsave', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1631', '2017-08-25 22:25:11', null, 'nullprev', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1632', '2017-08-25 22:25:11', null, 'nulldelete', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1633', '2017-08-25 22:25:11', null, 'nulllogout', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1634', '2017-08-25 22:25:11', null, 'nulllogin', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1635', '2017-08-25 22:25:11', null, 'nullenabled', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1636', '2017-08-25 22:25:11', null, 'nullenabled', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1637', '2017-08-25 22:25:11', null, 'nullcbodatas', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1638', '2017-08-25 22:25:11', null, 'nullchangePost', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1639', '2017-08-25 22:25:11', null, 'nullsavePassWord', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1640', '2017-08-25 22:25:11', null, 'nulleditPassWord', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1641', '2017-08-25 22:25:11', null, 'nullcashierlist', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1642', '2017-08-25 22:25:11', null, 'nullregotoLogin', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1643', '2017-08-25 22:25:12', null, 'nullgotoLogin', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1644', '2017-08-25 22:25:12', null, 'nullgetLeaders', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1645', '2017-08-25 22:25:12', null, 'nulldisabled', null, '2813', '0');
INSERT INTO `ts_classinfo` VALUES ('1646', '2017-08-25 22:25:12', null, 'nullget', null, '2814', '0');
INSERT INTO `ts_classinfo` VALUES ('1647', '2017-08-25 22:25:12', null, 'nulllist', null, '2814', '0');
INSERT INTO `ts_classinfo` VALUES ('1648', '2017-08-25 22:25:12', null, 'nulldelete', null, '2814', '0');
INSERT INTO `ts_classinfo` VALUES ('1649', '2017-08-25 22:25:12', null, 'nullenabled', null, '2814', '0');
INSERT INTO `ts_classinfo` VALUES ('1650', '2017-08-25 22:25:12', null, 'nullgetContents', null, '2814', '0');
INSERT INTO `ts_classinfo` VALUES ('1651', '2017-08-25 22:25:12', null, 'nullgetDatas', null, '2814', '0');
INSERT INTO `ts_classinfo` VALUES ('1652', '2017-08-25 22:25:12', null, 'nullget', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1653', '2017-08-25 22:25:12', null, 'nulladd', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1654', '2017-08-25 22:25:12', null, 'nullnext', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1655', '2017-08-25 22:25:12', null, 'nulllist', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1656', '2017-08-25 22:25:12', null, 'nullsave', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1657', '2017-08-25 22:25:12', null, 'nullprev', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1658', '2017-08-25 22:25:12', null, 'nulldelete', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1659', '2017-08-25 22:25:12', null, 'nullenabled', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1660', '2017-08-25 22:25:12', null, 'nullenabled', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1661', '2017-08-25 22:25:12', null, 'nullcbolist', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1662', '2017-08-25 22:25:12', null, 'nullenablelist', null, '2815', '0');
INSERT INTO `ts_classinfo` VALUES ('1663', '2017-08-25 22:25:12', null, 'nulldisabled', null, '2815', '0');

-- ----------------------------
-- Table structure for ts_fields
-- ----------------------------
DROP TABLE IF EXISTS `ts_fields`;
CREATE TABLE `ts_fields` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bind` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `choiceval` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `colName` varchar(50) COLLATE utf8_bin NOT NULL,
  `dataType` varchar(50) COLLATE utf8_bin NOT NULL,
  `decimalnum` int(11) DEFAULT NULL,
  `defaultval` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `fieldName` varchar(50) COLLATE utf8_bin NOT NULL,
  `isnull` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `len` int(11) DEFAULT NULL,
  `remark` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `sqltype` varchar(50) COLLATE utf8_bin NOT NULL,
  `srcId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4049 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ts_fields
-- ----------------------------
INSERT INTO `ts_fields` VALUES ('2333', '', null, 'dpenums', 'String', null, '', 'dpenums', 'true', '150', '默认接收号码', 'Varchar', '1400');
INSERT INTO `ts_fields` VALUES ('2334', '', null, 'fparas', 'String', null, '', 'fparas', 'true', '150', '模板参数', 'Varchar', '1400');
INSERT INTO `ts_fields` VALUES ('2335', '', null, 'content', 'String', null, '', 'content', 'false', '225', '模板内容', 'Varchar', '1400');
INSERT INTO `ts_fields` VALUES ('2336', '', null, 'title', 'String', null, '0', 'title', 'true', '100', '模板标题', 'Varchar', '1400');
INSERT INTO `ts_fields` VALUES ('2337', '', null, 'mname', 'String', null, '', 'mname', 'false', '50', '模板名称', 'Varchar', '1400');
INSERT INTO `ts_fields` VALUES ('2338', '', null, 'btype', 'Integer', null, '', 'btype', 'false', null, '业务类型', 'Int', '1400');
INSERT INTO `ts_fields` VALUES ('2339', '', null, 'mtype', 'Integer', null, '', 'mtype', 'false', null, '消息类型', 'Int', '1400');
INSERT INTO `ts_fields` VALUES ('2340', '', null, 'code', 'String', null, '', 'code', 'false', '20', '模板编号', 'Varchar', '1400');
INSERT INTO `ts_fields` VALUES ('2341', '', null, 'xstatus', 'Integer', null, '0', 'xstatus', 'false', null, '消息状态', 'Int', '1406');
INSERT INTO `ts_fields` VALUES ('2342', '', null, 'rstatus', 'Integer', null, '0', 'rstatus', 'false', null, '阅读状态', 'Int', '1406');
INSERT INTO `ts_fields` VALUES ('2343', '', null, 'msgStatusId', 'Long', null, '', 'msgStatusId', 'true', null, '消息状态ID', 'Bigint', '1406');
INSERT INTO `ts_fields` VALUES ('2344', '', null, 'penum', 'String', null, '', 'penum', 'false', '30', '接收号码', 'Varchar', '1406');
INSERT INTO `ts_fields` VALUES ('2345', '', null, 'sendTime', 'Date', null, '', 'sendTime', 'true', null, '发送时间', 'Datetime', '1406');
INSERT INTO `ts_fields` VALUES ('2346', '', null, 'sender', 'String', null, '', 'sender', 'true', '20', '发送人', 'Varchar', '1406');
INSERT INTO `ts_fields` VALUES ('2347', '', null, 'mtype', 'Integer', null, '', 'mtype', 'false', null, '消息类型', 'Int', '1406');
INSERT INTO `ts_fields` VALUES ('2348', '', null, 'content', 'String', null, '', 'content', 'false', '225', '内容', 'Varchar', '1406');
INSERT INTO `ts_fields` VALUES ('2349', '', null, 'title', 'String', null, '0', 'title', 'true', '100', '标题', 'Varchar', '1406');
INSERT INTO `ts_fields` VALUES ('2350', '', null, 'templateId', 'Long', null, '', 'templateId', 'true', null, '消息模板ID', 'Bigint', '1406');
INSERT INTO `ts_fields` VALUES ('2351', '', null, 'memberId', 'Long', null, '', 'memberId', 'false', null, '会员ID', 'Bigint', '1406');
INSERT INTO `ts_fields` VALUES ('2359', '', null, 'modifyTime', 'Date', null, '', 'modifyTime', 'Y', null, '修改日期', 'Datetime', '1429');
INSERT INTO `ts_fields` VALUES ('2360', '', null, 'modifier', 'Long', null, '', 'modifier', 'Y', '50', '修改人姓名', 'Bigint', '1429');
INSERT INTO `ts_fields` VALUES ('2361', '', null, 'createTime', 'Date', null, '', 'createTime', 'false', null, '创建日期', 'Datetime', '1429');
INSERT INTO `ts_fields` VALUES ('2362', '', null, 'isenabled', 'Byte', null, '1', 'isenabled', 'false', null, '可用标志', 'Tinyint', '1429');
INSERT INTO `ts_fields` VALUES ('2363', '', null, 'msgStatusId', 'Long', null, '', 'msgStatusId', 'true', null, '消息状态ID', 'Bigint', '1429');
INSERT INTO `ts_fields` VALUES ('2364', '', null, 'xstatus', 'Integer', null, '', 'xstatus', 'false', null, '状态', 'Int', '1429');
INSERT INTO `ts_fields` VALUES ('2365', '', null, 'endTime', 'Date', null, '', 'endTime', 'true', null, '失效时间', 'Datetime', '1429');
INSERT INTO `ts_fields` VALUES ('2366', '', null, 'sendTime', 'Date', null, '', 'sendTime', 'true', null, '发送时间', 'Datetime', '1429');
INSERT INTO `ts_fields` VALUES ('2367', '', null, 'vcode', 'String', null, '', 'vcode', 'false', '20', '验证码', 'Varchar', '1429');
INSERT INTO `ts_fields` VALUES ('2368', '', null, 'penum', 'String', null, '', 'penum', 'false', '30', '接收号码', 'Varchar', '1429');
INSERT INTO `ts_fields` VALUES ('2369', '', null, 'vtype', 'Integer', null, '', 'vtype', 'false', null, '验证码类型', 'Int', '1429');
INSERT INTO `ts_fields` VALUES ('2370', '', null, 'btype', 'Integer', null, '', 'btype', 'false', null, '业务类型', 'Int', '1429');
INSERT INTO `ts_fields` VALUES ('2371', '', null, 'memberId', 'Long', null, '', 'memberId', 'true', null, '会员ID', 'Bigint', '1429');
INSERT INTO `ts_fields` VALUES ('2372', '', null, 'createTime', 'Date', null, '', 'createTime', 'false', null, '创建日期', 'Datetime', '1455');
INSERT INTO `ts_fields` VALUES ('2373', '', null, 'remark', 'String', null, '', 'remark', 'Y', '200', '备注', 'Varchar', '1455');
INSERT INTO `ts_fields` VALUES ('2374', '', null, 'supplier', 'String', null, '', 'supplier', 'true', '100', '短信供应商', 'Varchar', '1455');
INSERT INTO `ts_fields` VALUES ('2375', '', null, 'respTime', 'String', null, '', 'respTime', 'true', null, '响应时间', 'Varchar', '1455');
INSERT INTO `ts_fields` VALUES ('2376', '', null, 'xstatus', 'String', null, '', 'xstatus', 'true', '50', '状态', 'Varchar', '1455');
INSERT INTO `ts_fields` VALUES ('2377', '', null, 'smsId', 'String', null, '', 'smsId', 'true', '50', '短信ID', 'Varchar', '1455');
INSERT INTO `ts_fields` VALUES ('3750', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2816');
INSERT INTO `ts_fields` VALUES ('3751', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2816');
INSERT INTO `ts_fields` VALUES ('3752', '', null, 'loginTime', 'String', null, null, 'loginTime', 'false', '50', '登录时间', 'VARCHAR', '2816');
INSERT INTO `ts_fields` VALUES ('3753', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2816');
INSERT INTO `ts_fields` VALUES ('3754', '', null, 'xstatus', 'Integer', '0', null, 'xstatus', 'false', '10', '登录状态', 'INT', '2816');
INSERT INTO `ts_fields` VALUES ('3755', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2816');
INSERT INTO `ts_fields` VALUES ('3756', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2816');
INSERT INTO `ts_fields` VALUES ('3757', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2817');
INSERT INTO `ts_fields` VALUES ('3758', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2817');
INSERT INTO `ts_fields` VALUES ('3759', '', null, 'loginTime', 'String', null, null, 'loginTime', 'false', '50', '登录时间', 'VARCHAR', '2817');
INSERT INTO `ts_fields` VALUES ('3760', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2817');
INSERT INTO `ts_fields` VALUES ('3761', '', null, 'xstatus', 'Integer', '0', null, 'xstatus', 'false', '10', '登录状态', 'INT', '2817');
INSERT INTO `ts_fields` VALUES ('3762', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2817');
INSERT INTO `ts_fields` VALUES ('3763', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2817');
INSERT INTO `ts_fields` VALUES ('3764', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2818');
INSERT INTO `ts_fields` VALUES ('3765', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2818');
INSERT INTO `ts_fields` VALUES ('3766', '', null, 'loginTime', 'String', null, null, 'loginTime', 'false', '50', '登录时间', 'VARCHAR', '2818');
INSERT INTO `ts_fields` VALUES ('3767', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2818');
INSERT INTO `ts_fields` VALUES ('3768', '', null, 'xstatus', 'Integer', '0', null, 'xstatus', 'false', '10', '登录状态', 'INT', '2818');
INSERT INTO `ts_fields` VALUES ('3769', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2818');
INSERT INTO `ts_fields` VALUES ('3770', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2818');
INSERT INTO `ts_fields` VALUES ('3771', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2821');
INSERT INTO `ts_fields` VALUES ('3772', '', null, 'loginLogId', 'Long', '0', null, 'loginLogId', 'false', '19', '登录日志ID', 'BIGINT', '2821');
INSERT INTO `ts_fields` VALUES ('3773', '', null, 'outTime', 'Date', null, null, 'outTime', 'false', '19', '退出时间', 'DATETIME', '2821');
INSERT INTO `ts_fields` VALUES ('3774', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2821');
INSERT INTO `ts_fields` VALUES ('3775', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2821');
INSERT INTO `ts_fields` VALUES ('3776', '', null, 'otype', 'Integer', '0', null, 'otype', 'false', '10', '退出方式', 'INT', '2821');
INSERT INTO `ts_fields` VALUES ('3777', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2821');
INSERT INTO `ts_fields` VALUES ('3778', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3779', '', null, 'pwd', 'String', null, null, 'pwd', 'false', '100', '密码', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3780', '', null, 'rname', 'String', null, null, 'rname', 'true', '50', '会员姓名', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3781', '', null, 'cardno', 'String', null, null, 'cardno', 'true', '20', '身份证号码', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3782', '', null, 'email', 'String', null, null, 'email', 'true', '50', '邮箱', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3783', '', null, 'phone', 'String', null, null, 'phone', 'true', '50', '手机', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3784', '', null, 'cardnoPass', 'Byte', '0', '0', 'cardnoPass', 'true', '3', '身份证是否验证', 'TINYINT', '2824');
INSERT INTO `ts_fields` VALUES ('3785', '', null, 'emailPass', 'Byte', '0', '0', 'emailPass', 'true', '3', '邮箱是否验证', 'TINYINT', '2824');
INSERT INTO `ts_fields` VALUES ('3786', '', null, 'phonePass', 'Byte', '0', '0', 'phonePass', 'true', '3', '手机是否验证', 'TINYINT', '2824');
INSERT INTO `ts_fields` VALUES ('3787', '', null, 'mlevel', 'Long', '0', null, 'mlevel', 'false', '19', '会员等级', 'BIGINT', '2824');
INSERT INTO `ts_fields` VALUES ('3788', '', null, 'imgPath', 'String', null, null, 'imgPath', 'true', '150', '用户头像', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3789', '', null, 'mtype', 'Integer', '0', null, 'mtype', 'false', '10', '会员类型', 'INT', '2824');
INSERT INTO `ts_fields` VALUES ('3790', '', null, 'historyId', 'String', null, null, 'historyId', 'true', '50', '历史记录ID', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3791', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3792', '', null, 'isenabled', 'Byte', '0', null, 'isenabled', 'false', '3', '可用标志', 'TINYINT', '2824');
INSERT INTO `ts_fields` VALUES ('3793', '', null, 'createTime', 'Date', null, null, 'createTime', 'false', '19', '创建日期', 'DATETIME', '2824');
INSERT INTO `ts_fields` VALUES ('3794', '', null, 'modifier', 'String', null, null, 'modifier', 'true', '50', '修改人姓名', 'VARCHAR', '2824');
INSERT INTO `ts_fields` VALUES ('3795', '', null, 'modifyTime', 'Date', null, null, 'modifyTime', 'true', '19', '修改日期', 'DATETIME', '2824');
INSERT INTO `ts_fields` VALUES ('3796', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2827');
INSERT INTO `ts_fields` VALUES ('3797', '', null, 'locked', 'Integer', '0', null, 'locked', 'false', '10', '是否锁定', 'INT', '2827');
INSERT INTO `ts_fields` VALUES ('3798', '', null, 'ecount', 'Integer', '0', null, 'ecount', 'false', '10', '密码错误次数', 'INT', '2827');
INSERT INTO `ts_fields` VALUES ('3799', '', null, 'lockTime', 'String', null, null, 'lockTime', 'true', '50', '锁定时间', 'VARCHAR', '2827');
INSERT INTO `ts_fields` VALUES ('3800', '', null, 'unlockTime', 'String', null, null, 'unlockTime', 'true', '50', '解锁时间', 'VARCHAR', '2827');
INSERT INTO `ts_fields` VALUES ('3801', '', null, 'duration', 'String', null, null, 'duration', 'true', '50', '锁定时长', 'VARCHAR', '2827');
INSERT INTO `ts_fields` VALUES ('3802', '', null, 'logId', 'Long', '0', null, 'logId', 'false', '19', '登录日志ID', 'BIGINT', '2827');
INSERT INTO `ts_fields` VALUES ('3803', '', null, 'shareCode', 'String', null, null, 'shareCode', 'true', '20', '邀请码', 'VARCHAR', '2827');
INSERT INTO `ts_fields` VALUES ('3804', '', null, 'sphone', 'String', null, null, 'sphone', 'true', '20', '推荐人手机号', 'VARCHAR', '2827');
INSERT INTO `ts_fields` VALUES ('3805', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'false', '10', '注册来源', 'INT', '2827');
INSERT INTO `ts_fields` VALUES ('3806', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2827');
INSERT INTO `ts_fields` VALUES ('3807', '', null, 'isenabled', 'Byte', '0', null, 'isenabled', 'false', '3', '可用标志', 'TINYINT', '2827');
INSERT INTO `ts_fields` VALUES ('3808', '', null, 'createTime', 'Date', null, null, 'createTime', 'false', '19', '创建日期', 'DATETIME', '2827');
INSERT INTO `ts_fields` VALUES ('3809', '', null, 'modifier', 'String', null, null, 'modifier', 'true', '50', '修改人姓名', 'VARCHAR', '2827');
INSERT INTO `ts_fields` VALUES ('3810', '', null, 'modifyTime', 'Date', null, null, 'modifyTime', 'true', '19', '修改日期', 'DATETIME', '2827');
INSERT INTO `ts_fields` VALUES ('3811', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2830');
INSERT INTO `ts_fields` VALUES ('3812', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2830');
INSERT INTO `ts_fields` VALUES ('3813', '', null, 'loginTime', 'String', null, null, 'loginTime', 'false', '50', '登录时间', 'VARCHAR', '2830');
INSERT INTO `ts_fields` VALUES ('3814', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2830');
INSERT INTO `ts_fields` VALUES ('3815', '', null, 'xstatus', 'Integer', '0', null, 'xstatus', 'false', '10', '登录状态', 'INT', '2830');
INSERT INTO `ts_fields` VALUES ('3816', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2830');
INSERT INTO `ts_fields` VALUES ('3817', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2830');
INSERT INTO `ts_fields` VALUES ('3818', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2833');
INSERT INTO `ts_fields` VALUES ('3819', '', null, 'loginLogId', 'Long', '0', null, 'loginLogId', 'false', '19', '登录日志ID', 'BIGINT', '2833');
INSERT INTO `ts_fields` VALUES ('3820', '', null, 'outTime', 'Date', null, null, 'outTime', 'false', '19', '退出时间', 'DATETIME', '2833');
INSERT INTO `ts_fields` VALUES ('3821', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2833');
INSERT INTO `ts_fields` VALUES ('3822', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2833');
INSERT INTO `ts_fields` VALUES ('3823', '', null, 'otype', 'Integer', '0', null, 'otype', 'false', '10', '退出方式', 'INT', '2833');
INSERT INTO `ts_fields` VALUES ('3824', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2833');
INSERT INTO `ts_fields` VALUES ('3825', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3826', '', null, 'pwd', 'String', null, null, 'pwd', 'false', '100', '密码', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3827', '', null, 'rname', 'String', null, null, 'rname', 'true', '50', '会员姓名', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3828', '', null, 'cardno', 'String', null, null, 'cardno', 'true', '20', '身份证号码', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3829', '', null, 'email', 'String', null, null, 'email', 'true', '50', '邮箱', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3830', '', null, 'phone', 'String', null, null, 'phone', 'true', '50', '手机', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3831', '', null, 'cardnoPass', 'Byte', '0', '0', 'cardnoPass', 'true', '3', '身份证是否验证', 'TINYINT', '2836');
INSERT INTO `ts_fields` VALUES ('3832', '', null, 'emailPass', 'Byte', '0', '0', 'emailPass', 'true', '3', '邮箱是否验证', 'TINYINT', '2836');
INSERT INTO `ts_fields` VALUES ('3833', '', null, 'phonePass', 'Byte', '0', '0', 'phonePass', 'true', '3', '手机是否验证', 'TINYINT', '2836');
INSERT INTO `ts_fields` VALUES ('3834', '', null, 'mlevel', 'Long', '0', null, 'mlevel', 'false', '19', '会员等级', 'BIGINT', '2836');
INSERT INTO `ts_fields` VALUES ('3835', '', null, 'imgPath', 'String', null, null, 'imgPath', 'true', '150', '用户头像', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3836', '', null, 'mtype', 'Integer', '0', null, 'mtype', 'false', '10', '会员类型', 'INT', '2836');
INSERT INTO `ts_fields` VALUES ('3837', '', null, 'historyId', 'String', null, null, 'historyId', 'true', '50', '历史记录ID', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3838', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3839', '', null, 'isenabled', 'Byte', '0', null, 'isenabled', 'false', '3', '可用标志', 'TINYINT', '2836');
INSERT INTO `ts_fields` VALUES ('3840', '', null, 'createTime', 'Date', null, null, 'createTime', 'false', '19', '创建日期', 'DATETIME', '2836');
INSERT INTO `ts_fields` VALUES ('3841', '', null, 'modifier', 'String', null, null, 'modifier', 'true', '50', '修改人姓名', 'VARCHAR', '2836');
INSERT INTO `ts_fields` VALUES ('3842', '', null, 'modifyTime', 'Date', null, null, 'modifyTime', 'true', '19', '修改日期', 'DATETIME', '2836');
INSERT INTO `ts_fields` VALUES ('3843', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2839');
INSERT INTO `ts_fields` VALUES ('3844', '', null, 'locked', 'Integer', '0', null, 'locked', 'false', '10', '是否锁定', 'INT', '2839');
INSERT INTO `ts_fields` VALUES ('3845', '', null, 'ecount', 'Integer', '0', null, 'ecount', 'false', '10', '密码错误次数', 'INT', '2839');
INSERT INTO `ts_fields` VALUES ('3846', '', null, 'lockTime', 'String', null, null, 'lockTime', 'true', '50', '锁定时间', 'VARCHAR', '2839');
INSERT INTO `ts_fields` VALUES ('3847', '', null, 'unlockTime', 'String', null, null, 'unlockTime', 'true', '50', '解锁时间', 'VARCHAR', '2839');
INSERT INTO `ts_fields` VALUES ('3848', '', null, 'duration', 'String', null, null, 'duration', 'true', '50', '锁定时长', 'VARCHAR', '2839');
INSERT INTO `ts_fields` VALUES ('3849', '', null, 'logId', 'Long', '0', null, 'logId', 'false', '19', '登录日志ID', 'BIGINT', '2839');
INSERT INTO `ts_fields` VALUES ('3850', '', null, 'shareCode', 'String', null, null, 'shareCode', 'true', '20', '邀请码', 'VARCHAR', '2839');
INSERT INTO `ts_fields` VALUES ('3851', '', null, 'sphone', 'String', null, null, 'sphone', 'true', '20', '推荐人手机号', 'VARCHAR', '2839');
INSERT INTO `ts_fields` VALUES ('3852', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'false', '10', '注册来源', 'INT', '2839');
INSERT INTO `ts_fields` VALUES ('3853', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2839');
INSERT INTO `ts_fields` VALUES ('3854', '', null, 'isenabled', 'Byte', '0', null, 'isenabled', 'false', '3', '可用标志', 'TINYINT', '2839');
INSERT INTO `ts_fields` VALUES ('3855', '', null, 'createTime', 'Date', null, null, 'createTime', 'false', '19', '创建日期', 'DATETIME', '2839');
INSERT INTO `ts_fields` VALUES ('3856', '', null, 'modifier', 'String', null, null, 'modifier', 'true', '50', '修改人姓名', 'VARCHAR', '2839');
INSERT INTO `ts_fields` VALUES ('3857', '', null, 'modifyTime', 'Date', null, null, 'modifyTime', 'true', '19', '修改日期', 'DATETIME', '2839');
INSERT INTO `ts_fields` VALUES ('3858', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2842');
INSERT INTO `ts_fields` VALUES ('3859', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2842');
INSERT INTO `ts_fields` VALUES ('3860', '', null, 'loginTime', 'String', null, null, 'loginTime', 'false', '50', '登录时间', 'VARCHAR', '2842');
INSERT INTO `ts_fields` VALUES ('3861', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2842');
INSERT INTO `ts_fields` VALUES ('3862', '', null, 'xstatus', 'Integer', '0', null, 'xstatus', 'false', '10', '登录状态', 'INT', '2842');
INSERT INTO `ts_fields` VALUES ('3863', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2842');
INSERT INTO `ts_fields` VALUES ('3864', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2842');
INSERT INTO `ts_fields` VALUES ('3865', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2845');
INSERT INTO `ts_fields` VALUES ('3866', '', null, 'loginLogId', 'Long', '0', null, 'loginLogId', 'false', '19', '登录日志ID', 'BIGINT', '2845');
INSERT INTO `ts_fields` VALUES ('3867', '', null, 'outTime', 'Date', null, null, 'outTime', 'false', '19', '退出时间', 'DATETIME', '2845');
INSERT INTO `ts_fields` VALUES ('3868', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2845');
INSERT INTO `ts_fields` VALUES ('3869', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2845');
INSERT INTO `ts_fields` VALUES ('3870', '', null, 'otype', 'Integer', '0', null, 'otype', 'false', '10', '退出方式', 'INT', '2845');
INSERT INTO `ts_fields` VALUES ('3871', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2845');
INSERT INTO `ts_fields` VALUES ('3872', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3873', '', null, 'pwd', 'String', null, null, 'pwd', 'false', '100', '密码', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3874', '', null, 'rname', 'String', null, null, 'rname', 'true', '50', '会员姓名', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3875', '', null, 'cardno', 'String', null, null, 'cardno', 'true', '20', '身份证号码', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3876', '', null, 'email', 'String', null, null, 'email', 'true', '50', '邮箱', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3877', '', null, 'phone', 'String', null, null, 'phone', 'true', '50', '手机', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3878', '', null, 'cardnoPass', 'Byte', '0', '0', 'cardnoPass', 'true', '3', '身份证是否验证', 'TINYINT', '2848');
INSERT INTO `ts_fields` VALUES ('3879', '', null, 'emailPass', 'Byte', '0', '0', 'emailPass', 'true', '3', '邮箱是否验证', 'TINYINT', '2848');
INSERT INTO `ts_fields` VALUES ('3880', '', null, 'phonePass', 'Byte', '0', '0', 'phonePass', 'true', '3', '手机是否验证', 'TINYINT', '2848');
INSERT INTO `ts_fields` VALUES ('3881', '', null, 'mlevel', 'Long', '0', null, 'mlevel', 'false', '19', '会员等级', 'BIGINT', '2848');
INSERT INTO `ts_fields` VALUES ('3882', '', null, 'imgPath', 'String', null, null, 'imgPath', 'true', '150', '用户头像', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3883', '', null, 'mtype', 'Integer', '0', null, 'mtype', 'false', '10', '会员类型', 'INT', '2848');
INSERT INTO `ts_fields` VALUES ('3884', '', null, 'historyId', 'String', null, null, 'historyId', 'true', '50', '历史记录ID', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3885', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3886', '', null, 'isenabled', 'Byte', '0', null, 'isenabled', 'false', '3', '可用标志', 'TINYINT', '2848');
INSERT INTO `ts_fields` VALUES ('3887', '', null, 'createTime', 'Date', null, null, 'createTime', 'false', '19', '创建日期', 'DATETIME', '2848');
INSERT INTO `ts_fields` VALUES ('3888', '', null, 'modifier', 'String', null, null, 'modifier', 'true', '50', '修改人姓名', 'VARCHAR', '2848');
INSERT INTO `ts_fields` VALUES ('3889', '', null, 'modifyTime', 'Date', null, null, 'modifyTime', 'true', '19', '修改日期', 'DATETIME', '2848');
INSERT INTO `ts_fields` VALUES ('3890', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2851');
INSERT INTO `ts_fields` VALUES ('3891', '', null, 'locked', 'Integer', '0', null, 'locked', 'false', '10', '是否锁定', 'INT', '2851');
INSERT INTO `ts_fields` VALUES ('3892', '', null, 'ecount', 'Integer', '0', null, 'ecount', 'false', '10', '密码错误次数', 'INT', '2851');
INSERT INTO `ts_fields` VALUES ('3893', '', null, 'lockTime', 'String', null, null, 'lockTime', 'true', '50', '锁定时间', 'VARCHAR', '2851');
INSERT INTO `ts_fields` VALUES ('3894', '', null, 'unlockTime', 'String', null, null, 'unlockTime', 'true', '50', '解锁时间', 'VARCHAR', '2851');
INSERT INTO `ts_fields` VALUES ('3895', '', null, 'duration', 'String', null, null, 'duration', 'true', '50', '锁定时长', 'VARCHAR', '2851');
INSERT INTO `ts_fields` VALUES ('3896', '', null, 'logId', 'Long', '0', null, 'logId', 'false', '19', '登录日志ID', 'BIGINT', '2851');
INSERT INTO `ts_fields` VALUES ('3897', '', null, 'shareCode', 'String', null, null, 'shareCode', 'true', '20', '邀请码', 'VARCHAR', '2851');
INSERT INTO `ts_fields` VALUES ('3898', '', null, 'sphone', 'String', null, null, 'sphone', 'true', '20', '推荐人手机号', 'VARCHAR', '2851');
INSERT INTO `ts_fields` VALUES ('3899', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'false', '10', '注册来源', 'INT', '2851');
INSERT INTO `ts_fields` VALUES ('3900', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2851');
INSERT INTO `ts_fields` VALUES ('3901', '', null, 'isenabled', 'Byte', '0', null, 'isenabled', 'false', '3', '可用标志', 'TINYINT', '2851');
INSERT INTO `ts_fields` VALUES ('3902', '', null, 'createTime', 'Date', null, null, 'createTime', 'false', '19', '创建日期', 'DATETIME', '2851');
INSERT INTO `ts_fields` VALUES ('3903', '', null, 'modifier', 'String', null, null, 'modifier', 'true', '50', '修改人姓名', 'VARCHAR', '2851');
INSERT INTO `ts_fields` VALUES ('3904', '', null, 'modifyTime', 'Date', null, null, 'modifyTime', 'true', '19', '修改日期', 'DATETIME', '2851');
INSERT INTO `ts_fields` VALUES ('3905', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2854');
INSERT INTO `ts_fields` VALUES ('3906', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2854');
INSERT INTO `ts_fields` VALUES ('3907', '', null, 'loginTime', 'String', null, null, 'loginTime', 'false', '50', '登录时间', 'VARCHAR', '2854');
INSERT INTO `ts_fields` VALUES ('3908', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2854');
INSERT INTO `ts_fields` VALUES ('3909', '', null, 'xstatus', 'Integer', '0', null, 'xstatus', 'false', '10', '登录状态', 'INT', '2854');
INSERT INTO `ts_fields` VALUES ('3910', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2854');
INSERT INTO `ts_fields` VALUES ('3911', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2854');
INSERT INTO `ts_fields` VALUES ('3912', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2860');
INSERT INTO `ts_fields` VALUES ('3913', '', null, 'loginLogId', 'Long', '0', null, 'loginLogId', 'false', '19', '登录日志ID', 'BIGINT', '2860');
INSERT INTO `ts_fields` VALUES ('3914', '', null, 'outTime', 'Date', null, null, 'outTime', 'false', '19', '退出时间', 'DATETIME', '2860');
INSERT INTO `ts_fields` VALUES ('3915', '', null, 'ip', 'String', null, null, 'ip', 'true', '75', '登录IP', 'VARCHAR', '2860');
INSERT INTO `ts_fields` VALUES ('3916', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'true', '10', '设备来源', 'INT', '2860');
INSERT INTO `ts_fields` VALUES ('3917', '', null, 'otype', 'Integer', '0', null, 'otype', 'false', '10', '退出方式', 'INT', '2860');
INSERT INTO `ts_fields` VALUES ('3918', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2860');
INSERT INTO `ts_fields` VALUES ('3919', '', null, 'account', 'String', null, null, 'account', 'false', '50', '用户名', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3920', '', null, 'pwd', 'String', null, null, 'pwd', 'false', '100', '密码', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3921', '', null, 'rname', 'String', null, null, 'rname', 'true', '50', '会员姓名', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3922', '', null, 'cardno', 'String', null, null, 'cardno', 'true', '20', '身份证号码', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3923', '', null, 'email', 'String', null, null, 'email', 'true', '50', '邮箱', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3924', '', null, 'phone', 'String', null, null, 'phone', 'true', '50', '手机', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3925', '', null, 'cardnoPass', 'Byte', '0', '0', 'cardnoPass', 'true', '3', '身份证是否验证', 'TINYINT', '2866');
INSERT INTO `ts_fields` VALUES ('3926', '', null, 'emailPass', 'Byte', '0', '0', 'emailPass', 'true', '3', '邮箱是否验证', 'TINYINT', '2866');
INSERT INTO `ts_fields` VALUES ('3927', '', null, 'phonePass', 'Byte', '0', '0', 'phonePass', 'true', '3', '手机是否验证', 'TINYINT', '2866');
INSERT INTO `ts_fields` VALUES ('3928', '', null, 'mlevel', 'Long', '0', null, 'mlevel', 'false', '19', '会员等级', 'BIGINT', '2866');
INSERT INTO `ts_fields` VALUES ('3929', '', null, 'imgPath', 'String', null, null, 'imgPath', 'true', '150', '用户头像', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3930', '', null, 'mtype', 'Integer', '0', null, 'mtype', 'false', '10', '会员类型', 'INT', '2866');
INSERT INTO `ts_fields` VALUES ('3931', '', null, 'historyId', 'String', null, null, 'historyId', 'true', '50', '历史记录ID', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3932', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3933', '', null, 'isenabled', 'Byte', '0', null, 'isenabled', 'false', '3', '可用标志', 'TINYINT', '2866');
INSERT INTO `ts_fields` VALUES ('3934', '', null, 'createTime', 'Date', null, null, 'createTime', 'false', '19', '创建日期', 'DATETIME', '2866');
INSERT INTO `ts_fields` VALUES ('3935', '', null, 'modifier', 'String', null, null, 'modifier', 'true', '50', '修改人姓名', 'VARCHAR', '2866');
INSERT INTO `ts_fields` VALUES ('3936', '', null, 'modifyTime', 'Date', null, null, 'modifyTime', 'true', '19', '修改日期', 'DATETIME', '2866');
INSERT INTO `ts_fields` VALUES ('3937', '', null, 'memberId', 'Long', '0', null, 'memberId', 'false', '19', '会员ID', 'BIGINT', '2872');
INSERT INTO `ts_fields` VALUES ('3938', '', null, 'locked', 'Integer', '0', null, 'locked', 'false', '10', '是否锁定', 'INT', '2872');
INSERT INTO `ts_fields` VALUES ('3939', '', null, 'ecount', 'Integer', '0', null, 'ecount', 'false', '10', '密码错误次数', 'INT', '2872');
INSERT INTO `ts_fields` VALUES ('3940', '', null, 'lockTime', 'String', null, null, 'lockTime', 'true', '50', '锁定时间', 'VARCHAR', '2872');
INSERT INTO `ts_fields` VALUES ('3941', '', null, 'unlockTime', 'String', null, null, 'unlockTime', 'true', '50', '解锁时间', 'VARCHAR', '2872');
INSERT INTO `ts_fields` VALUES ('3942', '', null, 'duration', 'String', null, null, 'duration', 'true', '50', '锁定时长', 'VARCHAR', '2872');
INSERT INTO `ts_fields` VALUES ('3943', '', null, 'logId', 'Long', '0', null, 'logId', 'false', '19', '登录日志ID', 'BIGINT', '2872');
INSERT INTO `ts_fields` VALUES ('3944', '', null, 'shareCode', 'String', null, null, 'shareCode', 'true', '20', '邀请码', 'VARCHAR', '2872');
INSERT INTO `ts_fields` VALUES ('3945', '', null, 'sphone', 'String', null, null, 'sphone', 'true', '20', '推荐人手机号', 'VARCHAR', '2872');
INSERT INTO `ts_fields` VALUES ('3946', '', null, 'rsource', 'Integer', '0', null, 'rsource', 'false', '10', '注册来源', 'INT', '2872');
INSERT INTO `ts_fields` VALUES ('3947', '', null, 'remark', 'String', null, null, 'remark', 'true', '200', '备注', 'VARCHAR', '2872');
INSERT INTO `ts_fields` VALUES ('3948', '', null, 'isenabled', 'Byte', '0', null, 'isenabled', 'false', '3', '可用标志', 'TINYINT', '2872');
INSERT INTO `ts_fields` VALUES ('3949', '', null, 'createTime', 'Date', null, null, 'createTime', 'false', '19', '创建日期', 'DATETIME', '2872');
INSERT INTO `ts_fields` VALUES ('3950', '', null, 'modifier', 'String', null, null, 'modifier', 'true', '50', '修改人姓名', 'VARCHAR', '2872');
INSERT INTO `ts_fields` VALUES ('3951', '', null, 'modifyTime', 'Date', null, null, 'modifyTime', 'true', '19', '修改日期', 'DATETIME', '2872');
INSERT INTO `ts_fields` VALUES ('3952', '', null, 'remark', 'String', null, '', 'remark', 'Y', '200', '备注', 'Varchar', '2878');
INSERT INTO `ts_fields` VALUES ('3953', '', null, 'createTime', 'DateTime', null, '', 'createTime', 'false', null, '创建时间', 'Varchar', '2878');
INSERT INTO `ts_fields` VALUES ('3954', '', null, 'rsource', 'Integer', null, '', 'rsource', 'true', null, '设备来源', 'Int', '2878');
INSERT INTO `ts_fields` VALUES ('3955', '', null, 'nval', 'String', null, '', 'nval', 'true', '100', '新值', 'Varchar', '2878');
INSERT INTO `ts_fields` VALUES ('3956', '', null, 'oval', 'String', null, '', 'oval', 'true', '100', '旧值', 'Varchar', '2878');
INSERT INTO `ts_fields` VALUES ('3957', '', null, 'fname', 'String', null, '', 'fname', 'true', '100', '字段名', 'Varchar', '2878');
INSERT INTO `ts_fields` VALUES ('3958', '', null, 'btype', 'Integer', null, '', 'btype', 'false', null, '业务类型', 'Int', '2878');
INSERT INTO `ts_fields` VALUES ('3959', '', null, 'memberId', 'Long', null, '', 'memberId', 'false', null, '会员ID', 'Bigint', '2878');
INSERT INTO `ts_fields` VALUES ('3960', '', null, 'uptime2', 'Date', null, '', 'uptime2', 'true', null, '更新时间2', 'Datetime', '2884');
INSERT INTO `ts_fields` VALUES ('3961', '', null, 'viewCount', 'Integer', null, '0', 'viewCount', 'false', null, '浏览人数', 'Int', '2884');
INSERT INTO `ts_fields` VALUES ('3962', '', null, 'uptime1', 'Date', null, '', 'uptime1', 'true', null, '更新时间1', 'Datetime', '2884');
INSERT INTO `ts_fields` VALUES ('3963', '', null, 'studyCount', 'Integer', null, '0', 'studyCount', 'false', null, '学习人数', 'Int', '2884');
INSERT INTO `ts_fields` VALUES ('3964', '', null, 'courseId', 'Long', null, '', 'courseId', 'false', null, '课程ID', 'Bigint', '2884');
INSERT INTO `ts_fields` VALUES ('3965', '', null, 'pwdtip', 'Integer', null, '', 'pwdtip', 'false', null, '首次密码提示', 'Int', '2890');
INSERT INTO `ts_fields` VALUES ('3966', '', null, 'iplimit', 'String', null, '', 'iplimit', 'true', '100', '限制ip段', 'Varchar', '2890');
INSERT INTO `ts_fields` VALUES ('3967', '', null, 'indeptId', 'Long', null, '', 'indeptId', 'true', null, '部门ID', 'Bigint', '2890');
INSERT INTO `ts_fields` VALUES ('3968', '', null, 'email', 'String', null, '', 'email', 'true', '50', '邮箱', 'Varchar', '2890');
INSERT INTO `ts_fields` VALUES ('3969', '', null, 'pwdcycle', 'Integer', null, '', 'pwdcycle', 'false', null, '过期周期', 'Int', '2890');
INSERT INTO `ts_fields` VALUES ('3970', '', null, 'userName', 'String', null, '', 'userName', 'false', '30', '账号', 'Varchar', '2890');
INSERT INTO `ts_fields` VALUES ('3971', '', null, 'tel', 'String', null, '', 'tel', 'true', '20', '联系电话', 'Varchar', '2890');
INSERT INTO `ts_fields` VALUES ('3972', '', null, 'leader', 'Long', null, '', 'leader', 'true', null, '直属领导', 'Bigint', '2890');
INSERT INTO `ts_fields` VALUES ('3973', '', null, 'loglimit', 'Integer', null, '', 'loglimit', 'false', null, '登录限制', 'Int', '2890');
INSERT INTO `ts_fields` VALUES ('3974', '', null, 'userId', 'Long', null, '', 'userId', 'false', null, '用户ID', 'Bigint', '2890');
INSERT INTO `ts_fields` VALUES ('3975', '', null, 'accessIds', 'String', null, '', 'accessIds', 'true', '255', '数据过滤ID列表', 'Varchar', '2890');
INSERT INTO `ts_fields` VALUES ('3976', '', null, 'dataLevel', 'Integer', null, '-1', 'dataLevel', 'false', null, '数据访问级别', 'Int', '2890');
INSERT INTO `ts_fields` VALUES ('3977', '', null, 'mnemonic', 'String', null, '', 'mnemonic', 'true', '100', '拼音助记码', 'Varchar', '2890');
INSERT INTO `ts_fields` VALUES ('3978', '', null, 'phone', 'String', null, '', 'phone', 'true', '20', '手机', 'Varchar', '2890');
INSERT INTO `ts_fields` VALUES ('3979', '', null, 'sex', 'Integer', null, '', 'sex', 'false', null, '性别', 'Int', '2890');
INSERT INTO `ts_fields` VALUES ('3980', '', null, 'postId', 'Long', null, '', 'postId', 'true', null, '岗位ID', 'Bigint', '2890');
INSERT INTO `ts_fields` VALUES ('3981', '', null, 'passWord', 'String', null, '', 'passWord', 'true', '30', '密码', 'Varchar', '2890');
INSERT INTO `ts_fields` VALUES ('3982', '', null, 'empName', 'String', null, '', 'empName', 'true', '30', '姓名', 'Varchar', '2890');
INSERT INTO `ts_fields` VALUES ('3983', '', null, 'inempId', 'Long', null, '', 'inempId', 'true', null, '员工ID', 'Bigint', '2890');
INSERT INTO `ts_fields` VALUES ('3984', '', null, 'pwdfail', 'Integer', null, '', 'pwdfail', 'false', null, '启用密码过期', 'Int', '2890');
INSERT INTO `ts_fields` VALUES ('3985', '', null, 'incompId', 'Long', null, '', 'incompId', 'true', null, '公司ID', 'Bigint', '2890');
INSERT INTO `ts_fields` VALUES ('3986', '', null, 'incompId', 'Long', '0', null, 'incompId', 'true', '19', '公司ID', 'BIGINT', '2896');
INSERT INTO `ts_fields` VALUES ('3987', '', null, 'pwdfail', 'Integer', '0', null, 'pwdfail', 'false', '10', '启用密码过期', 'INT', '2896');
INSERT INTO `ts_fields` VALUES ('3988', '', null, 'inempId', 'Long', '0', null, 'inempId', 'true', '19', '员工ID', 'BIGINT', '2896');
INSERT INTO `ts_fields` VALUES ('3989', '', null, 'empName', 'String', null, null, 'empName', 'true', '30', '姓名', 'VARCHAR', '2896');
INSERT INTO `ts_fields` VALUES ('3990', '', null, 'passWord', 'String', null, null, 'passWord', 'true', '30', '密码', 'VARCHAR', '2896');
INSERT INTO `ts_fields` VALUES ('3991', '', null, 'postId', 'Long', '0', null, 'postId', 'true', '19', '岗位ID', 'BIGINT', '2896');
INSERT INTO `ts_fields` VALUES ('3992', '', null, 'sex', 'Integer', '0', null, 'sex', 'false', '10', '性别', 'INT', '2896');
INSERT INTO `ts_fields` VALUES ('3993', '', null, 'phone', 'String', null, null, 'phone', 'true', '20', '手机', 'VARCHAR', '2896');
INSERT INTO `ts_fields` VALUES ('3994', '', null, 'mnemonic', 'String', null, null, 'mnemonic', 'true', '100', '拼音助记码', 'VARCHAR', '2896');
INSERT INTO `ts_fields` VALUES ('3995', '', null, 'dataLevel', 'Integer', '0', null, 'dataLevel', 'false', '10', '数据访问级别', 'INT', '2896');
INSERT INTO `ts_fields` VALUES ('3996', '', null, 'accessIds', 'String', null, null, 'accessIds', 'true', '255', '数据过滤ID列表', 'VARCHAR', '2896');
INSERT INTO `ts_fields` VALUES ('3997', '', null, 'userId', 'Long', '0', null, 'userId', 'false', '19', '用户ID', 'BIGINT', '2896');
INSERT INTO `ts_fields` VALUES ('3998', '', null, 'loglimit', 'Integer', '0', null, 'loglimit', 'false', '10', '登录限制', 'INT', '2896');
INSERT INTO `ts_fields` VALUES ('3999', '', null, 'leader', 'Long', '0', null, 'leader', 'true', '19', '直属领导', 'BIGINT', '2896');
INSERT INTO `ts_fields` VALUES ('4000', '', null, 'tel', 'String', null, null, 'tel', 'true', '20', '联系电话', 'VARCHAR', '2896');
INSERT INTO `ts_fields` VALUES ('4001', '', null, 'userName', 'String', null, null, 'userName', 'false', '30', '账号', 'VARCHAR', '2896');
INSERT INTO `ts_fields` VALUES ('4002', '', null, 'pwdcycle', 'Integer', '0', null, 'pwdcycle', 'false', '10', '过期周期', 'INT', '2896');
INSERT INTO `ts_fields` VALUES ('4003', '', null, 'email', 'String', null, null, 'email', 'true', '50', '邮箱', 'VARCHAR', '2896');
INSERT INTO `ts_fields` VALUES ('4004', '', null, 'indeptId', 'Long', '0', null, 'indeptId', 'true', '19', '部门ID', 'BIGINT', '2896');
INSERT INTO `ts_fields` VALUES ('4005', '', null, 'iplimit', 'String', null, null, 'iplimit', 'true', '100', '限制ip段', 'VARCHAR', '2896');
INSERT INTO `ts_fields` VALUES ('4006', '', null, 'pwdtip', 'Integer', '0', null, 'pwdtip', 'false', '10', '首次密码提示', 'INT', '2896');
INSERT INTO `ts_fields` VALUES ('4007', '', null, 'incompId', 'Long', '0', null, 'incompId', 'true', '19', '公司ID', 'BIGINT', '2902');
INSERT INTO `ts_fields` VALUES ('4008', '', null, 'pwdfail', 'Integer', '0', null, 'pwdfail', 'false', '10', '启用密码过期', 'INT', '2902');
INSERT INTO `ts_fields` VALUES ('4009', '', null, 'inempId', 'Long', '0', null, 'inempId', 'true', '19', '员工ID', 'BIGINT', '2902');
INSERT INTO `ts_fields` VALUES ('4010', '', null, 'empName', 'String', null, null, 'empName', 'true', '30', '姓名', 'VARCHAR', '2902');
INSERT INTO `ts_fields` VALUES ('4011', '', null, 'passWord', 'String', null, null, 'passWord', 'true', '30', '密码', 'VARCHAR', '2902');
INSERT INTO `ts_fields` VALUES ('4012', '', null, 'postId', 'Long', '0', null, 'postId', 'true', '19', '岗位ID', 'BIGINT', '2902');
INSERT INTO `ts_fields` VALUES ('4013', '', null, 'sex', 'Integer', '0', null, 'sex', 'false', '10', '性别', 'INT', '2902');
INSERT INTO `ts_fields` VALUES ('4014', '', null, 'phone', 'String', null, null, 'phone', 'true', '20', '手机', 'VARCHAR', '2902');
INSERT INTO `ts_fields` VALUES ('4015', '', null, 'mnemonic', 'String', null, null, 'mnemonic', 'true', '100', '拼音助记码', 'VARCHAR', '2902');
INSERT INTO `ts_fields` VALUES ('4016', '', null, 'dataLevel', 'Integer', '0', null, 'dataLevel', 'false', '10', '数据访问级别', 'INT', '2902');
INSERT INTO `ts_fields` VALUES ('4017', '', null, 'accessIds', 'String', null, null, 'accessIds', 'true', '255', '数据过滤ID列表', 'VARCHAR', '2902');
INSERT INTO `ts_fields` VALUES ('4018', '', null, 'userId', 'Long', '0', null, 'userId', 'false', '19', '用户ID', 'BIGINT', '2902');
INSERT INTO `ts_fields` VALUES ('4019', '', null, 'loglimit', 'Integer', '0', null, 'loglimit', 'false', '10', '登录限制', 'INT', '2902');
INSERT INTO `ts_fields` VALUES ('4020', '', null, 'leader', 'Long', '0', null, 'leader', 'true', '19', '直属领导', 'BIGINT', '2902');
INSERT INTO `ts_fields` VALUES ('4021', '', null, 'tel', 'String', null, null, 'tel', 'true', '20', '联系电话', 'VARCHAR', '2902');
INSERT INTO `ts_fields` VALUES ('4022', '', null, 'userName', 'String', null, null, 'userName', 'false', '30', '账号', 'VARCHAR', '2902');
INSERT INTO `ts_fields` VALUES ('4023', '', null, 'pwdcycle', 'Integer', '0', null, 'pwdcycle', 'false', '10', '过期周期', 'INT', '2902');
INSERT INTO `ts_fields` VALUES ('4024', '', null, 'email', 'String', null, null, 'email', 'true', '50', '邮箱', 'VARCHAR', '2902');
INSERT INTO `ts_fields` VALUES ('4025', '', null, 'indeptId', 'Long', '0', null, 'indeptId', 'true', '19', '部门ID', 'BIGINT', '2902');
INSERT INTO `ts_fields` VALUES ('4026', '', null, 'iplimit', 'String', null, null, 'iplimit', 'true', '100', '限制ip段', 'VARCHAR', '2902');
INSERT INTO `ts_fields` VALUES ('4027', '', null, 'pwdtip', 'Integer', '0', null, 'pwdtip', 'false', '10', '首次密码提示', 'INT', '2902');
INSERT INTO `ts_fields` VALUES ('4028', '', null, 'incompId', 'Long', '0', null, 'incompId', 'true', '19', '公司ID', 'BIGINT', '2908');
INSERT INTO `ts_fields` VALUES ('4029', '', null, 'pwdfail', 'Integer', '0', null, 'pwdfail', 'false', '10', '启用密码过期', 'INT', '2908');
INSERT INTO `ts_fields` VALUES ('4030', '', null, 'inempId', 'Long', '0', null, 'inempId', 'true', '19', '员工ID', 'BIGINT', '2908');
INSERT INTO `ts_fields` VALUES ('4031', '', null, 'empName', 'String', null, null, 'empName', 'true', '30', '姓名', 'VARCHAR', '2908');
INSERT INTO `ts_fields` VALUES ('4032', '', null, 'passWord', 'String', null, null, 'passWord', 'true', '30', '密码', 'VARCHAR', '2908');
INSERT INTO `ts_fields` VALUES ('4033', '', null, 'postId', 'Long', '0', null, 'postId', 'true', '19', '岗位ID', 'BIGINT', '2908');
INSERT INTO `ts_fields` VALUES ('4034', '', null, 'sex', 'Integer', '0', null, 'sex', 'false', '10', '性别', 'INT', '2908');
INSERT INTO `ts_fields` VALUES ('4035', '', null, 'phone', 'String', null, null, 'phone', 'true', '20', '手机', 'VARCHAR', '2908');
INSERT INTO `ts_fields` VALUES ('4036', '', null, 'mnemonic', 'String', null, null, 'mnemonic', 'true', '100', '拼音助记码', 'VARCHAR', '2908');
INSERT INTO `ts_fields` VALUES ('4037', '', null, 'dataLevel', 'Integer', '0', null, 'dataLevel', 'false', '10', '数据访问级别', 'INT', '2908');
INSERT INTO `ts_fields` VALUES ('4038', '', null, 'accessIds', 'String', null, null, 'accessIds', 'true', '255', '数据过滤ID列表', 'VARCHAR', '2908');
INSERT INTO `ts_fields` VALUES ('4039', '', null, 'userId', 'Long', '0', null, 'userId', 'false', '19', '用户ID', 'BIGINT', '2908');
INSERT INTO `ts_fields` VALUES ('4040', '', null, 'loglimit', 'Integer', '0', null, 'loglimit', 'false', '10', '登录限制', 'INT', '2908');
INSERT INTO `ts_fields` VALUES ('4041', '', null, 'leader', 'Long', '0', null, 'leader', 'true', '19', '直属领导', 'BIGINT', '2908');
INSERT INTO `ts_fields` VALUES ('4042', '', null, 'tel', 'String', null, null, 'tel', 'true', '20', '联系电话', 'VARCHAR', '2908');
INSERT INTO `ts_fields` VALUES ('4043', '', null, 'userName', 'String', null, null, 'userName', 'false', '30', '账号', 'VARCHAR', '2908');
INSERT INTO `ts_fields` VALUES ('4044', '', null, 'pwdcycle', 'Integer', '0', null, 'pwdcycle', 'false', '10', '过期周期', 'INT', '2908');
INSERT INTO `ts_fields` VALUES ('4045', '', null, 'email', 'String', null, null, 'email', 'true', '50', '邮箱', 'VARCHAR', '2908');
INSERT INTO `ts_fields` VALUES ('4046', '', null, 'indeptId', 'Long', '0', null, 'indeptId', 'true', '19', '部门ID', 'BIGINT', '2908');
INSERT INTO `ts_fields` VALUES ('4047', '', null, 'iplimit', 'String', null, null, 'iplimit', 'true', '100', '限制ip段', 'VARCHAR', '2908');
INSERT INTO `ts_fields` VALUES ('4048', '', null, 'pwdtip', 'Integer', '0', null, 'pwdtip', 'false', '10', '首次密码提示', 'INT', '2908');

-- ----------------------------
-- Table structure for ts_menu
-- ----------------------------
DROP TABLE IF EXISTS `ts_menu`;
CREATE TABLE `ts_menu` (
  `menuId` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime NOT NULL,
  `creator` bigint(20) NOT NULL,
  `deptId` bigint(20) NOT NULL,
  `isenabled` tinyint(4) NOT NULL,
  `modifier` bigint(20) DEFAULT NULL,
  `modifytime` datetime DEFAULT NULL,
  `orgid` bigint(20) NOT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `code` varchar(20) NOT NULL,
  `iconCls` varchar(50) DEFAULT NULL,
  `jsArray` varchar(200) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `pid` bigint(20) NOT NULL,
  `sysId` bigint(20) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`menuId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ts_menu
-- ----------------------------

-- ----------------------------
-- Table structure for ts_multiproject
-- ----------------------------
DROP TABLE IF EXISTS `ts_multiproject`;
CREATE TABLE `ts_multiproject` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `actionPack` varchar(200) COLLATE utf8_bin NOT NULL,
  `classes` varchar(50) COLLATE utf8_bin NOT NULL,
  `createTime` datetime NOT NULL,
  `daoPack` varchar(200) COLLATE utf8_bin NOT NULL,
  `dbNames` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `dbType` varchar(255) COLLATE utf8_bin NOT NULL,
  `dbpassword` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `dbusername` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `entityPack` varchar(200) COLLATE utf8_bin NOT NULL,
  `introduction` varchar(100) COLLATE utf8_bin NOT NULL,
  `mapperPath` varchar(200) COLLATE utf8_bin NOT NULL,
  `modifyTime` datetime DEFAULT NULL,
  `pagePath` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `path` varchar(200) COLLATE utf8_bin NOT NULL,
  `remark` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `servicePack` varchar(200) COLLATE utf8_bin NOT NULL,
  `srcName` varchar(50) COLLATE utf8_bin NOT NULL,
  `state` tinyint(4) NOT NULL,
  `webName` varchar(50) COLLATE utf8_bin NOT NULL,
  `dbServer` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `multi` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000010 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ts_multiproject
-- ----------------------------
INSERT INTO `ts_multiproject` VALUES ('100000007', 'com.cmw.controller', 'target/classes', '2017-07-13 20:14:18', 'com.cmw.dao', 'microservice-member', '0', 'root', 'root', 'com.cmw.entity', 'microservice-member', '/src/main/resources/mapper', null, null, 'F:/cmw/idea_devs/glxy-project', '会员微服务', 'com.cmw.service', 'src/main/java', '0', 'WebContent', 'localhost', '0');
INSERT INTO `ts_multiproject` VALUES ('100000008', 'com.cmw.controller', 'target/classes', '2017-07-13 20:19:41', 'com.cmw.dao', 'microservice-msg', '0', 'root', 'root', 'com.cmw.entity', 'microservice-msg', '/src/main/resources/mapper', null, null, 'F:/cmw/idea_devs/glxy-project', '消息微服务', 'com.cmw.service', 'src/main/java', '0', 'WebContent', 'localhost', '0');
INSERT INTO `ts_multiproject` VALUES ('100000009', 'com.cmw.controller', 'target/classes', '2017-07-19 11:58:43', 'com.cmw.dao', 'sports', '0', 'root', 'root', 'com.cmw.entity', 'api-sysbase', '/src/main/resources/mapper', null, null, 'D:/cmw/workspace/idea_dev/Sports-Sass', '系统基础微服务', 'com.cmw.service', 'src/main/java', '0', 'WebContent', '122.114.76.140', '0');

-- ----------------------------
-- Table structure for ts_package
-- ----------------------------
DROP TABLE IF EXISTS `ts_package`;
CREATE TABLE `ts_package` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime NOT NULL,
  `introduction` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `modifyTime` datetime DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `parentId` varchar(80) COLLATE utf8_bin NOT NULL,
  `projectId` bigint(20) NOT NULL,
  `remark` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ts_package
-- ----------------------------
INSERT INTO `ts_package` VALUES ('196', '2017-08-25 22:24:19', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\entity\\cs', null, 'cs', 'com.cmw.entity_3', '3', null, '0');
INSERT INTO `ts_package` VALUES ('197', '2017-08-25 22:24:20', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\entity\\mb', null, 'mb', 'com.cmw.entity_3', '3', null, '0');
INSERT INTO `ts_package` VALUES ('198', '2017-08-25 22:24:20', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\entity\\sys', null, 'sys', 'com.cmw.entity_3', '3', null, '0');
INSERT INTO `ts_package` VALUES ('199', '2017-08-25 22:24:38', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\dao\\inter\\cs', null, 'cs', 'com.cmw.dao.inter_3', '3', null, '1');
INSERT INTO `ts_package` VALUES ('200', '2017-08-25 22:24:39', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\dao\\inter\\mb', null, 'mb', 'com.cmw.dao.inter_3', '3', null, '1');
INSERT INTO `ts_package` VALUES ('201', '2017-08-25 22:24:39', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\dao\\inter\\sys', null, 'sys', 'com.cmw.dao.inter_3', '3', null, '1');
INSERT INTO `ts_package` VALUES ('202', '2017-08-25 22:24:41', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\dao\\impl\\cs', null, 'cs', 'com.cmw.dao.impl_3', '3', null, '1');
INSERT INTO `ts_package` VALUES ('203', '2017-08-25 22:24:41', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\dao\\impl\\mb', null, 'mb', 'com.cmw.dao.impl_3', '3', null, '1');
INSERT INTO `ts_package` VALUES ('204', '2017-08-25 22:24:41', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\dao\\impl\\sys', null, 'sys', 'com.cmw.dao.impl_3', '3', null, '1');
INSERT INTO `ts_package` VALUES ('205', '2017-08-25 22:24:43', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\service\\inter\\cs', null, 'cs', 'com.cmw.service.inter_3', '3', null, '2');
INSERT INTO `ts_package` VALUES ('206', '2017-08-25 22:24:43', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\service\\inter\\mb', null, 'mb', 'com.cmw.service.inter_3', '3', null, '2');
INSERT INTO `ts_package` VALUES ('207', '2017-08-25 22:24:43', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\service\\inter\\sys', null, 'sys', 'com.cmw.service.inter_3', '3', null, '2');
INSERT INTO `ts_package` VALUES ('208', '2017-08-25 22:24:45', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\service\\impl\\cache', null, 'cache', 'com.cmw.service.impl_3', '3', null, '2');
INSERT INTO `ts_package` VALUES ('209', '2017-08-25 22:24:46', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\service\\impl\\cs', null, 'cs', 'com.cmw.service.impl_3', '3', null, '2');
INSERT INTO `ts_package` VALUES ('210', '2017-08-25 22:24:46', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\service\\impl\\mb', null, 'mb', 'com.cmw.service.impl_3', '3', null, '2');
INSERT INTO `ts_package` VALUES ('211', '2017-08-25 22:24:46', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\service\\impl\\sys', null, 'sys', 'com.cmw.service.impl_3', '3', null, '2');
INSERT INTO `ts_package` VALUES ('212', '2017-08-25 22:24:48', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\service\\impl\\workflow', null, 'workflow', 'com.cmw.service.impl_3', '3', null, '2');
INSERT INTO `ts_package` VALUES ('213', '2017-08-25 22:24:49', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\action\\cs', null, 'cs', 'com.cmw.action_3', '3', null, '3');
INSERT INTO `ts_package` VALUES ('214', '2017-08-25 22:24:49', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\action\\mb', null, 'mb', 'com.cmw.action_3', '3', null, '3');
INSERT INTO `ts_package` VALUES ('215', '2017-08-25 22:24:49', 'F:\\cmw\\myworks\\education_sys\\src\\com\\cmw\\action\\sys', null, 'sys', 'com.cmw.action_3', '3', null, '3');

-- ----------------------------
-- Table structure for ts_project
-- ----------------------------
DROP TABLE IF EXISTS `ts_project`;
CREATE TABLE `ts_project` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `actionPack` varchar(200) COLLATE utf8_bin NOT NULL,
  `classes` varchar(50) COLLATE utf8_bin NOT NULL,
  `createTime` datetime NOT NULL,
  `daoPack` varchar(200) COLLATE utf8_bin NOT NULL,
  `dbNames` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `dbType` varchar(255) COLLATE utf8_bin NOT NULL,
  `dbpassword` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `dbusername` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `entityPack` varchar(200) COLLATE utf8_bin NOT NULL,
  `introduction` varchar(100) COLLATE utf8_bin NOT NULL,
  `modifyTime` datetime DEFAULT NULL,
  `pagePath` varchar(200) COLLATE utf8_bin NOT NULL,
  `path` varchar(200) COLLATE utf8_bin NOT NULL,
  `remark` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `servicePack` varchar(200) COLLATE utf8_bin NOT NULL,
  `srcName` varchar(50) COLLATE utf8_bin NOT NULL,
  `state` tinyint(4) NOT NULL,
  `webName` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ts_project
-- ----------------------------
INSERT INTO `ts_project` VALUES ('3', 'com.cmw.action', 'classes', '2017-08-02 19:57:48', 'com.cmw.dao', 'education_sys', '0', 'root', 'root', 'com.cmw.entity', 'education_sys', null, '/pages/app/', 'F:\\cmw\\myworks\\education_sys', null, 'com.cmw.service', 'src', '1', 'WebContent');

-- ----------------------------
-- Table structure for ts_srcfile
-- ----------------------------
DROP TABLE IF EXISTS `ts_srcfile`;
CREATE TABLE `ts_srcfile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `author` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  `creatorDate` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `description` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `extendcls` varchar(80) COLLATE utf8_bin DEFAULT NULL,
  `intercls` varchar(80) COLLATE utf8_bin DEFAULT NULL,
  `modifyTime` datetime DEFAULT NULL,
  `name` varchar(80) COLLATE utf8_bin NOT NULL,
  `parentId` varchar(80) COLLATE utf8_bin NOT NULL,
  `path` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `projectId` bigint(20) NOT NULL,
  `remark` longtext COLLATE utf8_bin,
  `tabname` varchar(80) COLLATE utf8_bin DEFAULT NULL,
  `type` int(11) NOT NULL,
  `bussType` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2914 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ts_srcfile
-- ----------------------------
INSERT INTO `ts_srcfile` VALUES ('2890', '程明卫', '2019-03-26 15:02:38', '2019-03-26T00:00:00', '用户信息', 'BaseEntity', null, null, 'UserEntity.java', '-1', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/entity/UserEntity.java', '100000009', 0x636F6D2E636D772E656E74697479, 'ts_User', '0', '1');
INSERT INTO `ts_srcfile` VALUES ('2891', '程明卫', '2019-03-26 15:02:43', '2019-03-26T00:00:00', '用户信息', null, null, null, 'UserDao.java', '204', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/dao/UserDao.java', '100000009', 0x636F6D2E636D772E64616F, null, '1', '0');
INSERT INTO `ts_srcfile` VALUES ('2892', '程明卫', '2019-03-26 15:02:44', '2019-03-26T00:00:00', '用户信息', null, null, null, 'UserService.java', '212', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/service//inter/UserService.java', '100000009', 0x636F6D2E636D772E736572766963652E696E746572, null, '2', '0');
INSERT INTO `ts_srcfile` VALUES ('2893', '程明卫', '2019-03-26 15:02:44', '2019-03-26T00:00:00', '用户信息', null, null, null, 'UserServiceImpl.java', '212', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/service//impl/UserServiceImpl.java', '100000009', 0x636F6D2E636D772E736572766963652E696D706C, 'userService', '2', '0');
INSERT INTO `ts_srcfile` VALUES ('2894', '程明卫', '2019-03-26 15:02:44', '2019-03-26T00:00:00', '用户信息', null, null, null, 'UserController.java', '215', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/controller/web/UserController.java', '100000009', 0xE88EB7E58F96E794A8E688B7E4BFA1E681AFE58897E8A1A82C75736572557365725F6C6973742E616374696F6E3BE88EB7E58F96E794A8E688B7E4BFA1E681AFE4BFA1E681AF2C75736572557365725F6765742E616374696F6E3BE4BF9DE5AD98E794A8E688B7E4BFA1E681AF2C75736572557365725F736176652E616374696F6E3BE696B0E5A29EE794A8E688B7E4BFA1E681AF2C75736572557365725F6164642E616374696F6E3BE588A0E999A4E794A8E688B7E4BFA1E681AF2C75736572557365725F64656C6574652E616374696F6E3BE590AFE794A8E794A8E688B7E4BFA1E681AF2C75736572557365725F656E61626C65642E616374696F6E3BE7A681E794A8E794A8E688B7E4BFA1E681AF2C75736572557365725F64697361626C65642E616374696F6E3B, null, '3', '0');
INSERT INTO `ts_srcfile` VALUES ('2895', '程明卫', '2019-03-26 15:02:44', '2019-03-26T00:00:00', '用户信息', null, null, null, 'UserMapper.xml', '-1', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/resources/mapper/UserMapper.xml', '100000009', null, null, '5', '0');
INSERT INTO `ts_srcfile` VALUES ('2896', '程明卫', '2019-03-26 15:09:42', '2019-03-26 15:09:42', '用户信息', null, null, null, 'UserEntity.java', '-1', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/entity/UserEntity.java', '100000009', 0x636F6D2E636D772E656E74697479, 'ts_user', '0', '0');
INSERT INTO `ts_srcfile` VALUES ('2897', '程明卫', '2019-03-26 15:10:12', '2019-03-26 15:09:42', '用户信息', null, null, null, 'UserDao.java', '204', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/dao/UserDao.java', '100000009', 0x636F6D2E636D772E64616F, null, '1', '0');
INSERT INTO `ts_srcfile` VALUES ('2898', '程明卫', '2019-03-26 15:10:12', '2019-03-26 15:09:42', '用户信息', null, null, null, 'UserService.java', '212', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/service//inter/UserService.java', '100000009', 0x636F6D2E636D772E736572766963652E696E746572, null, '2', '0');
INSERT INTO `ts_srcfile` VALUES ('2899', '程明卫', '2019-03-26 15:10:12', '2019-03-26 15:09:42', '用户信息', null, null, null, 'UserServiceImpl.java', '212', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/service//impl/UserServiceImpl.java', '100000009', 0x636F6D2E636D772E736572766963652E696D706C, 'userService', '2', '0');
INSERT INTO `ts_srcfile` VALUES ('2900', '程明卫', '2019-03-26 15:10:12', '2019-03-26 15:09:42', '用户信息', null, null, null, 'UserController.java', '215', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/controller/web/UserController.java', '100000009', 0xE88EB7E58F96E794A8E688B7E4BFA1E681AFE58897E8A1A82C75736572557365725F6C6973742E616374696F6E3BE88EB7E58F96E794A8E688B7E4BFA1E681AFE4BFA1E681AF2C75736572557365725F6765742E616374696F6E3BE4BF9DE5AD98E794A8E688B7E4BFA1E681AF2C75736572557365725F736176652E616374696F6E3BE696B0E5A29EE794A8E688B7E4BFA1E681AF2C75736572557365725F6164642E616374696F6E3BE588A0E999A4E794A8E688B7E4BFA1E681AF2C75736572557365725F64656C6574652E616374696F6E3BE590AFE794A8E794A8E688B7E4BFA1E681AF2C75736572557365725F656E61626C65642E616374696F6E3BE7A681E794A8E794A8E688B7E4BFA1E681AF2C75736572557365725F64697361626C65642E616374696F6E3B, null, '3', '0');
INSERT INTO `ts_srcfile` VALUES ('2901', '程明卫', '2019-03-26 15:10:12', '2019-03-26 15:09:42', '用户信息', null, null, null, 'UserMapper.xml', '-1', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/resources/mapper/UserMapper.xml', '100000009', null, null, '5', '0');
INSERT INTO `ts_srcfile` VALUES ('2902', '程明卫', '2019-03-26 15:11:07', '2019-03-26 15:11:07', '用户信息', null, null, null, 'UserEntity.java', '-1', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/entity/UserEntity.java', '100000009', 0x636F6D2E636D772E656E74697479, 'ts_user', '0', '0');
INSERT INTO `ts_srcfile` VALUES ('2903', '程明卫', '2019-03-26 15:11:19', '2019-03-26 15:11:07', '用户信息', null, null, null, 'UserDao.java', '204', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/dao/UserDao.java', '100000009', 0x636F6D2E636D772E64616F, null, '1', '0');
INSERT INTO `ts_srcfile` VALUES ('2904', '程明卫', '2019-03-26 15:11:19', '2019-03-26 15:11:07', '用户信息', null, null, null, 'UserService.java', '212', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/service//inter/UserService.java', '100000009', 0x636F6D2E636D772E736572766963652E696E746572, null, '2', '0');
INSERT INTO `ts_srcfile` VALUES ('2905', '程明卫', '2019-03-26 15:11:19', '2019-03-26 15:11:07', '用户信息', null, null, null, 'UserServiceImpl.java', '212', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/service//impl/UserServiceImpl.java', '100000009', 0x636F6D2E636D772E736572766963652E696D706C, 'userService', '2', '0');
INSERT INTO `ts_srcfile` VALUES ('2906', '程明卫', '2019-03-26 15:11:19', '2019-03-26 15:11:07', '用户信息', null, null, null, 'UserController.java', '215', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/controller/web/UserController.java', '100000009', 0xE88EB7E58F96E794A8E688B7E4BFA1E681AFE58897E8A1A82C75736572557365725F6C6973742E616374696F6E3BE88EB7E58F96E794A8E688B7E4BFA1E681AFE4BFA1E681AF2C75736572557365725F6765742E616374696F6E3BE4BF9DE5AD98E794A8E688B7E4BFA1E681AF2C75736572557365725F736176652E616374696F6E3BE696B0E5A29EE794A8E688B7E4BFA1E681AF2C75736572557365725F6164642E616374696F6E3BE588A0E999A4E794A8E688B7E4BFA1E681AF2C75736572557365725F64656C6574652E616374696F6E3BE590AFE794A8E794A8E688B7E4BFA1E681AF2C75736572557365725F656E61626C65642E616374696F6E3BE7A681E794A8E794A8E688B7E4BFA1E681AF2C75736572557365725F64697361626C65642E616374696F6E3B, null, '3', '0');
INSERT INTO `ts_srcfile` VALUES ('2907', '程明卫', '2019-03-26 15:11:20', '2019-03-26 15:11:07', '用户信息', null, null, null, 'UserMapper.xml', '-1', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/resources/mapper/UserMapper.xml', '100000009', null, null, '5', '0');
INSERT INTO `ts_srcfile` VALUES ('2908', '程明卫', '2019-03-26 15:14:25', '2019-03-26 15:14:25', '用户信息', null, null, null, 'UserEntity.java', '-1', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/entity/UserEntity.java', '100000009', 0x636F6D2E636D772E656E74697479, 'ts_user', '0', '0');
INSERT INTO `ts_srcfile` VALUES ('2909', '程明卫', '2019-03-26 15:14:31', '2019-03-26 15:14:25', '用户信息', null, null, null, 'UserDao.java', '204', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/dao/UserDao.java', '100000009', 0x636F6D2E636D772E64616F, null, '1', '0');
INSERT INTO `ts_srcfile` VALUES ('2910', '程明卫', '2019-03-26 15:14:31', '2019-03-26 15:14:25', '用户信息', null, null, null, 'UserService.java', '212', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/service//inter/UserService.java', '100000009', 0x636F6D2E636D772E736572766963652E696E746572, null, '2', '0');
INSERT INTO `ts_srcfile` VALUES ('2911', '程明卫', '2019-03-26 15:14:31', '2019-03-26 15:14:25', '用户信息', null, null, null, 'UserServiceImpl.java', '212', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/service//impl/UserServiceImpl.java', '100000009', 0x636F6D2E636D772E736572766963652E696D706C, 'userService', '2', '0');
INSERT INTO `ts_srcfile` VALUES ('2912', '程明卫', '2019-03-26 15:14:31', '2019-03-26 15:14:25', '用户信息', null, null, null, 'UserController.java', '215', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/java/com/cmw/controller/web/UserController.java', '100000009', 0xE88EB7E58F96E794A8E688B7E4BFA1E681AFE58897E8A1A82C75736572557365725F6C6973742E616374696F6E3BE88EB7E58F96E794A8E688B7E4BFA1E681AFE4BFA1E681AF2C75736572557365725F6765742E616374696F6E3BE4BF9DE5AD98E794A8E688B7E4BFA1E681AF2C75736572557365725F736176652E616374696F6E3BE696B0E5A29EE794A8E688B7E4BFA1E681AF2C75736572557365725F6164642E616374696F6E3BE588A0E999A4E794A8E688B7E4BFA1E681AF2C75736572557365725F64656C6574652E616374696F6E3BE590AFE794A8E794A8E688B7E4BFA1E681AF2C75736572557365725F656E61626C65642E616374696F6E3BE7A681E794A8E794A8E688B7E4BFA1E681AF2C75736572557365725F64697361626C65642E616374696F6E3B, null, '3', '0');
INSERT INTO `ts_srcfile` VALUES ('2913', '程明卫', '2019-03-26 15:14:32', '2019-03-26 15:14:25', '用户信息', null, null, null, 'UserMapper.xml', '-1', 'D:/cmw/workspace/idea_dev/Sports-Sass/api-sysbase/src/main/resources/mapper/UserMapper.xml', '100000009', null, null, '5', '0');

-- ----------------------------
-- Table structure for ts_system
-- ----------------------------
DROP TABLE IF EXISTS `ts_system`;
CREATE TABLE `ts_system` (
  `systemId` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime NOT NULL,
  `creator` bigint(20) NOT NULL,
  `deptId` bigint(20) NOT NULL,
  `isenabled` tinyint(4) NOT NULL,
  `modifier` bigint(20) DEFAULT NULL,
  `modifytime` datetime DEFAULT NULL,
  `orgid` bigint(20) NOT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `style` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`systemId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ts_system
-- ----------------------------

-- ----------------------------
-- Table structure for ts_tabcmns
-- ----------------------------
DROP TABLE IF EXISTS `ts_tabcmns`;
CREATE TABLE `ts_tabcmns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bind` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `colName` varchar(50) COLLATE utf8_bin NOT NULL,
  `dataType` varchar(50) COLLATE utf8_bin NOT NULL,
  `decimalnum` int(11) DEFAULT NULL,
  `defaultval` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `isnull` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `len` int(11) DEFAULT NULL,
  `remark` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `tabId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ts_tabcmns
-- ----------------------------
INSERT INTO `ts_tabcmns` VALUES ('1', null, 'remark', 'VARCHAR', null, null, 'true', '200', '备注', '1');
INSERT INTO `ts_tabcmns` VALUES ('2', null, 'rsource', 'INT', '0', null, 'true', '10', '设备来源', '1');
INSERT INTO `ts_tabcmns` VALUES ('3', null, 'xstatus', 'INT', '0', null, 'false', '10', '登录状态', '1');
INSERT INTO `ts_tabcmns` VALUES ('4', null, 'ip', 'VARCHAR', null, null, 'true', '75', '登录IP', '1');
INSERT INTO `ts_tabcmns` VALUES ('5', null, 'loginTime', 'VARCHAR', null, null, 'false', '50', '登录时间', '1');
INSERT INTO `ts_tabcmns` VALUES ('6', null, 'account', 'VARCHAR', null, null, 'false', '50', '用户名', '1');
INSERT INTO `ts_tabcmns` VALUES ('7', null, 'memberId', 'BIGINT', '0', null, 'false', '19', '会员ID', '1');
INSERT INTO `ts_tabcmns` VALUES ('8', '1', 'id', 'BIGINT', '0', null, 'false', '19', '登录日志Id', '1');
INSERT INTO `ts_tabcmns` VALUES ('9', null, 'remark', 'VARCHAR', null, null, 'true', '200', '备注', '2');
INSERT INTO `ts_tabcmns` VALUES ('10', null, 'otype', 'INT', '0', null, 'false', '10', '退出方式', '2');
INSERT INTO `ts_tabcmns` VALUES ('11', null, 'rsource', 'INT', '0', null, 'true', '10', '设备来源', '2');
INSERT INTO `ts_tabcmns` VALUES ('12', null, 'ip', 'VARCHAR', null, null, 'true', '75', '登录IP', '2');
INSERT INTO `ts_tabcmns` VALUES ('13', null, 'outTime', 'DATETIME', null, null, 'false', '19', '退出时间', '2');
INSERT INTO `ts_tabcmns` VALUES ('14', null, 'loginLogId', 'BIGINT', '0', null, 'false', '19', '登录日志ID', '2');
INSERT INTO `ts_tabcmns` VALUES ('15', null, 'memberId', 'BIGINT', '0', null, 'false', '19', '会员ID', '2');
INSERT INTO `ts_tabcmns` VALUES ('16', '1', 'id', 'BIGINT', '0', null, 'false', '19', '登出日志Id', '2');
INSERT INTO `ts_tabcmns` VALUES ('17', null, 'modifyTime', 'DATETIME', null, null, 'true', '19', '修改日期', '3');
INSERT INTO `ts_tabcmns` VALUES ('18', null, 'modifier', 'VARCHAR', null, null, 'true', '50', '修改人姓名', '3');
INSERT INTO `ts_tabcmns` VALUES ('19', null, 'createTime', 'DATETIME', null, null, 'false', '19', '创建日期', '3');
INSERT INTO `ts_tabcmns` VALUES ('20', null, 'isenabled', 'TINYINT', '0', null, 'false', '3', '可用标志', '3');
INSERT INTO `ts_tabcmns` VALUES ('21', null, 'remark', 'VARCHAR', null, null, 'true', '200', '备注', '3');
INSERT INTO `ts_tabcmns` VALUES ('22', null, 'historyId', 'VARCHAR', null, null, 'true', '50', '历史记录ID', '3');
INSERT INTO `ts_tabcmns` VALUES ('23', null, 'mtype', 'INT', '0', null, 'false', '10', '会员类型', '3');
INSERT INTO `ts_tabcmns` VALUES ('24', null, 'imgPath', 'VARCHAR', null, null, 'true', '150', '用户头像', '3');
INSERT INTO `ts_tabcmns` VALUES ('25', null, 'mlevel', 'BIGINT', '0', null, 'false', '19', '会员等级', '3');
INSERT INTO `ts_tabcmns` VALUES ('26', null, 'phonePass', 'TINYINT', '0', '0', 'true', '3', '手机是否验证', '3');
INSERT INTO `ts_tabcmns` VALUES ('27', null, 'emailPass', 'TINYINT', '0', '0', 'true', '3', '邮箱是否验证', '3');
INSERT INTO `ts_tabcmns` VALUES ('28', null, 'cardnoPass', 'TINYINT', '0', '0', 'true', '3', '身份证是否验证', '3');
INSERT INTO `ts_tabcmns` VALUES ('29', null, 'phone', 'VARCHAR', null, null, 'true', '50', '手机', '3');
INSERT INTO `ts_tabcmns` VALUES ('30', null, 'email', 'VARCHAR', null, null, 'true', '50', '邮箱', '3');
INSERT INTO `ts_tabcmns` VALUES ('31', null, 'cardno', 'VARCHAR', null, null, 'true', '20', '身份证号码', '3');
INSERT INTO `ts_tabcmns` VALUES ('32', null, 'rname', 'VARCHAR', null, null, 'true', '50', '会员姓名', '3');
INSERT INTO `ts_tabcmns` VALUES ('33', null, 'pwd', 'VARCHAR', null, null, 'false', '100', '密码', '3');
INSERT INTO `ts_tabcmns` VALUES ('34', null, 'account', 'VARCHAR', null, null, 'false', '50', '用户名', '3');
INSERT INTO `ts_tabcmns` VALUES ('35', '1', 'id', 'BIGINT', '0', null, 'false', '19', '会员信息Id', '3');
INSERT INTO `ts_tabcmns` VALUES ('36', null, 'modifyTime', 'DATETIME', null, null, 'true', '19', '修改日期', '4');
INSERT INTO `ts_tabcmns` VALUES ('37', null, 'modifier', 'VARCHAR', null, null, 'true', '50', '修改人姓名', '4');
INSERT INTO `ts_tabcmns` VALUES ('38', null, 'createTime', 'DATETIME', null, null, 'false', '19', '创建日期', '4');
INSERT INTO `ts_tabcmns` VALUES ('39', null, 'isenabled', 'TINYINT', '0', null, 'false', '3', '可用标志', '4');
INSERT INTO `ts_tabcmns` VALUES ('40', null, 'remark', 'VARCHAR', null, null, 'true', '200', '备注', '4');
INSERT INTO `ts_tabcmns` VALUES ('41', null, 'rsource', 'INT', '0', null, 'false', '10', '注册来源', '4');
INSERT INTO `ts_tabcmns` VALUES ('42', null, 'sphone', 'VARCHAR', null, null, 'true', '20', '推荐人手机号', '4');
INSERT INTO `ts_tabcmns` VALUES ('43', null, 'shareCode', 'VARCHAR', null, null, 'true', '20', '邀请码', '4');
INSERT INTO `ts_tabcmns` VALUES ('44', null, 'logId', 'BIGINT', '0', null, 'false', '19', '登录日志ID', '4');
INSERT INTO `ts_tabcmns` VALUES ('45', null, 'duration', 'VARCHAR', null, null, 'true', '50', '锁定时长', '4');
INSERT INTO `ts_tabcmns` VALUES ('46', null, 'unlockTime', 'VARCHAR', null, null, 'true', '50', '解锁时间', '4');
INSERT INTO `ts_tabcmns` VALUES ('47', null, 'lockTime', 'VARCHAR', null, null, 'true', '50', '锁定时间', '4');
INSERT INTO `ts_tabcmns` VALUES ('48', null, 'ecount', 'INT', '0', null, 'false', '10', '密码错误次数', '4');
INSERT INTO `ts_tabcmns` VALUES ('49', null, 'locked', 'INT', '0', null, 'false', '10', '是否锁定', '4');
INSERT INTO `ts_tabcmns` VALUES ('50', null, 'memberId', 'BIGINT', '0', null, 'false', '19', '会员ID', '4');
INSERT INTO `ts_tabcmns` VALUES ('51', '1', 'id', 'BIGINT', '0', null, 'false', '19', '会员详细信息Id', '4');
INSERT INTO `ts_tabcmns` VALUES ('52', null, 'pwdtip', 'INT', '0', null, 'false', '10', '首次密码提示', '5');
INSERT INTO `ts_tabcmns` VALUES ('53', null, 'iplimit', 'VARCHAR', null, null, 'true', '100', '限制ip段', '5');
INSERT INTO `ts_tabcmns` VALUES ('54', null, 'indeptId', 'BIGINT', '0', null, 'true', '19', '部门ID', '5');
INSERT INTO `ts_tabcmns` VALUES ('55', null, 'email', 'VARCHAR', null, null, 'true', '50', '邮箱', '5');
INSERT INTO `ts_tabcmns` VALUES ('56', null, 'pwdcycle', 'INT', '0', null, 'false', '10', '过期周期', '5');
INSERT INTO `ts_tabcmns` VALUES ('57', null, 'userName', 'VARCHAR', null, null, 'false', '30', '账号', '5');
INSERT INTO `ts_tabcmns` VALUES ('58', null, 'tel', 'VARCHAR', null, null, 'true', '20', '联系电话', '5');
INSERT INTO `ts_tabcmns` VALUES ('59', null, 'leader', 'BIGINT', '0', null, 'true', '19', '直属领导', '5');
INSERT INTO `ts_tabcmns` VALUES ('60', null, 'loglimit', 'INT', '0', null, 'false', '10', '登录限制', '5');
INSERT INTO `ts_tabcmns` VALUES ('61', null, 'userId', 'BIGINT', '0', null, 'false', '19', '用户ID', '5');
INSERT INTO `ts_tabcmns` VALUES ('62', null, 'accessIds', 'VARCHAR', null, null, 'true', '255', '数据过滤ID列表', '5');
INSERT INTO `ts_tabcmns` VALUES ('63', null, 'dataLevel', 'INT', '0', null, 'false', '10', '数据访问级别', '5');
INSERT INTO `ts_tabcmns` VALUES ('64', null, 'mnemonic', 'VARCHAR', null, null, 'true', '100', '拼音助记码', '5');
INSERT INTO `ts_tabcmns` VALUES ('65', null, 'phone', 'VARCHAR', null, null, 'true', '20', '手机', '5');
INSERT INTO `ts_tabcmns` VALUES ('66', null, 'sex', 'INT', '0', null, 'false', '10', '性别', '5');
INSERT INTO `ts_tabcmns` VALUES ('67', null, 'postId', 'BIGINT', '0', null, 'true', '19', '岗位ID', '5');
INSERT INTO `ts_tabcmns` VALUES ('68', null, 'passWord', 'VARCHAR', null, null, 'true', '30', '密码', '5');
INSERT INTO `ts_tabcmns` VALUES ('69', null, 'empName', 'VARCHAR', null, null, 'true', '30', '姓名', '5');
INSERT INTO `ts_tabcmns` VALUES ('70', null, 'inempId', 'BIGINT', '0', null, 'true', '19', '员工ID', '5');
INSERT INTO `ts_tabcmns` VALUES ('71', null, 'pwdfail', 'INT', '0', null, 'false', '10', '启用密码过期', '5');
INSERT INTO `ts_tabcmns` VALUES ('72', null, 'incompId', 'BIGINT', '0', null, 'true', '19', '公司ID', '5');

-- ----------------------------
-- Table structure for ts_tabinfo
-- ----------------------------
DROP TABLE IF EXISTS `ts_tabinfo`;
CREATE TABLE `ts_tabinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime NOT NULL,
  `modifyTime` datetime DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `projectId` bigint(20) NOT NULL,
  `remark` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ts_tabinfo
-- ----------------------------
INSERT INTO `ts_tabinfo` VALUES ('5', '2019-03-26 15:03:38', null, 'ts_user', '100000009', '用户信息');

-- ----------------------------
-- Table structure for ts_user
-- ----------------------------
DROP TABLE IF EXISTS `ts_user`;
CREATE TABLE `ts_user` (
  `userId` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime NOT NULL,
  `creator` bigint(20) NOT NULL,
  `deptId` bigint(20) NOT NULL,
  `empId` bigint(20) DEFAULT NULL,
  `isenabled` tinyint(4) NOT NULL,
  `modifier` bigint(20) DEFAULT NULL,
  `modifytime` datetime DEFAULT NULL,
  `orgid` bigint(20) NOT NULL,
  `remark` longtext COLLATE utf8_bin,
  `accessIds` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `accessNames` longtext COLLATE utf8_bin,
  `code` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `dataLevel` tinyint(4) DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `empName` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `i18n` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `incompId` bigint(20) DEFAULT NULL,
  `indeptId` bigint(20) DEFAULT NULL,
  `inempId` bigint(20) DEFAULT NULL,
  `iplimit` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `isSystem` int(11) DEFAULT NULL,
  `leader` bigint(20) DEFAULT NULL,
  `loglimit` int(11) DEFAULT NULL,
  `mnemonic` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `passWord` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `postId` bigint(20) DEFAULT NULL,
  `pwdcycle` int(11) DEFAULT NULL,
  `pwdfail` int(11) DEFAULT NULL,
  `pwdtip` int(11) DEFAULT NULL,
  `sex` int(11) NOT NULL,
  `tel` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `userName` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of ts_user
-- ----------------------------
