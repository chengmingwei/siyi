package com.cmw.service.impl.cache;

import java.io.Serializable;

import org.apache.log4j.Logger;

import com.cmw.core.base.exception.ServiceException;

/**
 * 系统参数缓存器
 * @author chengmingwei
 * @date 2014-03-08 下午 5:22Ø
 */
@SuppressWarnings("serial")
public class SysparamsCache implements Serializable {
	static Logger logger = Logger.getLogger(SysparamsCache.class);
	
	/**
	 * 根据业务引用键获取系统参数列表
	 * @param recodes 字符串（业务引用键列表，多个以“，”分隔）
	 */
	public static boolean compare(String recode, int val) throws ServiceException{
		return true;
	}
	
}
