package com.cmw.service.impl.sys;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.service.AbsService;
import com.cmw.dao.inter.sys.ClassInfoDaoInter;
import com.cmw.entity.sys.ClassInfoEntity;
import com.cmw.service.inter.sys.ClassInfoService;
/**
 *  类附加信息Service实现类
 * @author ddd
 *
 */
@Service("classInfoService")
public class ClassInfoServiceImpl extends AbsService<ClassInfoEntity, Long> implements  ClassInfoService {
	@Autowired
	private ClassInfoDaoInter classInfoDao;
	@Override
	public GenericDaoInter<ClassInfoEntity, Long> getDao() {
		return classInfoDao;
	}

}
