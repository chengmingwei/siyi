package com.cmw.service.impl.sys;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.kit.file.FileUtil;
import com.cmw.core.util.DateUtil;
import com.cmw.core.util.StringHandler;
import com.cmw.core.util.SystemUtils;
import com.cmw.entity.sys.FieldsEntity;
import com.cmw.entity.sys.MultiProjectEntity;
import com.cmw.entity.sys.PackageEntity;
import com.cmw.entity.sys.SrcFileEntity;
import com.cmw.service.inter.sys.SysmbolTempService;
/**
 * 多模块项目模板文件实现类
 * @author chengmingwei
 * @date 2017-06-08 15:59
 */
public class MultiTemplateServiceImpl implements SysmbolTempService {
	/**
	 * 放当前实体的父包列表
	 */
	private List<PackageEntity> parentPacks;
	
	public static final String ENTITY_KEY = "entity";
	public static final String DAOINTER_KEY = "daoInter";
	public static final String DAOIMPL_KEY = "daoImpl";
	public static final String SERVICE_KEY = "service";
	public static final String SERVICEIMPL_KEY = "serviceImpl";
	public static final String ACTION_KEY = "action";
	public static final String MAPPER_KEY = "mapper";
	static char sp = File.separatorChar;
	/**
	 * resource.properties 中的实体继承类列表
	 */
	private static final String ENTITY_EXTENDS_RESOURCE = "entity_extends";
	/** 
	 * 存放类继承的类
	 */
	private static Map<String,String> extendsClsMap = new HashMap<String, String>();
	/**
	 * Entity 模板文件字符串
	 */
	private static String entityTemp = null;
	/**
	 * Dao接口 模板文件字符串
	 */
	private static String daoInterTemp = null;
	/**
	 * Dao实现类 模板文件字符串
	 */
	private static String daoImplTemp = null;
	/**
	 * Service接口 模板文件字符串
	 */
	private static String serviceTemp = null;
	/**
	 * Service实现类 模板文件字符串
	 */
	private static String serviceImplTemp = null;
	/**
	 * 模板文件字符串
	 */
	private static String actionTemp = null;
	/**
	 * MyBatis XML文件模板 Mapper文件字符串
	 */
	private static String mapperTemp = null;
	
	
	
	static{
		//---------> Entity 继承类初始化
		String entitysSups = StringHandler.GetResValue(ENTITY_EXTENDS_RESOURCE);
		if(StringHandler.isValidStr(entitysSups)){
			String[] entity_kvs = entitysSups.split(";");
			for(String entity_kv : entity_kvs){
				String[] kv = entity_kv.split(":");
				extendsClsMap.put(kv[0], kv[1]);
			}
		}
		
//		String classPath = ClassLoader.getSystemResource("").getPath();
		String classPath = StringHandler.getClassPath();//"F:\\dev\\smartplatform\\WebContent\\WEB-INF\\classes\\";
		if(SystemUtils.isMacOS()){
			classPath = "/"+classPath;
		}
		System.out.println("classPath="+classPath);
		String filePath = classPath+"template_v2"+sp+"javaTemplate"+sp+"EntityTemplate.tp";
		System.out.println("entityTemp.filePath="+filePath);
		entityTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template_v2"+sp+"javaTemplate"+sp+"DaoInterTemplate.tp";
		daoInterTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template_v2"+sp+"javaTemplate"+sp+"DaoImplTemplate.tp";
		daoImplTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template_v2"+sp+"javaTemplate"+sp+"ServiceTemplate.tp";
		serviceTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template_v2"+sp+"javaTemplate"+sp+"ServiceImplTemplate.tp";
		serviceImplTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template_v2"+sp+"javaTemplate"+sp+"ActionTemplate.tp";
		actionTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template_v2"+sp+"javaTemplate"+sp+"MapperTemplate.tp";
		mapperTemp = FileUtil.ReadFileToStr(filePath);
	}
	
	/**
	 * 生成Entity文件，如果有选中要生成 Dao,Service,Action 的话，
	 * 这些文件也同时生成
	 * @param project 项目对象
	 * @param entity	源文件对象
	 * @param fields	字段对象
	 * @param params	其它参数
	 * @return
	 * @throws ServiceException 
	 */
	public Map<String,SrcFileEntity> makeFile(MultiProjectEntity project,SrcFileEntity entity,FieldsEntity[] fields,Map<String,Object> params) throws ServiceException{
		Map<String,SrcFileEntity> map = new HashMap<String, SrcFileEntity>();
		String abspath = getSrcFilePath(project, 0);
		String parentPack = entity.getPath();
		String fileName = entity.getName();
		if(fileName.indexOf("Entity") != -1){
			fileName = fileName.replace("Entity.java", "");
		}
		String entityFielName = fileName + "Entity";
		String srcFilePath = abspath+entityFielName+".java";
		entity.setName(entityFielName+".java");
		entity.setPath(srcFilePath);
		
		//---> step 1 : 根据 entityTemp 生成实体 JAVA 文件
		String packName = "com.cmw.entity";
		Map<String,String> context = createEntityFile(srcFilePath, packName, fileName, entity, fields);
		map.put(ENTITY_KEY, entity);
		
		String urlprefix = (String)params.get("urlprefix");
		context.put(BACK_URL_PREFIX, urlprefix);
		//---> step2 : 如果要求生成 DAO,SERVICE,ACTION 也要生成这些文件，并将这些 SrcFileEntity 放入 map 对象中
		params.put("fileName", fileName);	
		params.put("parentPack", parentPack);
		addEntityToMap(entity,params);	
		Map<String,SrcFileEntity> srcMap = getSrcFileByType(project, params, context, entity, fields);
		if(null != srcMap && srcMap.size()>0) map.putAll(srcMap);
		return map;
	}
	
	
	
	/**
	 * 将实体信息添加到 Map 对象中
	 * @param entity	实体对象
	 * @param params	用来存储实体对象值的Map对象
	 */
	private void addEntityToMap(SrcFileEntity entity,Map<String,Object> params){
		String description = entity.getDescription();
		String author = entity.getAuthor();
		String createDate = entity.getCreatorDate();
		String parentId = entity.getParentId();
		Long projectId = entity.getProjectId();
		params.put("description", description);
		params.put("author", author);	
		params.put("createDate", createDate);
		params.put("parentId", parentId);
		params.put("projectId", projectId);
	}
	/**
	 * 根据生成方式，生成 DAO，SERVICE，ACTION 并返回
	 * @param project	项目实体
	 * @param params	参数，此参数中放置了 是否生成 DAO，SERVICE，ACTION 的值，以及ACTION URL 前缀
	 * @param context	存放模板文件替换时，要用到的参数
	 * @return 返回 DAO,SERVICE,ACTION 实体对象
	 * @throws ServiceException 
	 */
	private Map<String,SrcFileEntity> getSrcFileByType(MultiProjectEntity project,Map<String,Object> params,Map<String,String> context,
			SrcFileEntity entity ,FieldsEntity[] fields) throws ServiceException{
		Map<String,SrcFileEntity> srcMap = new HashMap<String, SrcFileEntity>();
		String filetypes = (String)params.get("filetypes");
		if(!StringHandler.isValidStr(filetypes)) return null;
		String[] typeArr = filetypes.split(",");
		for(String type : typeArr){
			switch (Integer.parseInt(type)) {
			case PackageEntity.TYPE_DAO:{
				SrcFileEntity daoImplEntity = createSrcFileEntity(params,PackageEntity.TYPE_DAO);
				SrcFileEntity daosEntity = createDaoFiels(project,daoImplEntity,context);
				srcMap.put(DAOINTER_KEY, daosEntity);
				//srcMap.put(DAOIMPL_KEY, daosEntity[1]);
				break;
			}case PackageEntity.TYPE_SERVICE:{
				SrcFileEntity serviceImplEntity = createSrcFileEntity(params,PackageEntity.TYPE_SERVICE);
				SrcFileEntity[] servicesEntity = createServiceFiels(project,serviceImplEntity,context, fields);
				srcMap.put(SERVICE_KEY, servicesEntity[0]);
				srcMap.put(SERVICEIMPL_KEY, servicesEntity[1]);
				break;
			}case PackageEntity.TYPE_ACTION:{
				SrcFileEntity actionEntity = createSrcFileEntity(params,PackageEntity.TYPE_ACTION);
				actionEntity = createControllerFiles(project,actionEntity,context);
				srcMap.put(ACTION_KEY, actionEntity);
				break;
			}case PackageEntity.TYPE_MAPPER:{//MyBatis Mapper文件
				SrcFileEntity mapperEntity = createSrcFileEntity(params,PackageEntity.TYPE_MAPPER);
				mapperEntity = createMapperFiles(project,mapperEntity,context, entity, fields);
				srcMap.put(MAPPER_KEY, mapperEntity);
				break;
			}default:
				break;
			}
		}
		
		return srcMap;
	}
	
	/**
	 * 根据 Map 对象和类型创建 SrcFileEntity 对象
	 * @param params	要取值的Map 对象
	 * @param type	文件类型
	 * @return
	 */
	private SrcFileEntity createSrcFileEntity(Map<String,Object> params,int type){
		SrcFileEntity entity = new SrcFileEntity();
		Long projectId = (Long)params.get("projectId");
		String parentId = getParentId(type, false);
		if(!StringHandler.isValidStr(parentId)) parentId = "-1";
		String description = (String)params.get("description");
		String name = (String)params.get("fileName");
		String path = (String)params.get("parentPack");
		String author =  (String)params.get("author");
		String creatorDate = (String)params.get("createDate");
		
		entity.setProjectId(projectId);
		entity.setParentId(parentId);
		entity.setType(type);
		entity.setDescription(description);
		entity.setName(name);
		entity.setPath(path);
		entity.setAuthor(author);
		entity.setCreatorDate(creatorDate);
		return entity;
	}
	
	/**
	 * 获取指定类型源文件的父ID
	 * @param type	文件类型  see PackageEntity 中的常量定义
	 * @param isInter	是否是接口 	true : 接口 ，false : 实现类
	 * @return
	 */
	private String getParentId(int type,Boolean isInter){
		if(null == parentPacks || parentPacks.size()==0) return "-1";
		for(PackageEntity parentPackage : parentPacks){
			int _type = parentPackage.getType().intValue();
			if(_type==PackageEntity.TYPE_ACTION &&  _type == type){
				return parentPackage.getId().toString();
			}else{
				String _parentId = parentPackage.getParentId();
				if(null != isInter && isInter 
					&& _parentId.indexOf("inter_") != -1 &&  _type == type){
					return parentPackage.getId().toString();
				}else{
					if(_type == type && _parentId.indexOf("impl_") != -1) return parentPackage.getId().toString();
				}
			}
		}
		return "-1";
	}
	
	/**
	 * 创建DAO 接口和实现类 源文件
	 * @param project
	 * @param daoImplEntity
	 * @param context
	 * @return
	 * @throws ServiceException
	 */
	public SrcFileEntity createDaoFiels(MultiProjectEntity project,SrcFileEntity daoImplEntity,Map<String,String> context)
	throws ServiceException{
		SrcFileEntity daoInterEntity = null;
		try {
			daoInterEntity = (SrcFileEntity)daoImplEntity.clone();
			String parentId = getParentId(daoInterEntity.getType(), true);
			daoInterEntity.setParentId(parentId);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		String abspath = getSrcFilePath(project, 1);
		//--------------> DAO 接口源文件创建
		String fileName = daoInterEntity.getName();
		String daoFielName = fileName + "Dao";
		String srcFilePath = abspath+daoFielName+".java";
		daoInterEntity.setName(daoFielName+".java");
		daoInterEntity.setPath(srcFilePath);
		String packName = "com.cmw.dao";
		 Map<String,String> params =createDaoInterFile(packName,fileName,daoInterEntity,context);
		 context.putAll(params);
		return daoInterEntity;
	}
	
	/**
	 * 根据文件类型获取对应的文件路径
	 * @param project
	 * @param type
	 * @return
	 */
	private String getSrcFilePath(MultiProjectEntity project, int type){
		String srcFilePath = null;
		Integer multi = project.getMulti();
		String introduction = project.getIntroduction();
		String path = project.getPath();
		String srcName = project.getSrcName();
		String basePath = path+"/"+introduction;
		switch (type) {
			case 0:{//Entity
				if(null != multi && multi.intValue() == 1){//多模块
					String entityPack = project.getEntityPack();
					srcFilePath = entityPack+"/"+srcName+"/com/cmw/entity/";
				}else{
					srcFilePath = basePath+"/"+srcName+"/com/cmw/entity/";
				}
				break;
			}case 1:{//DAO
				if(null != multi && multi.intValue() == 1){//多模块
					String daoPack = project.getDaoPack();
					srcFilePath = daoPack+"/"+srcName+"/com/cmw/dao/";
				}else{
					srcFilePath = basePath+"/"+srcName+"/com/cmw/dao/";
				}
				break;
			}case 2:{//Service
				if(null != multi && multi.intValue() == 1){//多模块
					String servicePack = project.getServicePack();
					srcFilePath = servicePack+"/"+srcName+"/com/cmw/service/";
				}else{
					srcFilePath = basePath+"/"+srcName+"/com/cmw/service/";
				}
				break;
			}case 3:{//Controller
				if(null != multi && multi.intValue() == 1){//多模块
					String actionPack = project.getActionPack();
					srcFilePath = actionPack+"/"+srcName+"/com/cmw/controller/web/";
				}else{
					srcFilePath = basePath+"/"+srcName+"/com/cmw/controller/web/";
				}
				break;
			}case 5:{//Mapper
				if(null != multi && multi.intValue() == 1){//多模块
					String actionPack = project.getActionPack();
					srcFilePath = actionPack+"/src/main/resources/mapper/";
				}else{
					srcFilePath = basePath+"/src/main/resources/mapper/";
				}
				break;
			}default:
				break;
		}
		return srcFilePath;
	}
	
	/**
	 * 创建 Service 接口和实现类 源文件
	 * @param project
	 * @param serviceImplEntity	Service 源文件实体对象
	 * @param context
	 * @return
	 * @throws ServiceException
	 */
	public SrcFileEntity[] createServiceFiels(MultiProjectEntity project,SrcFileEntity serviceImplEntity,
			Map<String,String> context, FieldsEntity[] fields)
	throws ServiceException{
		SrcFileEntity[] serviceEntitys = new SrcFileEntity[2];
		SrcFileEntity serviceInterEntity = null;
		try {
			serviceInterEntity = (SrcFileEntity)serviceImplEntity.clone();
			String parentId = getParentId(serviceInterEntity.getType(), true);
			serviceInterEntity.setParentId(parentId);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		String servicePack = "com.cmw.service";
		//--------------> Service 接口源文件创建
		String fileName = serviceInterEntity.getName();
		String serviceFielName = fileName + "Service";
		
		String abspath = getSrcFilePath(project, 2);
		
		String srcFilePath = abspath+"/inter/"+serviceFielName+".java";
		serviceInterEntity.setName(serviceFielName+".java");
		serviceInterEntity.setPath(srcFilePath);
		serviceEntitys[0] = serviceInterEntity;
		String packName = servicePack+".inter";
		 Map<String,String> params =createServiceInterFile(packName,fileName,serviceInterEntity,context);
		 context.putAll(params);
		 
		//--------------> Service 实现类源文件创建
		fileName = serviceImplEntity.getName();
		serviceFielName = fileName + "ServiceImpl";
		srcFilePath = abspath+"/impl/"+serviceFielName+".java";
		serviceImplEntity.setName(serviceFielName+".java");
		serviceImplEntity.setPath(srcFilePath);
		serviceEntitys[1] = serviceImplEntity;
		packName =  servicePack+".impl";
		params = createServiceImplFile(packName,fileName,serviceImplEntity,context, fields);
		context.putAll(params);
		return serviceEntitys;
	}
	
	/**
	 * 创建  Mapper xml 文件
	 * @param project
	 * @param mapperEntity	Service 源文件实体对象
	 * @param context
	 * @return
	 * @throws ServiceException
	 */
	public SrcFileEntity createMapperFiles(MultiProjectEntity project,SrcFileEntity mapperEntity,Map<String,String> context, SrcFileEntity entity, FieldsEntity[] fields)
	throws ServiceException{
		
		String abspath = getSrcFilePath(project, 5);
		//--------------> Action 源文件创建
		String fileName = mapperEntity.getName();
		String mapperFielName = fileName + "Mapper";
	
		String srcFilePath = abspath+mapperFielName+".xml";
		mapperEntity.setName(mapperFielName+".xml");
		mapperEntity.setPath(srcFilePath);
		
		String mapperStr = mapperTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		String dao_cls = fileName+"Dao";
		Map<String,String> repMap = new HashMap<String, String>();
		repMap.put(BACK_TABLE, entity.getTabname());
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		repMap.put(BACK_DAO_CLS, dao_cls);
		repMap.put(BACK_ENTITY_PKID, context.get(BACK_ENTITY_PKID));
		
		String[] arr = getFieldsMapper(entity, fields);
		repMap.put(BACK_FIELDS_PROPS, arr[0]);
		repMap.put(BACK_BASE_CMNS, arr[1]);
		repMap.put(BACK_UP_CMNS, arr[2]);
		repMap.put(BACK_INSERT_CMNS_LIST, arr[4]);
		repMap.put(BACK_INSERT_CMNS_VALS, arr[3]);
		String filePath = mapperEntity.getPath();
		writeFile(filePath, mapperStr, repMap);
		return mapperEntity;
	}
	
	/**
	 * 获取Mapper文件字段替换值
	 * @param fields
	 * @return
	 */
	private String[] getFieldsMapper(SrcFileEntity entity, FieldsEntity[] fields){
		
		String[] pkIdArr = getPkId(entity, fields);
		StringBuilder sbFP = new StringBuilder();
		StringBuilder sbBC = new StringBuilder();
		StringBuilder sbUC = new StringBuilder();
		StringBuilder sbBCC = new StringBuilder();
		StringBuilder sbBCV = new StringBuilder();
		String extendCls = entity.getExtendcls();
		String pkIdFieldName = null;
		if(null != pkIdArr && pkIdArr.length == 2){
			pkIdFieldName = pkIdArr[0];
			sbFP.append("<id column=\""+pkIdArr[1]+"\" property=\""+pkIdArr[0]+"\" jdbcType=\"BIGINT\" />");
			sbFP.append("\n");
			sbBC.append(pkIdArr[1]).append(",");
		}
		for(int i=0,count=fields.length; i<count; i++){
			FieldsEntity fieldsObj = fields[i];
			String fieldName = fieldsObj.getFieldName();
			String colName = fieldsObj.getColName();
			String dataType = fieldsObj.getDataType();
			if(StringHandler.isValidStr(pkIdFieldName) && pkIdFieldName.equals(fieldName)) continue;
			String fpStr = getFields_Props(fieldsObj);
			if(StringHandler.isValidStr(fpStr)){
				sbFP.append(fpStr);
			}
			sbBC.append(colName).append(",");
			sbBCC.append(colName).append(",");
			String upStr = getUpCmns(fieldsObj);
			sbUC.append(upStr);
			String jdbcType = getJdbcType(dataType);
			sbBCV.append("#{"+fieldName+",jdbcType="+jdbcType+"},");
		}
		if(StringHandler.isValidStr(extendCls) &&
				(extendCls.equals("IdBaseEntity") || extendCls.equals("BaseEntity"))) {
			addBaseFileds(extendCls ,sbFP, sbBC, sbUC, sbBCV, sbBCC);
		}

		String[] strArr = new String[]{sbFP.toString(), StringHandler.RemoveStr(sbBC), sbUC.toString(), StringHandler.RemoveStr(sbBCV), StringHandler.RemoveStr(sbBCC)};
		return strArr;
	}
	
	private void addBaseFileds(String extendCls, StringBuilder sbFP, StringBuilder sbBC, StringBuilder sbUC,
			StringBuilder sbBCV, StringBuilder sbBCC) {
		sbFP.append("	<!-- 创建人 -->").append("\n")
		.append("	<result column=\"creator\" property=\"creator\" jdbcType=\"BIGINT\"/>").append("\n")
		.append("	<!-- 创建时间 -->").append("\n")
		.append("	<result column=\"createTime\" property=\"createTime\" jdbcType=\"DATE\"/>").append("\n")
		.append("	<!-- 创建机构 -->").append("\n")
		.append("	<result column=\"orgid\" property=\"orgid\" jdbcType=\"BIGINT\"/>").append("\n")
		.append("	<!-- 创建部门 -->").append("\n")
		.append("	<result column=\"deptId\" property=\"deptId\" jdbcType=\"BIGINT\"/>").append("\n")
		.append("	<!-- 可用标识 -->").append("\n")
		.append("	<result column=\"isenabled\" property=\"isenabled\" jdbcType=\"TINYINT\"/>").append("\n")
		.append("	<!-- 修改日期 -->").append("\n")
		.append("	<result column=\"modifytime\" property=\"modifytime\" jdbcType=\"DATE\"/>").append("\n")
		.append("	<!-- 修改人 -->").append("\n")
		.append("	<result column=\"modifier\" property=\"modifier\" jdbcType=\"BIGINT\"/>").append("\n")
		.append("	<!-- 备注 -->").append("\n")
		.append("	<result column=\"remark\" property=\"remark\" jdbcType=\"VARCHAR\"/>").append("\n");
		
		sbBC.append("creator,createTime,orgid,deptId,isenabled,modifytime,modifier,remark,");
		
		FieldsEntity upFields = new FieldsEntity();
		upFields.setRemark("可用标识");
		upFields.setFieldName("isenabled");
		upFields.setColName("isenabled");
		upFields.setDataType("Byte");
		String upStr = getUpCmns(upFields);
		sbUC.append(upStr);
		
		//修改日期
		upFields = new FieldsEntity();
		upFields.setRemark("修改日期");
		upFields.setFieldName("modifytime");
		upFields.setColName("modifytime");
		upFields.setDataType("Date");
		upStr = getUpCmns(upFields);
		sbUC.append(upStr);
		
		//修改人
		upFields = new FieldsEntity();
		upFields.setRemark("修改人");
		upFields.setFieldName("modifier");
		upFields.setColName("modifier");
		upFields.setDataType("Long");
		upStr = getUpCmns(upFields);
		sbUC.append(upStr);
		
		//备注
		upFields = new FieldsEntity();
		upFields.setRemark("备注");
		upFields.setFieldName("remark");
		upFields.setColName("remark");
		upFields.setDataType("String");
		upStr = getUpCmns(upFields);
		sbUC.append(upStr);
	
		sbBCV.append("#{creator,jdbcType=BIGINT},")
		.append("#{createTime,jdbcType=DATE},")
		.append("#{orgid,jdbcType=BIGINT},")
		.append("#{deptId,jdbcType=BIGINT},")
		.append("#{isenabled,jdbcType=TINYINT},")
		.append("#{remark,jdbcType=VARCHAR},");
		
		sbBCC.append("creator,createTime,orgid,deptId,isenabled,remark,");
	}
	
	/**
	 * 获取要更新的字段
	 *   <if test="name != null" >
        name = #{name,jdbcType=VARCHAR},
      </if>
	 * @param fieldsObj
	 * @return
	 */
	private String getUpCmns(FieldsEntity fieldsObj){
		StringBuilder sbStr = new StringBuilder();
		String remark = fieldsObj.getRemark();
		String fieldName = fieldsObj.getFieldName();
		String colName = fieldsObj.getColName();
		String dataType = fieldsObj.getDataType();
		String jdbcType = getJdbcType(dataType);
		if(StringHandler.isValidStr(remark)){
			sbStr.append("\t\t<!-- "+remark+" -->\n");
		}
		sbStr.append("\t\t<if test=\""+fieldName+" != null\" >\n")
			.append("\t\t  "+colName+" = #{"+fieldName+",jdbcType="+jdbcType+"},\n")
			.append("\t\t</if>\n");
		return sbStr.toString();
	}
	
	/**
	 * 获取主键映射
	 * @param entity
	 * @param fields
	 * @return 返回2个长度的数组 
	 */
	private String[] getPkId(SrcFileEntity entity, FieldsEntity[] fields){
		String[] pkIdArr = new String[2];
		String extendCls = entity.getExtendcls();
		if(StringHandler.isValidStr(extendCls) 
				&& (extendCls.equals("IdBaseEntity") || extendCls.equals("IdEntity"))){
			pkIdArr = new String[2];
			pkIdArr[0] = "id";
			pkIdArr[1] = "id";
		}else{
			String pkFieldName = null;
			String pkColName = null;
			for(FieldsEntity fieldsObj : fields){
				String bind = fieldsObj.getBind();
				if(StringHandler.isValidStr(bind) && bind.equals("主键")){
					pkFieldName = fieldsObj.getFieldName();
					pkColName = fieldsObj.getColName();
					break;
				}
			}
			if(StringHandler.isValidStr(pkFieldName)){
				pkIdArr = new String[2];
				pkIdArr[0] = pkFieldName;
				pkIdArr[1] = pkColName;
			}
		}
		return pkIdArr;
	}
	
	private String getFields_Props(FieldsEntity fieldsObj){
		StringBuilder sbStr = new StringBuilder();
		String remark = fieldsObj.getRemark();
		String fieldName = fieldsObj.getFieldName();
		String colName = fieldsObj.getColName();
		String dataType = fieldsObj.getDataType();
		String jdbcType = getJdbcType(dataType);
		
		if(StringHandler.isValidStr(remark)){
			sbStr.append("\t<!-- "+remark+" -->\n");
		}
		sbStr.append("\t<result column=\""+colName+"\" property=\""+fieldName+"\" jdbcType=\""+jdbcType+"\"/>\n");
		return sbStr.toString();
	}
	
	/**
	 * 获取 MyBatis JdbcType 数据类型
	 * @param dataType
	 * @return
	 */
	private String getJdbcType(String dataType){
		String jdbcType = null;
		if(dataType.indexOf("String") != -1){
			jdbcType = "VARCHAR";
		}else if(dataType.indexOf("Long") != -1){
			jdbcType = "BIGINT";
		}else if(dataType.indexOf("Integer") != -1){
			jdbcType = "INTEGER";
		}else if(dataType.indexOf("Double") != -1){
			jdbcType = "DOUBLE";
		}else if(dataType.indexOf("BigDecimal") != -1){
			jdbcType = "DECIMAL";
		}else if(dataType.indexOf("Float") != -1){
			jdbcType = "FLOAT";
		}else if(dataType.indexOf("Date") != -1){
			jdbcType = "DATE";
		}else if(dataType.indexOf("Byte") != -1){
			jdbcType = "TINYINT";
		}
		return jdbcType;
	}
	
	
	/**
	 * 创建  Controller 类 源文件
	 * @param project
	 * @param actionEntity	Service 源文件实体对象
	 * @param context
	 * @return
	 * @throws ServiceException
	 */
	public SrcFileEntity createControllerFiles(MultiProjectEntity project,SrcFileEntity actionEntity,Map<String,String> context)
	throws ServiceException{
		
		String abspath = getSrcFilePath(project, 3);
		//--------------> Action 源文件创建
		String fileName = actionEntity.getName();
		String actionFielName = fileName + "Controller";
	
		String srcFilePath = abspath+actionFielName+".java";
		actionEntity.setName(actionFielName+".java");
		actionEntity.setPath(srcFilePath);
		String packName = "com.cmw.controller.web";
		createActionSrcFile(packName,fileName,actionEntity,context);
		 
		return actionEntity;
	}
	
	/***
	 * 创建Action源文件
	 * @param packName	Service接口包名
	 * @param className	类名前缀
	 * @param daoInterEntity	接口源文件实体对象
	 * @return
	 */
	private void createActionSrcFile(String packName,String className,SrcFileEntity actionEntity,Map<String,String> context){
		String actionStr = actionTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		importPacks += getImportPackage(context.get(SERVICEINTERIMPORT_KEY));
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, actionEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		repMap.put(BACK_SERVICE_OBJ, context.get(BACK_SERVICE_OBJ));
		String urlPrefix = className.toLowerCase();
		repMap.put(BACK_URL_PREFIX, urlPrefix);
		repMap.put(BACK_ENTITY_PKID, context.get(BACK_ENTITY_PKID));
		repMap.put(BACK_CODE, context.get(BACK_CODE));
		String filePath = actionEntity.getPath();
		writeFile(filePath, actionStr, repMap);
		makeActionUrls(actionEntity,className,urlPrefix);
	}
	
	/**
	 * 处理  Action 的URL 列表 
	 * @param actionEntity
	 * @param className
	 * @param urlPrefix
	 */
	private void makeActionUrls(SrcFileEntity actionEntity,String className,String urlPrefix){
		String desc = actionEntity.getDescription();
		StringBuffer sb = new StringBuffer();
		String prefix = urlPrefix+className+"_";
		//---> 列表 URL
		sb.append("获取"+desc+"列表,").append(prefix+"list.action;");
		//---> 详情URL
		sb.append("获取"+desc+"信息,").append(prefix+"get.action;");
		//---> 保存URL
		sb.append("保存"+desc+",").append(prefix+"save.action;");
		//---> 新增URL
		sb.append("新增"+desc+",").append(prefix+"add.action;");
		//---> 删除URL
		sb.append("删除"+desc+",").append(prefix+"delete.action;");
		//---> 启用URL
		sb.append("启用"+desc+",").append(prefix+"enabled.action;");
		//---> 禁用URL
		sb.append("禁用"+desc+",").append(prefix+"disabled.action;");
		actionEntity.setRemark(sb.toString());
	}
	
	/***
	 * 创建Service接口源文件
	 * @param packName	Service接口包名
	 * @param className	类名前缀
	 * @param daoInterEntity	接口源文件实体对象
	 * @return
	 */
	private Map<String,String> createServiceInterFile(String packName,String className,SrcFileEntity serviceInterEntity,
			Map<String,String> context){
		String serviceInterStr = serviceTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, serviceInterEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		String filePath = serviceInterEntity.getPath();
		writeFile(filePath, serviceInterStr, repMap);
		
		serviceInterEntity.setRemark(packName);//将包名保存到 remark 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		String serviceImport = packName+"."+serviceInterEntity.getName().replace(".java", "");
		params.put(SERVICEINTERIMPORT_KEY, serviceImport);
		return params;
	}
	
	/***
	 * 创建Service实现类源文件
	 * @param packName	Service实现类包名
	 * @param className	类名前缀
	 * @param serviceImplEntity	Service 实现类源文件实体对象
	 * @return
	 */
	private Map<String,String> createServiceImplFile(String packName,String className,SrcFileEntity serviceImplEntity,
			Map<String,String> context,FieldsEntity[] fields){
		String serviceImplStr = serviceImplTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		importPacks += getImportPackage(context.get(DAOINTERIMPORT_KEY));
		importPacks += getImportPackage(context.get(SERVICEINTERIMPORT_KEY));
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, serviceImplEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		String firstChar = className.substring(0,1).toLowerCase();
		String serviceObj = firstChar+className.substring(1)+"Service";
		String daoObj = firstChar+className.substring(1)+"Dao";
		repMap.put(BACK_SERVICE_OBJ, serviceObj);
		repMap.put(BACK_DAO_OBJ, daoObj);
		setCodeAndValds(repMap, firstChar, fields);
		String filePath = serviceImplEntity.getPath();
		writeFile(filePath, serviceImplStr, repMap);
		
		serviceImplEntity.setRemark(packName);	//将包名保存到 remark 字段中
		serviceImplEntity.setTabname(serviceObj);	//将 注解对象保存到 tab 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		params.put(BACK_DAO_OBJ, daoObj);
		params.put(BACK_SERVICE_OBJ, serviceObj);
		return params;
	}
	
	private void setCodeAndValds(Map<String,String> repMap, String firstChar, FieldsEntity[] fields) {
		String prefix_code = firstChar.toUpperCase();
		String code_invokeMethod = "";
		String prop_valid_field = "";
		if(hasCode(fields)) {
			code_invokeMethod = "setCode(entity);";
		}
		prop_valid_field = getValidCodeStr(fields);
		repMap.put(SERVICE_TAG_SET_CODE, code_invokeMethod);
		repMap.put(SERVICE_TAG_PREFIX_CODE, prefix_code);
		repMap.put(SERVICE_TAG_PROP_VALID_FIELD, prop_valid_field);
	}
	
	private String getValidCodeStr(FieldsEntity[] fields) {
		StringBuilder sbValid = new StringBuilder();
		for(FieldsEntity field : fields) {
			String dataType = field.getDataType();
			
			String fname = field.getFieldName();
			Integer len = field.getLen();
			String isnull = field.getIsnull();
			String remark = field.getRemark();
			String fnameGet = getFnameGet(fname);
			if(isnull.equals("false")) {
				sbValid.append(getNotNullTemp(fnameGet, remark, dataType));
			}
			sbValid.append("\n");
			if(null == dataType || !dataType.equals("String")) continue;
			if(null != len && len.intValue() > 0) {
				sbValid.append(getLenValidTemp(fnameGet, remark, len));
			}
			sbValid.append("\n");
		}
		return sbValid.toString();
	}
	
	private String getFnameGet(String fname) {
		String fchar = fname.substring(0, 1);
		fchar = fchar.toUpperCase();
		String endStr = fname.substring(1);
		String fget = "get"+fchar+endStr;
		return fget;
	}
	
	private String getLenValidTemp(String fnameGet,String remark, Integer len) {
		StringBuilder sbStr = new StringBuilder();
		sbStr.append("			if(StringUtils.isEmpty(entity.").append(fnameGet).append("())")
		.append(" && entity.").append(fnameGet).append("().length() > ").append(len).append("){\r\n");
		sbStr.append("			throw new ServiceException(\""+remark+"长度不能超过"+len+"!\");\r\n");
		sbStr.append("			}\r\n");
		return sbStr.toString();
	}
	
	private String getNotNullTemp(String fnameGet,String remark, String dataType) {
		StringBuilder sbStr = new StringBuilder();
		if(null != dataType && dataType.equals("String")) {
			sbStr.append("		if(StringUtils.isEmpty(entity.").append(fnameGet).append("())){\r\n");
		}else {
			sbStr.append("		if(null == entity.").append(fnameGet).append("()){\r\n");
		}
		
		sbStr.append("			throw new ServiceException(\"").append(remark).append("不能为空!\");\r\n")
		.append("		}\r\n");
		
		return sbStr.toString();
	}
	
	private boolean hasCode(FieldsEntity[] fields) {
		for(FieldsEntity field : fields) {
			String fieldName = field.getFieldName();
			if(fieldName.equals("code")) {
				return true;
			}
		}
		return false;
	}
	
	
	/**
	 * 实体包导入KEY
	 */
	private static final String ENTITYIMPORT_KEY = "entityImport";
	/**
	 * DAO接口包导入KEY
	 */
	private static final String DAOINTERIMPORT_KEY = "daointerImport";
	/**
	 * Service接口包导入KEY
	 */
	private static final String SERVICEINTERIMPORT_KEY = "serviceinterImport";
	
	
	/***
	 * 创建DAO接口源文件
	 * @param packName	DAO接口包名
	 * @param className	类名前缀
	 * @param daoInterEntity	接口源文件实体对象
	 * @return
	 */
	private Map<String,String> createDaoInterFile(String packName,String className,SrcFileEntity daoInterEntity,Map<String,String> context){
		String daoInterStr = daoInterTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, daoInterEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		String filePath = daoInterEntity.getPath();
		writeFile(filePath, daoInterStr, repMap);
		
		daoInterEntity.setRemark(packName);//将包名保存到 remark 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		String daoImport = packName+"."+daoInterEntity.getName().replace(".java", "");
		params.put(DAOINTERIMPORT_KEY, daoImport);
		return params;
	}
	
	/***
	 * 创建DAO实现类源文件
	 * @param packName	DAO接口包名
	 * @param className	类名前缀
	 * @param daoImplEntity	接口源文件实体对象
	 * @return
	 */
	private Map<String,String> createDaoImplFile(String packName,String className,SrcFileEntity daoImplEntity,Map<String,String> context){
		String daoImplStr = daoImplTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		importPacks += getImportPackage(context.get(DAOINTERIMPORT_KEY));
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, daoImplEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		String daoObj = className.substring(0,1).toLowerCase()+className.substring(1)+"Dao";
		
		repMap.put(BACK_DAO_OBJ, daoObj);	
		String filePath = daoImplEntity.getPath();
		writeFile(filePath, daoImplStr, repMap);
		
		daoImplEntity.setRemark(packName);	//将包名保存到 remark 字段中
		daoImplEntity.setTabname(daoObj);	//将 注解对象保存到 tab 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		params.put(BACK_DAO_OBJ, daoObj);
		return params;
	}
	
	/**
	 * 阶建 Entity 源文件代码
	 * @param filePath
	 * @param packName
	 * @param entityClassName
	 * @param srcEntity
	 * @param fields
	 * @return
	 * @throws ServiceException
	 */
	public Map<String,String> createEntityFile(String filePath,String packName,String entityClassName,SrcFileEntity srcEntity,FieldsEntity[] fields)
	throws ServiceException{
		String entityStr = entityTemp;
	
		String extendcls = srcEntity.getExtendcls();
		String importPacks = extendsClsMap.get(extendcls);
		importPacks = getImportPackage(importPacks);
		if(null == importPacks) throw new ServiceException(extendcls+"在TemplateServiceImpl.java 的 extendsClsMap 未初始化！");
		Map<String, String> repMap = getReplaceMap(packName, entityClassName,
				 importPacks,srcEntity);
		repMap.put(BACK_TABLE, srcEntity.getTabname());
		repMap.put(BACK_SUPENTITY,extendcls);
		String[] fldsCodes = getFieldsSourceCode(fields);
		repMap.put(BACK_FIELDS_MEMBER, fldsCodes[0]);
		repMap.put(BACK_FIELDS_METHODS, fldsCodes[1]);
		repMap.put(BACK_FIELDS_VALS, fldsCodes[2]);
		repMap.put(BACK_FIELDS_NAMES, fldsCodes[3]);
		writeFile(filePath, entityStr, repMap);
		
		srcEntity.setRemark(packName);//将包名保存到 remark 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		String entityName = srcEntity.getName().replace(".java", "");
		params.put(BACK_ENTITY, entityName);
		params.put(ENTITYIMPORT_KEY, packName+"."+entityName);
		String pkField = getPkField(fields);
		params.put(BACK_ENTITY_PKID, pkField);
		String code = entityClassName.substring(0,1);
		params.put(BACK_CODE, code.toUpperCase());
		return params;
	}
	
	/**
	 * 获取主键字段名
	 * @param fields
	 * @return
	 */
	private String getPkField(FieldsEntity[] fields){
		String pkField = "id";
		for(FieldsEntity field : fields){
			String bind = field.getBind();
			if(StringHandler.isValidStr(bind) && PRIMARY_KEY_DESC.equals(bind)){
				pkField=field.getFieldName();
				break;
			}
		}
		return pkField;
	}
	
	/**
	 * 将要导入的包格式化后返回
	 * @param importPackage 导入的包
	 * @return
	 */
	private String getImportPackage(String importPackage){
		return "import "+importPackage+";\n";
	}
	
	/**
	 * 将模板进行处理后，以入文件
	 * @param filePath
	 * @param entityStr
	 * @param repMap
	 */
	private void writeFile(String filePath, String entityStr,
			Map<String, String> repMap) {
		Set<String> keys = repMap.keySet();
		for(String key : keys){
			String val = repMap.get(key);
			if(!StringHandler.isValidStr(val)) val = "";
			entityStr = entityStr.replace(key, val);
		}
		FileUtil.writeStrToFile(filePath, entityStr);
	}
	
	/**
	 * 创建用户替换模板文件标记的Map 对象
	 * @param packName	包名
	 * @param className 类名
	 * @param importPacks	导入包
	 * @param srcEntity	实体对象
	 * @return
	 */
	private Map<String, String> getReplaceMap(String packName,
			String className, String importPacks, SrcFileEntity srcEntity) {
		Map<String,String> repMap = new HashMap<String, String>();
		repMap.put(BACK_PACAKGE, packName+";\n");
		repMap.put(BACK_IMPORT, importPacks);
		String description = srcEntity.getDescription();
		String author = srcEntity.getAuthor();
		String createDate = DateUtil.dateFormatToStr("yyyy-MM-dd HH:mm:ss", new Date());
		repMap.put(BACK_DESCRIPTION, description);
		repMap.put(BACK_AUTHOR, author);
		repMap.put(BACK_DATE, createDate);
		repMap.put(BACK_CLASSNAME, className);
		return repMap;
	}
	
	private String[] getFieldsSourceCode(FieldsEntity[] fields){
		String[] arrs = new String[4];
		StringBuffer sb1 = new StringBuffer();
		StringBuffer sb2 = new StringBuffer();
		StringBuffer sb3 = new StringBuffer();
		StringBuffer sb4 = new StringBuffer();
		for(FieldsEntity field : fields){
			String fieldStr = getFieldsStrs(field);
			sb1.append(fieldStr + "\n");
			String methodStr = getMethodStrs(field);
			sb2.append(methodStr + "\n");
			String fieldName = field.getFieldName();
			sb3.append(fieldName+",");
			sb4.append("\""+fieldName+"\",");
		}
		arrs[0] = sb1.toString();
		arrs[1] = sb2.toString();
		if(sb3.length()>0){
			arrs[2] = StringHandler.RemoveStr(sb3, ",");
			arrs[3] = StringHandler.RemoveStr(sb4, ",");
		}
		return arrs;
	}

	private static final String PRIMARY_KEY_DESC = "主键";
	private static final String UNIQUE_KEY_DESC = "唯一";
	/**
	 * 获取字段源代码片断 
	 * @param field
	 * @return
	 */
	private String getFieldsStrs(FieldsEntity field) {
		StringBuffer sbCode = new StringBuffer();
		String fieldName = field.getFieldName();
		//remark dataType sqltype bind isnull len decimalnum defaultval
		String colName = field.getColName();
		String remark = field.getRemark();
		String dataType = field.getDataType();
		String sqltype = field.getSqltype();
		String bind = field.getBind();
		String isnull = field.getIsnull();
		Integer len = field.getLen();
		Integer decimalnum = field.getDecimalnum();
		String defaultval = field.getDefaultval();
		String choiceval = field.getChoiceval();
		sbCode.append("\n\t @Description(remark=\"").append(remark).append("\")\n");
		if(StringHandler.isValidStr(choiceval)) sbCode.append("\t\t").append(choiceval+"\n");
		if(bind.equals(PRIMARY_KEY_DESC)){
			sbCode.append("\t @Id @GeneratedValue(strategy=GenerationType.IDENTITY");
		}else{
			sbCode.append("\t @Column(name=\""+colName+"\" ");
			if(bind.equals(UNIQUE_KEY_DESC)) sbCode.append(",unique=true ");
			if(StringHandler.isValidStr(isnull) && isnull.equals("false")){
				sbCode.append(",nullable=false ");
			}
			if(null != len){
				sbCode.append(",length="+len+" ");
			}
			if(null != decimalnum) sbCode.append(",scale="+decimalnum);
		}
		
		sbCode.append(")\n");
		sbCode.append("\t private "+dataType+" "+fieldName);
		if(StringHandler.isValidStr(defaultval)) sbCode.append(" = "+defaultval);
		sbCode.append(";");
		
		return sbCode.toString();
	}
	
	/**
	 * 
	 * @param field
	 * @return
	 */
	private String getMethodStrs(FieldsEntity field){
		StringBuffer sbCode = new StringBuffer();
		String remark = field.getRemark();
		String fieldName = field.getFieldName();
		String dataType = field.getDataType();

		String firstChar = fieldName.substring(0, 1).toUpperCase();
		String endMethod = fieldName.substring(1);
		//---> setXxx() 方法
		sbCode.append("\t/**\n\t  * 设置"+remark+"的值\n" +
				"\t * @param \t"+fieldName+"\t "+remark+"\n" +
				"\t**/\n");
		
		sbCode.append("\tpublic void set").append(firstChar).append(endMethod).append("("+dataType+"  "+fieldName+"){\n");
		sbCode.append("\t\t this."+fieldName+"="+fieldName+";\n ");
		sbCode.append("\t}\n");
		
		//---> getXxx() 方法
		sbCode.append("\n\t/**\n\t  * 获取"+remark+"的值\n" +
				"\t * @return 返回"+remark+"的值\n" +
				"\t**/\n");
		
		sbCode.append("\tpublic "+dataType+" get").append(firstChar).append(endMethod).append("(){\n");
		sbCode.append("\t\t return "+fieldName+";\n ");
		sbCode.append("\t}\n");
		return sbCode.toString();
	}

	public List<PackageEntity> getParentPacks() {
		return parentPacks;
	}

	public void setParentPacks(List<PackageEntity> parentPacks) {
		this.parentPacks = parentPacks;
	}
	
	/**
	 * 获取 classes 所在的真实物理路径
	 * @return
	 */
	public static String getClassPath(){
		String classPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
		int index = classPath.indexOf("/");
		if(index == 0) classPath = classPath.substring(1);
		return classPath;
	}
	
	public static void main(String[] args){
		String classPath = StringHandler.getClassPath();
		System.out.println("classPath="+classPath);
	}
}
