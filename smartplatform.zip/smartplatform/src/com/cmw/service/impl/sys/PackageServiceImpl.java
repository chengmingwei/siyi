package com.cmw.service.impl.sys;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.exception.DaoException;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.service.AbsService;
import com.cmw.core.util.DataTable;
import com.cmw.dao.inter.sys.PackageDaoInter;
import com.cmw.entity.sys.PackageEntity;
import com.cmw.service.inter.sys.PackageService;
/**
 * 包业务实现类
 * @author ddd
 *
 */
@Service("packageService")
public class PackageServiceImpl extends AbsService<PackageEntity, Long> implements PackageService {
	@Autowired
	private PackageDaoInter packageDao;
	@Override
	public GenericDaoInter<PackageEntity, Long> getDao() {
		return packageDao;
	}
	
	
	@Override
	public DataTable getDataSource(Long projectId) throws ServiceException {
		try{
			return packageDao.getDataSource(projectId);
		}catch(DaoException ex){
			throw new ServiceException(ex);
		}
	}

}
