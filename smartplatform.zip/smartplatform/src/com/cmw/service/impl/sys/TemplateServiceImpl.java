package com.cmw.service.impl.sys;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.kit.file.FileUtil;
import com.cmw.core.util.StringHandler;
import com.cmw.core.util.SystemUtils;
import com.cmw.entity.sys.FieldsEntity;
import com.cmw.entity.sys.PackageEntity;
import com.cmw.entity.sys.ProjectEntity;
import com.cmw.entity.sys.SrcFileEntity;
import com.cmw.service.inter.sys.SysmbolTempService;
/**
 * 模板文件实现类
 * @author chengmingwei
 * 
 */
public class TemplateServiceImpl implements SysmbolTempService {
	/**
	 * 放当前实体的父包列表
	 */
	private List<PackageEntity> parentPacks;
	
	public static final String ENTITY_KEY = "entity";
	public static final String DAOINTER_KEY = "daoInter";
	public static final String DAOIMPL_KEY = "daoImpl";
	public static final String SERVICE_KEY = "service";
	public static final String SERVICEIMPL_KEY = "serviceImpl";
	public static final String ACTION_KEY = "action";
	static char sp = File.separatorChar;
	/**
	 * resource.properties 中的实体继承类列表
	 */
	private static final String ENTITY_EXTENDS_RESOURCE = "entity_extends";
	/** 
	 * 存放类继承的类
	 */
	private static Map<String,String> extendsClsMap = new HashMap<String, String>();
	/**
	 * Entity 模板文件字符串
	 */
	private static String entityTemp = null;
	/**
	 * Dao接口 模板文件字符串
	 */
	private static String daoInterTemp = null;
	/**
	 * Dao实现类 模板文件字符串
	 */
	private static String daoImplTemp = null;
	/**
	 * Service接口 模板文件字符串
	 */
	private static String serviceTemp = null;
	/**
	 * Service实现类 模板文件字符串
	 */
	private static String serviceImplTemp = null;
	/**
	 * 模板文件字符串
	 */
	private static String actionTemp = null;
	
	static{
		//---------> Entity 继承类初始化
		String entitysSups = StringHandler.GetResValue(ENTITY_EXTENDS_RESOURCE);
		if(StringHandler.isValidStr(entitysSups)){
			String[] entity_kvs = entitysSups.split(";");
			for(String entity_kv : entity_kvs){
				String[] kv = entity_kv.split(":");
				extendsClsMap.put(kv[0], kv[1]);
			}
		}
		
//		String classPath = ClassLoader.getSystemResource("").getPath();
		String classPath = StringHandler.getClassPath();//"F:\\dev\\smartplatform\\WebContent\\WEB-INF\\classes\\";
		if(SystemUtils.isMacOS()){
			classPath = "/"+classPath;
		}
		System.out.println("classPath="+classPath);
		String filePath = classPath+"template"+sp+"javaTemplate"+sp+"EntityTemplate.tp";
		System.out.println("entityTemp.filePath="+filePath);
		entityTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template"+sp+"javaTemplate"+sp+"DaoInterTemplate.tp";
		daoInterTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template"+sp+"javaTemplate"+sp+"DaoImplTemplate.tp";
		daoImplTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template"+sp+"javaTemplate"+sp+"ServiceTemplate.tp";
		serviceTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template"+sp+"javaTemplate"+sp+"ServiceImplTemplate.tp";
		serviceImplTemp = FileUtil.ReadFileToStr(filePath);
		
		filePath = classPath+"template"+sp+"javaTemplate"+sp+"ActionTemplate.tp";
		actionTemp = FileUtil.ReadFileToStr(filePath);
	}
	
	/**
	 * 生成Entity文件，如果有选中要生成 Dao,Service,Action 的话，
	 * 这些文件也同时生成
	 * @param project 项目对象
	 * @param entity	源文件对象
	 * @param fields	字段对象
	 * @param params	其它参数
	 * @return
	 * @throws ServiceException 
	 */
	public Map<String,SrcFileEntity> makeFile(ProjectEntity project,SrcFileEntity entity,FieldsEntity[] fields,Map<String,Object> params) throws ServiceException{
		Map<String,SrcFileEntity> map = new HashMap<String, SrcFileEntity>();
		String abspath = project.getPath()+""+sp+""+project.getSrcName();
		String entityPack = project.getEntityPack();
		String parentPack = entity.getPath();
		String fileName = entity.getName();
		String entityFielName = fileName + "Entity";
		String entityPackPath = entityPack.replace(".", ""+sp+"");
		String srcFilePath = abspath+""+sp+""+entityPackPath+""+sp+""+parentPack.replace(".", ""+sp+"")+""+sp+""+entityFielName+".java";
		entity.setName(entityFielName+".java");
		entity.setPath(srcFilePath);
		
		//---> step 1 : 根据 entityTemp 生成实体 JAVA 文件
		String packName = entityPack + "." + parentPack;
		Map<String,String> context = createEntityFile(srcFilePath, packName, fileName, entity, fields);
		map.put(ENTITY_KEY, entity);
		
		String urlprefix = (String)params.get("urlprefix");
		context.put(BACK_URL_PREFIX, urlprefix);
		//---> step2 : 如果要求生成 DAO,SERVICE,ACTION 也要生成这些文件，并将这些 SrcFileEntity 放入 map 对象中
		params.put("fileName", fileName);	
		params.put("parentPack", parentPack);
		addEntityToMap(entity,params);	
		Map<String,SrcFileEntity> srcMap = getSrcFileByType(project, params, context);
		if(null != srcMap && srcMap.size()>0) map.putAll(srcMap);
		return map;
	}
	
	/**
	 * 将实体信息添加到 Map 对象中
	 * @param entity	实体对象
	 * @param params	用来存储实体对象值的Map对象
	 */
	private void addEntityToMap(SrcFileEntity entity,Map<String,Object> params){
		String description = entity.getDescription();
		String author = entity.getAuthor();
		String createDate = entity.getCreatorDate();
		String parentId = entity.getParentId();
		Long projectId = entity.getProjectId();
		params.put("description", description);
		params.put("author", author);	
		params.put("createDate", createDate);
		params.put("parentId", parentId);
		params.put("projectId", projectId);
	}
	/**
	 * 根据生成方式，生成 DAO，SERVICE，ACTION 并返回
	 * @param project	项目实体
	 * @param params	参数，此参数中放置了 是否生成 DAO，SERVICE，ACTION 的值，以及ACTION URL 前缀
	 * @param context	存放模板文件替换时，要用到的参数
	 * @return 返回 DAO,SERVICE,ACTION 实体对象
	 * @throws ServiceException 
	 */
	private Map<String,SrcFileEntity> getSrcFileByType(ProjectEntity project,Map<String,Object> params,Map<String,String> context) throws ServiceException{
		Map<String,SrcFileEntity> srcMap = new HashMap<String, SrcFileEntity>();
		String filetypes = (String)params.get("filetypes");
		if(!StringHandler.isValidStr(filetypes)) return null;
		String[] typeArr = filetypes.split(",");
		for(String type : typeArr){
			switch (Integer.parseInt(type)) {
			case PackageEntity.TYPE_DAO:{
				SrcFileEntity daoImplEntity = createSrcFileEntity(params,PackageEntity.TYPE_DAO);
				SrcFileEntity[] daosEntity = createDaoFiels(project,daoImplEntity,context);
				srcMap.put(DAOINTER_KEY, daosEntity[0]);
				srcMap.put(DAOIMPL_KEY, daosEntity[1]);
				break;
			}case PackageEntity.TYPE_SERVICE:{
				SrcFileEntity serviceImplEntity = createSrcFileEntity(params,PackageEntity.TYPE_SERVICE);
				SrcFileEntity[] servicesEntity = createServiceFiels(project,serviceImplEntity,context);
				srcMap.put(SERVICE_KEY, servicesEntity[0]);
				srcMap.put(SERVICEIMPL_KEY, servicesEntity[1]);
				break;
			}case PackageEntity.TYPE_ACTION:{
				SrcFileEntity actionEntity = createSrcFileEntity(params,PackageEntity.TYPE_ACTION);
				actionEntity = createActionFiles(project,actionEntity,context);
				srcMap.put(ACTION_KEY, actionEntity);
				break;
			}default:
				break;
			}
		}
		
		return srcMap;
	}
	
	/**
	 * 根据 Map 对象和类型创建 SrcFileEntity 对象
	 * @param params	要取值的Map 对象
	 * @param type	文件类型
	 * @return
	 */
	private SrcFileEntity createSrcFileEntity(Map<String,Object> params,int type){
		SrcFileEntity entity = new SrcFileEntity();
		Long projectId = (Long)params.get("projectId");
		String parentId = getParentId(type, false);
		String description = (String)params.get("description");
		String name = (String)params.get("fileName");
		String path = (String)params.get("parentPack");
		String author =  (String)params.get("author");
		String creatorDate = (String)params.get("createDate");
		
		entity.setProjectId(projectId);
		entity.setParentId(parentId);
		entity.setType(type);
		entity.setDescription(description);
		entity.setName(name);
		entity.setPath(path);
		entity.setAuthor(author);
		entity.setCreatorDate(creatorDate);
		return entity;
	}
	
	/**
	 * 获取指定类型源文件的父ID
	 * @param type	文件类型  see PackageEntity 中的常量定义
	 * @param isInter	是否是接口 	true : 接口 ，false : 实现类
	 * @return
	 */
	private String getParentId(int type,Boolean isInter){
		if(null == parentPacks || parentPacks.size()==0) return null;
		for(PackageEntity parentPackage : parentPacks){
			int _type = parentPackage.getType().intValue();
			if(_type==PackageEntity.TYPE_ACTION &&  _type == type){
				return parentPackage.getId().toString();
			}else{
				String _parentId = parentPackage.getParentId();
				if(null != isInter && isInter 
					&& _parentId.indexOf("inter_") != -1 &&  _type == type){
					return parentPackage.getId().toString();
				}else{
					if(_type == type && _parentId.indexOf("impl_") != -1) return parentPackage.getId().toString();
				}
			}
		}
		return null;
	}
	
	/**
	 * 创建DAO 接口和实现类 源文件
	 * @param project
	 * @param daoImplEntity
	 * @param context
	 * @return
	 * @throws ServiceException
	 */
	public SrcFileEntity[] createDaoFiels(ProjectEntity project,SrcFileEntity daoImplEntity,Map<String,String> context)
	throws ServiceException{
		SrcFileEntity[] daoEntitys = new SrcFileEntity[2];
		SrcFileEntity daoInterEntity = null;
		try {
			daoInterEntity = (SrcFileEntity)daoImplEntity.clone();
			String parentId = getParentId(daoInterEntity.getType(), true);
			daoInterEntity.setParentId(parentId);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		String abspath = project.getPath()+""+sp+""+project.getSrcName();
		String daoPack = project.getDaoPack();
		String daoPackPath = daoPack.replace(".", ""+sp+"");
		//--------------> DAO 接口源文件创建
		String parentPack = daoInterEntity.getPath();
		String fileName = daoInterEntity.getName();
		String daoFielName = fileName + "DaoInter";
	
		String srcFilePath = abspath+""+sp+""+daoPackPath+""+sp+"inter"+sp+""+parentPack.replace(".", ""+sp+"")+""+sp+""+daoFielName+".java";
		daoInterEntity.setName(daoFielName+".java");
		daoInterEntity.setPath(srcFilePath);
		daoEntitys[0] = daoInterEntity;
		String packName = daoPack+".inter."+parentPack;
		 Map<String,String> params =createDaoInterFile(packName,fileName,daoInterEntity,context);
		 context.putAll(params);
		 
		//--------------> DAO 实现类源文件创建
		 parentPack = daoImplEntity.getPath();
		fileName = daoImplEntity.getName();
		daoFielName = fileName + "DaoImpl";
		daoPackPath = daoPack.replace(".", ""+sp+"");
		srcFilePath = abspath+""+sp+""+daoPackPath+""+sp+"impl"+sp+""+parentPack.replace(".", ""+sp+"")+""+sp+""+daoFielName+".java";
		daoImplEntity.setName(daoFielName+".java");
		daoImplEntity.setPath(srcFilePath);
		daoEntitys[1] = daoImplEntity;
		packName =  daoPack+".impl."+parentPack;
		params = createDaoImplFile(packName,fileName,daoImplEntity,context);
		context.putAll(params);
		return daoEntitys;
	}
	
	/**
	 * 创建 Service 接口和实现类 源文件
	 * @param project
	 * @param serviceImplEntity	Service 源文件实体对象
	 * @param context
	 * @return
	 * @throws ServiceException
	 */
	public SrcFileEntity[] createServiceFiels(ProjectEntity project,SrcFileEntity serviceImplEntity,Map<String,String> context)
	throws ServiceException{
		SrcFileEntity[] serviceEntitys = new SrcFileEntity[2];
		SrcFileEntity serviceInterEntity = null;
		try {
			serviceInterEntity = (SrcFileEntity)serviceImplEntity.clone();
			String parentId = getParentId(serviceInterEntity.getType(), true);
			serviceInterEntity.setParentId(parentId);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		String abspath = project.getPath()+""+sp+""+project.getSrcName();
		String servicePack = project.getServicePack();
		String servicePackPath = servicePack.replace(".", ""+sp+"");
		//--------------> Service 接口源文件创建
		String parentPack = serviceInterEntity.getPath();
		String fileName = serviceInterEntity.getName();
		String serviceFielName = fileName + "Service";
	
		String srcFilePath = abspath+""+sp+""+servicePackPath+""+sp+"inter"+sp+""+parentPack.replace(".", ""+sp+"")+""+sp+""+serviceFielName+".java";
		serviceInterEntity.setName(serviceFielName+".java");
		serviceInterEntity.setPath(srcFilePath);
		serviceEntitys[0] = serviceInterEntity;
		String packName = servicePack+".inter."+parentPack;
		 Map<String,String> params =createServiceInterFile(packName,fileName,serviceInterEntity,context);
		 context.putAll(params);
		 
		//--------------> Service 实现类源文件创建
		 parentPack = serviceImplEntity.getPath();
		fileName = serviceImplEntity.getName();
		serviceFielName = fileName + "ServiceImpl";
		servicePackPath = servicePack.replace(".", ""+sp+"");
		srcFilePath = abspath+""+sp+""+servicePackPath+""+sp+"impl"+sp+""+parentPack.replace(".", ""+sp+"")+""+sp+""+serviceFielName+".java";
		serviceImplEntity.setName(serviceFielName+".java");
		serviceImplEntity.setPath(srcFilePath);
		serviceEntitys[1] = serviceImplEntity;
		packName =  servicePack+".impl."+parentPack;
		params = createServiceImplFile(packName,fileName,serviceImplEntity,context);
		context.putAll(params);
		return serviceEntitys;
	}
	
	/**
	 * 创建  Action 类 源文件
	 * @param project
	 * @param actionEntity	Service 源文件实体对象
	 * @param context
	 * @return
	 * @throws ServiceException
	 */
	public SrcFileEntity createActionFiles(ProjectEntity project,SrcFileEntity actionEntity,Map<String,String> context)
	throws ServiceException{
		
		String abspath = project.getPath()+""+sp+""+project.getSrcName();
		String actionPack = project.getActionPack();
		String actionPackPath = actionPack.replace(".", ""+sp+"");
		//--------------> Action 源文件创建
		String parentPack = actionEntity.getPath();
		String fileName = actionEntity.getName();
		String actionFielName = fileName + "Action";
	
		String srcFilePath = abspath+""+sp+""+actionPackPath+""+sp+""+parentPack.replace(".", ""+sp+"")+""+sp+""+actionFielName+".java";
		actionEntity.setName(actionFielName+".java");
		actionEntity.setPath(srcFilePath);
		String packName = actionPack+"."+parentPack;
		createActionSrcFile(packName,fileName,actionEntity,context);
		 
		return actionEntity;
	}
	
	/***
	 * 创建Action源文件
	 * @param packName	Service接口包名
	 * @param className	类名前缀
	 * @param daoInterEntity	接口源文件实体对象
	 * @return
	 */
	private void createActionSrcFile(String packName,String className,SrcFileEntity actionEntity,Map<String,String> context){
		String actionStr = actionTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		importPacks += getImportPackage(context.get(SERVICEINTERIMPORT_KEY));
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, actionEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		repMap.put(BACK_SERVICE_OBJ, context.get(BACK_SERVICE_OBJ));
		String urlPrefix = context.get(BACK_URL_PREFIX);
		repMap.put(BACK_URL_PREFIX, urlPrefix);
		repMap.put(BACK_ENTITY_PKID, context.get(BACK_ENTITY_PKID));
		repMap.put(BACK_CODE, context.get(BACK_CODE));
		String filePath = actionEntity.getPath();
		writeFile(filePath, actionStr, repMap);
		makeActionUrls(actionEntity,className,urlPrefix);
	}
	
	/**
	 * 处理  Action 的URL 列表 
	 * @param actionEntity
	 * @param className
	 * @param urlPrefix
	 */
	private void makeActionUrls(SrcFileEntity actionEntity,String className,String urlPrefix){
		String desc = actionEntity.getDescription();
		StringBuffer sb = new StringBuffer();
		String prefix = urlPrefix+className+"_";
		//---> 列表 URL
		sb.append("获取"+desc+"列表,").append(prefix+"list.action;");
		//---> 详情URL
		sb.append("获取"+desc+"信息,").append(prefix+"get.action;");
		//---> 保存URL
		sb.append("保存"+desc+",").append(prefix+"save.action;");
		//---> 新增URL
		sb.append("新增"+desc+",").append(prefix+"add.action;");
		//---> 删除URL
		sb.append("删除"+desc+",").append(prefix+"delete.action;");
		//---> 启用URL
		sb.append("启用"+desc+",").append(prefix+"enabled.action;");
		//---> 禁用URL
		sb.append("禁用"+desc+",").append(prefix+"disabled.action;");
		actionEntity.setRemark(sb.toString());
	}
	
	/***
	 * 创建Service接口源文件
	 * @param packName	Service接口包名
	 * @param className	类名前缀
	 * @param daoInterEntity	接口源文件实体对象
	 * @return
	 */
	private Map<String,String> createServiceInterFile(String packName,String className,SrcFileEntity serviceInterEntity,Map<String,String> context){
		String serviceInterStr = serviceTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, serviceInterEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		String filePath = serviceInterEntity.getPath();
		writeFile(filePath, serviceInterStr, repMap);
		
		serviceInterEntity.setRemark(packName);//将包名保存到 remark 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		String serviceImport = packName+"."+serviceInterEntity.getName().replace(".java", "");
		params.put(SERVICEINTERIMPORT_KEY, serviceImport);
		return params;
	}
	
	/***
	 * 创建Service实现类源文件
	 * @param packName	Service实现类包名
	 * @param className	类名前缀
	 * @param serviceImplEntity	Service 实现类源文件实体对象
	 * @return
	 */
	private Map<String,String> createServiceImplFile(String packName,String className,SrcFileEntity serviceImplEntity,Map<String,String> context){
		String serviceImplStr = serviceImplTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		importPacks += getImportPackage(context.get(DAOINTERIMPORT_KEY));
		importPacks += getImportPackage(context.get(SERVICEINTERIMPORT_KEY));
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, serviceImplEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		String serviceObj = className.substring(0,1).toLowerCase()+className.substring(1)+"Service";
		repMap.put(BACK_SERVICE_OBJ, serviceObj);
		repMap.put(BACK_DAO_OBJ, context.get(BACK_DAO_OBJ));
		String filePath = serviceImplEntity.getPath();
		writeFile(filePath, serviceImplStr, repMap);
		
		serviceImplEntity.setRemark(packName);	//将包名保存到 remark 字段中
		serviceImplEntity.setTabname(serviceObj);	//将 注解对象保存到 tab 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		params.put(BACK_SERVICE_OBJ, serviceObj);
	
		return params;
	}
	
	/**
	 * 实体包导入KEY
	 */
	private static final String ENTITYIMPORT_KEY = "entityImport";
	/**
	 * DAO接口包导入KEY
	 */
	private static final String DAOINTERIMPORT_KEY = "daointerImport";
	/**
	 * Service接口包导入KEY
	 */
	private static final String SERVICEINTERIMPORT_KEY = "serviceinterImport";
	/***
	 * 创建DAO接口源文件
	 * @param packName	DAO接口包名
	 * @param className	类名前缀
	 * @param daoInterEntity	接口源文件实体对象
	 * @return
	 */
	private Map<String,String> createDaoInterFile(String packName,String className,SrcFileEntity daoInterEntity,Map<String,String> context){
		String daoInterStr = daoInterTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, daoInterEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		String filePath = daoInterEntity.getPath();
		writeFile(filePath, daoInterStr, repMap);
		
		daoInterEntity.setRemark(packName);//将包名保存到 remark 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		String daoImport = packName+"."+daoInterEntity.getName().replace(".java", "");
		params.put(DAOINTERIMPORT_KEY, daoImport);
		return params;
	}
	
	/***
	 * 创建DAO实现类源文件
	 * @param packName	DAO接口包名
	 * @param className	类名前缀
	 * @param daoImplEntity	接口源文件实体对象
	 * @return
	 */
	private Map<String,String> createDaoImplFile(String packName,String className,SrcFileEntity daoImplEntity,Map<String,String> context){
		String daoImplStr = daoImplTemp;
		String importPacks = context.get(ENTITYIMPORT_KEY);
		importPacks = getImportPackage(importPacks);
		importPacks += getImportPackage(context.get(DAOINTERIMPORT_KEY));
		Map<String,String> repMap = getReplaceMap(packName, className, importPacks, daoImplEntity);
		repMap.put(BACK_ENTITY, context.get(BACK_ENTITY));
		String daoObj = className.substring(0,1).toLowerCase()+className.substring(1)+"Dao";
		
		repMap.put(BACK_DAO_OBJ, daoObj);	
		String filePath = daoImplEntity.getPath();
		writeFile(filePath, daoImplStr, repMap);
		
		daoImplEntity.setRemark(packName);	//将包名保存到 remark 字段中
		daoImplEntity.setTabname(daoObj);	//将 注解对象保存到 tab 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		params.put(BACK_DAO_OBJ, daoObj);
		return params;
	}
	
	/**
	 * 阶建 Entity 源文件代码
	 * @param filePath
	 * @param packName
	 * @param entityClassName
	 * @param srcEntity
	 * @param fields
	 * @return
	 * @throws ServiceException
	 */
	public Map<String,String> createEntityFile(String filePath,String packName,String entityClassName,SrcFileEntity srcEntity,FieldsEntity[] fields)
	throws ServiceException{
		String entityStr = entityTemp;
	
		String extendcls = srcEntity.getExtendcls();
		String importPacks = extendsClsMap.get(extendcls);
		importPacks = getImportPackage(importPacks);
		if(null == importPacks) throw new ServiceException(extendcls+"在TemplateServiceImpl.java 的 extendsClsMap 未初始化！");
		Map<String, String> repMap = getReplaceMap(packName, entityClassName,
				 importPacks,srcEntity);
		repMap.put(BACK_TABLE, srcEntity.getTabname());
		repMap.put(BACK_SUPENTITY,extendcls);
		String[] fldsCodes = getFieldsSourceCode(fields);
		repMap.put(BACK_FIELDS_MEMBER, fldsCodes[0]);
		repMap.put(BACK_FIELDS_METHODS, fldsCodes[1]);
		repMap.put(BACK_FIELDS_VALS, fldsCodes[2]);
		repMap.put(BACK_FIELDS_NAMES, fldsCodes[3]);
		writeFile(filePath, entityStr, repMap);
		
		srcEntity.setRemark(packName);//将包名保存到 remark 字段中
		
		Map<String,String> params = new HashMap<String, String>();
		String entityName = srcEntity.getName().replace(".java", "");
		params.put(BACK_ENTITY, entityName);
		params.put(ENTITYIMPORT_KEY, packName+"."+entityName);
		String pkField = getPkField(fields);
		params.put(BACK_ENTITY_PKID, pkField);
		String code = entityClassName.substring(0,1);
		params.put(BACK_CODE, code.toUpperCase());
		return params;
	}
	
	/**
	 * 获取主键字段名
	 * @param fields
	 * @return
	 */
	private String getPkField(FieldsEntity[] fields){
		String pkField = "id";
		for(FieldsEntity field : fields){
			if(null == field) continue;
			String bind = field.getBind();
			if(StringHandler.isValidStr(bind) && PRIMARY_KEY_DESC.equals(bind)){
				pkField=field.getFieldName();
				break;
			}
		}
		return pkField;
	}
	
	/**
	 * 将要导入的包格式化后返回
	 * @param importPackage 导入的包
	 * @return
	 */
	private String getImportPackage(String importPackage){
		return "import "+importPackage+";\n";
	}
	
	/**
	 * 将模板进行处理后，以入文件
	 * @param filePath
	 * @param entityStr
	 * @param repMap
	 */
	private void writeFile(String filePath, String entityStr,
			Map<String, String> repMap) {
		Set<String> keys = repMap.keySet();
		for(String key : keys){
			entityStr = entityStr.replace(key, repMap.get(key));
		}
		FileUtil.writeStrToFile(filePath, entityStr);
	}
	
	/**
	 * 创建用户替换模板文件标记的Map 对象
	 * @param packName	包名
	 * @param className 类名
	 * @param importPacks	导入包
	 * @param srcEntity	实体对象
	 * @return
	 */
	private Map<String, String> getReplaceMap(String packName,
			String className, String importPacks, SrcFileEntity srcEntity) {
		Map<String,String> repMap = new HashMap<String, String>();
		repMap.put(BACK_PACAKGE, packName+";\n");
		repMap.put(BACK_IMPORT, importPacks);
		String description = srcEntity.getDescription();
		String author = srcEntity.getAuthor();
		String createDate = srcEntity.getCreatorDate();
		repMap.put(BACK_DESCRIPTION, description);
		repMap.put(BACK_AUTHOR, author);
		repMap.put(BACK_DATE, createDate);
		repMap.put(BACK_CLASSNAME, className);
		return repMap;
	}
	
	private String[] getFieldsSourceCode(FieldsEntity[] fields){
		String[] arrs = new String[4];
		StringBuffer sb1 = new StringBuffer();
		StringBuffer sb2 = new StringBuffer();
		StringBuffer sb3 = new StringBuffer();
		StringBuffer sb4 = new StringBuffer();
		for(FieldsEntity field : fields){
			if(null == field) continue;
			String fieldStr = getFieldsStrs(field);
			sb1.append(fieldStr + "\n");
			String methodStr = getMethodStrs(field);
			sb2.append(methodStr + "\n");
			String fieldName = field.getFieldName();
			sb3.append(fieldName+",");
			sb4.append("\""+fieldName+"\",");
		}
		arrs[0] = sb1.toString();
		arrs[1] = sb2.toString();
		if(sb3.length()>0){
			arrs[2] = StringHandler.RemoveStr(sb3, ",");
			arrs[3] = StringHandler.RemoveStr(sb4, ",");
		}
		return arrs;
	}

	private static final String PRIMARY_KEY_DESC = "主键";
	private static final String UNIQUE_KEY_DESC = "唯一";
	/**
	 * 获取字段源代码片断 
	 * @param field
	 * @return
	 */
	private String getFieldsStrs(FieldsEntity field) {
		StringBuffer sbCode = new StringBuffer();
		String fieldName = field.getFieldName();
		//remark dataType sqltype bind isnull len decimalnum defaultval
		String colName = field.getColName();
		String remark = field.getRemark();
		String dataType = field.getDataType();
		String sqltype = field.getSqltype();
		String bind = field.getBind();
		String isnull = field.getIsnull();
		Integer len = field.getLen();
		Integer decimalnum = field.getDecimalnum();
		String defaultval = field.getDefaultval();
		String choiceval = field.getChoiceval();
		sbCode.append("\n\t @Description(remark=\"").append(remark).append("\")\n");
		if(StringHandler.isValidStr(choiceval)) sbCode.append("\t\t").append(choiceval+"\n");
		if(StringHandler.isValidStr(bind) && bind.equals(PRIMARY_KEY_DESC)){
			sbCode.append("\t @Id @GeneratedValue(strategy=GenerationType.IDENTITY");
		}else{
			sbCode.append("\t @Column(name=\""+colName+"\" ");
			if(bind.equals(UNIQUE_KEY_DESC)) sbCode.append(",unique=true ");
			if(StringHandler.isValidStr(isnull) && isnull.equals("false")){
				sbCode.append(",nullable=false ");
			}
			if(null != len){
				sbCode.append(",length="+len+" ");
			}
			if(null != decimalnum) sbCode.append(",scale="+decimalnum);
		}
		
		sbCode.append(")\n");
		sbCode.append("\t private "+dataType+" "+fieldName);
		if(StringHandler.isValidStr(defaultval)) sbCode.append(" = "+defaultval);
		sbCode.append(";");
		
		return sbCode.toString();
	}
	
	/**
	 * 
	 * @param field
	 * @return
	 */
	private String getMethodStrs(FieldsEntity field){
		StringBuffer sbCode = new StringBuffer();
		String remark = field.getRemark();
		String fieldName = field.getFieldName();
		String dataType = field.getDataType();

		String firstChar = fieldName.substring(0, 1).toUpperCase();
		String endMethod = fieldName.substring(1);
		//---> setXxx() 方法
		sbCode.append("\t/**\n\t  * 设置"+remark+"的值\n" +
				"\t * @param \t"+fieldName+"\t "+remark+"\n" +
				"\t**/\n");
		
		sbCode.append("\tpublic void set").append(firstChar).append(endMethod).append("("+dataType+"  "+fieldName+"){\n");
		sbCode.append("\t\t this."+fieldName+"="+fieldName+";\n ");
		sbCode.append("\t}\n");
		
		//---> getXxx() 方法
		sbCode.append("\n\t/**\n\t  * 获取"+remark+"的值\n" +
				"\t * @return 返回"+remark+"的值\n" +
				"\t**/\n");
		
		sbCode.append("\tpublic "+dataType+" get").append(firstChar).append(endMethod).append("(){\n");
		sbCode.append("\t\t return "+fieldName+";\n ");
		sbCode.append("\t}\n");
		return sbCode.toString();
	}

	public List<PackageEntity> getParentPacks() {
		return parentPacks;
	}

	public void setParentPacks(List<PackageEntity> parentPacks) {
		this.parentPacks = parentPacks;
	}
	
	/**
	 * 获取 classes 所在的真实物理路径
	 * @return
	 */
	public static String getClassPath(){
		String classPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
		int index = classPath.indexOf("/");
		if(index == 0) classPath = classPath.substring(1);
		return classPath;
	}
	
	public static void main(String[] args){
		String classPath = StringHandler.getClassPath();
		System.out.println("classPath="+classPath);
	}
}
