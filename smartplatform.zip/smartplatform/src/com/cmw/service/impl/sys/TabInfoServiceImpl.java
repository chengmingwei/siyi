package com.cmw.service.impl.sys;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.service.AbsService;
import com.cmw.core.util.FastJsonUtil;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.StringHandler;
import com.cmw.dao.inter.sys.TabInfoDaoInter;
import com.cmw.entity.sys.MultiProjectEntity;
import com.cmw.entity.sys.TabCmnsEntity;
import com.cmw.entity.sys.TabInfoEntity;
import com.cmw.service.inter.sys.MultiProjectService;
import com.cmw.service.inter.sys.TabCmnsService;
import com.cmw.service.inter.sys.TabInfoService;
/**
 * 数据库表信息Service实现类
 * @author chengmingwei
 * @date 2017-08-11 17:17
 */
@Description(remark = "数据库表信息Service接口",createDate="2017-08-11 17:17")
@Service("tabInfoService")
public class TabInfoServiceImpl extends AbsService<TabInfoEntity, Long> implements  TabInfoService {
	@Autowired
	private TabInfoDaoInter tabInfoDao;
	
	@Resource(name="tabCmnsService")
	private  TabCmnsService tabCmnsService;
	
	@Resource(name="dbMgrService")
	private DbMgrService dbMgrService;
	
	@Resource(name="multiProjectService")
	private MultiProjectService multiProjectService;
	
	@Override
	public GenericDaoInter<TabInfoEntity, Long> getDao() {
		return tabInfoDao;
	}
	
	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> complexData)
			throws ServiceException {
		Long id = complexData.getvalAsLng("id");
		String description = complexData.getvalAsStr("description");
		String fields = complexData.getvalAsStr("fields");
		TabInfoEntity tabInfoObj = getEntity(id);
		Long projectId = tabInfoObj.getProjectId();
		String tab = tabInfoObj.getName();
		MultiProjectEntity multiProj = multiProjectService.getEntity(projectId);
		String comment = tabInfoObj.getRemark();
		if(!StringHandler.isValidStr(comment)
			|| !comment.equals(description)){
			String sql = "ALTER TABLE `"+tab+"` COMMENT '"+description+"'";
			dbMgrService.executeSql(multiProj, sql);
		}
		tabInfoObj.setRemark(description);
		tabInfoObj.setModifyTime(new Date());
		
		updateEntity(tabInfoObj);
		
		updateTabCmns(multiProj, tab, fields);
		
		return null;
	}

	private void updateTabCmns(MultiProjectEntity multiProj, String tab, String fields) {
		if(!StringHandler.isValidStr(fields)) return;
		JSONArray jsonArr = FastJsonUtil.convertStrToJSONArr(fields);
		if(null == jsonArr || jsonArr.size() == 0) return;
		List<String> listSql = new ArrayList<String>();
		for(int i=0, count = jsonArr.size(); i < count; i++){
			JSONObject jsonObj = jsonArr.getJSONObject(i);
			Long id = jsonObj.getLong("id");
			String remark  = jsonObj.getString("remark");
			TabCmnsEntity entity = tabCmnsService.getEntity(id);
			String colName = entity.getColName();
			String comment = entity.getRemark();
			String dataType = entity.getDataType();
			
			int len = entity.getLen();
			if(!StringHandler.isValidStr(comment) || 
				!comment.equals(remark)){
				String sql = "ALTER TABLE `"+tab+"` MODIFY COLUMN `"+colName+"` "+dataType+" COMMENT '"+remark+"' ";
				if(len > 0 && !dataType.equals("DATETIME")){
					String lenStr = len+"";
					dataType = dataType.toUpperCase();
					if(dataType.equals("DECIMAL") || dataType.equals("FLOAT") || dataType.equals("DOUBLE")){
						Integer decimalnum = entity.getDecimalnum();
						if(null != decimalnum && decimalnum.intValue() > 0){
							lenStr = len+","+decimalnum;
						}
					}
					sql = "ALTER TABLE `"+tab+"` MODIFY COLUMN `"+colName+"` "+dataType+"("+lenStr+") COMMENT '"+remark+"' ";
				}
				listSql.add(sql);
			}
			entity.setRemark(remark);
		}
		if(null == listSql || listSql.size() == 0) return;
		dbMgrService.executeSql(multiProj, listSql);
	}
	
	
}
