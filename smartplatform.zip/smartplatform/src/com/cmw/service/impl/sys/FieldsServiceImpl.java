package com.cmw.service.impl.sys;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.service.AbsService;
import com.cmw.dao.inter.sys.FieldsDaoInter;
import com.cmw.entity.sys.FieldsEntity;
import com.cmw.service.inter.sys.FieldsService;
/**
 *  字段业务实现类
 * @author ddd
 *
 */
@Service("fieldsService")
public class FieldsServiceImpl extends AbsService<FieldsEntity, Long> implements  FieldsService {
	@Autowired
	private FieldsDaoInter fieldsDao;
	@Override
	public GenericDaoInter<FieldsEntity, Long> getDao() {
		return fieldsDao;
	}

}
