package com.cmw.service.impl.sys;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.service.AbsService;
import com.cmw.dao.inter.sys.MultiProjectDaoInter;
import com.cmw.entity.sys.MultiProjectEntity;
import com.cmw.service.inter.sys.MultiProjectService;
/**
 * 多模块项目业务实现类
 * @author chengmingwei
 * @date 2017-05-28 16:34
 */
@Service("multiProjectService")
public class MultiProjectServiceImpl extends AbsService<MultiProjectEntity, Long> implements MultiProjectService {
	@Autowired
	private MultiProjectDaoInter multiProjectDao;
	@Override
	public GenericDaoInter<MultiProjectEntity, Long> getDao() {
		return multiProjectDao;
	}
	
}
