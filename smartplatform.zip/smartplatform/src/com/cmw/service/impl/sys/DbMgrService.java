package com.cmw.service.impl.sys;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmw.core.jdbc.ConnectionManager;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.SqlUtil;
import com.cmw.core.util.StringHandler;
import com.cmw.entity.sys.FieldsEntity;
import com.cmw.entity.sys.MultiProjectEntity;
import com.cmw.entity.sys.SrcFileEntity;
import com.cmw.entity.sys.TabCmnsEntity;
import com.cmw.entity.sys.TabInfoEntity;
import com.cmw.service.inter.sys.TabCmnsService;
import com.cmw.service.inter.sys.TabInfoService;

/**
 * 数据库操作Service实现类
 * @author chengmingwei
 * @date 2017-06-09 17:37
 */
@Service("dbMgrService")
public class DbMgrService {
	static final Logger LOGGER = Logger.getLogger(DbMgrService.class);
	ConnectionManager connMgr = ConnectionManager.getInstance();
	
	@Resource(name = "tabInfoService")
	TabInfoService tabInfoService;
	
	@Resource(name = "tabCmnsService")
	TabCmnsService tabCmnsService;
	
	/**
	 * 同步数据库的所有表
	 * @param project
	 * @throws Exception 
	 */
	public void synchroTabs(MultiProjectEntity project) throws Exception{
		 Connection conn = null;
		 Statement stmt = null;
		 conn = getConn(project);
		 Long projectId = project.getId();
		 try {
			DatabaseMetaData dbMetaData = conn.getMetaData();
			String catalog = conn.getCatalog();
			ResultSet  rs = dbMetaData.getTables(catalog, null, null, new String[]{"TABLE"});
			
			while(rs.next()){
				saveTabInfo(conn, rs, projectId);  
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }
		      
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
	}

	@Transactional
	public void saveTabInfo(Connection conn, ResultSet rs, Long projectId)
			throws SQLException, Exception {
		String tabName = rs.getString("TABLE_NAME");
		String tabComment = rs.getString("REMARKS");
		DatabaseMetaData dmd = conn.getMetaData();
		ResultSet rsCmns = dmd.getColumns(null, getSchema(conn),tabName.toUpperCase(), "%");
		
		List<String> primaryKeys = getPrimaryKeys(dmd, conn, tabName.toUpperCase());
		
		SHashMap<String, Object> pars = new SHashMap<String, Object>();
		pars.put("projectId", projectId);
		pars.put("name", SqlUtil.LOGIC_EQ + SqlUtil.LOGIC + tabName);
		TabInfoEntity tabInfoObjOld = tabInfoService.getEntity(pars);
		if(null != tabInfoObjOld){
			Long tabInfoId = tabInfoObjOld.getId();
			tabInfoService.deleteEntity(tabInfoId);
			pars.clear();
			pars.put("tabId", tabInfoId);
			tabCmnsService.deleteEntitys(pars);
		}
		
		TabInfoEntity tabInfoObj = new TabInfoEntity();
		tabInfoObj.setProjectId(projectId);
		tabInfoObj.setName(tabName);
		tabInfoObj.setRemark(tabComment);
		tabInfoService.saveEntity(tabInfoObj);
		Long tabId = tabInfoObj.getId();
		List<TabCmnsEntity> list = new ArrayList<TabCmnsEntity>();
		
		while(rsCmns.next()){
			TabCmnsEntity tabCmnsObj = new TabCmnsEntity();
		    String colName = rsCmns.getString("COLUMN_NAME");
		    String remarks = rsCmns.getString("REMARKS");  
		    if(remarks == null || remarks.equals("")){  
		        remarks = colName;  
		    } 
		    String dbType = rsCmns.getString("TYPE_NAME");
		    String IS_NULLABLE = rsCmns.getString("IS_NULLABLE"); 
		    String COLUMN_DEF = rsCmns.getString("COLUMN_DEF");
		    String COLUMN_SIZE = rsCmns.getString("COLUMN_SIZE");
		    String DECIMAL_DIGITS = rsCmns.getString("DECIMAL_DIGITS");
		    
		    
		    tabCmnsObj.setTabId(tabId);
		    tabCmnsObj.setColName(colName);
		    tabCmnsObj.setRemark(remarks);
		    tabCmnsObj.setDataType(dbType);
		    if(StringHandler.isValidStr(DECIMAL_DIGITS)){
		    	 tabCmnsObj.setDecimalnum(Integer.parseInt(DECIMAL_DIGITS));
		    }
		    if(StringHandler.isValidStr(COLUMN_SIZE)){
		    	  tabCmnsObj.setLen(Integer.parseInt(COLUMN_SIZE));
		    }
		    if(StringHandler.isValidStr(COLUMN_DEF)){
		    	tabCmnsObj.setDefaultval(COLUMN_DEF);
		    }
		    if(StringHandler.isValidStr(IS_NULLABLE)){
		    	String isnull = (IS_NULLABLE.equals("NO")) ? "false" : "true";
		    	  tabCmnsObj.setIsnull(isnull);
		    }
		    String bind = null;
		    if(null != primaryKeys && primaryKeys.size() > 0){
		    	for(String primaryKey : primaryKeys){
		    		if(colName.equals(primaryKey)){
		    			bind = "1";
		    			break;
		    		}
		    	}
		    }
		    tabCmnsObj.setBind(bind);
		    list.add(tabCmnsObj);
		}
		tabCmnsService.batchSaveEntitys(list);
	}
	
	/**
	 * 获取表中所有的主键
	 * @param dmd
	 * @param conn
	 * @param tabName
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	private List<String> getPrimaryKeys(DatabaseMetaData dmd, Connection conn, String tabName) throws SQLException, Exception{
		List<String> list = new ArrayList<String>();
		ResultSet rs = dmd.getPrimaryKeys(null, null, tabName.toUpperCase());
		while(rs.next()){
			 String colName = rs.getString("COLUMN_NAME");
			 list.add(colName);
		}
		return list;
	}
	
	/**
	 * 创建表
	 * @param pars 数据库链接地址和帐号和密码
	 * @param project	多模块项目
	 * @param fields	字段列表
	 */
	public void createTable(MultiProjectEntity project, SrcFileEntity entity, FieldsEntity[] fields){
		 Connection conn = null;
		 Statement stmt = null;
		 conn = getConn(project);
		 try {
			stmt = conn.createStatement();
			createTableSql(stmt, entity, fields);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
		      try{
		         if(stmt!=null)
		            conn.close();
		      }catch(SQLException se){
		      }
		      
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
		
	}

    
   //其他数据库不需要这个方法 oracle和db2需要  
   private static String getSchema(Connection conn) throws Exception {  
       String schema;  
       schema = conn.getMetaData().getUserName();  
       if ((schema == null) || (schema.length() == 0)) {  
           throw new Exception("ORACLE数据库模式不允许为空");  
       }  
       return schema.toUpperCase().toString();  
   }  
 
   
	private void createTableSql(Statement stmt, SrcFileEntity entity, FieldsEntity[] fields) throws SQLException{
		StringBuilder sbSql = new StringBuilder();
		String tabName = entity.getTabname();
		String description = entity.getDescription();
		String tabFieldSql = getTabFieldSql(entity, fields);
		stmt.execute("DROP TABLE IF EXISTS `"+tabName+"`");
		sbSql.append(" CREATE TABLE `"+tabName+"` (")
		.append(tabFieldSql)
		.append(") ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ");
		if(StringHandler.isValidStr(description)){
			sbSql.append(" COMMENT='"+description+"';");
		}
		
		String tableSql = sbSql.toString();
		LOGGER.info(tableSql);
		stmt.execute(tableSql);
	}
	
	private String getTabFieldSql(SrcFileEntity entity, FieldsEntity[] fields){
		StringBuilder sbFields = new StringBuilder();
		String extendcls = entity.getExtendcls();
		if(StringHandler.isValidStr(extendcls) && (extendcls.equals("IdBaseEntity") || extendcls.equals("IdEntity"))){
			String cmnSqls = getCmnSqls(fields, null);
			sbFields.append(cmnSqls);
			if(extendcls.equals("IdBaseEntity")){
				sbFields.append("  `createTime` datetime NOT NULL, ")
					.append(" `creator` bigint(20) NOT NULL, ")
					.append(" `deptId` bigint(20) NOT NULL, ")
					.append(" `empId` bigint(20) DEFAULT NULL, ")
					.append(" `isenabled` tinyint(4) NOT NULL, ")
					.append(" `modifier` bigint(20) DEFAULT NULL, ")
					.append(" `modifytime` datetime DEFAULT NULL, ")
					.append(" `orgid` bigint(20) NOT NULL, ")
					.append(" `remark` longtext COLLATE utf8_bin, ");
			}
			sbFields.append("`id` bigint(20) NOT NULL AUTO_INCREMENT,PRIMARY KEY (`id`)");
		}else{
			FieldsEntity primaryFields = getPrimayFieldEntity(fields);
			String cmnSqls = getCmnSqls(fields, primaryFields);
			if(null != primaryFields){
				sbFields.append(cmnSqls);
				String primayKeyStr = getPrimaryKeyStr(primaryFields);
				sbFields.append(primayKeyStr);
			}else{
				cmnSqls = StringHandler.RemoveStr(cmnSqls, ",");
				sbFields.append(cmnSqls);
			}
		}
		return sbFields.toString();
	}
	
	private String getCmnSqls(FieldsEntity[] fields, FieldsEntity primaryFields){
		StringBuilder sbFields = new StringBuilder();
		if(null != primaryFields){
			for(FieldsEntity field : fields){
				String remark = field.getRemark();
				String colName = field.getColName();
				if(primaryFields.getColName().equals(colName)) continue;
				String sqldataType = field.getSqltype();
				String isnull = field.getIsnull();
				int len = 0;
				if(null != field.getLen()) len = field.getLen();
				
				String defaultVal = field.getDefaultval();
				String bind = field.getBind();
				Integer decimalnum = field.getDecimalnum();
				StringBuilder sbCmn = new StringBuilder();
				if(sqldataType.toUpperCase().indexOf("INT") != -1 && len == 0){
					len = 11;
				}else if(sqldataType.toUpperCase().indexOf("CHAR") != -1 && len == 0){
					len = 50;
				}else if((sqldataType.toUpperCase().indexOf("DECIMAL") != -1 && len == 0)
						|| (sqldataType.toUpperCase().indexOf("DOUBLE") != -1 && len == 0)
						|| (sqldataType.toUpperCase().indexOf("FLOAT") != -1 && len == 0)){
					len = 19;
				}
				String lenStr = len+"";
				if(null != decimalnum && decimalnum.intValue() > 0){
					lenStr += ","+decimalnum;
				}
				if(sqldataType.toUpperCase().indexOf("DATE") != -1){ //日期格式不需要加长度
					sbCmn.append("`"+colName+"` ").append(sqldataType);
				}else{
					sbCmn.append("`"+colName+"` ").append(sqldataType).append("("+lenStr+") ");
				}
				
				
				boolean notNull = false;
				if(StringHandler.isValidStr(isnull) && isnull.equals("false")){
				  sbCmn.append(" NOT NULL ");	
				  notNull = true;
				}
				
				if(StringHandler.isValidStr(defaultVal)){
					defaultVal = " DEFAULT '"+defaultVal+"' ";
				}else{
					defaultVal = " DEFAULT NULL ";
				}
				if(!notNull) sbCmn.append(defaultVal);
				if(StringHandler.isValidStr(bind) && bind.equals("唯一")){
					sbCmn.append(" unique ");
				}
				
				if(StringHandler.isValidStr(remark)){
					sbCmn.append(" COMMENT '"+remark+"' ");
				}
				sbCmn.append(",");
				sbFields.append(sbCmn.toString());
			}
		}else{
			for(FieldsEntity field : fields){
				String remark = field.getRemark();
				String colName = field.getColName();
				String sqldataType = field.getSqltype();
				String isnull = field.getIsnull();
				int len = 0;
				if(null != field.getLen()) len = field.getLen();
				
				String defaultVal = field.getDefaultval();
				String bind = field.getBind();
				Integer decimalnum = field.getDecimalnum();
				StringBuilder sbCmn = new StringBuilder();
				if(sqldataType.toUpperCase().indexOf("INT") != -1 && len == 0){
					len = 11;
				}else if(sqldataType.toUpperCase().indexOf("CHAR") != -1 && len == 0){
					len = 50;
				}else if(sqldataType.toUpperCase().indexOf("DECIMAL") != -1 && len == 0){
					len = 19;
				}
				String lenStr = len+"";
				if(null != decimalnum && decimalnum.intValue() > 0){
					lenStr += ","+decimalnum;
				}
				
				if(sqldataType.toUpperCase().indexOf("DATE") != -1){ //日期格式不需要加长度
					sbCmn.append("`"+colName+"` ").append(sqldataType);
				}else{
					sbCmn.append("`"+colName+"` ").append(sqldataType).append("("+lenStr+") ");
				}
				
				boolean notNull = false;
				if(StringHandler.isValidStr(isnull) && isnull.equals("false")){
				  sbCmn.append(" NOT NULL ");	
				  notNull = true;
				}
				
				if(StringHandler.isValidStr(defaultVal)){
					defaultVal = " DEFAULT '"+defaultVal+"' ";
				}else{
					defaultVal = " DEFAULT NULL ";
				}
				if(!notNull) sbCmn.append(defaultVal);
				if(StringHandler.isValidStr(bind) && bind.equals("唯一")){
					sbCmn.append(" unique ");
				}
				
				if(StringHandler.isValidStr(remark)){
					sbCmn.append(" COMMENT '"+remark+"' ");
				}
				sbCmn.append(",");
				sbFields.append(sbCmn.toString());
			}
		}
		return sbFields.toString();
	}

	private String getPrimaryKeyStr(FieldsEntity primaryFields) {
		StringBuilder sbFields = new StringBuilder();
		if(null != primaryFields){
			String colName = primaryFields.getColName();
			String sqltype = primaryFields.getSqltype();
			Integer len = primaryFields.getLen();
			sbFields.append("`"+colName+"` "+sqltype+"("+len+") NOT NULL");
			if(sqltype.toUpperCase().indexOf("CHAR") == -1){
				sbFields.append(" AUTO_INCREMENT,");
			}
			sbFields.append(" PRIMARY KEY (`"+colName+"`)");
		}
		return sbFields.toString();
	}

	private FieldsEntity getPrimayFieldEntity(FieldsEntity[] fields) {
		FieldsEntity primaryFields = null;
		for(FieldsEntity field : fields){
			String bind = field.getBind();
			if(StringHandler.isValidStr(bind) && bind.equals("主键")){
				primaryFields = field;
				break;
			}
		}
		return primaryFields;
	}
	
	/**
	 * 获取数据库链接
	 * @param project
	 * @return
	 */
	private Connection getConn(MultiProjectEntity project) {
		SHashMap<String, Object> pars = new SHashMap<String, Object>();
		String dbServer = project.getDbServer();
		String dbName = project.getDbNames();
		String user = project.getDbusername();
		String dbpassword = project.getDbpassword();
		pars.put("url", "jdbc:mysql://"+dbServer+":3306/"+dbName+"?useUnicode=true&characterEncoding=UTF-8");
		pars.put("user", user);
		pars.put("password", dbpassword);
		LOGGER.info("======== getConn =========");
		LOGGER.info("url =" + pars.getvalAsStr("url"));
		LOGGER.info("user =" + pars.getvalAsStr("user"));
		LOGGER.info("password =" + pars.getvalAsStr("password"));
		Connection conn = connMgr.getConnection(pars);
		return conn;
	}
	
	/**
	 * 检查DB是否存在
	 * @param project
	 * @return
	 */
	public boolean existDB(MultiProjectEntity project){
		boolean exist = false;
		String dbName = project.getDbNames();
		Connection conn = getSchemaConn(project);
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			String sql = "select * from SCHEMATA where SCHEMA_NAME='"+dbName+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				exist = true;
				break;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
	      try{
		         if(stmt!=null)
		            conn.close();
		      }catch(SQLException se){
		      }
		      
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
		return exist;
	}

	private Connection getSchemaConn(MultiProjectEntity project) {
		String userName = project.getDbusername();
		String passWord = project.getDbpassword();
		
		String dbServer = project.getDbServer();
		SHashMap<String, Object> pars = new SHashMap<String, Object>();
		pars.put("url", "jdbc:mysql://"+dbServer+":3306/information_schema");
		pars.put("user", userName);
		pars.put("password", passWord);
		Connection conn = connMgr.getConnection(pars);
		return conn;
	}
	
	public DataTable getSchemaDatas(MultiProjectEntity project, String tab, String cmns){
		String dbName = project.getDbNames();
		Connection conn = getSchemaConn(project);
		String sql = "select COLLATION_NAME,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION" +
				" from `COLUMNS` where TABLE_SCHEMA = '"+dbName+"' and TABLE_NAME='"+tab+"'";
		DataTable dt = executeQuery(conn, sql);
		return dt;
	}

	private DataTable executeQuery(Connection conn, String sql) {
		DataTable dt = null;
		Statement stmt = null;
		try {
			List<Object> dataSource = new ArrayList<Object>();
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			Map<String, Integer> cmnMap = getCmnNames(rs);
			if(null == cmnMap || cmnMap.size() == 0) return null;
			
			Set<String> cmnsSet = cmnMap.keySet();
			int cmnCount = cmnsSet.size();
			String[] cmnsArr = new String[cmnCount];
			cmnsArr = cmnsSet.toArray(cmnsArr);
			dt = new DataTable(dataSource, StringHandler.join(cmnsArr));
			while(rs.next()){
				Object[] row = new Object[cmnCount];
				for(int j=0; j<cmnCount; j++){
					String cmn = cmnsArr[j];
					row[j] = rs.getObject(cmn);
				}
				dataSource.add(row);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
	      try{
		         if(stmt!=null)
		            conn.close();
		      }catch(SQLException se){
		      }
		      
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
		return dt;
	}
	
	/**
	 * 获取查询的表字段
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Map<String, Integer> getCmnNames(ResultSet rs) throws SQLException{
		ResultSetMetaData metaData = rs.getMetaData();
		int cmnCount = metaData.getColumnCount();
		if(0 == cmnCount) return null;
		Map<String, Integer> cmnMap = new HashMap<String, Integer>();
		for(int i = 0; i < cmnCount; i++){
			String cmn = metaData.getColumnLabel(i);
			int cmnType = metaData.getColumnType(i);
			cmnMap.put(cmn, cmnType);
		}
		return cmnMap;
	}
	
	public static void main(String[] args){
		SHashMap<String, Object> pars = new SHashMap<String, Object>();
		pars.put("url", "jdbc:mysql://localhost:3306/provider-course");
		pars.put("user", "root");
		pars.put("password", "root");
		Connection conn = ConnectionManager.getInstance().getConnection(pars);
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			//String tableSql = "DROP TABLE IF EXISTS ts_RankReport;\n CREATE TABLE ts_RankReport (id bigint(20) NOT NULL AUTO_INCREMENT,PRIMARY KEY (id)) ";
			String tableSql = "DROP TABLE IF EXISTS ts_RankReport ";
			//LOGGER.info(tableSql);
			stmt.execute(tableSql);
			tableSql = "CREATE TABLE ts_RankReport (id bigint(20) NOT NULL AUTO_INCREMENT,PRIMARY KEY (id)) ";
			stmt.execute(tableSql);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
		      try{
		         if(stmt!=null)
		            conn.close();
		      }catch(SQLException se){
		      }
		      
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
	}

	/**
	 * 执行SQL语句
	 * @param multiProj
	 * @param sql
	 * @author chengmingwei
	 * @date 2017年8月20日 下午5:02:57
	 */
	public void executeSql(MultiProjectEntity project, String sql) {
		 Connection conn = null;
		 Statement stmt = null;
		 conn = getConn(project);
		 try {
			stmt = conn.createStatement();
			stmt.execute(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		    	  se.printStackTrace();
		      }
		      
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
	}
	
	/**
	 * 执行SQL语句
	 * @param multiProj
	 * @param sql
	 * @author chengmingwei
	 * @date 2017年8月20日 下午5:02:57
	 */
	public void executeSql(MultiProjectEntity project, List<String> listSql) {
		if(null == listSql || listSql.size() == 0) return;
		 Connection conn = null;
		 Statement stmt = null;
		 conn = getConn(project);
		 try {
			stmt = conn.createStatement();
			for(String sql : listSql){
				stmt.execute(sql);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		    	  se.printStackTrace();
		      }
		      
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
	}
}

