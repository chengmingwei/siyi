package com.cmw.service.impl.sys;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.exception.DaoException;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.service.AbsService;
import com.cmw.core.util.DataTable;
import com.cmw.dao.inter.sys.ProjectDaoInter;
import com.cmw.entity.sys.ProjectEntity;
import com.cmw.service.inter.sys.ProjectService;
/**
 * 项目管理业务实现类
 * @author ddd
 *
 */
@Service("projectService")
public class ProjectServiceImpl extends AbsService<ProjectEntity, Long> implements ProjectService {
	@Autowired
	private ProjectDaoInter projectDao;
	@Override
	public GenericDaoInter<ProjectEntity, Long> getDao() {
		return projectDao;
	}
	
	@Override
	public DataTable getDataSource() throws ServiceException {
		try{
			return projectDao.getDataSource();
		}catch(DaoException ex){
			throw new ServiceException(ex);
		}
	}
	
	
}
