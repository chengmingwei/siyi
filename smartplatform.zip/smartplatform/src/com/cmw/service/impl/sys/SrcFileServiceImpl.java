package com.cmw.service.impl.sys;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.service.AbsService;
import com.cmw.dao.inter.sys.SrcFileDaoInter;
import com.cmw.entity.sys.SrcFileEntity;
import com.cmw.service.inter.sys.SrcFileService;
/**
 * 源文件业务实现类
 * @author ddd
 *
 */
@Service("srcfileService")
public class SrcFileServiceImpl extends AbsService<SrcFileEntity, Long> implements SrcFileService {
	@Autowired
	private SrcFileDaoInter srcfileDao;
	@Override
	public GenericDaoInter<SrcFileEntity, Long> getDao() {
		return srcfileDao;
	}

}
