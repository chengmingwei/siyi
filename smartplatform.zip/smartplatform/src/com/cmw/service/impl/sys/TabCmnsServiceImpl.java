package com.cmw.service.impl.sys;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.service.AbsService;
import com.cmw.dao.inter.sys.TabCmnsDaoInter;
import com.cmw.entity.sys.TabCmnsEntity;
import com.cmw.service.inter.sys.TabCmnsService;
/**
 * 表列信息 Service实现类
 * @author chengmingwei
 * @date 2017-08-11 17:17
 */
@Description(remark = "表列信息 Service实现类",createDate="2017-08-11 17:17")
@Service("tabCmnsService")
public class TabCmnsServiceImpl extends AbsService<TabCmnsEntity, Long> implements  TabCmnsService {
	@Autowired
	private TabCmnsDaoInter tabCmnsDao;
	@Override
	public GenericDaoInter<TabCmnsEntity, Long> getDao() {
		return tabCmnsDao;
	}

}
