package com.cmw.service.inter.sys;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.service.IService;
import com.cmw.entity.sys.TabInfoEntity;

/**
 * 数据库表信息Service接口
 * @author chengmingwei
 * @date 2017-08-11 17:17
 */
@Description(remark = "数据库表信息Service接口",createDate="2017-08-11 17:17")
public interface TabInfoService extends IService<TabInfoEntity, Long> {
}
