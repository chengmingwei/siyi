package com.cmw.service.inter.sys;

import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.service.IService;
import com.cmw.core.util.DataTable;
import com.cmw.entity.sys.PackageEntity;

/**
 * 包业务接口
 * @author cmw_1984122
 *
 */
public interface PackageService extends IService<PackageEntity, Long> {
	/**
	 * 根据项目ID获取包数据
	 * @param projectId
	 * @return
	 * @throws ServiceException
	 */
	DataTable getDataSource(Long projectId) throws ServiceException;
}
