package com.cmw.service.inter.sys;

import com.cmw.core.base.service.IService;
import com.cmw.entity.sys.SrcFileEntity;

/**
 * 源文件业务接口
 * @author cmw_1984122
 *
 */
public interface SrcFileService extends IService<SrcFileEntity, Long> {
}
