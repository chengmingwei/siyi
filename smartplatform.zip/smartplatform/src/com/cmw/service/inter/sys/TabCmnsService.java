package com.cmw.service.inter.sys;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.service.IService;
import com.cmw.entity.sys.TabCmnsEntity;

/**
 * 表列信息 Service接口
 * @author chengmingwei
 * @date 2017-08-11 17:17
 */
@Description(remark = " 表列信息 Service接口",createDate="2017-08-11 17:17")
public interface TabCmnsService extends IService<TabCmnsEntity, Long> {
}
