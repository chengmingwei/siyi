package com.cmw.service.inter.sys;

import com.cmw.core.base.service.IService;
import com.cmw.entity.sys.ClassInfoEntity;

/**
 *  类附加信息业务接口
 * @author cmw_1984122
 *
 */
public interface ClassInfoService extends IService<ClassInfoEntity, Long> {
}
