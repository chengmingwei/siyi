package com.cmw.service.inter.sys;
/**
 * 模板符号常量接口
 * @author chengmingwei
 *
 */
public interface SysmbolTempService {
	/**
	 * 包替换符 : 在模板文件中的符号[ #PACKAGE# ] [Entity,DAO,SERVICE,ACTION] 共用
	 */
	public static final String BACK_PACAKGE = "#PACKAGE#";
	/**
	 * 导包替换符 : 在模板文件中的符号[ #IMPORT# ] [Entity,DAO,SERVICE,ACTION] 共用
	 */
	public static final String BACK_IMPORT = "#IMPORT#";
	/**
	 * 继承实体替换符: 在模板文件中的符号[ #SUPENTITY# ] [Entity] 共用
	 */
	public static final String BACK_SUPENTITY = "#SUPENTITY#";
	/**
	 * 类说明替换符: 在模板文件中的符号[ #DESCRIPTION# ] [Entity,DAO,SERVICE,ACTION] 共用
	 */
	public static final String BACK_DESCRIPTION = "#DESCRIPTION#";
	/**
	 * 作者替换符: 在模板文件中的符号[ #AUTHOR# ] [Entity,DAO,SERVICE,ACTION] 共用
	 */
	public static final String BACK_AUTHOR = "#AUTHOR#";
	/**
	 * 创建日期替换符: 在模板文件中的符号[ #DATE# ] [Entity,DAO,SERVICE,ACTION] 共用
	 */
	public static final String BACK_DATE = "#DATE#";
	/**
	 * 实体表替换符: 在模板文件中的符号[ #TABLE# ] [Entity] 共用
	 */
	public static final String BACK_TABLE = "#TABLE#";
	/**
	 * 类名替换符: 在模板文件中的符号[ #CLASSNAME# ] [Entity,DAO,SERVICE,ACTION] 共用
	 */
	public static final String BACK_CLASSNAME = "#CLASSNAME#";
	
	/**---------------- ** Entity 特有替换符 CODE START ** --------------**/
	/**
	 * Entity 字段替换符: 在模板文件中的符号[ #FIELDS_MEMBER# ] [Entity] 共用
	 */
	public static final String BACK_FIELDS_MEMBER = "#FIELDS_MEMBER#";
	/**
	 * Entity get,set 方法 替换符: 在模板文件中的符号[ #FIELDS_METHODS# ] [Entity] 共用
	 */
	public static final String BACK_FIELDS_METHODS = "#FIELDS_METHODS#";
	/**
	 * Entity getDatas() 方法值替换符: 在模板文件中的符号[ #FIELDS_VALS# ] [Entity] 共用
	 */
	public static final String BACK_FIELDS_VALS = "#FIELDS_VALS#";
	/**
	 *  Entity getFields 方法字段名列表替换符: 在模板文件中的符号[ #FIELDS_NAMES# ] [Entity] 共用
	 */
	public static final String BACK_FIELDS_NAMES = "#FIELDS_NAMES#";
	/**---------------- ** Entity 特有替换符 CODE END ** --------------**/
	
	/**
	 * Entity类 替换符: 在模板文件中的符号[ #ENTITY# ] [DAO,SERVICE,ACTION] 共用
	 */
	public static final String BACK_ENTITY = "#ENTITY#";
	/**
	 * Dao实现类注解对象 替换符: 在模板文件中的符号[ #DAO_OBJ# ] [DAO,SERVICE] 共用
	 */
	public static final String BACK_DAO_OBJ = "#DAO_OBJ#";
	/**
	 * Service实现类注解对象 替换符: 在模板文件中的符号[ #SERVICE_OBJ# ] [SERVICE,ACTION] 共用
	 */
	public static final String BACK_SERVICE_OBJ = "#SERVICE_OBJ#";
	/**
	 * Action URL前缀 替换符: 在模板文件中的符号[ #URL_PREFIX# ] [ACTION] 共用
	 */
	public static final String BACK_URL_PREFIX = "#URL_PREFIX#";
	/**
	 * Action 实体主键ID替换符: 在模板文件中的符号[ #ENTITY_PKID# ] [ACTION] 共用
	 */
	public static final String BACK_ENTITY_PKID = "#ENTITY_PKID#";
	/**
	 * Action 实体编号前缀替换符: 在模板文件中的符号[ #CODE# ] [ACTION] 共用
	 */
	public static final String BACK_CODE = "#CODE#";
	
	
	/**
	 * Mapper xml文件编号前缀替换符: 在模板文件中的符号[ #FIELDS_PROPS# ] 实体至表之间关系映射
	 */
	public static final String BACK_FIELDS_PROPS = "#FIELDS_PROPS#";
	
	/**
	 * Mapper xml文件编号前缀替换符: 在模板文件中的符号[ #BASE_CMNS# ] 表查询，插入字段
	 */
	public static final String BACK_BASE_CMNS = "#BASE_CMNS#";
	
	/**
	 * Mapper xml文件编号前缀替换符: 在模板文件中的符号[ #BASE_CMNS_VALS# ] 表插入值字段
	 */
	public static final String BACK_INSERT_CMNS_LIST = "#INSERT_CMNS_LIST#";
	
	/**
	 * Mapper xml文件编号前缀替换符: 在模板文件中的符号[ #BASE_CMNS_VALS# ] 表插入值字段
	 */
	public static final String BACK_INSERT_CMNS_VALS = "#INSERT_CMNS_VALS#";
	
	/**
	 * Mapper xml文件编号前缀替换符: 在模板文件中的符号[ #UP_CMNS# ] 表更新的字段
	 */
	public static final String BACK_UP_CMNS = "#UP_CMNS#";
	
	/**
	 * Mapper xml文件编号前缀替换符: 在模板文件中的符号[ #DAO_CLS# ] Dao类名
	 */
	public static final String BACK_DAO_CLS = "#DAO_CLS#";
	
	/**========== ServiceImpl 替换标识常量 =========**/
	/**
	 * 编号设置方法
	 */
	public static final String SERVICE_TAG_SET_CODE = "#SET_CODE#";
	/**
	 * 编号前缀
	 */
	public static final String SERVICE_TAG_PREFIX_CODE = "#PREFIX_CODE#";
	
	/**
	 * 实体字段验证
	 */
	public static final String SERVICE_TAG_PROP_VALID_FIELD = "#PROP_VALID_FIELD#";
	
}
