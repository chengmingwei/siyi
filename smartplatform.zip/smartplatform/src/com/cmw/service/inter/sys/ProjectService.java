package com.cmw.service.inter.sys;

import com.cmw.core.base.exception.DaoException;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.service.IService;
import com.cmw.core.util.DataTable;
import com.cmw.entity.sys.ProjectEntity;

/**
 * 项目管理业务接口
 * @author cmw_1984122
 *
 */
public interface ProjectService extends IService<ProjectEntity, Long> {
	
	/**
	 * 获取下拉框数据源
	 * @return
	 * @throws DaoException
	 */
	DataTable getDataSource() throws ServiceException;
}
