package com.cmw.service.inter.sys;

import com.cmw.core.base.service.IService;
import com.cmw.entity.sys.FieldsEntity;

/**
 *  字段业务接口
 * @author cmw_1984122
 *
 */
public interface FieldsService extends IService<FieldsEntity, Long> {
}
