package com.cmw.service.inter.sys;

import com.cmw.core.base.service.IService;
import com.cmw.entity.sys.MultiProjectEntity;

/**
 * 多模块项目管理业务接口
 * @author chengmingwei
 * @date 2017-05-28 15:34
 */
public interface MultiProjectService extends IService<MultiProjectEntity, Long> {
}
