package com.cmw.constant;
/**
 * 系统常量类
 * @author cmw_1984122
 *
 */
public class SysConstant {
	/**
	 * 用来标识一个不存在的ID
	 */
	public static final long NOEXIST_ID = -9999;
	/**
	 * 系统管理员 ID 编号[虚拟ID]
	 */
	public static final long ADMIN_ID = 99999999; 
	/**
	 * 系统管理员编号
	 */
	public static final Integer ADMIN_CODE = 9999; 
	/*数据访问级别 0:自己数据, 1: 本部门数据, 2: 本部门及所有子部门数据, 3: 自定义部门数据, 4: 本公司数据, 5: 所有公司数据*/
	/**
	 * 数据访问级别 0:自己数据
	 */
	public static final Byte DATA_LEVEL_SELF = 0;
	/**
	 * 数据访问级别 1: 本部门数据
	 */
	public static final Byte DATA_LEVEL_CURRDEPT = 1;
	/**
	 * 数据访问级别 2: 本部门及所有子部门数据
	 */
	public static final Byte DATA_LEVEL_CURR_CHILDS_DEPT = 2;
	/**
	 * 数据访问级别 3: 自定义部门数据
	 */
	public static final Byte DATA_LEVEL_CUSTOMDEPT = 3;
	/**
	 * 数据访问级别 4: 本公司数据
	 */
	public static final Byte DATA_LEVEL_CURRCOMPANY = 4;
	/**
	 * 数据访问级别 5: 所有公司数据
	 */
	public static final Byte DATA_LEVEL_ALLCOMPANY = 5;
	/**
	 * 实体类从父类继承的字段  -----  empId[员工ID]
	 */
	public static final String EMPID = "empId";
	/**
	 * 当前用户 KEY 标识
	 */
	public static final String USER_KEY = "user";
	/**
	 * 根节点ID
	 */
	public static final int MENU_ROOT_ID = 0;
	/**
	 * 菜单类型 ------ 卡片菜单
	 */
	public static final int MENU_TYPE_CARD = 1;
	/**
	 * 菜单类型 ------ 节点菜单
	 */
	public static final int MENU_TYPE_NODE = 2;
	
	/**
	 * 实体类从父类继承的字段  ----- isenabled [可用标识]
	 */
	public static final String ISENABLED = "isenabled";
	/**
	 * 实体类从父类继承的字段  -----  remark[备注]
	 */
	public static final String REMARK = "remark";
	/**
	 * 实体类从父类继承的字段  -----  creator[创建人]
	 */
	public static final String CREATOR = "creator";
	/**
	 * 实体类从父类继承的字段  -----  createTime[创建时间]
	 */
	public static final String CREATETIME = "createTime";
	/**
	 * 实体类从父类继承的字段  -----  deptId[部门ID]
	 */
	public static final String DEPTID = "deptId";
	/**
	 * 实体类从父类继承的字段  -----  orgid[机构ID]
	 */
	public static final String ORGID = "orgid";
	/**
	 * 实体类从父类继承的字段  -----  modifier[修改人ID]
	 */
	public static final String MODIFIER = "modifier";
	/**
	 * 实体类从父类继承的字段  -----  modifytime[修改时间]
	 */
	public static final String MODIFYTIME = "modifytime";
	/**
	 * 首页  ----- 左边导航菜单
	 */
	public static final int MENU_ACTION_NAV = 0;
	/**
	 * 菜单管理  ----- 菜单所传参数
	 */
	public static final int MENU_ACTION_SYS = 1;
	
	/**---------------- 项目结构/包类型  CODE START  --------------------**/
	/**
	 * 包类型 ---- Entity 包
	 */
	public static final int PACK_ENTITY = 0;
	/**
	 * 包类型 ---- DAO 包
	 */
	public static final int PACK_DAO = 1000;
	/**
	 * 包类型 ---- Service 包
	 */
	public static final int PACK_SERVICE = 2;
	/**
	 * 包类型 ---- Action 包
	 */
	public static final int PACK_ACTION = 3;
	/**
	 * 包类型 ---- Web 页面包
	 */
	public static final int PACK_PAGE = 4;
	/**
	 * 包类型 ---- 数据库
	 */
	public static final int PACK_DB = 5;
	/**
	 * 包类型 ---- 项目
	 */
	public static final int PACK_PROJECT = 7;
	/**
	 * 包类型 ---- 源文件夹 
	 */
	public static final int PACK_SRC = 8;
	/**
	 * 包类型 ---- WEB 目录
	 */
	public static final int PACK_WEBCONTENT = 9;
	/**
	 * 接口类型 ---- DAO 接口
	 */
	public static final int INTER_DAO = 10;
	/**
	 * 接口类型 ---- SERVICE 接口
	 */
	public static final int INTER_SERVICE = 11;
	
	/**
	 * 项目结构树图标 ---- 公共文件夹
	 */
	public static final String TREE_ICONS_BASE_PATH = "images/platform/";
	/**
	 * 树节点图标 ---- 项目
	 */
	public static final String ICONS_PROJ = TREE_ICONS_BASE_PATH+"prj_obj.gif";
	/**
	 * 树节点图标 ---- 源文件夹
	 */
	public static final String ICONS_SRC = TREE_ICONS_BASE_PATH+"packagefolder_obj.gif";
	/**
	 * 树节点图标 ---- 包
	 */
	public static final String ICONS_PACKAGE = TREE_ICONS_BASE_PATH+"package_obj.gif";
	/**
	 * 树节点图标 ---- WEB 文件夹
	 */
	public static final String ICONS_WEB = TREE_ICONS_BASE_PATH+"fldr_obj.gif";
	
	/**
	 * 树节点图标 ---- WEB UI文件夹
	 */
	public static final String ICONS_UI = TREE_ICONS_BASE_PATH+"page.png";
	
	/**
	 * 树节点图标 ---- 数据库
	 */
	public static final String ICONS_DB = TREE_ICONS_BASE_PATH+"db.gif";
	/**
	 * 树节点图标 ---- java源文件
	 */
	public static final String ICONS_JAVA = TREE_ICONS_BASE_PATH+"java.png";
	/**
	 * 树节点图标 ---- js源文件
	 */
	public static final String ICONS_JS = TREE_ICONS_BASE_PATH+"js.png";
	
	/**
	 * 操作类型  ---- 删除
	 */
	public static final int OPTION_DEL = -1;
	/**
	 * 操作类型  ---- 起用
	 */
	public static final int OPTION_ENABLED = 1;
	/**
	 * 操作类型  ---- 禁用
	 */
	public static final int OPTION_DISABLED = 0;
}
