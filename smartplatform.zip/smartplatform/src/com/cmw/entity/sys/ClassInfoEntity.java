package com.cmw.entity.sys;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;
import com.cmw.core.util.StringHandler;
/**
 * 类附加信息实体类
 * @author chengmingwei
 *
 */
@Description(remark = "类附加信息实体类",createDate="2011-08-08")
@Entity
@Table ( name="ts_classInfo" )
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("serial")
public class ClassInfoEntity extends IdEntity {
	//src源文件ID
	@Column(name="srcId",nullable=false)
	private Long srcId;
	//类型  1 : action URL 名 ,  2 : dao 注解对象名, 3 : service 注解对象名 
	@Column(name="type",nullable=false)
	private Integer type;
	//DAO/Service 注解对象或Action url 名
	@Column(name="name",length=100,nullable=false)
	private String name;
	//创建时间
	@Column(name="createTime",nullable=false,updatable=false)
	private Date createTime;
	//修改时间
	@Column(name="modifyTime",insertable=false)
	private Date modifyTime;
	//备注
	@Column(name="remark",length=200)
	private String remark;
	
	public ClassInfoEntity() {

	}
	

	public Integer getType() {
		return type;
	}



	public void setType(Integer type) {
		this.type = type;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public Date getCreateTime() {
		return createTime;
	}



	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}



	public Date getModifyTime() {
		return modifyTime;
	}



	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}



	public String getRemark() {
		return remark;
	}



	public void setRemark(String remark) {
		this.remark = remark;
	}

	

	public Long getSrcId() {
		return srcId;
	}


	public void setSrcId(Long srcId) {
		this.srcId = srcId;
	}


	@Override
	public Object[] getDatas() {
		return new Object[]{srcId,type,name,StringHandler.dateFormatToStr(StringHandler.DATE_FORMAT, createTime),StringHandler.dateFormatToStr(StringHandler.DATE_FORMAT, modifyTime),remark};
	}

	@Override
	public String[] getFields() {
		return new String[]{"srcId","type","name","createTime","modifyTime","remark"};
	}

}
