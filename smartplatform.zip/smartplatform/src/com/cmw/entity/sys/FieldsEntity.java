package com.cmw.entity.sys;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.cmw.core.base.entity.IdEntity;
/**
 * 字段实体
 * @author chengmingwei
 *
 */
@Entity
@Table(name="ts_fields")
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("serial")
public class FieldsEntity extends IdEntity {
	//src源文件ID
	@Column(name="srcId",nullable=false)
	private Long srcId;
	//字段名
	@Column(name="fieldName",nullable=false,length=50)
	private String fieldName;
	//列名
	@Column(name="colName",nullable=false,length=50)
	private String colName;
	//备注说明
	@Column(name="remark",length=100)
	private String remark;
	// java 数据类型
	@Column(name="dataType",nullable=false,length=50)
	private String dataType;
	//SQL 数据类型
	@Column(name="sqltype",nullable=false,length=50)
	private String sqltype;
	//约束  主键/唯一
	@Column(name="bind",length=50)
	private String bind;
	//是否为空 true / false /null
	@Column(name="isnull",length=50)
	private String isnull;
	//长度
	@Column(name="len")
	private Integer len;
	//小数保留位数
	@Column(name="decimalnum")
	private Integer decimalnum;
	//默认值
	@Column(name="defaultval",length=150)
	private String defaultval;
	//可选值
	@Column(name="choiceval",length=150)
	private String choiceval;
	
	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getColName() {
		return colName;
	}

	public void setColName(String colName) {
		this.colName = colName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getSqltype() {
		return sqltype;
	}

	public void setSqltype(String sqltype) {
		this.sqltype = sqltype;
	}

	public String getBind() {
		return bind;
	}

	public void setBind(String bind) {
		this.bind = bind;
	}

	public String getIsnull() {
		return isnull;
	}

	public void setIsnull(String isnull) {
		this.isnull = isnull;
	}

	public Integer getLen() {
		return len;
	}

	public void setLen(Integer len) {
		this.len = len;
	}

	public Integer getDecimalnum() {
		return decimalnum;
	}

	public void setDecimalnum(Integer decimalnum) {
		this.decimalnum = decimalnum;
	}

	
	public String getDefaultval() {
		return defaultval;
	}

	public void setDefaultval(String defaultval) {
		this.defaultval = defaultval;
	}

	public Long getSrcId() {
		return srcId;
	}

	public void setSrcId(Long srcId) {
		this.srcId = srcId;
	}

	
	
	public String getChoiceval() {
		return choiceval;
	}

	public void setChoiceval(String choiceval) {
		this.choiceval = choiceval;
	}

	@Override
	public Object[] getDatas() {
		return new Object[]{getId(),srcId,fieldName,colName,remark,dataType,sqltype,bind,isnull,len,decimalnum,defaultval,choiceval};
	}

	@Override
	public String[] getFields() {
		return new String[]{"id","srcId","fieldName","colName","remark","dataType","sqltype","bind","isnull","len","decimalnum","defaultval","choiceval"};
	}

}
