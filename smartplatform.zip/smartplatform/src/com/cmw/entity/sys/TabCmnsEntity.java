package com.cmw.entity.sys;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.cmw.core.base.entity.IdEntity;
/**
 * 表列信息实体
 * @author chengmingwei
 * @date 2017-08-11 17:17
 */
@Entity
@Table(name="ts_TabCmns")
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("serial")
public class TabCmnsEntity extends IdEntity {
	//表ID
	@Column(name="tabId",nullable=false)
	private Long tabId;
	//列名
	@Column(name="colName",nullable=false,length=50)
	private String colName;
	//备注说明
	@Column(name="remark",length=100)
	private String remark;
	// SQL数据类型
	@Column(name="dataType",nullable=false,length=50)
	private String dataType;
	//约束  主键/唯一 (1:主键,2:唯一,3:外键)
	@Column(name="bind",length=50)
	private String bind;
	//是否为空 true / false /null
	@Column(name="isnull",length=50)
	private String isnull;
	//长度
	@Column(name="len")
	private Integer len;
	//小数保留位数
	@Column(name="decimalnum")
	private Integer decimalnum;
	//默认值
	@Column(name="defaultval",length=150)
	private String defaultval;
	

	public String getColName() {
		return colName;
	}

	public void setColName(String colName) {
		this.colName = colName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getBind() {
		return bind;
	}

	public void setBind(String bind) {
		this.bind = bind;
	}

	public String getIsnull() {
		return isnull;
	}

	public void setIsnull(String isnull) {
		this.isnull = isnull;
	}

	public Integer getLen() {
		return len;
	}

	public void setLen(Integer len) {
		this.len = len;
	}

	public Integer getDecimalnum() {
		return decimalnum;
	}

	public void setDecimalnum(Integer decimalnum) {
		this.decimalnum = decimalnum;
	}

	
	public String getDefaultval() {
		return defaultval;
	}

	public void setDefaultval(String defaultval) {
		this.defaultval = defaultval;
	}
	
	public Long getTabId() {
		return tabId;
	}

	public void setTabId(Long tabId) {
		this.tabId = tabId;
	}


	@Override
	public Object[] getDatas() {
		return new Object[]{getId(),tabId,colName,remark,dataType,bind,isnull,len,decimalnum,defaultval};
	}

	@Override
	public String[] getFields() {
		return new String[]{"id","tabId","colName","remark","dataType","bind","isnull","len","decimalnum","defaultval"};
	}

	
}
