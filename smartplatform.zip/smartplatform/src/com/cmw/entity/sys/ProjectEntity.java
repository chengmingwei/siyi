package com.cmw.entity.sys;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.cmw.core.base.entity.BaseInter;
import com.cmw.core.base.entity.IdEntity;
/**
 * 项目实体类
 * @author chengmingwei
 *
 */
@Entity
@Table(name="ts_project")
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("serial")
public class ProjectEntity extends IdEntity implements Serializable,BaseInter{
	//项目描述
	@Column(name="introduction",length=100,nullable=false)
	private String introduction;
	//项目路径	
	@Column(name="path",length=200,nullable=false )
	private String path;
	//src 源文件夹名称
	@Column(name="srcName",length=50,nullable=false)
	private String srcName;
	//webContent 目录名称
	@Column(name="webName",length=50,nullable=false)
	private String webName;
	//classes 目录
	@Column(name="classes",length=50,nullable=false)
	private String classes;
	//Entity包名
	@Column(name="entityPack",length=200,nullable=false)
	private String entityPack;
	//Dao包名
	@Column(name="daoPack",length=200,nullable=false)
	private String daoPack;
	//Service包名
	@Column(name="servicePack",length=200,nullable=false)
	private String servicePack;
	//Action包名
	@Column(name="actionPack",length=200,nullable=false)
	private String actionPack;
	//生成的页面文件夹
	@Column(name="pagePath",length=200,nullable=false)
	private String pagePath;
	//数据库类型  0:mysql,1:sqlserver,2:oracle
	@Column(name="dbType",nullable=false)
	private String dbType;
	//数据库名称
	@Column(name="dbNames",length=50)
	private String dbNames;
	//用户名
	@Column(name="dbusername",length=50)
	private String dbusername;
	//密码
	@Column(name="dbpassword",length=50)
	private String dbpassword;
	//状态(-1:删除,0:关闭，1：打开)
	@Column(name="state",nullable=false)
	private Byte state=0;
	//创建时间
	@Column(name="createTime",nullable=false,updatable=false)
	private Date createTime;
	//创建时间
	@Column(name="modifyTime",insertable=false)
	private Date modifyTime;
	//备注
	@Column(name="remark",length=200)
	private String remark;
	
	
	public ProjectEntity() {
		
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getSrcName() {
		return srcName;
	}

	public void setSrcName(String srcName) {
		this.srcName = srcName;
	}

	public String getWebName() {
		return webName;
	}

	public void setWebName(String webName) {
		this.webName = webName;
	}

	public String getEntityPack() {
		return entityPack;
	}

	public void setEntityPack(String entityPack) {
		this.entityPack = entityPack;
	}

	public String getDaoPack() {
		return daoPack;
	}

	public void setDaoPack(String daoPack) {
		this.daoPack = daoPack;
	}

	public String getServicePack() {
		return servicePack;
	}

	public void setServicePack(String servicePack) {
		this.servicePack = servicePack;
	}

	public String getActionPack() {
		return actionPack;
	}

	public void setActionPack(String actionPack) {
		this.actionPack = actionPack;
	}

	public String getPagePath() {
		return pagePath;
	}

	public void setPagePath(String pagePath) {
		this.pagePath = pagePath;
	}

	public String getDbNames() {
		return dbNames;
	}

	public void setDbNames(String dbNames) {
		this.dbNames = dbNames;
	}

	
	
	public String getDbusername() {
		return dbusername;
	}

	public void setDbusername(String dbusername) {
		this.dbusername = dbusername;
	}

	public String getDbpassword() {
		return dbpassword;
	}

	public void setDbpassword(String dbpassword) {
		this.dbpassword = dbpassword;
	}

	public Byte getState() {
		return state;
	}

	public void setState(Byte state) {
		this.state = state;
	}

	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getClasses() {
		return classes;
	}

	public void setClasses(String classes) {
		this.classes = classes;
	}

	public String getDbType() {
		return dbType;
	}

	public void setDbType(String dbType) {
		this.dbType = dbType;
	}

	@Override
	public Object[] getDatas() {
		return new Object[]{getId(),introduction,path,srcName,webName,classes,entityPack,
				daoPack,servicePack,actionPack,pagePath,dbType,dbNames,dbusername,dbpassword,
				state,createTime,modifyTime,remark};
	}

	@Override
	public String[] getFields() {
		return new String[]{"id","introduction","path","srcName","webName","classes","entityPack",
				"daoPack","servicePack","actionPack","pagePath","dbType","dbNames","dbusername","dbpassword",
				"state","createTime","modifyTime","remark"};
	}
}
