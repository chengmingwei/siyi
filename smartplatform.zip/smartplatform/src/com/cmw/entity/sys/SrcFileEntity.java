package com.cmw.entity.sys;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.cmw.core.base.entity.IdEntity;
/**
 * 源文件实体类
 * @author chengmingwei
 *
 */
@Entity
@Table(name="ts_srcfile")
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("serial")
public class SrcFileEntity extends IdEntity implements Cloneable {
	//项目ID
	@Column(name="projectId",nullable=false)
	private Long projectId;
	//文件名
	@Column(name="name",length=80,nullable=false)
	private String name;
	//类型
	@Column(name="type",nullable=false)
	private Integer type;
	//表名
	@Column(name="tabname",length=80)
	private String tabname;
	//父ID
	@Column(name="parentId",nullable=false,length=80)
	private String parentId;
	//继承类
	@Column(name="extendcls",length=80)
	private String extendcls;
	//实现接口
	@Column(name="intercls",length=80)
	private String intercls;
	//路径 
	@Column(name="path",length=200)
	private String path;
	//描述
	@Column(name="description",length=100)
	private String description;
	//src 文件创建日期
	@Column(name="creatorDate")
	private String creatorDate;
	//作者
	@Column(name="author",length=50)
	private String author;
	//同步时间
	@Column(name="createTime",updatable=false)
	private Date createTime;
	//修改时间
	@Column(name="modifyTime",insertable=false)
	private Date modifyTime;
	//备注
	@Column(name="remark",length=300)
	private String remark;
	
	/**
	 * 业务类型
	 * NULL或0:项目,1:多模块项目
	 */
	@Column(name="bussType")
	private Integer bussType=0;
	
	public SrcFileEntity() {
		
	}

	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	
	public String getParentId() {
		return parentId;
	}


	public void setParentId(String parentId) {
		this.parentId = parentId;
	}


	public String getTabname() {
		return tabname;
	}


	public void setTabname(String tabname) {
		this.tabname = tabname;
	}


	public String getExtendcls() {
		return extendcls;
	}


	public void setExtendcls(String extendcls) {
		this.extendcls = extendcls;
	}


	public String getIntercls() {
		return intercls;
	}


	public void setIntercls(String intercls) {
		this.intercls = intercls;
	}


	public String getPath() {
		return path;
	}


	public void setPath(String path) {
		this.path = path;
	}


	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getCreatorDate() {
		return creatorDate;
	}


	public void setCreatorDate(String creatorDate) {
		this.creatorDate = creatorDate;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public Integer getType() {
		return type;
	}


	public void setType(Integer type) {
		this.type = type;
	}
	
	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}


	
	public Integer getBussType() {
		return bussType;
	}


	public void setBussType(Integer bussType) {
		this.bussType = bussType;
	}


	@Override
	public Object[] getDatas() {
		return new Object[]{getId(),projectId,name,type,tabname,parentId,extendcls,intercls,path,createTime,modifyTime,remark,bussType};
	}

	@Override
	public String[] getFields() {
		return new String[]{"id","projectId","name","type","tabname","parentId","extendcls","intercls","path","createTime","modifyTime","remark","bussType"};
	}


	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
}
