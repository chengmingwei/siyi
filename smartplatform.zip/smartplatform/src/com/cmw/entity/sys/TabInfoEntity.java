package com.cmw.entity.sys;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;
/**
 * 数据库表信息实体类
 * @author chengmingwei
 * @date 2017-08-11 17:17
 */
@Description(remark = "数据库表信息实体类",createDate="2011-08-08")
@Entity
@Table ( name="ts_TabInfo" )
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("serial")
public class TabInfoEntity extends IdEntity {

	//项目ID
	@Column(name="projectId",nullable=false)
	private Long projectId;
		
	@Column(name="name",length=100,nullable=false)
	private String name;
	//创建时间
	@Column(name="createTime",nullable=false,updatable=false)
	private Date createTime = new Date();
	//修改时间
	@Column(name="modifyTime",insertable=false)
	private Date modifyTime;
	//备注
	@Column(name="remark",length=200)
	private String remark;
	
	
	
	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public Object[] getDatas() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String[] getFields() {
		// TODO Auto-generated method stub
		return null;
	}

}
