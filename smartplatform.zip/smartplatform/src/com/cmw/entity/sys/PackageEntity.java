package com.cmw.entity.sys;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.cmw.core.base.entity.IdEntity;
/**
 * 包实体类
 * @author chengmingwei
 *
 */
/**
 * @author chengmingwei
 *
 */
@Entity
@Table(name="ts_package")
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("serial")
public class PackageEntity extends IdEntity{
	//描述
	@Column(name="introduction",length=200)
	private String introduction;
	//包名称	
	@Column(name="name",length=100,nullable=false)
	private String name;
	//项目ID
	@Column(name="projectId",nullable=false)
	private Long projectId;
	//父ID
	@Column(name="parentId",nullable=false,length=80)
	private String parentId;
	//类型  0:entity,1:dao,2:service,3:action,4:page
	@Column(name="type",nullable=false)
	private Integer type;
	//创建时间
	@Column(name="createTime",nullable=false,updatable=false)
	private Date createTime;
	//创建时间
	@Column(name="modifyTime",insertable=false)
	private Date modifyTime;
	//备注
	@Column(name="remark",length=200)
	private String remark;
	
	
	public PackageEntity() {
		
	}

	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Long getProjectId() {
		return projectId;
	}


	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}


	public String getParentId() {
		return parentId;
	}


	public void setParentId(String parentId) {
		this.parentId = parentId;
	}


	public Integer getType() {
		return type;
	}


	public void setType(Integer type) {
		this.type = type;
	}


	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public Object[] getDatas() {
		return new Object[]{introduction,name,projectId,parentId,type,createTime,modifyTime,remark};
	}

	@Override
	public String[] getFields() {
		return new String[]{"introduction","name","projectId","parentId","type","createTime","modifyTime","remark"};
	}

	/**
	 *  type = entity : 0
	 */
	public static final int TYPE_ENTITY = 0;
	/**
	 *  type = dao : 1
	 */
	public static final int TYPE_DAO = 1;
	/**
	 *  type = service : 2
	 */
	public static final int TYPE_SERVICE = 2;
	/**
	 *  type = action : 3
	 */
	public static final int TYPE_ACTION = 3;
	/**
	 *  type = page : 4
	 */
	public static final int TYPE_PAGE = 4;
	/**
	 *  type = MyBatis Mapper文件 : 5
	 */
	public static final int TYPE_MAPPER = 5;
}
