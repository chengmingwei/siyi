package com.cmw.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cmw.entity.sys.UserEntity;

/**
 * Servlet implementation class for Servlet: AuthenticateFilter
 *  用户权限过滤
 */
 public class AuthenticateFilter implements Filter  {
   static final long serialVersionUID = 1L;
	public static final String[] NOTLOGINTYPE = {"","login"};
	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)resp;
		HttpSession session = request.getSession();
		String url = request.getRequestURI();
		UserEntity user  = (UserEntity)session.getAttribute("user");
		if(!exclusionLoginType(url) &&  null == user){
			response.sendRedirect(request.getContextPath()+"/user/login.jsp");
			return;
		}
		chain.doFilter(request, response);
	}
	
	/**
	 * 不需要登录验证的页面
	 * @param url
	 * @return
	 */
	public boolean exclusionLoginType(String url){
		url = url.substring(url.lastIndexOf("/")+1);
		if(null == url || url.equals("")) return true;
		url=url.indexOf(".") != -1 ? url.substring(0,url.indexOf(".")) : url;
		for(String nurl : NOTLOGINTYPE){
			if(url.equals(nurl)) return true;
		}
		return false;
	}
	
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		
	}
	
	@Override
	public void destroy() {
		
	}
}