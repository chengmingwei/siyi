/**
 * 
 */
package com.cmw.action.sys;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.ResultMsg;
import com.cmw.core.base.action.BaseAction;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.kit.file.FileUtil;
import com.cmw.core.util.BeanUtil;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.DateUtil;
import com.cmw.core.util.FastJsonUtil;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.SqlUtil;
import com.cmw.core.util.StringHandler;
import com.cmw.entity.sys.FieldsEntity;
import com.cmw.entity.sys.MultiProjectEntity;
import com.cmw.entity.sys.PackageEntity;
import com.cmw.entity.sys.ProjectEntity;
import com.cmw.entity.sys.SrcFileEntity;
import com.cmw.entity.sys.TabCmnsEntity;
import com.cmw.entity.sys.TabInfoEntity;
import com.cmw.service.impl.sys.DbMgrService;
import com.cmw.service.impl.sys.MultiTemplateServiceImpl;
import com.cmw.service.impl.sys.TemplateServiceImpl;
import com.cmw.service.inter.sys.ClassInfoService;
import com.cmw.service.inter.sys.FieldsService;
import com.cmw.service.inter.sys.MultiProjectService;
import com.cmw.service.inter.sys.PackageService;
import com.cmw.service.inter.sys.ProjectService;
import com.cmw.service.inter.sys.SrcFileService;
import com.cmw.service.inter.sys.TabCmnsService;
import com.cmw.service.inter.sys.TabInfoService;

/**
 * @author 程明卫 E-mail:chengmingwei_1984122@126.com
 * @version 创建时间：2010-6-15 下午12:14:31
 * 类说明 	源文件管理 ACTION
 */
@SuppressWarnings("serial")
public class SrcFileAction extends BaseAction {
	/**
	 * 获取 session 中当前登录用户的 KEY
	 */
	public static final String USER_KEY = "user";
	@Resource(name="srcfileService")
	private SrcFileService srcfileService;
	//项目业务类
	@Resource(name="projectService")
	private ProjectService projectService;
	//项目业务类
	@Resource(name="packageService")
	private PackageService packageService;
	//字段业务对象
	@Resource(name="fieldsService")
	private FieldsService fieldsService;
	//类附加信息Service实现对象
	@Resource(name="classInfoService")
	private ClassInfoService classInfoService;
	
	@Resource(name="multiProjectService")
	private MultiProjectService multiProjectService;
	
	@Resource(name="dbMgrService")
	private DbMgrService dbMgrService;
	
	@Resource(name="tabInfoService")
	private  TabInfoService tabInfoService;
	
	@Resource(name="tabCmnsService")
	private  TabCmnsService tabCmnsService;
	
	//多模块模板处理业务对象
	private MultiTemplateServiceImpl multiTempService = new MultiTemplateServiceImpl();
	
	//模板处理业务对象
	private TemplateServiceImpl tempService = new TemplateServiceImpl();
	
	private String result = ResultMsg.GRID_NODATA;
	
	
	/**
	 * 获取源文件列表
	 * @return
	 * @throws Exception
	 */
	public String list()throws Exception {
		try {
			//获取卡片项的ID，并将其作为 父ID
			SHashMap<String, Object> map = new SHashMap<String, Object>();
			DataTable dt = srcfileService.getResultList(map);
			result = (null == dt || dt.getSize() == 0) ? result = ResultMsg.NODATA : dt.getJsonArr();
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 获取源文件信息
	 * @return
	 * @throws Exception
	 */
	public String get()throws Exception {
		try {
			//获取卡片项的ID，并将其作为 父ID
			String id = getVal("id");
			if(!StringHandler.isValidStr(id)) throw new ServiceException(ServiceException.ID_IS_NULL);
			SrcFileEntity entity = srcfileService.getEntity(Long.parseLong(id));
			Map<String,Object> appendParams = new HashMap<String, Object>();
			appendParams.put("abspath", entity.getPath());
			Long srcId = entity.getId();
			String parentId = entity.getParentId();
			PackageEntity packEntity = packageService.getEntity(Long.parseLong(parentId));
			entity.setPath(packEntity.getName());
			
			//--------> 获取 URL 前缀
			SHashMap<String, Object> map = new SHashMap<String, Object>();
			map.put("srcId", srcId);
//			List<ClassInfoEntity> clsList = classInfoService.getEntityList(map);
//			if(null != clsList && clsList.size() > 0){
//				ClassInfoEntity clsEntity = clsList.get(0);
//				String name = clsEntity.getName();
//				char[] chs = name.toCharArray();
//				int offset = -1;
//				for(int i=0,count=chs.length; i<count; i++){
//					int x = (int)chs[i];
//					if(x>=65 || x<=90){
//						offset = i;
//						break;
//					}
//				}
//				String prefix = name.substring(0,offset+1);
//				appendParams.put("urlprefix", prefix);
//			}
			result = FastJsonUtil.convertJsonToStr(entity, appendParams);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 重新保存源文件
	 * @return
	 * @throws Exception
	 */
	public String resave()throws Exception {
		try{
			Long id = getLVal("id");
			if(null == id) throw new ServiceException("实体ID不能为空！");
			SrcFileEntity entity = srcfileService.getEntity(id);
			Long projectId = entity.getProjectId();
			MultiProjectEntity multiProject = multiProjectService.getEntity(projectId);
			String entityName = entity.getName();
			entityName = entityName.replace("Entity.java", "");
			SHashMap<String, Object> pars = new SHashMap<String, Object>();
			pars.put("name", SqlUtil.LOGIC_EQ + SqlUtil.LOGIC + entityName+"Dao.java");
			srcfileService.deleteEntitys(pars);
			
			pars.put("name", SqlUtil.LOGIC_EQ + SqlUtil.LOGIC + entityName+"Service.java");
			srcfileService.deleteEntitys(pars);
			
			pars.put("name", SqlUtil.LOGIC_EQ + SqlUtil.LOGIC + entityName+"ServiceImpl.java");
			srcfileService.deleteEntitys(pars);
			
			pars.put("name", SqlUtil.LOGIC_EQ + SqlUtil.LOGIC + entityName+"Controller.java");
			srcfileService.deleteEntitys(pars);
			
			pars.put("name", SqlUtil.LOGIC_EQ + SqlUtil.LOGIC + entityName+"Mapper.xml");
			srcfileService.deleteEntitys(pars);
			
			saveByType(multiProject,entity,true, new SHashMap<String, Object>());
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 根据ts_TabInfo 表信息生成微服务或后台系统代码
	 * @date 2017-08-24 10:54
	 * @return
	 * @throws Exception
	 */
	public String generaction()throws Exception {
		try {
			SHashMap<String, Object> dataMap = getQParams("bussType,tabIds,sysProjectId,sys_filetypes,package,urlprefix,filetypes,author");
			Integer bussType = dataMap.getvalAsInt("bussType");
			String tabIds = dataMap.getvalAsStr("tabIds");
			Long projectId = dataMap.getvalAsLng("sysProjectId");
			String sys_package = dataMap.getvalAsStr("package");
			if(null == bussType) throw new ServiceException("参数：bussType 不能为空!");
			String author = dataMap.getvalAsStr("author");
			tabIds = tabIds.replace("T", "");
			String[] tabIdsArr = tabIds.split(",");
			if(null != bussType && bussType.intValue() == 1){//微服务
				MultiProjectEntity multiProject = null;
				for(String tabId : tabIdsArr){
					Long _tabId = Long.parseLong(tabId);
					TabInfoEntity tabInfoObj = tabInfoService.getEntity(_tabId);
					if(null == multiProject){
						projectId = tabInfoObj.getProjectId();
						multiProject = multiProjectService.getEntity(projectId);
					}
					SrcFileEntity entity = setProps(projectId, sys_package,tabInfoObj, author);
					setFields(tabInfoObj, entity, dataMap);
					saveByType(multiProject,entity, false, dataMap);
					
				}
			}else{ //后台系统代码
				ProjectEntity project = projectService.getEntity(projectId);
				
				for(String tabId : tabIdsArr){
					Long _tabId = Long.parseLong(tabId);
					TabInfoEntity tabInfoObj = tabInfoService.getEntity(_tabId);
					SrcFileEntity entity = setProps(projectId, sys_package,tabInfoObj, author);
					setFields(tabInfoObj, entity, dataMap);
					saveByType(project,entity, dataMap);
				}
			}
			String msg = ResultMsg.SAVE_SUCCESS;
			msg = this.getText(msg);
			JSONObject obj = ResultMsg.createJsonObject(ResultMsg.SUCCESS_STATE,msg);
			result = obj.toString();
		} catch (Exception ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 设置字段
	 * @param tabInfoObj
	 * @param dataMap
	 */
	private void setFields(TabInfoEntity tabInfoObj, SrcFileEntity entitySrc, SHashMap<String, Object> dataMap){
		SHashMap<String, Object> pars = new SHashMap<String, Object>();
		pars.put("tabId", tabInfoObj.getId());
		List<TabCmnsEntity> tabCmnsList = tabCmnsService.getEntityList(pars);
		if(null == tabCmnsList || tabCmnsList.size() == 0) throw new ServiceException("表"+tabInfoObj.getName()+"在 ts_tabCmns 中没有表列记录，请点击“同步表”同步一次!");
		String extendcls = getExtendCls(tabCmnsList);
		entitySrc.setExtendcls(extendcls);
		FieldsEntity[] fields = new FieldsEntity[tabCmnsList.size()];
		int index = 0;
		for(TabCmnsEntity tabCmnsObj : tabCmnsList){
			FieldsEntity fieldsObj = new FieldsEntity();
			String remark = tabCmnsObj.getRemark();
			String colName = tabCmnsObj.getColName();
			if(StringHandler.isValidStr(extendcls)){
				String _name = colName.toLowerCase();
				if(extendcls.equals("IdBaseEntity")){
					if(_name.equals("id") || _name.equals("createTime") ||
						_name.equals("creator") || _name.equals("deptId") ||
						_name.equals("empId") || _name.equals("isenabled") ||
						_name.equals("modifier") || _name.equals("modifytime") ||
						_name.equals("orgid") || _name.equals("remark")){
						continue;
					}
				}else if(extendcls.equals("BaseEntity")){
					if(_name.equals("createTime") ||
							_name.equals("creator") || _name.equals("deptId") ||
							_name.equals("empId") || _name.equals("isenabled") ||
							_name.equals("modifier") || _name.equals("modifytime") ||
							_name.equals("orgid") || _name.equals("remark")){
							continue;
						}
				}else if(extendcls.equals("IdEntity")){
					if(_name.equals("id")){
						continue;
					}
				}
			}
			String dataType = tabCmnsObj.getDataType();
			String bind = tabCmnsObj.getBind();
			String isnull = tabCmnsObj.getIsnull();
			Integer len = tabCmnsObj.getLen();
			Integer decimalnum = tabCmnsObj.getDecimalnum();
			String defaultval = tabCmnsObj.getDefaultval();
			String objDataType = getDataType(dataType);
			fieldsObj.setFieldName(colName);
			fieldsObj.setColName(colName);
			fieldsObj.setRemark(remark);
			fieldsObj.setDataType(objDataType);
			fieldsObj.setSqltype(dataType);
			if(StringHandler.isValidStr(bind)){
				if(bind.equals("1")){ //1:主键,2:唯一,3:外键
					bind = "主键";
				}else if(bind.equals("2")){ //1:主键,2:唯一,3:外键
					bind = "唯一";
				}else if(bind.equals("3")){ //1:主键,2:唯一,3:外键
					bind = "外键";
				} 
			}else{
				bind = "";
			}
			fieldsObj.setBind(bind);
			fieldsObj.setLen(len);
			fieldsObj.setDefaultval(defaultval);
			fieldsObj.setDecimalnum(decimalnum);
			fieldsObj.setIsnull(isnull);
			fields[index] = fieldsObj;
			index++;
		}
		dataMap.put("fields", fields);
	}
	
	/**
	 * 获取实体继承的父类
	 * @param tabCmnsList
	 * @return
	 * @author chengmingwei
	 * @date 2017年8月24日 下午10:47:28
	 */
	private String getExtendCls(List<TabCmnsEntity> tabCmnsList){
		Map<String, Boolean> ecMap = getExtendClsMap();
		for(TabCmnsEntity obj : tabCmnsList){
			String colName = obj.getColName();
			colName = colName.toLowerCase();
			if(!ecMap.containsKey(colName)) continue;
			ecMap.put(colName, true);
		}
		String[] keys = new String[]{"id","createTime","creator","deptId","empId","isenabled","modifier","modifytime","orgid","remark"};
		Boolean isExtCls = true;
		for(String key : keys){
			boolean flag = ecMap.get(key);
			if(!flag){
				isExtCls = false;
				break;
			}
		}
		if(isExtCls){
			return "IdBaseEntity";
		}
		
		keys = new String[]{"createTime","creator","deptId","empId","isenabled","modifier","modifytime","orgid","remark"};
		for(String key : keys){
			boolean flag = ecMap.get(key);
			if(!flag){
				isExtCls = false;
				break;
			}
		}
		if(isExtCls){
			return "BaseEntity";
		}
		isExtCls = ecMap.get("id");
		if(null == isExtCls || !isExtCls){
			return null;
		}else{
			return "IdEntity";
		}
	}
	
	private Map<String, Boolean> getExtendClsMap(){
		Map<String, Boolean> extendClsMap = new HashMap<String, Boolean>();
		extendClsMap.put("id", false);
		extendClsMap.put("createTime", false);
		extendClsMap.put("creator", false);
		extendClsMap.put("deptId", false);
		extendClsMap.put("empId", false);
		extendClsMap.put("isenabled", false);
		extendClsMap.put("modifier", false);
		extendClsMap.put("modifytime", false);
		extendClsMap.put("orgid", false);
		extendClsMap.put("remark", false);
		return extendClsMap;
	}
	
	private String getDataType(String sqlType){
		String dataType = "String";
		sqlType = sqlType.toUpperCase();
		if(sqlType.equals("VARCHAR") || sqlType.equals("LONGTEXT")){
			dataType = "String";
		}else if(sqlType.equals("INT")){
			dataType = "Integer";
		}else if(sqlType.equals("BIGINT")){
			dataType = "Long";
		}else if(sqlType.equals("DATETIME")){
			dataType = "Date";
		}else if(sqlType.equals("TINYINT")){
			dataType = "Byte";
		}else if(sqlType.equals("DECIMAL")){
			dataType = "BigDecimal";
		}else if(sqlType.equals("FLOAT")){
			dataType = "Float";
		}else if(sqlType.equals("DOUBLE")){
			dataType = "Double";
		}
		return dataType;
	}
	
	private SrcFileEntity setProps(Long projectId, String sys_package,
			TabInfoEntity tabInfoObj, String author) {
		String remark = tabInfoObj.getRemark();
		String tabName = tabInfoObj.getName();
		String name = tabName.substring(tabName.indexOf("_")+1, tabName.length());
		String firstStr = name.substring(0,1);
		String endStr = name.substring(1,name.length());
		name = firstStr.toUpperCase() + endStr;
		SrcFileEntity entity = new SrcFileEntity();
		entity.setType(0);
		entity.setName(name);
		entity.setTabname(tabName);
		entity.setAuthor(author);
		entity.setCreatorDate(DateUtil.dateFormatToStr("yyyy-MM-dd HH:mm:ss", new Date()));
		entity.setCreateTime(new Date());
		entity.setParentId("-1");
		entity.setProjectId(projectId);
		entity.setDescription(remark);
		entity.setPath(sys_package);
		return entity;
	}
	
	/**
	 * 保存源文件
	 * @return
	 * @throws Exception
	 */
	public String save()throws Exception {
		try {
			SrcFileEntity entity = BeanUtil.copyValue(SrcFileEntity.class,getRequest());
			entity.setCreateTime(new Date());
			Long projectId = entity.getProjectId();
			if(null == projectId) throw new Exception("项目ID不能为空！");
			Integer bussType = entity.getBussType();
			if(null != bussType && bussType.intValue() == 1){
				MultiProjectEntity multiProject = multiProjectService.getEntity(projectId);
				saveByType(multiProject,entity, false, new SHashMap<String, Object>());
			}else{
				ProjectEntity project = projectService.getEntity(projectId);
				saveByType(project,entity, new SHashMap<String, Object>());
			}
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (Exception ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 创建表
	 * @return
	 * @throws Exception
	 */
	public String createTab()throws Exception {
		try {
			Long id = getLVal("id");
			if(null == id) throw new ServiceException("实体ID不能为空！");
			SrcFileEntity entity = srcfileService.getEntity(id);
			Long projectId = entity.getProjectId();
			MultiProjectEntity multiProject = multiProjectService.getEntity(projectId);
			
			SHashMap<String, Object> map = new SHashMap<String, Object>();
			map.put("srcId", entity.getId());
			List<FieldsEntity> listFields = fieldsService.getEntityList(map);
			if(null == listFields || listFields.size() == 0){
				result = ResultMsg.getFailureMsg(this,ResultMsg.SAVE_FAILURE);
				outJsonString(result);
				return null;
			}
			FieldsEntity[] fields = new FieldsEntity[listFields.size()];
			fields = listFields.toArray(fields);  
			
			dbMgrService.createTable(multiProject, entity, fields);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (Exception ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	
	/**
	 * 根据类型保存数据(多模块项目)
	 */
	private void saveByType(MultiProjectEntity project,SrcFileEntity entity, boolean rebulid, SHashMap<String, Object> dataMap) throws ServiceException{
	
		int type = entity.getType();
		
		
		if(type == PackageEntity.TYPE_ENTITY){//实体的情况
			SHashMap<String,Object> map = new SHashMap<String, Object>();
			map.put("name", entity.getPath());
			List<PackageEntity> parentPacks = packageService.getEntityList(map);
			multiTempService.setParentPacks(parentPacks);
			
			String filetypes = null;
			
			FieldsEntity[] fields = null;
			if(rebulid){
				filetypes = "1,2,3,5";
				map.clear();
				map.put("srcId", entity.getId());
				List<FieldsEntity> listFields = fieldsService.getEntityList(map);
				if(null == listFields || listFields.size() == 0){
					return;
				}
				fields = new FieldsEntity[listFields.size()];
				fields = listFields.toArray(fields);  
			}else{
				 filetypes = dataMap.getvalAsStr("filetypes");
				if(!StringHandler.isValidStr(filetypes)){
					filetypes = getVal("filetypes");
				}
				
				fields = (FieldsEntity[])dataMap.get("fields");
				if(null == fields || fields.length == 0){
					fields = getFields();
				}
			}
			
			String urlprefix = dataMap.getvalAsStr("urlprefix");
			if(!StringHandler.isValidStr(urlprefix)){
				urlprefix = getVal("urlprefix");
			}
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("filetypes", filetypes);
			params.put("urlprefix", urlprefix);	//Action Url 前缀
		
			Map<String,SrcFileEntity> entityMap = multiTempService.makeFile(project, entity, fields, params);
			//----> 1.保存 Entity 和 Fields
			entity = entityMap.get(TemplateServiceImpl.ENTITY_KEY);
			srcfileService.saveOrUpdateEntity(entity);
			saveFields(entity.getId(),fields);
			String createTab = getRequest().getParameter("createTab");
			if(StringHandler.isValidStr(createTab) && createTab.equals("1")){//创建表
				dbMgrService.createTable(project, entity, fields);
			}
			
			
			//----> 2.保存 DAO 接口和实现类
			if(isSaveByType(filetypes, 1)){
				SrcFileEntity daoInterEntity = entityMap.get(MultiTemplateServiceImpl.DAOINTER_KEY);
				daoInterEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(daoInterEntity);
			}
			
			
			//----> 3.保存 Service 接口和实现类
			if(isSaveByType(filetypes, 2)){
				SrcFileEntity serviceInterEntity = entityMap.get(MultiTemplateServiceImpl.SERVICE_KEY);
				serviceInterEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(serviceInterEntity);
				SrcFileEntity serviceImplEntity = entityMap.get(MultiTemplateServiceImpl.SERVICEIMPL_KEY);
				serviceImplEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(serviceImplEntity);
			}
			//----> 4.保存Controller
			if(isSaveByType(filetypes, 3)){
				SrcFileEntity actionEntity = entityMap.get(MultiTemplateServiceImpl.ACTION_KEY);
				actionEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(actionEntity);
			}
			
			SrcFileEntity mapperEntity = entityMap.get(MultiTemplateServiceImpl.MAPPER_KEY);
			if(null != mapperEntity){
				mapperEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(mapperEntity);
			}
			
		}else if(type == PackageEntity.TYPE_DAO){//DAO的情况
			
		}else if(type == PackageEntity.TYPE_SERVICE){//Service的情况
			
		}
		
	}

	
	
	/**
	 * 根据类型保存数据
	 */
	private void saveByType(ProjectEntity project,SrcFileEntity entity, SHashMap<String, Object> dataMap) throws ServiceException{
	
		int type = entity.getType();
		
		
		if(type == PackageEntity.TYPE_ENTITY){//实体的情况
			SHashMap<String,Object> map = new SHashMap<String, Object>();
			map.put("name", entity.getPath());
			List<PackageEntity> parentPacks = packageService.getEntityList(map);
			tempService.setParentPacks(parentPacks);
			
			String filetypes = dataMap.getvalAsStr("sys_filetypes");
			if(!StringHandler.isValidStr(filetypes)){
				filetypes = getVal("filetypes");
			}
			String urlprefix = dataMap.getvalAsStr("urlprefix");
			if(!StringHandler.isValidStr(urlprefix)){
				urlprefix = getVal("urlprefix");
			}
			
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("filetypes", filetypes);
			params.put("urlprefix", urlprefix);	//Action Url 前缀
			FieldsEntity[] fields = (FieldsEntity[])dataMap.get("fields");
			if(null == fields || fields.length == 0){
				fields = getFields();
			}
			
			Map<String,SrcFileEntity> entityMap = tempService.makeFile(project, entity, fields, params);
			//----> 1.保存 Entity 和 Fields
			entity = entityMap.get(TemplateServiceImpl.ENTITY_KEY);
			srcfileService.saveOrUpdateEntity(entity);
			saveFields(entity.getId(),fields);
			
			//----> 2.保存 DAO 接口和实现类
			if(isSaveByType(filetypes, 1)){
				SrcFileEntity daoInterEntity = entityMap.get(TemplateServiceImpl.DAOINTER_KEY);
				daoInterEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(daoInterEntity);
				SrcFileEntity daoImplEntity = entityMap.get(TemplateServiceImpl.DAOIMPL_KEY);
				daoImplEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(daoImplEntity);
			}
			
			//----> 3.保存 Service 接口和实现类
			if(isSaveByType(filetypes, 2)){
				SrcFileEntity serviceInterEntity = entityMap.get(TemplateServiceImpl.SERVICE_KEY);
				serviceInterEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(serviceInterEntity);
				SrcFileEntity serviceImplEntity = entityMap.get(TemplateServiceImpl.SERVICEIMPL_KEY);
				serviceImplEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(serviceImplEntity);
			}
			//----> 4.保存 Action
			if(isSaveByType(filetypes, 3)){
				SrcFileEntity actionEntity = entityMap.get(TemplateServiceImpl.ACTION_KEY);
				actionEntity.setCreateTime(new Date());
				srcfileService.saveOrUpdateEntity(actionEntity);
			}
			
		}else if(type == PackageEntity.TYPE_DAO){//DAO的情况
			
		}else if(type == PackageEntity.TYPE_SERVICE){//Service的情况
			
		}
		
	}

	private boolean isSaveByType(String filetypes, int type){
		boolean flag = false;
		String[] typesArr = filetypes.split(",");
		for(String typeStr : typesArr){
			if(Integer.parseInt(typeStr) == type){
				flag = true;
				break;
			}
		}
		return flag;
	}
	
	/**
	 * 获取实体字段
	 * @return
	 */
	private FieldsEntity[] getFields(){
		String jsonDatas = getVal("fields");
		List<FieldsEntity> list = FastJsonUtil.convertJsonToList(jsonDatas, FieldsEntity.class);
		FieldsEntity[] fields = new FieldsEntity[1];
		fields = list.toArray(fields);
		return fields;
	}
	
	/**
	 * 保存字段
	 * @param srcFileId
	 * @param fields
	 * @throws ServiceException 
	 */
	private void saveFields(Long srcId,FieldsEntity[] fields) throws ServiceException{
		for(FieldsEntity field : fields){
			if(null == field) continue;
			field.setSrcId(srcId);
			fieldsService.saveOrUpdateEntity(field);
		}
	}

	/**
	 * 删除源文件
	 * @return
	 * @throws Exception
	 */
	public String delete()throws Exception {
		try {
			String _id = getVal("id");
			_id = _id.replace("S", "");
			String delType = getVal("delType");
			if(!StringHandler.isValidStr(_id)) throw new ServiceException(ServiceException.ID_IS_NULL);
			Long id = Long.parseLong(_id);
			if(StringHandler.isValidStr(delType) && Integer.parseInt(delType) == 1){	//删除物理文件
				SrcFileEntity entity = srcfileService.getEntity(id);
				String fielPath = entity.getPath();
				FileUtil.delFile(fielPath);
			}
			srcfileService.deleteEntity(id);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.DELETE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 获取源代码
	 * @return
	 */
	public String getSource(){
		try {
			String id = getVal("id");
			SrcFileEntity srcEntity = srcfileService.getEntity(Long.parseLong(id));
			String path = srcEntity.getPath();
			String sourceStr = FileUtil.ReadFileToStr(path);
			result = sourceStr.replaceAll("\n", "<br/>").replaceAll("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
		} catch (Exception ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
}
