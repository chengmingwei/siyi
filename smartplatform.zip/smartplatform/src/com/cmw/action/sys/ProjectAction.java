/**
 * 
 */
package com.cmw.action.sys;

import java.io.File;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cmw.constant.ResultMsg;
import com.cmw.constant.SysConstant;
import com.cmw.core.base.action.BaseAction;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.util.BeanUtil;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.FileClassLoader;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.StringHandler;
import com.cmw.core.util.TreeUtil;
import com.cmw.entity.sys.ClassInfoEntity;
import com.cmw.entity.sys.FieldsEntity;
import com.cmw.entity.sys.PackageEntity;
import com.cmw.entity.sys.ProjectEntity;
import com.cmw.entity.sys.SrcFileEntity;
import com.cmw.service.inter.sys.ClassInfoService;
import com.cmw.service.inter.sys.FieldsService;
import com.cmw.service.inter.sys.PackageService;
import com.cmw.service.inter.sys.ProjectService;
import com.cmw.service.inter.sys.SrcFileService;

/**
 * @author 程明卫 E-mail:chengmingwei_1984122@126.com
 * @version 创建时间：2010-6-15 下午12:14:31
 * 类说明 	项目管理 ACTION
 */
@SuppressWarnings("serial")
public class ProjectAction extends BaseAction {
	/**
	 * 获取 session 中当前登录用户的 KEY
	 */
	public static final String USER_KEY = "user";
	@Resource(name="projectService")
	private ProjectService projectService;
	
	@Resource(name="packageService")
	private PackageService packageService;
	//源文件业务对象
	@Resource(name="srcfileService")
	private SrcFileService srcfileService;
	//字段业务对象
	@Resource(name="fieldsService")
	private FieldsService fieldsService;
	//类附加信息业务对象
	@Resource(name="classInfoService")
	private ClassInfoService classInfoService;
	
	private String result = ResultMsg.GRID_NODATA;
	//存放指定项目的所有包文件夹
	private DataTable pkDt = null;
	//存放指定项目的所有源文件
	private DataTable srcDt = null;
	
	public ProjectAction() {
	}

	/**
	 * 项目导航树
	 * @return
	 */
	public String navtree(){
		//获取卡片项的ID，并将其作为 父ID
		SHashMap<String, Object> map = new SHashMap<String, Object>();
		try {
			result = ResultMsg.NODATA;
			DataTable dt = projectService.getResultList(map);
			
			if(null != dt && dt.getRowCount() > 0){
				boolean hasProjects = false;	//标识是否有可打开的项目
				StringBuffer sb = new StringBuffer();
				List<Object> dataSource = new ArrayList<Object>();
				for(int i=0,count=dt.getRowCount(); i<count; i++){
					Byte state = dt.getByte(i, "state");
					if(null == state || state.intValue() <= 0) continue;	//只开启状态为打开的项目
					Long id = dt.getLong(i, "id");
					sb.append(id+",");
					convertToTreeData(dt, dataSource, i, id);
					hasProjects = true;
				}
				if(!hasProjects) return null;
				map = new SHashMap<String, Object>();
				map.put("projectIds", StringHandler.RemoveStr(sb, ","));
				DataTable dtPackage = packageService.getResultList(map);
				if(null != dataSource && dataSource.size() > 0){
					dtPackage.addDtToFirst(dataSource);
					DataTable dtSrcs = srcfileService.getResultList(map);
					if(null != dtSrcs && dtSrcs.getRowCount()>0){
						dtPackage.addDtToEnd(dtSrcs);
					}
					
					for(int i=0,count=dtPackage.getRowCount(); i<count; i++){
						String _src = dtPackage.getString(i, "src");
						_src = _src.replaceAll("[\\\\]", "\\/");
						dtPackage.setCellData(i,"src",_src);
					}
					
					TreeUtil tree = new TreeUtil(dtPackage);
					tree.setIconPath("");
					result = tree.getJsonArr("0");
				}
			}
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		
		return null;
	}

	private void convertToTreeData(DataTable dt, List<Object> dataSource,
			int i, Long id) {
		Object[] data = null;
		String _id =null, _pid = null,_text=null,_icon=null,_leaf=null,_src=null,_projectId=null,_type=null;
		String inter = "inter";//接口包名
		String impl = "impl";	//实现类包名
		String introduction = dt.getString(i, "introduction");
		String path = dt.getString(i, "path");
		path = StringHandler.getSpeatorPath(path);
		String srcName = dt.getString(i, "srcName");
		String webName = dt.getString(i, "webName");
		String entityPack = dt.getString(i, "entityPack");
		String daoPack = dt.getString(i, "daoPack");
		String servicePack = dt.getString(i, "servicePack");
		String actionPack = dt.getString(i, "actionPack");
		String pagePath = dt.getString(i, "pagePath");
		String dbNames = dt.getString(i, "dbNames");
		String dbusername = dt.getString(i, "dbusername");
		String dbpassword = dt.getString(i, "dbpassword");
		//id,pid,text,icon,leaf,src,projectId,type
		_id = introduction+"_"+id;
		_pid = "0";
		_text = introduction;
		_icon = SysConstant.ICONS_PROJ;
		_leaf = "false";
		_src = path;
		_projectId = id+"";
		_type = SysConstant.PACK_PROJECT+"";
		//项目数据
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//src数据
		_pid = _id;
		String _srcid = srcName+"_"+id;
		_text = srcName;
		_icon = SysConstant.ICONS_SRC;
		_src = "";
		_src = path +"/"+ srcName;
		_type = SysConstant.PACK_SRC + "";
		data = new Object[]{_srcid,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//entity数据
		_pid = _srcid;
		_id = entityPack+"_"+id;
		_text = entityPack;
		_icon = SysConstant.ICONS_PACKAGE;
		_src = path +"/"+ srcName+"/"+entityPack.replaceAll("\\.", "/");
		_type = SysConstant.PACK_ENTITY + "";
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//dao数据
		int daoType = SysConstant.PACK_DAO;// - 999;
		_pid = _srcid;
		String daoId = daoPack+"_"+id;
		_text = daoPack;
		_icon = SysConstant.ICONS_PACKAGE;
		_src = path +"/"+ srcName+"/"+daoPack.replaceAll("\\.", "/");
		_type = daoType + "";
		data = new Object[]{daoId,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//dao inter 数据
		_pid = daoId;
		_id = daoPack+"."+inter+"_"+id;
		_text = inter;
		_icon = SysConstant.ICONS_PACKAGE;
		_src = path +"/"+ srcName+"/"+daoPack.replaceAll("\\.", "/")+"/"+inter;
		_type = daoType + "";
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//dao impl 数据
		_pid = daoId;
		_id = daoPack+"."+impl+"_"+id;
		_text = impl;
		_icon = SysConstant.ICONS_PACKAGE;
		_src = path +"/"+ srcName+"/"+daoPack.replaceAll("\\.", "/")+"/"+impl;
		_type = SysConstant.PACK_DAO + "";
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//service数据
		_pid = _srcid;
		String serviceId = servicePack+"_"+id;
		_text = servicePack;
		_icon = SysConstant.ICONS_PACKAGE;
		_src = path +"/"+ srcName+"/"+servicePack.replaceAll("\\.", "/");
		_type = SysConstant.PACK_SERVICE + "";
		data = new Object[]{serviceId,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//service inter 数据
		_pid = serviceId;
		_id = servicePack+"."+inter+"_"+id;
		_text = inter;
		_icon = SysConstant.ICONS_PACKAGE;
		_src = path +"/"+ srcName+"/"+servicePack.replaceAll("\\.", "/")+"/"+inter;
		_type = SysConstant.PACK_SERVICE + "";
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//service impl 数据
		_pid = serviceId;
		_id = servicePack+"."+impl+"_"+id;
		_text = impl;
		_icon = SysConstant.ICONS_PACKAGE;
		_src = path +"/"+ srcName+"/"+servicePack.replaceAll("\\.", "/")+"/"+impl;
		_type = SysConstant.PACK_SERVICE + "";
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		
		//action数据
		_pid = _srcid;
		_id = actionPack+"_"+id;
		_text = actionPack;
		_icon = SysConstant.ICONS_PACKAGE;
		_src = path +"/"+ srcName+"/"+actionPack.replaceAll("\\.", "/");
		_type = SysConstant.PACK_ACTION + "";
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//web文件内容目录数据
		_pid = introduction+"_"+id;
		_id = webName+"_"+id;
		_text = webName;
		_icon = SysConstant.ICONS_WEB;
		_src = path +"/"+ webName;
		_type = SysConstant.PACK_WEBCONTENT + "";
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//web页面目录数据
		_pid = _id;
		_id = pagePath+"_"+id;
		_text = pagePath;
		_icon = SysConstant.ICONS_WEB;
		_src = _src + pagePath;
		_type = SysConstant.PACK_PAGE + "";
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
		
		//database 目录数据
		_pid = introduction+"_"+id;
		_id = "db_"+dbNames+"_"+id;
		_text = dbNames;
		_icon = SysConstant.ICONS_DB;
		if(StringHandler.isValidStr(dbusername) && StringHandler.isValidStr(dbpassword)){
			_src = dbusername + ";" + dbpassword;	//用户名；密码组合
		}else{
			_src = "";
		}
		
		_type = SysConstant.PACK_DB + "";
		data = new Object[]{_id,_pid,_text,_icon,_leaf,_src,_projectId,_type,""};
		dataSource.add(data);
	}
	
	/**
	 * 获取项目列表
	 * @return
	 * @throws Exception
	 */
	public String list()throws Exception {
		try {
			//获取卡片项的ID，并将其作为 父ID
			SHashMap<String, Object> map = new SHashMap<String, Object>();
			DataTable dt = projectService.getResultList(map);
			result = (null == dt || dt.getSize() == 0) ? result = ResultMsg.NODATA : dt.getJsonArr();
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 获取项目列表
	 * @return
	 * @throws Exception
	 */
	public String dataSource()throws Exception {
		try {
			DataTable dt = projectService.getDataSource();
			result = (null == dt || dt.getSize() == 0) ? result = ResultMsg.NODATA : dt.getJsonArr();
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 保存项目
	 * @return
	 * @throws Exception
	 */
	public String save()throws Exception {
		try {
			ProjectEntity entity = BeanUtil.copyValue(ProjectEntity.class,getRequest());
			entity.setCreateTime(new Date());
			projectService.saveOrUpdateEntity(entity);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 删除项目
	 * @return
	 * @throws Exception
	 */
	public String delete()throws Exception {
		try {
			String _id = getVal("id");
			if(!StringHandler.isValidStr(_id)) throw new ServiceException(ServiceException.ID_IS_NULL);
			projectService.enabledEntity(Long.parseLong(_id), -1);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.DELETE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	private String classesDir = null;//--> 存放 classes目录 例如："webContent\WEB-INF\classes"
	private String srcName = null;	//--> 存放 src 目录
	/**
	 * 同步项目
	 * @return
	 */
	public String synchronous(){
		try {
			String projectId = getVal("projectId");	//项目ID
			SHashMap<String, Object> map = new SHashMap<String, Object>();
			map.put("projectIds", projectId);
			pkDt = packageService.getResultList(map);
			srcDt = srcfileService.getResultList(map);
			ProjectEntity pEntity = projectService.getEntity(Long.parseLong(projectId));
			srcName = pEntity.getSrcName();
			String classes = pEntity.getClasses();
			String webName = pEntity.getWebName();
			classesDir = webName + "\\WEB-INF\\" + classes;
			
			synchronousEntitys(projectId);
			synchronousDaos(projectId);
			synchronousServices(projectId);
			synchronousPages(projectId);
			synchronousTables(projectId);
			synchronousActions(projectId);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SYNCHRONOUS_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 同步实体包和类
	 */
	private void synchronousEntitys(String projectId) throws ServiceException {
		String entityId = getVal("entityId");
		String entitySrc = getVal("entitySrc");
		System.out.println("entityId="+entityId+",entitySrc="+entitySrc);
		saveFiles(projectId,PackageEntity.TYPE_ENTITY,entityId,entitySrc);
	}
	
	/**
	 * 保存文件
	 * @param type
	 * @param parentId
	 * @param files
	 * @throws ServiceException 
	 */
	private void saveFiles(String projectId ,int type,String parentId,String filePath) throws ServiceException{
	
		
		File parentfolder = new File(filePath);
		if(!parentfolder.exists()){
			parentfolder.mkdirs();
		}else{
			if(parentfolder.isDirectory()){//文件夹
			  File[] files = parentfolder.listFiles();
			  doFilesTodb(projectId, type, parentId, files);
			}
		}
	}

	/**
	 * @param projectId
	 * @param type
	 * @param parentId
	 * @param files
	 * @throws ServiceException 
	 */
	private void doFilesTodb(String projectId, int type, String parentId,
			File[] files) throws ServiceException {
		for(File file : files){
			String fileName = file.getName();
			System.out.println("fileName="+fileName + "result = "+ fileName.matches(".svn"));
			if(fileName.matches(".svn") || fileName.matches("base")) continue;
			if(file.isDirectory()){
		  		PackageEntity entity = createPackageEntity(projectId, type,
						parentId, file);
		  		Long _parentId = entity.getId();
		  		File[] _files = file.listFiles();
		  		if(null == _files || _files.length == 0) continue;
		  		//递归文件夹
		  		doFilesTodb(projectId,type,_parentId+"",_files);
			}else{
				//处理是文件的类型 srcfileEntity
				createSrcFileEntity(Long.parseLong(projectId),fileName,parentId,type,file);
			}
		}
	}
	
	/**
	 * 创建  SrcFileEntity 并保存到数据库中
	 * @param fileName	文件名
	 * @param parentId	父ID
	 * @param type	类型
	 * @param file	File 对象
	 * @return  返回 SrcFileEntity 对象
	 * @throws ServiceException
	 */
	private SrcFileEntity createSrcFileEntity(Long projectId,String fileName,String parentId,int type,File file) throws ServiceException{
		if(isExistSrcFile(type,fileName)) return null;
		SrcFileEntity entity = new SrcFileEntity();
		entity.setProjectId(projectId);
		entity.setName(fileName);
		entity.setParentId(parentId);
		entity.setCreateTime(new Date());
		entity.setPath(file.getAbsolutePath());
		entity.setType(type);
		
		if(PackageEntity.TYPE_PAGE != type){	//如果文件夹类型不是Web 目录则要读取实现接口及其它信息
			fillFileContentToSrcEntity(type,file,entity);
		}else{
			srcfileService.saveEntity(entity);
		}
		
		return entity;
	}
	
	/**
	 * 判断指定的源文件是否存在。
	 *  true : 表示要同步的源文件已经存在， false :在表中 不存在
	 * @param type	源文件类型
	 * @param fileName	源文件名称
	 * @return  true : 表示要同步的源文件或包在数据库表中已经存在， false :在表中 不存在
	 */
	private boolean isExistSrcFile(int type,String fileName){
		boolean isExist = false;
		if(null == srcDt || srcDt.getRowCount() == 0) return false;
		for(int i=0,count=srcDt.getRowCount(); i<count; i++){
			int _type = srcDt.getInteger(i, "type");
			String name = srcDt.getString(i, "text");
			if(_type == type && name.equals(fileName)) return true;
		}
		return isExist;
	}
	
	private FileClassLoader fileClsLoader = new FileClassLoader();
	/**
	 * 填充内容到 SrcFileEntity 中，如果类型是 ENTITY 的话，还须读取信息到 Fileds 表中
	 * @param type	包类型
	 * @param file	要读取的文件
	 * @param entity	SrcFileEntity 对象
	 */
	@SuppressWarnings("unchecked")
	private void fillFileContentToSrcEntity(int type,File file,SrcFileEntity entity){
		// step 1 read File Content
		String srcPath = file.getAbsolutePath();
		String[] arr = srcPath.split(srcName);
		String classPath = arr[0] + classesDir;
		classPath = classPath.replaceAll("[\\\\]", "/");
		String fileName = arr[1];
		if(!fileName.endsWith("java")) return;
		String className = fileName.replaceAll("[\\\\]", ".").replaceAll("/",".").replace(".java", "");
	
		if(0 == className.indexOf(".")) className = className.substring(1);
		System.out.println("classPath="+classPath+" , className="+className);
		fileClsLoader.setClassPath(classPath);
		try {
			Class cls = fileClsLoader.loadClass(className);
			System.out.println("ClassName="+cls.getName());
			makeClassInfo(cls,entity,type);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private void makeClassInfo(Class cls,SrcFileEntity entity,int type) {
		Description descAnnotation = (Description)cls.getAnnotation(Description.class);
		String defaultVals = null; 
		if(null != descAnnotation){
			String description = descAnnotation.remark();
			String createDate = descAnnotation.createDate();
			String author = descAnnotation.author();
			defaultVals = descAnnotation.defaultVals();
			if(StringHandler.isValidStr(description)) entity.setDescription(description);
			if(StringHandler.isValidStr(createDate)) entity.setCreatorDate(createDate);
			if(StringHandler.isValidStr(author)) entity.setDescription(author);
		}
		String extendcls = null;
		//--------> 接口没有父类
		Class supCls = cls.getSuperclass();
		if(null != supCls && !supCls.isInterface()) extendcls = getClassNames(new Class[]{supCls});
		
		String intercls = getClassNames(cls.getInterfaces());
		if(StringHandler.isValidStr(extendcls)) entity.setExtendcls(extendcls);
		if(StringHandler.isValidStr(intercls)) entity.setIntercls(intercls);
	
		int _type = getInterType(entity);
		if(-1 != _type){
			entity.setType(_type);	//接口类型
		}else{
			entity.setType(type);
		}
	    try {
			//判断 type 类型
			switch (type) {
			case PackageEntity.TYPE_ENTITY:{
				 Table tabAnnotation = (Table)cls.getAnnotation(Table.class);
				 if(null != tabAnnotation) entity.setTabname(tabAnnotation.name());
				 Description srcAnnotation = (Description)cls.getAnnotation(Description.class);
				 if(null != srcAnnotation){
					 String description = srcAnnotation.remark();
					 String createDate = srcAnnotation.createDate();
					 entity.setDescription(description);
					 entity.setCreatorDate(createDate);
				 } 
				 srcfileService.saveEntity(entity);
				 saveFields(entity.getId(),cls);
				break;
			}case PackageEntity.TYPE_DAO:{
				if(-1 == _type && cls.isAnnotationPresent(Repository.class)){
					Repository repAnnotation = (Repository)cls.getAnnotation(Repository.class);
					entity.setTabname(repAnnotation.value());
				}
				 srcfileService.saveEntity(entity);
				break;
			}case PackageEntity.TYPE_SERVICE:{
				if(-1 == _type && cls.isAnnotationPresent(Service.class)){
					Service serviceAnnotation = (Service)cls.getAnnotation(Service.class);
					entity.setTabname(serviceAnnotation.value());
				}
				 srcfileService.saveEntity(entity);
				break;
			}case PackageEntity.TYPE_ACTION:{
				srcfileService.saveEntity(entity);
				try{
					saveClassInfos(entity.getId(),defaultVals,cls);
				}catch(Exception ex){
					ex.printStackTrace();
				}
				break;
			}default:
				break;
			}
		 } catch (ServiceException e) {
				e.printStackTrace();
	   }
	}
	
	/**
	 * 保存 Action url 信息
	 */
	@SuppressWarnings("unchecked")
	private void saveClassInfos(Long srcId,String urlPrefix,Class cls){
		if(!StringHandler.isValidStr(urlPrefix)){
			System.out.println(cls.getName() + " 没有添加 @Description 注解，或者没有设置 @Description 的  defaultVals 属性值! ");
		}
		Method[] methods = cls.getDeclaredMethods();
		
		ClassInfoEntity entity = new ClassInfoEntity();
		try {
			for(Method method : methods){
				int mod = method.getModifiers();
				if(Modifier.isProtected(mod) || Modifier.isPrivate(mod) 
					|| Modifier.isStatic(mod) || Modifier.isAbstract(mod)) continue;
				String name = method.getName();
				entity.setSrcId(srcId);
				entity.setName(urlPrefix+name);
				entity.setType(0);
				entity.setCreateTime(new Date());
				classInfoService.saveEntity(entity);
			}
		} catch (ServiceException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 以下两个常量类，是用来比较指定的JAVA 源文件是否是接口文件
	 */
	private static final String DAO_INTER_FILTER = "DaoInter.java";
	private static final String SERVICE_INTER_FILTER = "Service.java";
	/**
	 * 返回接口类型
	 * @param entity
	 * @return
	 */
	private int getInterType(SrcFileEntity entity){
		String name = entity.getName();
		int type = -1;
		if(DAO_INTER_FILTER.indexOf(name) != -1){
			type = SysConstant.INTER_DAO;
		}
		if(SERVICE_INTER_FILTER.indexOf(name) != -1){
			type = SysConstant.INTER_DAO;
		}
		return type;
	}
	
	/**
	 * 保存类字段
	 * @param cls
	 */
	@SuppressWarnings("unchecked")
	private void saveFields(Long srcId,Class cls){
		System.out.println("===========================实体名："+cls.getName()+"===========================");
		Field[] fields = cls.getDeclaredFields();
		FieldsEntity entity = null;
		for(Field field : fields){
			boolean isSave = false;
			entity = new FieldsEntity();
			String fieldName = field.getName();
			entity.setSrcId(srcId);
			if(field.isAnnotationPresent(Id.class)){
				isSave = true;
				entity.setColName(fieldName);
				entity.setBind("主键");
			}else if(field.isAnnotationPresent(Column.class)){
				isSave = true;
				Column columnAnnotation = (Column)field.getAnnotation(Column.class);
				String colName = columnAnnotation.name();
				boolean isnull = columnAnnotation.nullable();
				int len = columnAnnotation.length();
				int decimalnum = columnAnnotation.precision();
				boolean unique = columnAnnotation.unique();
				if(StringHandler.isValidStr(colName)) entity.setColName(colName);
				entity.setIsnull(isnull ? "true" : "false");
				if(len > 0) entity.setLen(len);
				if(decimalnum > 0) entity.setDecimalnum(decimalnum);
				if(unique) entity.setBind("唯一");
			}
			
			if(isAnnotation(field,Description.class)){
				Map<String,String> desMap = getAnnotation(field, Description.class);
				
				String remark = null;
				String defaultVals = null;
				if(null != desMap && desMap.size() > 0){
					remark = desMap.get("remark");
					defaultVals = desMap.get("defaultVals");
				}
				if(StringHandler.isValidStr(remark)) entity.setRemark(remark);
				if(StringHandler.isValidStr(defaultVals)) entity.setDefaultval(defaultVals);
			}
			
			entity.setFieldName(fieldName);
			String dataType =  field.getType().getSimpleName();
			entity.setDataType(dataType);
			String sqlDataType = getSqlDataType(dataType);
			entity.setSqltype(sqlDataType);
			if(isSave){	//是可保存的持久化字段
				try {
					fieldsService.saveEntity(entity);
				} catch (ServiceException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private boolean isAnnotation(Field field,Class clz){
		boolean flag = false;
		flag = field.isAnnotationPresent(clz);
		if(flag) return flag;
		String sourceActionType = clz.getSimpleName();
		Annotation[] annotations = field.getAnnotations();
		for(Annotation an : annotations){
			String annotationType = an.annotationType().getSimpleName();
			System.out.println("sourceActionType = "+sourceActionType+",annotationType="+annotationType);
			if(sourceActionType.equals(annotationType)){
				flag = true;
				return flag;
			}
		}
		return flag;
	}
	
	/**
	 * 根据注解类获取注解对象
	 * @param field	字段对象
	 * @param clz	注解类
	 * @return	返回注解类对象
	 */
	@SuppressWarnings("unchecked")
	private  Map<String,String> getAnnotation(Field field,Class clz){
		Annotation theAnnotation = field.getAnnotation(clz);
		if(null != theAnnotation) return getAnnotationVals(theAnnotation);
		boolean flag = false;
		flag = field.isAnnotationPresent(clz);
		if(flag) return null;
		String sourceActionType = clz.getSimpleName();
		Annotation[] annotations = field.getAnnotations();
		for(Annotation an : annotations){
			String annotationType = an.annotationType().getSimpleName();
			Map<String,String> anmap = getAnnotationVals(an);
			if(sourceActionType.equals(annotationType)){
				return anmap;
			}
		}
		return null;
	}

	private Map<String,String> getAnnotationVals( Annotation an) {
		Map<String,String> anmap = new HashMap<String, String>();
		Method[] methods = an.annotationType().getDeclaredMethods();
		for(Method method : methods){
			try {
				String name = method.getName();
				Object obj = method.invoke(an, null);
				String val = "";
				if(null != obj) val = obj.toString();
				anmap.put(name, val);
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
		}
		return anmap;
	}
	
	public static void main(String[] args){
		System.out.println(Description.class.toString());
	}
	
	/**
	 * 根据字段的数据类型返回SQL数据类型
	 * @param javaDataType
	 * @return
	 */
	private String getSqlDataType(String javaDataType){
		String sqlDataType = "程序不支持";
		if("String".equals(javaDataType)){
			sqlDataType = "varchar";
		}else if("Long".equals(javaDataType)){
			sqlDataType = "bigint";
		}else if("Integer".equals(javaDataType)){
			sqlDataType = "int";
		}else if("Byte".equals(javaDataType)){
			sqlDataType = "tinyint";
		}else if("Date".equals(javaDataType)){
			sqlDataType = "datetime";
		}else if("Double".equals(javaDataType)){
			sqlDataType = "double";
		}else if("Float".equals(javaDataType)){
			sqlDataType = "float";
		}else if("BigDecimal".equals(javaDataType)){
			sqlDataType = "decimal";
		}
		return sqlDataType;
	}
	
	/**
	 * 返加类数组的类名列表，以“,”分隔
	 * @param clses	类数组
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String getClassNames(Class[] clses){
		if(null == clses || clses.length == 0) return null;
		StringBuffer sb = new StringBuffer();
		for(Class cls : clses){
			sb.append(cls.getSimpleName()+",");
		}
		return StringHandler.RemoveStr(sb, ",");
	}
	
	/**
	 * 如果指定的包或文件夹在数据库中存在，则返回空。否则，创建包Entity 并返回
	 * @param projectId	项目ID
	 * @param type	包或文件夹类型
	 * @param parentId	父ID
	 * @param fileName	包或文件夹
	 * @return	返回  PackageEntity 对象
	 * @throws ServiceException
	 */
	private PackageEntity createPackageEntity(String projectId, int type,
			String parentId, File file) throws ServiceException {
		String fileName = file.getName();
		String absFileName = file.getAbsolutePath();
		Long packageId = isExistPackage(type,fileName);
		PackageEntity entity = new PackageEntity();
		if(null != packageId){
			entity.setId(packageId);
		}else{
			entity.setName(fileName);
			entity.setIntroduction(absFileName);
			entity.setParentId(parentId);
			entity.setProjectId(Long.parseLong(projectId));
			entity.setType(type);
			entity.setCreateTime(new Date());
			packageService.saveEntity(entity);
		}
		return entity;
	}
	
	/**
	 * 判断指定的包或文件夹是否存在。
	 *  true : 表示要同步的文件夹或包已经存在， false :在表中 不存在
	 * @param type	包或文件夹类型
	 * @param fileName	包或文件夹名称
	 * @return  true : 表示要同步的文件夹或包在数据库表中已经存在， false :在表中 不存在
	 */
	private Long isExistPackage(int type,String fileName){
		Long packageId = null;
		if(null == pkDt || pkDt.getRowCount() == 0) return null;
		for(int i=0,count=pkDt.getRowCount(); i<count; i++){
			int _type = pkDt.getInteger(i, "type");
			String name = pkDt.getString(i, "text");
			if(_type == type && name.equals(fileName)){
				String id = pkDt.getString(i, "id");
				if(id.indexOf("P") == 0){
					id = id.substring(1);
				}
				packageId = Long.parseLong(id);
				break;
			} 
		}
		return packageId;
	}
	
	/**
	 * 同步DAO包和类
	 */
	private void synchronousDaos(String projectId) throws ServiceException {
		String daoInterId = getVal("daoInterId");
		String daoInterSrc = getVal("daoInterSrc");
		String daoImplId = getVal("daoImplId");
		String daoImplSrc = getVal("daoImplSrc");
		System.out.println("daoInterId="+daoInterId+",daoInterSrc="+daoInterSrc+",daoImplId="+daoImplId+",daoImplSrc="+daoImplSrc);
		saveFiles(projectId,PackageEntity.TYPE_DAO,daoInterId,daoInterSrc);
		saveFiles(projectId,PackageEntity.TYPE_DAO,daoImplId,daoImplSrc);
	}
	
	/**
	 * 同步Service包和类
	 */
	private void synchronousServices(String projectId) throws ServiceException {
		String serviceInterlId = getVal("serviceInterId");
		String serviceInterSrc = getVal("serviceInterSrc");
		String serviceImplId = getVal("serviceImplId");
		String serviceImplSrc = getVal("serviceImplSrc");
		System.out.println("serviceInterlId="+serviceInterlId+",serviceInterSrc="+serviceInterSrc+",serviceImplId="+serviceImplId+",serviceImplSrc="+serviceImplSrc);
		saveFiles(projectId,PackageEntity.TYPE_SERVICE,serviceInterlId,serviceInterSrc);
		saveFiles(projectId,PackageEntity.TYPE_SERVICE,serviceImplId,serviceImplSrc);
	}
	
	/**
	 * 同步Action包和类
	 */
	private void synchronousActions(String projectId) throws ServiceException {
		String actionId = getVal("actionId");
		String actionSrc = getVal("actionSrc");
		System.out.println("actionId="+actionId+",actionSrc="+actionSrc);
		saveFiles(projectId,PackageEntity.TYPE_ACTION,actionId,actionSrc);
	}
	
	/**
	 * 同步JS页面包和类
	 */
	private void synchronousPages(String projectId) throws ServiceException {
		String pageId = getVal("pageId");
		String pageSrc = getVal("pageSrc");
		System.out.println("pageId="+pageId+",="+pageSrc);
		saveFiles(projectId,PackageEntity.TYPE_PAGE,pageId,pageSrc);
	}
	
	/**
	 * 同步数据库表
	 */
	private void synchronousTables(String projectId) throws ServiceException {
		String dbId = getVal("dbId");
		String dbSrc = getVal("dbSrc");
		System.out.println("dbId="+dbId+",dbSrc="+dbSrc);
	}
	
	
}
