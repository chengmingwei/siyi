/**
 * 
 */
package com.cmw.action.sys;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.cmw.constant.ResultMsg;
import com.cmw.core.base.action.BaseAction;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.util.BeanUtil;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.FastJsonUtil;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.StringHandler;
import com.cmw.core.util.TreeUtil;
import com.cmw.entity.sys.MultiProjectEntity;
import com.cmw.entity.sys.TabCmnsEntity;
import com.cmw.entity.sys.TabInfoEntity;
import com.cmw.service.impl.sys.DbMgrService;
import com.cmw.service.inter.sys.MultiProjectService;
import com.cmw.service.inter.sys.TabCmnsService;
import com.cmw.service.inter.sys.TabInfoService;

/**
 * @author 程明卫 E-mail:chengmingwei_1984122@126.com
 * @version 创建时间：2010-6-15 下午12:14:31
 * 类说明 	数据库操作 ACTION
 */
@SuppressWarnings("serial")
public class DbAction extends BaseAction {

	@Resource(name="multiProjectService")
	private MultiProjectService multiProjectService;
	
	@Resource(name="dbMgrService")
	private DbMgrService dbMgrService;
	
	@Resource(name="tabInfoService")
	private  TabInfoService tabInfoService;
	
	@Resource(name="tabCmnsService")
	private  TabCmnsService tabCmnsService;
	
	private String result = ResultMsg.GRID_NODATA;
	
	
	/**
	 * 同步数据库表信息
	 * @return
	 * @throws Exception
	 */
	public String synchroTabs()throws Exception {
		try {
			Long projectId = getLVal("projectId");
			MultiProjectEntity projectObj = multiProjectService.getEntity(projectId);
			dbMgrService.synchroTabs(projectObj);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 获取数据库表树
	 * @return
	 * @throws Exception
	 */
	public String tabTree()throws Exception {
		try {
			SHashMap<String, Object> map = getQParams("projectId");
			
			if(null == map || map.size() == 0){
				result = ResultMsg.NODATA;
			}else{
				DataTable dt =  tabInfoService.getResultList(map);
				TreeUtil tree = new TreeUtil(dt);
				tree.setIconPath("");
				result = tree.getJsonArr("M"+map.getvalAsStr("projectId"));
			}
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 获取源文件信息
	 * @return
	 * @throws Exception
	 */
	public String get()throws Exception {
		try {
			String id = getVal("id");
			if(!StringHandler.isValidStr(id)) throw new ServiceException(ServiceException.ID_IS_NULL);
			id = id.replace("T", "");
			TabInfoEntity entity = tabInfoService.getEntity(Long.parseLong(id));
			SHashMap<String, Object> pars = new SHashMap<String, Object>();
			pars.put("tabId", Long.parseLong(id));
			List<TabCmnsEntity> tabCmnsList = tabCmnsService.getEntityList(pars);
			Map<String, Object> appendParams = new HashMap<String, Object>();
			appendParams.put("columns", tabCmnsList);
			result = FastJsonUtil.convertJsonToStr(entity, appendParams);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 保存项目
	 * @return
	 * @throws Exception
	 */
	public String save()throws Exception {
		try {
			SHashMap<String, Object> pars = getQParams("id,name,description,fields");
			String id = pars.getvalAsStr("id");
			id = id.replace("T", "");
			pars.put("id", id);
			tabInfoService.doComplexBusss(pars);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
}
