package com.cmw.action.sys;

import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.action.BaseAction;
/**
 * 
 * @author Administrator
 *
 */
@SuppressWarnings("serial")
public class TestAction extends BaseAction {
	/**
	 * 获取包列表
	 * @return
	 * @throws Exception
	 */
	public String list()throws Exception {
		JSONObject jsonObj = new JSONObject();
//		jsonObj.put("name", "列表视图");
//		jsonObj.put("url", "/smartplatform/images/templates/listview/thumbnails/GridForm_small.png");
//		jsonObj.put("size", 30.0f);
//		jsonObj.put("lastmod", new Date());
		String result = jsonObj.toString();
		outJsonString(result);
		return null;
	}
}
