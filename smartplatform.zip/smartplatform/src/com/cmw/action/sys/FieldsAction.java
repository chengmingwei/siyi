/**
 * 
 */
package com.cmw.action.sys;

import javax.annotation.Resource;

import com.cmw.constant.ResultMsg;
import com.cmw.core.base.action.BaseAction;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.util.BeanUtil;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.StringHandler;
import com.cmw.entity.sys.FieldsEntity;
import com.cmw.service.inter.sys.FieldsService;

/**
 * @author 程明卫 E-mail:chengmingwei_1984122@126.com
 * @version 创建时间：2010-6-15 下午12:14:31
 * 类说明 	字段管理 ACTION
 */
@SuppressWarnings("serial")
public class FieldsAction extends BaseAction {
	/**
	 * 获取 session 中当前登录用户的 KEY
	 */
	public static final String USER_KEY = "user";
	@Resource(name="fieldsService")
	private FieldsService fieldsService;
	
	private String result = ResultMsg.GRID_NODATA;
	/**
	 * 获取字段列表
	 * @return
	 * @throws Exception
	 */
	public String list()throws Exception {
		try {
			//获取卡片项的ID，并将其作为 父ID
			SHashMap<String, Object> map = new SHashMap<String, Object>();
			map.put("srcId", getVal("srcId"));
			DataTable dt = fieldsService.getResultList(map);
			result = (null == dt || dt.getSize() == 0) ? result = ResultMsg.NODATA : dt.getJsonArr();
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	
	/**
	 * 保存字段
	 * @return
	 * @throws Exception
	 */
	public String save()throws Exception {
		try {
			FieldsEntity entity = BeanUtil.copyValue(FieldsEntity.class,getRequest());
			fieldsService.saveOrUpdateEntity(entity);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 删除字段
	 * @return
	 * @throws Exception
	 */
	public String delete()throws Exception {
		try {
			String _id = getVal("id");
			if(!StringHandler.isValidStr(_id)) throw new ServiceException(ServiceException.ID_IS_NULL);
			fieldsService.enabledEntity(Long.parseLong(_id), -1);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.DELETE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
}
