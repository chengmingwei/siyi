/**
 * 
 */
package com.cmw.action.sys;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import com.cmw.constant.ResultMsg;
import com.cmw.core.base.action.BaseAction;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.kit.file.ExtFileUtil;
import com.cmw.core.kit.file.ExtFileUtil.FileGatherModel;
import com.cmw.core.kit.file.FileUtil;
import com.cmw.core.util.BeanUtil;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.StringHandler;
import com.cmw.core.util.TreeUtil;
import com.cmw.entity.sys.MultiProjectEntity;
import com.cmw.service.inter.sys.MultiProjectService;
import com.cmw.service.inter.sys.SrcFileService;

/**
 * @author 程明卫 E-mail:chengmingwei_1984122@126.com
 * @version 创建时间：2010-6-15 下午12:14:31
 * 类说明 	项目管理 ACTION
 */
@SuppressWarnings("serial")
public class MultiProjectAction extends BaseAction {
	/**
	 * 获取 session 中当前登录用户的 KEY
	 */
	public static final String USER_KEY = "user";
	@Resource(name="multiProjectService")
	private MultiProjectService multiProjectService;
	
	@Resource(name="srcfileService")
	private SrcFileService srcfileService;
	
	private String result = ResultMsg.GRID_NODATA;
		
	public MultiProjectAction() {
	}


	
	/**
	 * 获取项目列表
	 * @return
	 * @throws Exception
	 */
	public String list()throws Exception {
		try {
			//获取卡片项的ID，并将其作为 父ID
			SHashMap<String, Object> map = new SHashMap<String, Object>();
			DataTable dt = multiProjectService.getResultList(map);
			result = (null == dt || dt.getSize() == 0) ? result = ResultMsg.NODATA : dt.getJsonArr();
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	
	/**
	 * 获取实体树
	 * @return
	 * @throws Exception
	 */
	public String navTree()throws Exception {
		try {
			SHashMap<String, Object> map = getQParams("projectIds");
			
			if(null == map || map.size() == 0){
				result = ResultMsg.NODATA;
			}else{
				map.put("multi", 1);
				DataTable dt =  srcfileService.getResultList(map);
				TreeUtil tree = new TreeUtil(dt);
				tree.setIconPath("");
				result = tree.getJsonArr("P"+map.getvalAsStr("projectIds"));
			}
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 保存项目
	 * @return
	 * @throws Exception
	 */
	public String save()throws Exception {
		try {
			MultiProjectEntity entity = BeanUtil.copyValue(MultiProjectEntity.class,getRequest());
			entity.setCreateTime(new Date());
			multiProjectService.saveOrUpdateEntity(entity);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 项目源码下载前检查
	 * @return
	 * @throws Exception
	 */
	public String downLoadCheck()throws Exception {
		try {
			Long id = getLVal("id");
			if(!StringHandler.isValidObj(id)){
				throw new Exception("参数：id的值为空!");
			}
			String projPath = null;
			MultiProjectEntity multiProjectObj = multiProjectService.getEntity(id);
			String path = multiProjectObj.getPath();
			String introduction = multiProjectObj.getIntroduction();
			int offset = path.lastIndexOf("/");
			if(offset == -1 || offset != path.length()-1){
				projPath = path+"/"+introduction;
			}else{
				projPath = path+introduction;
			}
			
			boolean exist = FileUtil.exist(projPath);
			
			Map<String,Object> appendParams = new HashMap<String, Object>();
			appendParams.put("exist", exist);
			appendParams.put("uuid", UUID.randomUUID().toString());
			appendParams.put("projPath", projPath);
			result = ResultMsg.getSuccessMsg(appendParams);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 项目文件复制
	 * @return
	 * @throws Exception
	 */
	public String copy()throws Exception {
		try {
			String projPath = getVal("projPath");
			String uuid = getVal("uuid");
			Long id = getLVal("id");
			MultiProjectEntity projectEntity = multiProjectService.getEntity(id);
			String basePath = StringHandler.getClassPath();
			FileCopyTask target = new FileCopyTask(basePath, uuid, projPath, projectEntity);
			Thread copyThread = new Thread(target);
			copyThread.start();
			Thread.sleep(1000);
			result = ResultMsg.getSuccessMsg();
		} catch (Exception ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 获取项目文件复制进度
	 * @return
	 * @throws Exception
	 */
	public String progess()throws Exception {
		try {
			String uuid = getVal("uuid");
			FileGatherModel fileGatherModel = ExtFileUtil.getProgess(uuid);
			if(null == fileGatherModel){
				result = ResultMsg.getFailureMsg();
			}else{
				Map<String,Object> appendParams = new HashMap<String, Object>();
				appendParams.put("totalCount", fileGatherModel.getTotalCount());
				appendParams.put("currNum", fileGatherModel.getCurrNum());
				int currPrecent = fileGatherModel.getCurrPrecent();
				appendParams.put("currPrecent", currPrecent);
				boolean finish = currPrecent>99 ? true : false;
				appendParams.put("finish", finish);
				result = ResultMsg.getSuccessMsg(appendParams);
			}
			
		} catch (Exception ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	
	/**
	 * 文件复制任务
	 * @author Administrator
	 *
	 */
	public class FileCopyTask implements Runnable{
		private String uuid;
		private String basePath;
		private String projPath;
		private MultiProjectEntity projectEntity;
		
		public FileCopyTask(String basePath,String uuid, String projPath, MultiProjectEntity projectEntity) {
			super();
			this.uuid = uuid;
			this.basePath = basePath;
			this.projPath = projPath;
			this.projectEntity = projectEntity;
		}



		@Override
		public void run() {
			String webTempPath = "/pages/app/module/sctemps/sbm-template"; //单项目模板
			if(null != projectEntity && projectEntity.getMulti().intValue() == 1){//多模块模板
				webTempPath = "/pages/app/module/sctemps/websource_temp";
			}
			basePath = basePath.substring(0, basePath.indexOf("/WEB-INF"));
			String oldPath = basePath + webTempPath;
			ExtFileUtil.copyFolder(uuid,oldPath, projPath);
		}
		
	}
}
