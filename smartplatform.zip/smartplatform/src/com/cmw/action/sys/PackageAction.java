/**
 * 
 */
package com.cmw.action.sys;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.annotation.Resource;

import com.cmw.constant.ResultMsg;
import com.cmw.constant.SysConstant;
import com.cmw.core.base.action.BaseAction;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.kit.file.FileUtil;
import com.cmw.core.util.BeanUtil;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.StringHandler;
import com.cmw.entity.sys.PackageEntity;
import com.cmw.entity.sys.ProjectEntity;
import com.cmw.service.inter.sys.PackageService;
import com.cmw.service.inter.sys.ProjectService;
import com.cmw.service.inter.sys.SrcFileService;

import javassist.NotFoundException;

/**
 * @author 程明卫 E-mail:chengmingwei_1984122@126.com
 * @version 创建时间：2010-6-15 下午12:14:31
 * 类说明 	包管理 ACTION
 */
@SuppressWarnings("serial")
public class PackageAction extends BaseAction {
	/**
	 * 获取 session 中当前登录用户的 KEY
	 */
	public static final String USER_KEY = "user";
	@Resource(name="packageService")
	private PackageService packageService;
	
	@Resource(name="projectService")
	private ProjectService projectService;
	
	@Resource(name="srcfileService")
	private SrcFileService srcfileService;
	
	private String result = ResultMsg.GRID_NODATA;
	/**
	 * 获取包列表
	 * @return
	 * @throws Exception
	 */
	public String list()throws Exception {
		try {
			//获取卡片项的ID，并将其作为 父ID
			SHashMap<String, Object> map = new SHashMap<String, Object>();
			DataTable dt = packageService.getResultList(map);
			result = (null == dt || dt.getSize() == 0) ? result = ResultMsg.NODATA : dt.getJsonArr();
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	/**
	 * 获取项目列表
	 * ./sysPackage_dataSource.action
	 * @return
	 * @throws Exception
	 */
	public String dataSource()throws Exception {
		try {
			Long projectId = getLVal("projectId");
			DataTable dt = packageService.getDataSource(projectId);
			result = (null == dt || dt.getSize() == 0) ? result = ResultMsg.NODATA : dt.getJsonArr();
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	
	/**
	 * 保存包
	 * @return
	 * @throws Exception
	 */
	public String save()throws Exception {
		try {
			//所属项目,包名,包描述,生成类型 
			//projectId,name,introduction,type
			PackageEntity entity = BeanUtil.copyValue(PackageEntity.class,getRequest());
			boolean isAdd = entity.getId()==null;
			packageService.saveOrUpdateEntity(entity);
			String introduction = entity.getIntroduction();
			if(isAdd){
				FileUtil.creatDictory(introduction);
			}else{
				String sourcePath = getVal("oldPath");
				FileUtil.rename(sourcePath, entity.getName());
			}
			
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	
	/**
	 * 保存包
	 * @return
	 * @throws Exception
	 */
	public String savepackages()throws Exception {
		try {
			//所属项目,包名,包描述,生成类型 
			//projectId,name,introduction,type
			Long projectId = getLVal("projectId");
			Long id = getLVal("id");
			String name = getVal("name");
			String types = getVal("type");
			String remark = getVal("remark");
			boolean isAdd = null == id;
			String oldName = null;
			if(!isAdd){
				PackageEntity packEntity = packageService.getEntity(id);
				oldName = packEntity.getName();
			}
			String introduction = null;
			String parentId = null;
			String[] typesArr = types.split(",");
			ProjectEntity projEntity = projectService.getEntity(projectId);
			String srcPath = projEntity.getPath()+File.separator+projEntity.getSrcName()+File.separator;
			String webPath = projEntity.getPath()+File.separator+projEntity.getWebName()+File.separator;
			for(String type : typesArr){
				int _type = Integer.parseInt(type);
				parentId = projEntity.getEntityPack()+"_"+projectId;
				if(_type == SysConstant.PACK_ENTITY){
					introduction = srcPath + convertPath(projEntity.getEntityPack())+File.separator + name;
					if(isAdd){
						save(projectId, introduction, parentId, _type, name, remark);
					}else{
						introduction = srcPath + convertPath(projEntity.getEntityPack())+File.separator + oldName;
						update(parentId,introduction,oldName,name,remark);
					}
				}else if(_type == (SysConstant.PACK_DAO-999)){
					if(isAdd){
						String daoPack = projEntity.getDaoPack()+".inter";
						parentId = daoPack+"_"+projectId;
						introduction = srcPath + convertPath(daoPack)+File.separator + name;
						save(projectId, introduction, parentId, _type, name, remark);
						
						daoPack = projEntity.getDaoPack()+".impl";
						introduction = srcPath + convertPath(daoPack)+File.separator + name;
						parentId = daoPack+"_"+projectId;
						save(projectId, introduction, parentId, _type, name, remark);
					}else{
						String daoPack = projEntity.getDaoPack()+".inter";
						parentId = daoPack+"_"+projectId;
						introduction = srcPath + convertPath(daoPack)+File.separator + oldName;
						
						update(parentId,introduction,oldName,name,remark);
						
						daoPack = projEntity.getDaoPack()+".impl";
						parentId = daoPack+"_"+projectId;
						introduction = srcPath + convertPath(daoPack)+File.separator + oldName;
						update(parentId,introduction,oldName,name,remark);
					}
				}else if(_type == SysConstant.PACK_SERVICE){
					if(isAdd){
						String servicePack = projEntity.getServicePack()+".inter";
						parentId = servicePack+"_"+projectId;
						introduction = srcPath + convertPath(servicePack)+File.separator + name;
						save(projectId, introduction, parentId, _type, name, remark);
						
						servicePack = projEntity.getServicePack()+".impl";
						introduction = srcPath + convertPath(servicePack)+File.separator + name;
						parentId = servicePack+"_"+projectId;
						save(projectId, introduction, parentId, _type, name, remark);
					}else{
						String servicePack = projEntity.getServicePack()+".inter";
						parentId = servicePack+"_"+projectId;
						introduction = srcPath + convertPath(servicePack)+File.separator + oldName;
						update(parentId,introduction,oldName,name,remark);
						
						servicePack = projEntity.getServicePack()+".impl";
						parentId = servicePack+"_"+projectId;
						introduction = srcPath + convertPath(servicePack)+File.separator + oldName;
						update(parentId,introduction,oldName,name,remark);
					}
				}else if(_type == SysConstant.PACK_ACTION){
					parentId = projEntity.getActionPack()+"_"+projectId;
					introduction = srcPath + convertPath(projEntity.getActionPack())+File.separator + name;
					if(isAdd){
						save(projectId, introduction, parentId, _type, name, remark);
					}else{
						introduction = srcPath + convertPath(projEntity.getActionPack())+File.separator + oldName;
						update(parentId,introduction,oldName,name,remark);
					}
				}else if(_type == SysConstant.PACK_PAGE){
					parentId = projEntity.getPagePath()+"_"+projectId;
					introduction = webPath + convertPath(projEntity.getPagePath())+File.separator + name;
					if(isAdd){
						save(projectId, introduction, parentId, _type, name, remark);
					}else{
						introduction = webPath + convertPath(projEntity.getPagePath())+File.separator + oldName;
						update(parentId,introduction,oldName,name,remark);
					}
				}
			
			}
			result = ResultMsg.getSuccessMsg(this, ResultMsg.SAVE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		} catch (Exception ex){
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
	
	private String convertPath(String str){
		int offset = str.indexOf("/");
		if(str.length()>0 && offset == 0) str = str.substring(1);
		offset = str.lastIndexOf("/");
		if(str.length()>0 && offset == str.length()-1) str = str.substring(0,offset);
		return str.replace("/", File.separator).replace(".", File.separator);
	}
	
	private void save(Long projectId,String introduction,String parentId, Integer type, String name, String remark) throws ServiceException, IOException, NotFoundException{
		PackageEntity entity = new PackageEntity();
		entity.setProjectId(projectId);
		entity.setName(name);
		entity.setParentId(parentId);
		entity.setIntroduction(introduction);
		entity.setRemark(remark);
		entity.setType(type);
		entity.setCreateTime(new Date());
		packageService.saveOrUpdateEntity(entity);
		FileUtil.creatDictory(introduction);
	}
	
	private void update(String parentId,String introduction,String oldName, String name, String remark) throws ServiceException{
		SHashMap<String, Object> params = new SHashMap<String, Object>();
		params.put("parentId", parentId);
		params.put("name", oldName);
		PackageEntity entity = packageService.getEntity(params);
		if(null==entity) return;
		entity.setName(name);
		entity.setRemark(remark);
		String newPath=null;
		try {
			newPath = FileUtil.rename(introduction, entity.getName());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NotFoundException e) {
			e.printStackTrace();
		}
		if(!StringHandler.isValidStr(newPath)) return;
		entity.setIntroduction(newPath);
		packageService.saveOrUpdateEntity(entity);
		
	}
	/**
	 * 删除包
	 * @return
	 * @throws Exception
	 */
	public String delete()throws Exception {
		try {
			String _id = getVal("id");
			_id = _id.replace("P", "");
			String delType = getVal("delType");
			if(!StringHandler.isValidStr(_id)) throw new ServiceException(ServiceException.ID_IS_NULL);
			Long id = Long.parseLong(_id);
			if(StringHandler.isValidStr(delType) && Integer.parseInt(delType) == 1){	//删除物理文件
				PackageEntity entity = packageService.getEntity(id);
				String fielPath = entity.getIntroduction();
				FileUtil.delFile(fielPath);
			}
			packageService.deleteEntity(id);
			result = ResultMsg.getSuccessMsg(this, ResultMsg.DELETE_SUCCESS);
		} catch (ServiceException ex){
			result = ResultMsg.getFailureMsg(this,ex.getMessage());
			if(null == result) result = ex.getMessage();
			ex.printStackTrace();
		}
		outJsonString(result);
		return null;
	}
}
