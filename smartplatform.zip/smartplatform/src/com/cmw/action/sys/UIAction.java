package com.cmw.action.sys;

import java.io.File;
import java.util.Date;

import javax.annotation.Resource;

import com.cmw.constant.ResultMsg;
import com.cmw.constant.SysConstant;
import com.cmw.core.base.action.BaseAction;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.kit.file.FileUtil;
import com.cmw.core.util.StringHandler;
import com.cmw.entity.sys.SrcFileEntity;
import com.cmw.service.inter.sys.SrcFileService;
/**
 * 前端JS文件处理Action
 * @author Administrator
 *
 */
@SuppressWarnings("serial")
public class UIAction extends BaseAction {
	@Resource(name="srcfileService")
	private SrcFileService srcfileService;
	/**
	 * 获取包列表
	 * @return
	 * @throws Exception
	 */
	public String save()throws Exception {
		String filePathName = getVal("TEMPPATH");
		String filename = getVal("FILENAME");
		String sigins = getVal("SIGINS");
		String serverPath = FileUtil.getFilePath(request, "WEB-INF/classes/template/jsTemplate/");
		filePathName = serverPath + filePathName;
		String tempStr = FileUtil.ReadFileToStr(filePathName);
		String author = (null != getCurUser()) ? getCurUser().getUserName() : "smartplatform_auto";
		String date = StringHandler.dateFormatToStr("yyyy-MM-dd hh:mm:ss", new Date());
		tempStr = tempStr.replace("#AUTHOR#", author).replace("#DATE#", date);
		String[] siginArr = sigins.split(",");
		for(String sigin : siginArr){
			String val = getVal(sigin);
			tempStr = tempStr.replace("#"+sigin+"#", val);
		}
		File file = FileUtil.writeStrToFile(filename, tempStr);
		String parentId = getVal("parentId");
		Long projectId = getLVal("projectId");
		saveEntity(file,parentId,projectId);
		String result = ResultMsg.getSuccessMsg(tempStr);
		outJsonString(result);
		return null;
	}
	
	/**
	 * 保存源代码文件内容		
	 * @return
	 * @throws Exception
	 */
	public String saveSource()throws Exception {
		String sourceCode = getVal("SOURCECODE");
		String filename = getVal("FILENAME");
		String sigins = getVal("SIGINS");
		if(StringHandler.isValidStr(sigins)){
			String[] siginArr = sigins.split(",");
			for(String sigin : siginArr){
				String val = getVal(sigin);
				if(!StringHandler.isValidStr(val)) continue;
				String singnStr = "#"+sigin+"#";
				if(sourceCode.indexOf(singnStr) == -1) continue;
				sourceCode = sourceCode.replace(singnStr, val);
			}
		}
		
		File file = FileUtil.writeStrToFile(filename, sourceCode);
		String parentId = getVal("parentId");
		Long projectId = getLVal("projectId");
		saveEntity(file,parentId,projectId);
		//--->删除预览文件
		String serverPath = FileUtil.getFilePath(request, "pages/app/demo/");
		File demoDir = new File(serverPath);
		if(demoDir != null){
			File[] delList = demoDir.listFiles();
			if(null != delList && delList.length>0){
				for(File delFile : delList){
					serverPath = delFile.getAbsolutePath();
					FileUtil.delFile(serverPath);
				}
			}
		}
		String result = ResultMsg.getSuccessMsg();
		outJsonString(result);
		return null;
	}
	
	private void saveEntity(File file,String parentId,Long projectId){
		SrcFileEntity entity = new SrcFileEntity();
		entity.setParentId(parentId);
		entity.setProjectId(projectId);
		entity.setName(file.getName());
		entity.setType(SysConstant.PACK_PAGE);
		entity.setPath(file.getAbsolutePath());
		entity.setCreateTime(new Date());
		try {
			srcfileService.saveOrUpdateEntity(entity);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 获取解析好后的源代码文件内容
	 * @return
	 * @throws Exception
	 */
	public String getSource()throws Exception {
		String filePathName = getVal("TEMPPATH");
		String tempStr = getContent(filePathName);
		String fileUuid = getVal("fileUuid");
		String serverPath = FileUtil.getFilePath(request, "pages/app/demo/");
		if(!FileUtil.exist(serverPath)){
			FileUtil.creatDictory(serverPath);
		}
		String absFileName = serverPath+fileUuid+".js";
		FileUtil.writeStrToFile(absFileName, tempStr);
		//String result = ResultMsg.getSuccessMsg(tempStr);
		outJsonString(tempStr);
		return null;
	}
	
	private String getContent(String filePathName) {
		String sigins = getVal("SIGINS");
		String serverPath = FileUtil.getFilePath(request, "WEB-INF/classes/template/jsTemplate/");
		filePathName = serverPath + filePathName;
		Integer isReadTemp = getIVal("isReadTemp");
		String tempStr = (null == isReadTemp || isReadTemp.intValue() == 0) ? 
				FileUtil.ReadFileToStr(filePathName) : getVal("APPFORMDEFINELES");
		String author = (null != getCurUser()) ? getCurUser().getUserName() : "smartplatform_auto";
		if(!StringHandler.isValidStr(author)) author = "smartplatform_auto";
		String date = StringHandler.dateFormatToStr("yyyy-MM-dd hh:mm:ss", new Date());
		tempStr = tempStr.replace("#AUTHOR#", author).replace("#DATE#", date);
		String[] siginArr = sigins.split(",");
		for(String sigin : siginArr){
			String val = getVal(sigin);
			if(!StringHandler.isValidStr(val)) continue;
			String singnStr = "#"+sigin+"#";
			if(tempStr.indexOf(singnStr) == -1) continue;
			tempStr = tempStr.replace(singnStr, val);
		}
		return tempStr;
	}
	
}
