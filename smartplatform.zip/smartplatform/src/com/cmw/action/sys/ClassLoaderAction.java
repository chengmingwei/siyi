package com.cmw.action.sys;

import javax.persistence.Table;

import com.cmw.core.base.action.BaseAction;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.util.FileClassLoader;

@SuppressWarnings("serial")
public class ClassLoaderAction extends BaseAction {
	private FileClassLoader fileClsLoader = new FileClassLoader();
	@SuppressWarnings("unchecked")
	@Override
	public String execute() throws Exception {
		fileClsLoader.setClassPath("E:\\j2ee_proj\\skythink\\WebContent\\WEB-INF\\classes");
		Class cls = fileClsLoader.loadClass("com.cmw.entity.sys.AccordionEntity");
//		Object obj = cls.newInstance();
		Description des = (Description)cls.getAnnotation(Description.class);
		System.out.println(des.remark()+" , "+des.author()+" , "+des.createDate());
		return SUCCESS;
	}
	
	/**
	 * 获取包列表
	 * @return
	 * @throws Exception
	 */
	public String list()throws Exception {
		fileClsLoader.setClassPath("E:\\j2ee_proj\\skythink\\WebContent\\WEB-INF\\classes");
		Class cls = fileClsLoader.loadClass("com.cmw.entity.sys.AccordionEntity");
//		Object obj = cls.newInstance();
		Description des = (Description)cls.getAnnotation(Description.class);
		Table tab = (Table)cls.getAnnotation(Table.class);
		System.out.println(des.remark()+" , "+des.author()+" , "+des.createDate()+",tab.name="+tab.name());
		return SUCCESS;
	}
}
