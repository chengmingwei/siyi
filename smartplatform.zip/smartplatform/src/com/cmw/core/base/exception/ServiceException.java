package com.cmw.core.base.exception;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.cmw.core.kit.file.FileUtil;
import com.cmw.core.util.DateUtil;
import com.cmw.core.util.StringHandler;
import com.cmw.core.util.SystemUtils;
import com.cmw.entity.sys.UserEntity;

public class ServiceException extends RuntimeException{
	static Logger logger = Logger.getLogger(ServiceException.class);
	private static Map<String,String> i18nMap = new HashMap<String, String>();
	private static Map<String,Object[]> argsMap = new HashMap<String, Object[]>();
	
	public ServiceException() {
		super();
	}

	public ServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public ServiceException(String message) {
		super(message);
		printStackTrace();
	}

	public ServiceException(UserEntity user,String message,Object... args) {
		super(message);
		String i18n = (null == user || !StringHandler.isValidStr(user.getI18n())) ? UserEntity.I18N_ZH_CN : user.getI18n();
		i18nMap.put(message, i18n);
		argsMap.put(message, args);
		printStackTrace();
	}

	
	public ServiceException(Throwable cause) {
		super(cause);
		printStackTrace();
	}

	@Override
	public void printStackTrace() {
		super.printStackTrace();
		StringBuilder sbMsg = new StringBuilder();
		String msg = this.getMessage();
		sbMsg.append("Error : "+msg +"\n");
		StackTraceElement[] stackArr = this.getStackTrace();
		if(null != stackArr && stackArr.length > 0){
			for(StackTraceElement stack : stackArr){
				String emsg = stack.toString();
				sbMsg.append("\tat "+emsg+"\n");
			}
		}
		
		String exeTrace = sbMsg.toString();
		writeLogFile(exeTrace);
	}
	
	/**
	 * 将异常信息写入 classes/logs 目录下
	 * @param exeTrace
	 */
	private void writeLogFile(String exeTrace){
		String classesPath = StringHandler.getClassPath();
		if(!SystemUtils.isWindows()) classesPath = File.separator + classesPath;
		Date today = new Date();
		String monthDir = DateUtil.dateFormatToStr(DateUtil.DATE_YYYYMM_FORMAT, today);
		boolean isexist = false;
		String logsDir = classesPath+"logs";
		isexist = FileUtil.exist(logsDir);
		if(!isexist) FileUtil.creatDictory(logsDir);
		
		monthDir = logsDir+File.separator+monthDir;
		isexist = FileUtil.exist(monthDir);
		if(!isexist) FileUtil.creatDictory(monthDir);
		/*以 年月日时分秒作为文件名，Windows 系统下面的文件名中不能有 空格 和 “：”号非法字符*/
		String fileName = DateUtil.dateFormatToStr(DateUtil.DATE_TIME_FORMAT, today).replace(" ", "_").replace(":", "_")+".log";
		String absFileName = monthDir + File.separator+fileName;
		FileUtil.writeStrToFile(absFileName, exeTrace);
	}
	
	/**
	 * 指 message_*.properties 中的字符串
	 * 根据资源键获取资源文件中字符串所需的参数数组
	 * @param key	资源键
	 * @param isRemove
	 * @return
	 */
	public static Map<String,Object[]> getArgsByKey(String key,boolean isRemove) {
		if(!StringHandler.isValidStr(key)) return null;
		Object[] arg = argsMap.get(key);
		if(null != arg){
			String i18n = i18nMap.get(key);
			Map<String,Object[]> map = new HashMap<String, Object[]>();
			map.put(i18n, arg);
			if(isRemove){
				argsMap.remove(key);
				i18nMap.remove(key);
			}
			return map;
		}
		return null;
	}
	/**
	 * 没有系统id
	 */
	public static final String NO_SYSID_ERROR = "no.sysid.error";
	/**
	 * 没有系统id
	 */
	public static final String NO_NAME_ERROR = "no.name.error";
	/**
	 * 流程文件格式错误
	 */
	public static final String PROCESS_FILES_ERROR = "process.files.error";
	
	/**
	 * 流程部署失败
	 */
	public static final String PROCESS_DEPLOYMENT_FAILURE = "process.deployment.failure";
	/**
	 * 为空
	 */
	public static final String USER_IS_NULL = "user.is.null";
	/**
	 *没有添加借款合同
	 */
	public static final String LOANCONTRACT_IS_NULL = "LoanContract.failure";
	
	/**
	 * 没有业务品种
	 */
	public static final String BREED_IS_NULL = "no.bree.error";
	/**
	 * 客户类型不能为空的
	 */
	public static final String CUSTTYPE_IS_NULL = "custType.bree.error";
	/**
	 * ID 为空
	 */
	public static final String ID_IS_NULL = "id.is.null";
	/**
	 * code 为空
	 */
	public static final String CODE_IS_NULL = "code.is.null";
	/**
	 * 岗位ID 为空
	 */
	public static final String POSTID_IS_NULL = "postid.is.null";
	/**
	 * IDS 为空
	 */
	public static final String IDS_IS_NULL = "ids.is.null";

	/**
	 *  资源ID为空
	 */
	public static final String RESTYPEID_IS_NULL = "restypeid.is.null";
	
	/****
	 * ID为空
	 */
	public static final String CTYPE_IS_NULL = "ctype.is.null";
	
	/**
	 * 获取数据失败
	 * 
	 */
	public static final String DATA_GET_FAILURE = "data.get.failure";
	
	/**
	 * 分页查询的第一条记录索引 为空或0
	 */
	public static final String OFFSET_INDEX_IS_NULL = "offset.index.is.null";
	/**
	 * 过滤参数为空
	 */
	public static final String FILTER_PARAMS_NULL = "filter.params.null";
	/**
	 * 查询参数为空
	 */
	public static final String QUERY_PARAMS_NULL = "query.params.null";
	
	/**
	 * 查询的数据为空
	 */
	public static final String QUERY_DATA_IS_NULL = "query.data.is.null";
	
	/**
	 * 查询的指定对象为空
	 */
	public static final String QUERY_THE_OBJECT_IS_NULL = "query.the.object.is.null";
	
	
	/**
	 * 持久化对象为空
	 */
	public static final String OBJECT_IS_NULL = "object.is.null";
	/**
	 * 对象保存失败
	 */
	public static final String OBJECT_SAVE_FAILURE = "object.save.failure";
	/**
	 * 对象批量保存失败
	 */
	public static final String OBJECT_BATCH_SAVE_FAILURE = "object.batch.save.failure";
	/**
	 * 对象更新失败
	 */
	public static final String OBJECT_UPDATE_FAILURE = "object.update.failure";
	/**
	 * 对象批量更新失败
	 */
	public static final String OBJECT_BATCH_UPDATE_FAILURE = "object.batch.update.failure";
	/**
	 * 对象保存或更新失败
	 */
	public static final String OBJECT_SAVEORUPDATE_FAILURE = "object.saveorupdate.failure";
	/**
	 * 对象批量保存或更新失败
	 */
	public static final String OBJECT_BATCH_SAVEORUPDATE_FAILURE = "object.batch.saveorupdate.failure";
	/**
	 * 对象删除失败
	 */
	public static final String OBJECT_DELETE_FAILURE = "object.delete.failure";
	
	/**
	 * 对象禁用失败
	 */
	public static final String OBJECT_ENABLED_FAILURE = "object.enabled.failure";
	/**
	 * 获取总记录数失败
	 */
	public static final String OBJECT_TOTAL_FAILURE = "object.total.failure";
	/**
	 * 获取最大的ID失败
	 */
	public static final String OBJECT_MAXID_FAILURE = "object.maxid.failure";
	/**
	 * isenabled 的值为空
	 */
	public static final String ISENABLED_IS_NULL = "isenabled.value.null";

}