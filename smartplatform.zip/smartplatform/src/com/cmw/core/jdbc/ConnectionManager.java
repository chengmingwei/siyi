package com.cmw.core.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cmw.core.util.SHashMap;
import com.cmw.core.util.StringHandler;


/**
 *	连接池对象管理类 
 * @author chenjin
 *
 */
public class ConnectionManager {
	
	/**
	 * 获取数据库连接
	 * @param pars
	 * 	 [url:"jdbc:mysql://127.0.0.1/student",
	 * 	  driverName : "com.mysql.jdbc.Driver",
	 * 	  user : "root",
	 * 	  password : "root"
	 *   ]
	 * @return
	 */
	public Connection getConnection(SHashMap<String, Object> pars){
		Connection conn = null;
		String url = pars.getvalAsStr("url"); 
		String driverName = pars.getvalAsStr("driverName");
		if(!StringHandler.isValidStr(driverName)) driverName = "com.mysql.jdbc.Driver";
		String user = pars.getvalAsStr("user"); 
		String password = pars.getvalAsStr("password");
		
		try {
			Class.forName(driverName);
			try {
				Properties props =new Properties();
				props.setProperty("user", user);
		        props.setProperty("password", password);
		        props.setProperty("remarks", "true"); //设置可以获取remarks信息 
		        props.setProperty("useInformationSchema", "true");//设置可以获取tables remarks信息
		        conn = DriverManager.getConnection(url, props);
//				conn = DriverManager.getConnection(url, user, password);
			} catch (SQLException e) {
				e.printStackTrace();
			}//获取连接  
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	/**
	 * 获取工厂实例
	 * 
	 * @return PlanFactory 对象
	 */
	public static ConnectionManager getInstance() {
		return LazyHolder.INSTANCE;
	}

	private static final class LazyHolder {
		private static final ConnectionManager INSTANCE = new ConnectionManager();
	}

}
