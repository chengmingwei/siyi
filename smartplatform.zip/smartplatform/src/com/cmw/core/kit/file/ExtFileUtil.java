package com.cmw.core.kit.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.cmw.core.util.StringHandler;

public class ExtFileUtil extends FileUtil {
	
	static Map<String,FileGatherModel> fgatherMap = new HashMap<String, FileGatherModel>();
	
	/**
	 * 获取指定文件的数量
	 * @param f 文件对象
	 * @return 返回文件目录下的数量
	 */
	public static long getlist(File f){//递归求取目录文件个数
        long size = 0;
        File flist[] = f.listFiles();
        size=flist.length;
        for (int i = 0; i < flist.length; i++) {
            if (flist[i].isDirectory()) {
                size = size + getlist(flist[i]);
                size--;
            }
        }
        return size;
    }
	
	/**
	 * 获取指定文件的数量
	 * @param filePath 文件路径
	 * @return	返回文件目录下的数量
	 */
	public static long getlist(String filePath){
		return getlist(new File(filePath));
	}
	
	/** 
	* 复制单个文件 
	* @param oldPath String 原文件路径 如：c:/fqf.txt 
	* @param newPath String 复制后路径 如：f:/fqf.txt 
	* @return boolean 
	*/ 
	public static void copyFile(String oldPath, String newPath) { 
		try { 
			int bytesum = 0; 
			int byteread = 0; 
			File oldfile = new File(oldPath); 
			if (oldfile.exists()) { //文件存在时 
				InputStream inStream = new FileInputStream(oldPath); //读入原文件 
				FileOutputStream fs = new FileOutputStream(newPath); 
				byte[] buffer = new byte[1444]; 
				while ( (byteread = inStream.read(buffer)) != -1) { 
				bytesum += byteread; //字节数 文件大小 
				System.out.println(bytesum); 
				fs.write(buffer, 0, byteread); 
				} 
				inStream.close(); 
				if(null != fs) fs.close();
			} 
		}catch (Exception e) { 
			System.out.println("复制单个文件操作出错"); 
			e.printStackTrace(); 
		} 
	}
	
	/**
	 * 移除文件统计Model
	 * @param uuid
	 */
	public static void removeFileGather(String uuid){
		if(fgatherMap.containsKey(uuid)) fgatherMap.remove(uuid);
	}
	
	/**
	 * 获取文件进度
	 * @param uuid
	 * @return
	 */
	public static FileGatherModel getProgess(String uuid){
		return fgatherMap.get(uuid);
	}

	/** 
	* 复制整个文件夹内容 
	* @param oldPath String 原文件路径 如：c:/fqf 
	* @param newPath String 复制后路径 如：f:/fqf/ff 
	* @return boolean 
	*/ 
	public static void copyFolder(String uuid ,String oldPath, String newPath) { 
		try { 
			(new File(newPath)).mkdirs(); //如果文件夹不存在 则建立新文件夹 
			File a=new File(oldPath); 
			String[] file=a.list(); 
			if(null == file || file.length == 0) return;
			if(StringHandler.isValidStr(uuid) && !fgatherMap.containsKey(uuid)){
				FileGatherModel model = new FileGatherModel();
				long totalCount = getlist(oldPath);
				model.setTotalCount(totalCount);
				fgatherMap.put(uuid, model);
			}
		
			File temp=null; 
			for (int i = 0; i < file.length; i++) { 
				if(oldPath.endsWith(File.separator)){ 
					temp=new File(oldPath+file[i]); 
				}else{ 
					temp=new File(oldPath+File.separator+file[i]); 
				} 
				
				
				if(temp.isFile()){
					FileInputStream input = new FileInputStream(temp); 
					FileOutputStream output = new FileOutputStream(newPath + "/" + 
					(temp.getName()).toString()); 
					byte[] b = new byte[1024 * 5]; 
					int len; 
					while ( (len = input.read(b)) != -1) { 
						output.write(b, 0, len); 
					}
					output.flush(); 
					output.close(); 
					input.close();
					
					FileGatherModel gatherModel = fgatherMap.get(uuid);
					if(null != gatherModel){
						long currNum = gatherModel.getCurrNum();
						currNum++;
						gatherModel.setCurrNum(currNum);
						fgatherMap.put(uuid, gatherModel);
					}
				//	System.out.println("fileName="+temp.getName()+",currNum="+gatherModel.getCurrNum()+",uuid="+uuid);
				} 
				if(temp.isDirectory()){//如果是子文件夹 
					copyFolder(uuid,oldPath+"/"+file[i],newPath+"/"+file[i]); 
				}
			} 
		} catch (Exception e) { 
			System.out.println("复制整个文件夹内容操作出错"); 
			e.printStackTrace(); 
		}
	}
	
	/** 
	* 复制整个文件夹内容 
	* @param oldPath String 原文件路径 如：c:/fqf 
	* @param newPath String 复制后路径 如：f:/fqf/ff 
	* @return boolean 
	*/ 
	public static void copyFolder(String oldPath, String newPath) { 
		try { 
			(new File(newPath)).mkdirs(); //如果文件夹不存在 则建立新文件夹 
			File a=new File(oldPath); 
			String[] file=a.list(); 
			File temp=null; 
			for (int i = 0; i < file.length; i++) { 
				if(oldPath.endsWith(File.separator)){ 
					temp=new File(oldPath+file[i]); 
				}else{ 
					temp=new File(oldPath+File.separator+file[i]); 
				} 
			
				if(temp.isFile()){
					FileInputStream input = new FileInputStream(temp); 
					FileOutputStream output = new FileOutputStream(newPath + "/" + 
					(temp.getName()).toString()); 
					byte[] b = new byte[1024 * 5]; 
					int len; 
					while ( (len = input.read(b)) != -1) { 
						output.write(b, 0, len); 
					} 
					output.flush(); 
					output.close(); 
					input.close(); 
				} 
				if(temp.isDirectory()){//如果是子文件夹 
					copyFolder(oldPath+"/"+file[i],newPath+"/"+file[i]); 
				}
			} 
		} catch (Exception e) { 
			System.out.println("复制整个文件夹内容操作出错"); 
			e.printStackTrace(); 
		}
	}
	
	/**
	 * 文件信息统计
	 * @author Administrator
	 *
	 */
	@SuppressWarnings("serial")
	public static class FileGatherModel implements Serializable{
		//总文件数量
		private long totalCount = 0;
		//当前读取的文件
		private long currNum = 0;
		//当前百分比
		private int currPrecent; //当前百分比
		
		
		/**
		 * 获取总文件数量
		 * @return	返回总文件数量
		 */
		public long getTotalCount() {
			return totalCount;
		}

		/**
		 * 设置总文件数量
		 * @param totalCount	总文件数量
		 */
		public void setTotalCount(long totalCount) {
			this.totalCount = totalCount;
		}

		/**
		 * 获取当前读取的文件数量
		 * @return	返回当前读取的文件
		 */
		public long getCurrNum() {
			return currNum;
		}

		/**
		 * 设置当前读取的文件数量
		 * @param currNum	当前读取的文件数量
		 */
		public void setCurrNum(long currNum) {
			this.currNum = currNum;
		}

		/**
		 * 获取当前百分比
		 * @return	返回当前百分比
		 */
		public int getCurrPrecent() {
			currPrecent = (int)(currNum/totalCount);
			return currPrecent*100;
		}
		
	}
	
}
