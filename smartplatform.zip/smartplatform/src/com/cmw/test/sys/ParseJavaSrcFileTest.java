package com.cmw.test.sys;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ParseJavaSrcFileTest {

	private static final String PATH = "E://j2ee_proj//skythink//src//com//cmw//entity//sys//AccordionEntity.java";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String content = readContent();
		System.out.println("------------------------- START  ------------------------");
		System.out.println(content);
		
		System.out.println("----------------------- END --------------------------");
	}
	
	private static String readContent(){
		StringBuffer content = new StringBuffer();
		File file = new File(PATH);
		try {
			BufferedReader breader = new BufferedReader(new FileReader(file));
			String data = null;
			while((data = breader.readLine()) != null){
				content.append(data+"\n");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		return content.toString();
	}
	
	
}
