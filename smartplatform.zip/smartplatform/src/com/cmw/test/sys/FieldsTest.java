package com.cmw.test.sys;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.test.AbstractTestCase;
import com.cmw.entity.sys.FieldsEntity;
import com.cmw.service.inter.sys.FieldsService;
/**
 * 项目包测试
 * @author chengmingwei
 *
 */
public class FieldsTest extends AbstractTestCase {
	@Autowired
	private FieldsService fieldsService;
	@Test
	public void testSave() throws ServiceException{
		FieldsEntity field = new FieldsEntity();
		field.setSrcId(2L);
		field.setFieldName("code");
		field.setColName("code");
		field.setDataType("String");
		field.setSqltype("varchar");
		field.setBind("唯一");
		fieldsService.saveEntity(field);
	}
	
}
