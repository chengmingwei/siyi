package com.cmw.test.sys;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.test.AbstractTestCase;
import com.cmw.service.inter.sys.ProjectService;

public class ProjectTest extends AbstractTestCase {
	@Autowired
	private ProjectService projectService;
//	@Test
//	public void testSave() throws ServiceException{
//		ProjectEntity entity = new ProjectEntity();
//		entity.setId(1l);
//		entity.setDesc("ddd");
//		projectService.saveEntity(entity);
//	}
	
	@Test
	public void testgetResultList() throws ServiceException{
		//获取卡片项的ID，并将其作为 父ID
//		SHashMap<String, Object> map = new SHashMap<String, Object>();
//		DataTable dt = projectService.getResultList(map);
//		System.out.println(dt.getJsonArr());
	}
	
}
