package com.cmw.example.chat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.directwebremoting.ScriptSession;
import org.directwebremoting.ServerContextFactory;
import org.directwebremoting.WebContextFactory;

/**
 * 聊天管理类
 * @author Administrator
 *
 */
public class ChatManager {
	/**
	 * 保存当前在线用户
	 */
	public static List<User> users = new ArrayList<User>();
	
	/**
	 * 更新用户列表
	 * @param username	待添加到列表的用户名
	 * @param flag	是添加到用户列表，还是只获得当前列表
	 * @param request
	 * @return
	 */
	public String updateUsersList(String username,boolean flag,HttpServletRequest request){
		
		return null;
	}
	
	/**
	 * 将用户ID和页面脚本 session 绑定
	 * @param userid
	 */
	public void setScriptSessionFlag(String userid){
		WebContextFactory.get().getScriptSession().setAttribute("userid", userid);
	}
	
	/**
	 * 根据用户ID获得指定用户的页面脚本 Session
	 * @param userid
	 * @param request
	 * @return
	 */
	public ScriptSession getScriptSession(String userid,HttpServletRequest request){
		ScriptSession scriptSession = null;
		Collection<ScriptSession> sessions = new HashSet<ScriptSession>();
		sessions.addAll(ServerContextFactory.get(request.getSession().getServletContext()).getScriptSessionsByPage("/example/chat/chat.jsp"));
		for(ScriptSession session : sessions){
			String xuserid = (String)session.getAttribute("userid");
		}
		return scriptSession;
	}
	
	/**
	 * 发送消息
	 * @param sender	发送者
	 * @param receiverid	接收者
	 * @param msg	消息内容
	 * @param request	请求对象
	 */
	public void send(String sender,String receiverid,String msg,HttpServletRequest request){
		
	}
}
