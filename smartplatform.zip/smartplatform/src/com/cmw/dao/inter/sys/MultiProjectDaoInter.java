package com.cmw.dao.inter.sys;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.entity.sys.MultiProjectEntity;

/**
 *  多模块项目DAO接口
 * @author cmw_1984122
 * @date 2017-05-28	15:31
 */
public interface MultiProjectDaoInter extends GenericDaoInter<MultiProjectEntity, Long>{
}
