package com.cmw.dao.inter.sys;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.entity.sys.FieldsEntity;

/**
 *  字段管理DAO接口
 * @author cmw_1984122
 *
 */
public interface FieldsDaoInter  extends GenericDaoInter<FieldsEntity, Long>{

}
