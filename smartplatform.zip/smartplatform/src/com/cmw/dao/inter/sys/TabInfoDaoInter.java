package com.cmw.dao.inter.sys;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.entity.sys.TabInfoEntity;

/**
 *  数据库表信息 DAO接口
 * @author chengmingwei
 * @date 2017-08-11 17:17
 *
 */
public interface TabInfoDaoInter  extends GenericDaoInter<TabInfoEntity, Long>{

}
