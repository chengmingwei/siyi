package com.cmw.dao.inter.sys;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.exception.DaoException;
import com.cmw.core.util.DataTable;
import com.cmw.entity.sys.PackageEntity;

/**
 *  包DAO接口
 * @author cmw_1984122
 *
 */
public interface PackageDaoInter extends GenericDaoInter<PackageEntity, Long>{
	
	/**
	 * 根据项目ID获取包数据
	 * @param projectId
	 * @return
	 */
	DataTable getDataSource(Long projectId) throws DaoException;
}
