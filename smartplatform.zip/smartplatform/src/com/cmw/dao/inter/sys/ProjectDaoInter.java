package com.cmw.dao.inter.sys;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.core.base.exception.DaoException;
import com.cmw.core.util.DataTable;
import com.cmw.entity.sys.ProjectEntity;

/**
 *  项目DAO接口
 * @author cmw_1984122
 *
 */
public interface ProjectDaoInter extends GenericDaoInter<ProjectEntity, Long>{
	/**
	 * 获取下拉框数据源
	 * @return
	 * @throws DaoException
	 */
	DataTable getDataSource() throws DaoException;
}
