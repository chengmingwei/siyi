package com.cmw.dao.inter.sys;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.entity.sys.ClassInfoEntity;

/**
 *  类附加信息 DAO接口
 * @author cmw_1984122
 *
 */
public interface ClassInfoDaoInter  extends GenericDaoInter<ClassInfoEntity, Long>{

}
