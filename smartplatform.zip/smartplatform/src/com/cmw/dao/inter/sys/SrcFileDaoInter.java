package com.cmw.dao.inter.sys;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.entity.sys.SrcFileEntity;

/**
 *  源文件管理DAO接口
 * @author cmw_1984122
 *
 */
public interface SrcFileDaoInter  extends GenericDaoInter<SrcFileEntity, Long>{

}
