package com.cmw.dao.inter.sys;

import com.cmw.core.base.dao.GenericDaoInter;
import com.cmw.entity.sys.TabCmnsEntity;

/**
 *  表列信息 DAO接口
 * @author chengmingwei
 * @date 2017-08-11 17:17
 *
 */
public interface TabCmnsDaoInter  extends GenericDaoInter<TabCmnsEntity, Long>{

}
