package com.cmw.dao.impl.sys;

import org.springframework.stereotype.Repository;

import com.cmw.core.base.dao.GenericDaoAbs;
import com.cmw.core.base.exception.DaoException;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.SHashMap;
import com.cmw.dao.inter.sys.TabInfoDaoInter;
import com.cmw.entity.sys.TabInfoEntity;
/**
 *  类附加信息 DAO 实现类
 * @author chengmingwei
 * @date 2017-08-11 17:17
 */
@Repository("tabInfoDao")
public class TabInfoDaoImpl extends GenericDaoAbs<TabInfoEntity, Long> implements TabInfoDaoInter {

	@Override
	public <K, V> DataTable getResultList(SHashMap<K, V> map)
			throws DaoException {
		Long projectId = map.getvalAsLng("projectId");
		if(null == projectId) projectId = -1L;
		StringBuilder sbSql = new StringBuilder();
		sbSql.append("select concat('T',cast(A.id as CHAR)) as id,")
		.append("concat('M',CAST(A.projectId AS CHAR)) as pid,")
		.append("concat(A.name,'[',A.remark,']') as text, 'true' as leaf, '1' as type,'false' as checked ")
		.append(" from ts_TabInfo as A where A.projectId='"+projectId+"'");
		DataTable dt = findBySql(sbSql.toString());
		dt.setColumnNames("id,pid,text,leaf,type,checked");
		return dt;
	}
	
}
