package com.cmw.dao.impl.sys;

import org.springframework.stereotype.Repository;

import com.cmw.constant.SysConstant;
import com.cmw.core.base.dao.GenericDaoAbs;
import com.cmw.core.base.exception.DaoException;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.StringHandler;
import com.cmw.dao.inter.sys.SrcFileDaoInter;
import com.cmw.entity.sys.SrcFileEntity;
/**
 *  源文件实现类
 * @author cmw_1984122
 *
 */
@Repository("srcfileDao")
public class SrcFileDaoImpl extends GenericDaoAbs<SrcFileEntity, Long> implements SrcFileDaoInter {
	public <K, V> DataTable getResultList(SHashMap<K, V> map)
			throws DaoException {
		String projectIds = map.getvalAsStr("projectIds");
		if(!StringHandler.isValidStr(projectIds)) return super.getResultList(map);
		Integer multi = map.getvalAsInt("multi");
		String hql = null;
		String cmns = "id,pid,text,icon,leaf,src,projectId,type,remark";
		if(null != multi && multi.intValue() == 1){//多模块项目
			hql = "select concat('S',cast(A.id as CHAR)) as id," +
					"concat('P',CAST(A.projectId AS CHAR)) as pid," +
					" concat(A.name,'[',A.description,']') as text,(case when A.type="+SysConstant.PACK_PAGE+" then '"+
					SysConstant.ICONS_JS+"' else '"+SysConstant.ICONS_JAVA+"' end) as icon," +
					" 'true' as leaf, A.path as src,A.projectId,"+
					"(case when A.type=1 then "+SysConstant.INTER_DAO+" else A.type end) as type," +
					" A.remark,'false' as checked from ts_srcfile A where A.type=0 and A.projectId in ("+projectIds+")";
			cmns += ",checked";
		}else{
			hql = "select concat('S',cast(A.id as CHAR)) as id," +
					"concat('P',A.parentId) as pid," +
					" A.name as text,(case when A.type="+SysConstant.PACK_PAGE+" then '"+
					SysConstant.ICONS_JS+"' else '"+SysConstant.ICONS_JAVA+"' end) as icon," +
					" 'true' as leaf, A.path as src,A.projectId,"+
					"(case when A.type=1 then "+SysConstant.INTER_DAO+" else A.type end) as type," +
					" A.remark from ts_srcfile A where A.projectId in ("+projectIds+")";
		}
		DataTable dt = findBySql(hql);
		dt.setColumnNames(cmns);
		return dt;
	}
}
