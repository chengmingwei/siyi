package com.cmw.dao.impl.sys;

import org.springframework.stereotype.Repository;

import com.cmw.core.base.dao.GenericDaoAbs;
import com.cmw.dao.inter.sys.MultiProjectDaoInter;
import com.cmw.entity.sys.MultiProjectEntity;
/**
 *  项目DAO实现类
 * @author cmw_1984122
 *
 */
@Repository("multiProjectDao")
public class MultiProjectDaoImpl extends GenericDaoAbs<MultiProjectEntity, Long> implements MultiProjectDaoInter {

}
