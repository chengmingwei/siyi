package com.cmw.dao.impl.sys;

import org.springframework.stereotype.Repository;

import com.cmw.core.base.dao.GenericDaoAbs;
import com.cmw.dao.inter.sys.ClassInfoDaoInter;
import com.cmw.entity.sys.ClassInfoEntity;
/**
 *  类附加信息 DAO 实现类
 * @author chengmingwei
 * @date 2017-08-11 17:17
 */
@Repository("classInfoDao")
public class ClassInfoDaoImpl extends GenericDaoAbs<ClassInfoEntity, Long> implements ClassInfoDaoInter {

}
