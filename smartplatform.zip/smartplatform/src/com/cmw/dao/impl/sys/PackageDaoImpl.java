package com.cmw.dao.impl.sys;

import org.springframework.stereotype.Repository;

import com.cmw.constant.SysConstant;
import com.cmw.core.base.dao.GenericDaoAbs;
import com.cmw.core.base.exception.DaoException;
import com.cmw.core.util.DataTable;
import com.cmw.core.util.SHashMap;
import com.cmw.core.util.StringHandler;
import com.cmw.dao.inter.sys.PackageDaoInter;
import com.cmw.entity.sys.PackageEntity;
/**
 *  包DAO实现类
 * @author cmw_1984122
 *
 */
@Repository("packageDao")
public class PackageDaoImpl extends GenericDaoAbs<PackageEntity, Long> implements PackageDaoInter {

	public <K, V> DataTable getResultList(SHashMap<K, V> map)
			throws DaoException {
		String projectIds = map.getvalAsStr("projectIds");
		if(!StringHandler.isValidStr(projectIds)) return super.getResultList(map);
		String hql = "select concat('P',cast(A.id as CHAR)) as id," +
				"(case when A.parentId is null then concat(cast(A.projectId as CHAR),'_',cast(A.type as CHAR))" +
				" when locate('_',A.parentId)>0 then A.parentId " +
				" else concat('P',cast(A.parentId as CHAR)) end) as pid," +
				" A.name as text,(case when A.type="+SysConstant.PACK_PAGE+" then '"+
				SysConstant.ICONS_WEB+"' when A.type=5 then '"+SysConstant.ICONS_UI+"' else '"+SysConstant.ICONS_PACKAGE+"' end) as icon," +
				" 'false' as leaf," +
				" A.introduction as src,A.projectId," +
				"(case when A.type=1 then "+SysConstant.INTER_DAO+" else A.type end) as type," +
				"A.remark from ts_package A where A.projectId in ("+projectIds+")";
		DataTable dt = findBySql(hql);
		dt.setColumnNames("id,pid,text,icon,leaf,src,projectId,type,remark");
		return dt;
	}

	@Override
	public DataTable getDataSource(Long projectId) throws DaoException {
		try{
			String sql = "select DISTINCT name as id,name from ts_package where projectId='"+projectId+"'";
			DataTable dt = findBySql(sql);
			dt.setColumnNames("id,name");
			return dt;
		}catch(Exception ex){
			throw new DaoException(ex);
		}
	
	}
	
	
}
