package com.cmw.dao.impl.sys;

import org.springframework.stereotype.Repository;

import com.cmw.core.base.dao.GenericDaoAbs;
import com.cmw.dao.inter.sys.TabCmnsDaoInter;
import com.cmw.entity.sys.TabCmnsEntity;
/**
 *  表列信息  DAO 实现类
 * @author chengmingwei
 * @date 2017-08-11 17:17
 */
@Repository("tabCmnsDao")
public class TabCmnsDaoImpl extends GenericDaoAbs<TabCmnsEntity, Long> implements TabCmnsDaoInter {

}
