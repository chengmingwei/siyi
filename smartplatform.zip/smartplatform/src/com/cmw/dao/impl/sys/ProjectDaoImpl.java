package com.cmw.dao.impl.sys;

import org.springframework.stereotype.Repository;

import com.cmw.core.base.dao.GenericDaoAbs;
import com.cmw.core.base.exception.DaoException;
import com.cmw.core.util.DataTable;
import com.cmw.dao.inter.sys.ProjectDaoInter;
import com.cmw.entity.sys.ProjectEntity;
/**
 *  项目DAO实现类
 * @author cmw_1984122
 *
 */
@Repository("projectDao")
public class ProjectDaoImpl extends GenericDaoAbs<ProjectEntity, Long> implements ProjectDaoInter {
	
	@Override
	public DataTable getDataSource() throws DaoException{
		try{
			StringBuilder sbSql = new StringBuilder();
			sbSql.append("select id,introduction as name from ts_project where state=1");
			return findBySql(sbSql.toString(), "id,name");
		}catch(Exception ex){
			throw new DaoException(ex);
		}
	}
}
