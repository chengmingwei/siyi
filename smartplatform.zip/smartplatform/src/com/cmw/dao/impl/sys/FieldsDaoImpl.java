package com.cmw.dao.impl.sys;

import org.springframework.stereotype.Repository;

import com.cmw.core.base.dao.GenericDaoAbs;
import com.cmw.dao.inter.sys.FieldsDaoInter;
import com.cmw.entity.sys.FieldsEntity;
/**
 *  字段实现类
 * @author cmw_1984122
 *
 */
@Repository("fieldsDao")
public class FieldsDaoImpl extends GenericDaoAbs<FieldsEntity, Long> implements FieldsDaoInter {

}
