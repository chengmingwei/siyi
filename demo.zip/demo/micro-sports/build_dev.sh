#!/usr/bin/env bash
#编译打包
mvn clean package -Dmaven.test.skip=true -U
#删除上次的镜像
docker rmi hub.c.163.com/chengmingwei/springcloud/micro-sports:dev

#编译成Docker 镜像文件
docker build -t hub.c.163.com/springcloud/micro-sports:dev .
#设置在线镜像TAG 标签
docker tag hub.c.163.com/springcloud/micro-sports:dev hub.c.163.com/chengmingwei/springcloud/micro-sports:dev
# PUSH 到 网易镜像中心
docker push hub.c.163.com/chengmingwei/springcloud/micro-sports:dev

docker rmi hub.c.163.com/springcloud/micro-sports:dev
docker rmi hub.c.163.com/chengmingwei/springcloud/micro-sports:dev
