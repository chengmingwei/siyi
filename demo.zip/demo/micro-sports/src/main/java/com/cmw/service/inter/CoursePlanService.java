package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.CoursePlanEntity;


/**
 * 教学计划  Service接口
 * @author 程明卫
 * @date 2019-04-10 14:01:31
 */
@Description(remark="教学计划业务接口",createDate="2019-04-10 14:01:31",author="程明卫")
public interface CoursePlanService extends IService<CoursePlanEntity, Long> {
}
