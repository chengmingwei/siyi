package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.CommentEntity;

import java.util.List;
import java.util.Map;


/**
 * 评论表  Service接口
 * @author 程明卫
 * @date 2019-04-20 13:35:01
 */
@Description(remark="评论表业务接口",createDate="2019-04-20 13:35:01",author="程明卫")
public interface CommentService extends IService<CommentEntity, Long> {

    /**
     * 获取评论
     * @Author 肖家添
     * @Date 2019/7/4 4:39 PM
     */
    List<Map<String, Object>> getCommentByPars(Map<String, Object> params);
    
}
