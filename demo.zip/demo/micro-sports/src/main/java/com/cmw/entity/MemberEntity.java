package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 会员信息
 *
 * @author 程明卫
 * @date 2019-04-10 22:07:38
 */
@Description(remark = "会员信息实体", createDate = "2019-04-10 22:07:38", author = "程明卫")
@Entity
@Table(name = "GL_Member")
@SuppressWarnings("serial")
public class MemberEntity extends IdBaseEntity {

    @Description(remark = "微信openid")
    @Column(name = "openid", length = 50)
    private String openid;

    @Description(remark = "历史记录ID")
    @Column(name = "historyId", length = 50)
    private String historyId;

    @Description(remark = "会员类型")
    @Column(name = "mtype", nullable = false)
    private Integer mtype = 1;

    @Description(remark = "用户头像")
    @Column(name = "imgPath", length = 150)
    private String imgPath;

    @Description(remark = "会员等级")
    @Column(name = "mlevel", nullable = false)
    private Long mlevel = 0L;

    @Description(remark = "手机是否验证")
    @Column(name = "phonePass")
    private Byte phonePass = 0;

    @Description(remark = "邮箱是否验证")
    @Column(name = "emailPass")
    private Byte emailPass = 0;

    @Description(remark = "身份证是否验证")
    @Column(name = "cardnoPass")
    private Byte cardnoPass = 0;

    @Description(remark = "手机")
    @Column(name = "phone", length = 50)
    private String phone;

    @Description(remark = "邮箱")
    @Column(name = "email", length = 50)
    private String email;

    @Description(remark = "身份证号码")
    @Column(name = "cardno", length = 20)
    private String cardno;

    @Description(remark = "会员姓名")
    @Column(name = "rname", length = 50)
    private String rname;

    @Description(remark = "密码")
    @Column(name = "pwd", nullable = false, length = 100)
    private String pwd;

    @Description(remark = "用户名")
    @Column(name = "account", nullable = false, length = 50)
    private String account;

    public MemberEntity() {

    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    /**
     * 设置历史记录ID的值
     *
     * @param historyId 历史记录ID
     **/
    public void setHistoryId(String historyId) {
        this.historyId = historyId;
    }

    /**
     * 获取历史记录ID的值
     *
     * @return 返回历史记录ID的值
     **/
    public String getHistoryId() {
        return historyId;
    }

    /**
     * 设置会员类型的值
     *
     * @param mtype 会员类型
     **/
    public void setMtype(Integer mtype) {
        this.mtype = mtype;
    }

    /**
     * 获取会员类型的值
     *
     * @return 返回会员类型的值
     **/
    public Integer getMtype() {
        return mtype;
    }

    /**
     * 设置用户头像的值
     *
     * @param imgPath 用户头像
     **/
    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }

    /**
     * 获取用户头像的值
     *
     * @return 返回用户头像的值
     **/
    public String getImgPath() {
        return imgPath;
    }

    /**
     * 设置会员等级的值
     *
     * @param mlevel 会员等级
     **/
    public void setMlevel(Long mlevel) {
        this.mlevel = mlevel;
    }

    /**
     * 获取会员等级的值
     *
     * @return 返回会员等级的值
     **/
    public Long getMlevel() {
        return mlevel;
    }

    /**
     * 设置手机是否验证的值
     *
     * @param phonePass 手机是否验证
     **/
    public void setPhonePass(Byte phonePass) {
        this.phonePass = phonePass;
    }

    /**
     * 获取手机是否验证的值
     *
     * @return 返回手机是否验证的值
     **/
    public Byte getPhonePass() {
        return phonePass;
    }

    /**
     * 设置邮箱是否验证的值
     *
     * @param emailPass 邮箱是否验证
     **/
    public void setEmailPass(Byte emailPass) {
        this.emailPass = emailPass;
    }

    /**
     * 获取邮箱是否验证的值
     *
     * @return 返回邮箱是否验证的值
     **/
    public Byte getEmailPass() {
        return emailPass;
    }

    /**
     * 设置身份证是否验证的值
     *
     * @param cardnoPass 身份证是否验证
     **/
    public void setCardnoPass(Byte cardnoPass) {
        this.cardnoPass = cardnoPass;
    }

    /**
     * 获取身份证是否验证的值
     *
     * @return 返回身份证是否验证的值
     **/
    public Byte getCardnoPass() {
        return cardnoPass;
    }

    /**
     * 设置手机的值
     *
     * @param phone 手机
     **/
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * 获取手机的值
     *
     * @return 返回手机的值
     **/
    public String getPhone() {
        return phone;
    }

    /**
     * 设置邮箱的值
     *
     * @param email 邮箱
     **/
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * 获取邮箱的值
     *
     * @return 返回邮箱的值
     **/
    public String getEmail() {
        return email;
    }

    /**
     * 设置身份证号码的值
     *
     * @param cardno 身份证号码
     **/
    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    /**
     * 获取身份证号码的值
     *
     * @return 返回身份证号码的值
     **/
    public String getCardno() {
        return cardno;
    }

    /**
     * 设置会员姓名的值
     *
     * @param rname 会员姓名
     **/
    public void setRname(String rname) {
        this.rname = rname;
    }

    /**
     * 获取会员姓名的值
     *
     * @return 返回会员姓名的值
     **/
    public String getRname() {
        return rname;
    }

    /**
     * 设置密码的值
     *
     * @param pwd 密码
     **/
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    /**
     * 获取密码的值
     *
     * @return 返回密码的值
     **/
    public String getPwd() {
        return pwd;
    }

    /**
     * 设置用户名的值
     *
     * @param account 用户名
     **/
    public void setAccount(String account) {
        this.account = account;
    }

    /**
     * 获取用户名的值
     *
     * @return 返回用户名的值
     **/
    public String getAccount() {
        return account;
    }

    @Override
    public Object[] getDatas() {
        return new Object[]{historyId, mtype, imgPath, mlevel, phonePass, emailPass, cardnoPass, phone, email, cardno, rname, pwd, account};
    }

    @Override
    public String[] getFields() {
        return new String[]{"historyId", "mtype", "imgPath", "mlevel", "phonePass", "emailPass", "cardnoPass", "phone", "email", "cardno", "rname", "pwd", "account"};
    }

}
