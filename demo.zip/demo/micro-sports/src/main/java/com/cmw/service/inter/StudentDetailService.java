package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.StudentDetailEntity;


/**
 * 学员详细信息  Service接口
 * @author 程明卫
 * @date 2019-04-10 11:39:22
 */
@Description(remark="学员详细信息业务接口",createDate="2019-04-10 11:39:22",author="程明卫")
public interface StudentDetailService extends IService<StudentDetailEntity, Long> {
}
