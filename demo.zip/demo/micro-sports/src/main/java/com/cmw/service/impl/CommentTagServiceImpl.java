package com.cmw.service.impl;

import com.cmw.constant.back.BussContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.CommentTagDao;
import com.cmw.entity.CommentTagEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.CommentTagService;
import com.cmw.util.BeanUtil;
import com.cmw.util.StringHandler;
import org.apache.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 评论标签业务实现类
 * @Author 肖家添
 * @Date 2019/8/13 17:07
 */
@Description(remark="评论标签业务实现类",createDate="2019-08-13 17:06",author="肖家添")
@Service
public class CommentTagServiceImpl extends AbsService<CommentTagEntity, Long> implements CommentTagService{

    @Resource
    private CommentTagDao commentTagDao;

    @Override
    public GenericDaoInter<CommentTagEntity, Long> getDao() {
        return commentTagDao;
    }
    
    /**
     * 用户的评论标签
     * @Author 肖家添
     * @Date 2019/8/13 17:16
     */
    @Override
    @Transactional
    public List<CommentTagEntity> getCommentTagForUser(Map<String, Object> params_method) {
        UserModel userModel = LoginInterceptor.getLoginUser();

        Map<String, Object> params = new HashMap<>();

        params.put("userId", userModel.getId());

        List<CommentTagEntity> commentTags = commentTagDao.getCommentTag(params);

        if(commentTags == null || commentTags.size() <= 0){
            settingDefaultTags();
        }

        params.putAll(params_method);
        params.put("isenabled", 1);

        commentTags = commentTagDao.getCommentTag(params);

        return StringHandler.isValidObj(commentTags) ? commentTags : new ArrayList<>();
    }
    
    /**
     * 为用户新增默认标签
     * @Author 肖家添
     * @Date 2019/8/13 17:23
     */
    private void settingDefaultTags(){
        String[] masterTags = {
            "态度认真",
            "进步神速",
            "虚心好学",
            "遵守纪律",
            "活泼开朗",
            "阳光大男孩",
            "认真专注",
            "勤奋好学",
            "坚毅不屈",
            "沉稳 ",
            "有点害羞"
        };

        String[] coachTags = {
            "技巧拓荒者",
            "团队的灵魂",
            "控球魂",
            "速度之星",
            "最准之星",
            "稳步提高",
            "一日不见如隔三秋",
            "努力拼搏",
            "勤奋好学",
            "吃苦耐劳",
            "不服输",
            "有待提高",
            "认真专注",
            "团结队友",
            "领袖气质"
        };

        UserModel userModel = LoginInterceptor.getLoginUser();

        Long userId = userModel.getId();
        int userType = userModel.getUtype();

        String[] tags;

        switch (userType){
            case BussContant.USER_UTYPE_4:{
                tags = coachTags;
                break;
            }
            case BussContant.USER_UTYPE_5:{
                tags = masterTags;
                break;
            }
            default: return;
        }

        if(!StringHandler.isValidObj(tags))
            return;

        List<CommentTagEntity> commentTagEntities = new ArrayList<>();

        for (int i = 0; i < tags.length; i++) {
            CommentTagEntity commentTagEntity = new CommentTagEntity(tags[i], userId);

            commentTagEntities.add(commentTagEntity);
        }

        commentTagDao.batchInsert(commentTagEntities);
    }
    
    /**
     * [新增] [修改] -> 标签
     * @Author 肖家添
     * @Date 2019/8/14 14:35
     */
    @Override
    @Transactional
    public void doComplexBusss(Map<String, Object> params) throws ServiceException {
        CommentTagEntity commentTagEntity;

        try{
            commentTagEntity = BeanUtil.copyValue(CommentTagEntity.class, params);
        }catch (Exception ex){
            ex.printStackTrace();
            throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, ex.getMessage());
        }

        validCommentTag(commentTagEntity);

        setCreateInfo(commentTagEntity);

        Long tagId = commentTagEntity.getId();

        if(null == tagId){
            insert(commentTagEntity);
        }else{
            update(commentTagEntity);
        }
    }
    
    /**
     * 验证字段
     * @Author 肖家添
     * @Date 2019/8/14 14:22
     */
    private void validCommentTag(CommentTagEntity commentTagEntity){
        String tagName = commentTagEntity.getTagName();

        if(!StringHandler.isValidStr(tagName)){
            throw new ServiceException("标签名不能为空");
        }
    }
    
    /**
     * 设置初始化信息
     * @Author 肖家添
     * @Date 2019/8/14 14:24
     */
    private void setCreateInfo(CommentTagEntity commentTagEntity){
        UserModel userModel = LoginInterceptor.getLoginUser();

        commentTagEntity.setUserId(userModel.getId());
    }
}
