package com.cmw.service.impl;


import com.alibaba.druid.util.StringUtils;
import com.cmw.constant.GlobalConstant;
import com.cmw.constant.SmsTemplateConstant;
import com.cmw.constant.SysParamConstant;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.ClassGoDao;
import com.cmw.dao.TeacherDao;
import com.cmw.entity.*;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.*;
import com.cmw.util.*;
import com.esotericsoftware.minlog.Log;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Consumer;


/**
 * 上课记录表  Service实现类
 * @author 程明卫
 * @date 2019-04-20 13:08:06
 */
@Slf4j
@Description(remark="上课记录表业务实现类",createDate="2019-04-20 13:08:06",author="程明卫")
@Service("classGoService")
public class ClassGoServiceImpl extends AbsService<ClassGoEntity, Long> implements  ClassGoService {

	@Resource
	private ClassGoDao classGoDao;

	@Autowired
	private EnrollService enrollService;

	@Autowired
	private TempPlanService tempPlanService;

	@Autowired
	private StudentService studentService;

	@Autowired
	private CourseService courseService;

	@Autowired
	private AmqpTemplate amqpTemplate;

	@Autowired
	private ClassService classService;

	@Resource
	private TeacherDao teacherDao;

	@Autowired
	private StringRedisTemplate stringRedisTemplate;

	@Override
	public GenericDaoInter<ClassGoEntity, Long> getDao() {
		return classGoDao;
	}

	@Override
	public List<Map<String, Object>> getListByClassId(Long classId) {
		return classGoDao.getListByClassId(classId);
	}

	@Override
	public Integer getFinishCount(Map<String, Object> pars) {
		return classGoDao.getFinishCount(pars);
	}

	@Override
	public List<Map<String, Object>> getListByPlanId(Long planId) {
		return classGoDao.getListByPlanId(planId);
	}

	@Override
	public Integer getDoCount(Map<String, Object> pars) {
		return classGoDao.getDoCount(pars);
	}

	@Override
	public List<Map<String, Object>> getListByXstatus(Map<String, Object> pars) {
		return classGoDao.getListByXstatus(pars);
	}

	@Override
	public List<Map<String, Object>> getLeavesByPlanId(Map<String, Object> pars) {
		return classGoDao.getLeavesByPlanId(pars);
	}

	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> pars) throws ServiceException {
		UserModel userInfo = (UserModel)pars.getvalAsObj("userInfo");
		ClassGoEntity classGoEntity = updateXstatus(pars, userInfo);
		updateUhours(userInfo, classGoEntity);
		updateTempPlanYcount(userInfo, classGoEntity);
		return null;
	}

	/**
	 * 更新课次表实到人数
	 * @param userModel
	 * @param classGoEntity
	 */
	public void updateTempPlanYcount(UserModel userModel, ClassGoEntity classGoEntity){
		Long planId = classGoEntity.getPlanId();
		Map<String,Object> pars = new HashMap<>();
		pars.put("planId", planId);
		pars.put("btype", 1);
		Integer doCount = classGoDao.getDoCount(pars);
		TempPlanEntity tempPlanEntity = tempPlanService.get(planId);
		Integer xcount = tempPlanEntity.getXcount();
		if(null == xcount || xcount.intValue() <= doCount){
			pars.remove("btype");
			Long l_xcount = classGoDao.getTotalsByPars(pars);
			xcount = l_xcount.intValue();
			tempPlanEntity.setXcount(xcount);
		}
		UserUtil.setModifyInfo(userModel, tempPlanEntity);
		tempPlanEntity.setYcount(doCount);
		if(tempPlanEntity.getXstatus().intValue() == BussContant.TEMPPLAN_XSTATUS_0){
			tempPlanEntity.setXstatus(BussContant.TEMPPLAN_XSTATUS_1);
		}
		tempPlanService.update(tempPlanEntity);
	}


	/**
	 *
	 * update time: 2019-07-12, Mr.Shaw
	 *
	 * 更新已消耗课时
	 * @param userModel
	 * @param classGoEntity
	 */
	@Override
	public void updateUhours(UserModel userModel, ClassGoEntity classGoEntity){
		Long studentId = classGoEntity.getStudentId();
		Long courseId = classGoEntity.getCourseId();
		Map<String,Object> msg = new HashMap<>();
		msg.put("studentId", studentId);
		msg.put("courseId", courseId);

		//2.发送消息
		//	this.amqpTemplate.convertAndSend(GlobalConstant.SYNCHROUHOURS_TASK_EXCHANGE,GlobalConstant.SYNCHROUHOURS_TASK_KEY,msg);
		//log.info("向MQ 的Exchange="+GlobalConstant.SYNCHROUHOURS_TASK_EXCHANGE+" 的管道发送消息任务完成，参数：[studentId："+studentId+", courseId:"+courseId+"]！");

		//if(1 == 1) return;

		//-- 统计已使用课时
		Map<String,Object> pars = new HashMap<>();

		pars.put("courseId", courseId);
		pars.put("studentId", studentId);

		//Integer doCount = classGoDao.getDoCount(pars);
		List<ClassGoEntity> classGoList = classGoDao.getListByFinish(courseId, studentId);

		//-- 更新报名订单使用课时，以报名顺序扣课时
		Map<EnrollEntity,Integer> countMapping = updateEnrollUseHour(studentId, courseId, classGoList);

		//-- 检查是否成为历史学员
		checkStudentHourIsUseUp(studentId);
		Integer index = 0;
		Integer endCount = 0;
		Set<EnrollEntity> keys = countMapping.keySet();
		for(EnrollEntity enrollEntity : keys){
			Integer count = countMapping.get(enrollEntity);
			endCount += count;
			for(; index < endCount; index++){
				ClassGoEntity _classGoObj = classGoList.get(index);
				updateClassGoEnrollId(userModel, enrollEntity, _classGoObj);
			}
			index = endCount;
		}
	}

	private void updateClassGoEnrollId(UserModel userModel, EnrollEntity enrollEntity, ClassGoEntity classGoEntity) {
		//-- 更新消耗课时和课消金额
		Long enrollId = enrollEntity.getId();
		BigDecimal price = enrollEntity.getPrice();
		BigDecimal payPrice = enrollEntity.getPayPrice();
		Long _enrollId = classGoEntity.getEnrollId();
		Long classGoId = classGoEntity.getId();
		if(enrollId.equals(_enrollId)){
			log.info("ID为:"+classGoEntity.getId()+"的上课记录报名ID="+_enrollId+",不需要再更新其enrollId 字段");
			return;
		}
		Integer uhours = 1;
		if(null == payPrice || payPrice.doubleValue() == 0d){ //活动课程订单金额为0，课消金额设为0
			price = new BigDecimal("0");
		}
		Integer cupHours = classGoEntity.getCupHours();
		if((null != cupHours && cupHours.intValue() == 2) || classGoEntity.getXstatus().intValue() == BussContant.CLASSGO_XSTATUS_0){ //不扣课时
			uhours = 0;
			price = new BigDecimal("0");
		}
		classGoEntity.setEnrollId(enrollId);
		classGoEntity.setUnamount(price);
		classGoEntity.setUhours(uhours);
		UserUtil.setModifyInfo(userModel, classGoEntity);
		classGoDao.update(classGoEntity);
	}

	/**
	 * 更新报名订单已使用课时
	 *
	 * studentId = 学生编号
	 * courseId = 课程编号
	 * doCount = 课程使用总课时
	 *
	 * @Author 肖家添
	 * @Date 2019/7/12 17:21
	 */
	private Map<EnrollEntity,Integer> updateEnrollUseHour(Long studentId, Long courseId, List<ClassGoEntity> classGoList){
		UserModel userModel = LoginInterceptor.getLoginMember();

		Map<String, Object> params = new HashMap<>();

		params.put("studentId", studentId);
		params.put("courseId", courseId);
		params.put("xstatus", "1");

		List<Map<String, Object>> enrollList = enrollService.getEnrollByParams(params);

		if(null == enrollList || enrollList.size() <= 0){
			throw new ServiceException("学生ID="+ studentId +" 的学生未找到报名记录！");
		}

		Integer doCount = classGoList.size();
		Map<EnrollEntity,Integer> countMapping = new LinkedHashMap<>();
		EnrollEntity enrollModify = null;
		//-- 重新设置已使用课时
		for (Map<String, Object> enroll : enrollList) {
			EnrollEntity enrollEntity = null;
			try{
				enrollEntity = BeanUtil.copyValue(EnrollEntity.class, enroll);
			}catch (Exception ex){
				ex.printStackTrace();
			}

			if(!StringHandler.isValidObj(enrollEntity)){
				break;
			}

			Integer hours = enrollEntity.getHours();		//购买课时
			Integer giveHours = enrollEntity.getGhours();	//赠送课时
			Integer thours = enrollEntity.getThours();
			Integer stockUhours = enrollEntity.getStockUhours();
			if(null == thours) thours = 0;
			if(null == stockUhours) stockUhours = 0;
			Integer countHour = hours + giveHours - thours - stockUhours;			//总课时
			Integer useHour = enrollEntity.getUhours();		//已使用课时

			Integer updateHour = 0;		//即将更新的 ==> 已使用课时

			if(doCount > countHour){
				updateHour = countHour;
				countMapping.put(enrollEntity, updateHour);
				doCount -= countHour;
			}else{
				if(doCount <= 0) doCount = 0;
				updateHour = doCount;
				doCount = 0;
				if(updateHour > 0) countMapping.put(enrollEntity, updateHour);
			}

			enrollEntity.setUhours(updateHour);

			if(useHour == updateHour){
				continue;
			}else{
				enrollModify = enrollEntity;
			}
			UserUtil.setModifyInfo(userModel, enrollEntity);
			enrollService.update(enrollEntity);
			if(doCount == 0) break;
		}
		return countMapping;
	}

	/**
	 * 检查学生课时是否已经用完
	 * @Author 肖家添
	 * @Date 2019/7/12 18:22
	 */
	private void checkStudentHourIsUseUp(Long studentId){
		UserModel userModel = LoginInterceptor.getLoginMember();

		Integer count = enrollService.findNoFinishEnrollCount(studentId);

		if(count == null || count == 0){
			StudentEntity studentEntity = studentService.get(studentId);
			studentEntity.setXstatus(BussContant.STUDENT_XSTATUS_5);
			UserUtil.setModifyInfo(userModel, studentEntity);
			studentEntity.setRemark("本次点名后，学员已上完全部课时，故更新状态为历史学员");
			studentService.update(studentEntity);
		}
	}

	/**
	 * 更新点名状态
	 * @param pars
	 * @param userInfo
	 * @return
	 */
	private ClassGoEntity updateXstatus(SHashMap<String, Object> pars, UserModel userInfo) {
		Long id = pars.getvalAsLng("id");
		Integer xstatus = pars.getvalAsInt("xstatus");
		Integer cupHours = pars.getvalAsInt("cupHours");

		ClassGoEntity classGoEntity = get(id);

		UserUtil.setModifyInfo(userInfo, classGoEntity);

		classGoEntity.setXstatus(xstatus);

		//-- 是否扣课时 begin
		if(!StringHandler.isValidObj(cupHours))
			cupHours = 0;

		else if(cupHours != 1 && cupHours != 2)
			throw new ServiceException("更新点名状态失败，ClassGo.cupHours="+ cupHours +"的状态无效！");

		classGoEntity.setCupHours(cupHours);
		//-- 是否扣课时 end

		if(null != xstatus && (xstatus.intValue() == BussContant.CLASSGO_XSTATUS_1 || xstatus.intValue() == BussContant.CLASSGO_XSTATUS_2)){
			classGoEntity.setYgoTime(new Date());
		}
		Integer uhours = 0;
		if((null != cupHours && cupHours.intValue() != 2)&& (xstatus != BussContant.CLASSGO_XSTATUS_0)){
			uhours = 1;
		}
		classGoEntity.setUhours(uhours);

		//-- 更新状态
		update(classGoEntity);

		//-- 消息通知
		sendMsg(xstatus, classGoEntity);

		return classGoEntity;
	}

	@Override
	public void doComplexBusss(Map<String, Object> params) throws ServiceException {
		super.doComplexBusss(params);
	}

	/**
	 * 学生点名 ==> 发送站内通知
	 *
	 * sendType = GL_ClassGo.xstatus
	 *
	 * @Author 肖家添
	 * @Date 2019/6/17 11:05
	 */
	private void sendMsg(int sendType, ClassGoEntity classGo){
		if(!StringHandler.isValidObj(classGo)) return;

		try{
			Long studentId = classGo.getStudentId();
			Long courseId = classGo.getCourseId();
			Long classId = classGo.getClassId();
			Date goTime = classGo.getGoTime();

			String goTimeStr = DateUtil.dateFormatToStr("yyyy-MM-dd HH:mm:ss", goTime);

			StudentEntity student = studentService.get(studentId);
			CourseEntity course = courseService.get(courseId);
			ClassEntity cls = classService.get(classId);

			Long masterId = cls.getMaster();

			Map<String, Object> params = new HashMap<>();

			params.put("teacherId", masterId);

			Map<String, Object> teacherMap = teacherDao.getTeacherMap(params);

			SHashMap<String, Object> teacherMap_SH = new SHashMap<>(teacherMap);

			UserModel userModel = new UserModel();
			userModel.setId(student.getMemberId());
			userModel.setInempId(student.getId());

			Integer rtype = BussContant.MSG_RTYPE_2;
			String studentName = student.getSname();  						//学生名称
			String courseName = course.getCname();  						//课程名称
			String classHours = goTimeStr;  								//上课时间
			String studentPhone = student.getPhone();						//学生手机
			String masterPhone = teacherMap_SH.getvalAsStr("phone");	//班主任手机
			Long masterUserId = teacherMap_SH.getvalAsLng("userId");
			String tempCode = null;

			switch (sendType){
				case 1: {  //正常
					tempCode = SmsTemplateConstant.STUDENT_ROLLCALL_CLASS_CODE;
					break;
				}
				default:{
					Log.info("send news failed, sendType not found.");
					return;
				}
			}

			Map<String, Object> msg = new HashMap<>();

			msg.put(SysContant.USER_INFO, userModel);

			//-- template values
			msg.put("studentName", studentName);
			msg.put("courseName", courseName);
			msg.put("classHours", classHours);

			//-- save entity values
			msg.put("tempCode", tempCode);
			msg.put("rtype", rtype);
			msg.put("sender", masterPhone);		//发送人
			msg.put("memberId", student.getMemberId());
			msg.put("phone", studentPhone);		//接收人
			log.info("点名消息发送，点名记录ID：%s,发送人:%s, 接收人：%s", classGo.getId(), masterPhone, studentPhone);
			this.amqpTemplate.convertAndSend(GlobalConstant.AMQP_EXCHANGE_COMMON_KEY,GlobalConstant.AMQP_ROUTINGKEY_COMMON_KEY,msg);

		}catch (Exception ex){
			ex.printStackTrace();

			Log.info("send news failed, system has exception.");
		}
	}

	@Override
	public List<Map<String, Object>> getClassGoByParams(Map<String, Object> params) {
		return classGoDao.getClassGoByParams(params);
	}

	@Override
	public List<Map<String, Object>> getClassGoByStudent(Map<String, Object> params) {
		return classGoDao.getClassGoByStudent(params);
	}

	@Override
	public void resetTimeToTempPlan() {
		List<ClassGoEntity> classGoEntityList = getListAll();

		classGoEntityList.forEach(new Consumer<ClassGoEntity>() {
			@Override
			public void accept(ClassGoEntity classGoEntity) {
				TempPlanEntity tempPlanEntity = tempPlanService.get(classGoEntity.getPlanId());

				classGoEntity.setGoTime(tempPlanEntity.getStartTime());
				classGoEntity.setDownTime(tempPlanEntity.getEndTime());

				update(classGoEntity);
			}
		});
	}

	@Override
	public Map<String, Object> checkRoll(Integer rollType, String classGoIds,Integer cupHours) {
		Map<String,Object> resultMap = new HashMap<>();
		String[] classGoIdsArr = classGoIds.split(",");
		Long classGoId = Long.parseLong(classGoIdsArr[0]);
		ClassGoEntity classGoObj = classGoDao.get(classGoId);
		Date goTime = classGoObj.getGoTime();
		Date dowTime = classGoObj.getDownTime();
		Date today = new Date();

		/**------ STEP 1: 验证是否是已过期点名 ------**/
		int expireVal = getSysParamIntVal(SysParamConstant.ROOLL_CALL_EXPIRE,SysParamConstant.ROOLL_CALL_EXPIRE_VAL_2);
		if(expireVal == Integer.parseInt(SysParamConstant.ROOLL_CALL_EXPIRE_VAL_1)){
			int result = DateUtil.compareDate(dowTime, today);
			if(result != 0){
				resultMap.put("errMsg","只有上课结束时间在当天的才允许延迟点名！");
				return resultMap;
			}
		}else if(expireVal == Integer.parseInt(SysParamConstant.ROOLL_CALL_EXPIRE_VAL_2)){
			Integer expireTime = getSysParamIntVal(SysParamConstant.ROLL_EXPIRE_TIME, SysParamConstant.ROLL_EXPIRE_TIME_VAL);
			Date expireDate = DateUtil.addDaysToDate(dowTime, expireTime);
			int result = DateUtil.compareDate(expireDate, today);
			if(result < 0){
				resultMap.put("errMsg","只有上课结束时间在"+expireTime+"天以内才允许延迟点名！");
				return resultMap;
			}
		}


		/**------ STEP 2:验证是否提前点名  ------**/
		if(today.getTime() < goTime.getTime()){
			int restrictionVal = getSysParamIntVal(SysParamConstant.ROLL_CALL_RESTRICTION,SysParamConstant.ROLL_CALL_RESTRICTION_VAL_2);
			if(restrictionVal == Integer.parseInt(SysParamConstant.ROLL_CALL_RESTRICTION_VAL_1)){
				long beforeTime = goTime.getTime() - 60*1000; //上课提前一分钟可以打卡
				if(beforeTime > today.getTime()){
					resultMap.put("errMsg","还未到上课时间，不允许点名！");
					return resultMap;
				}
			}else if(restrictionVal == Integer.parseInt(SysParamConstant.ROLL_CALL_RESTRICTION_VAL_2)){
				String beforeTime = getSysParamVal(SysParamConstant.ROLL_BEFORE_TIME, SysParamConstant.ROLL_BEFORE_TIME_VAL);
				String[] beforeTimeArr = beforeTime.split(":");
				Integer hours = Integer.parseInt(beforeTimeArr[0]);
				Integer minutes = 0;
				if(beforeTimeArr.length > 1){
					minutes = Integer.parseInt(beforeTimeArr[1]);
				}
				Long beforeTimeVal = goTime.getTime()  - ((hours * 3600 * 1000) + (minutes * 60 * 1000)); //多加2分钟，使其可以在指定的时间还能延后一分钟点名
				if(beforeTimeVal > today.getTime()){
					resultMap.put("errMsg","只能在上课时间基础上提前"+hours+"小时"+minutes+"分以内才可以点名！");
					return resultMap;
				}
			}
		}


		if(null != cupHours && cupHours.intValue() != 1) return null;  //不扣课时时，就不检查剩余课时
		/**------ STEP 3: 验证是否有可用课时 ------**/

		List<Map<String,Object>> zhourList = classGoDao.getZhourList(classGoIds);
		if(null != zhourList && zhourList.size() > 0){
			StringBuilder sbClassGoIds = new StringBuilder();
			StringBuilder sbStuNames = new StringBuilder();
			zhourList.stream().forEach(item -> {
				Object _classGoId = item.get("classGoId");
				Object _studentName = item.get("studentName");
				sbClassGoIds.append(_classGoId).append(",");
				sbStuNames.append(_studentName).append(",");
			});
			String stuNames = StringHandler.RemoveStr(sbStuNames);
			String classGoIdsStr = StringHandler.RemoveStr(sbClassGoIds);
			String errMsg = null;
			if(StringHandler.isValidStr(classGoIdsStr)){
				resultMap.put("classGoIds", classGoIdsStr);
			}
			if(rollType == 2){ //批量点名
				errMsg = "批量点名时，检查到学生：["+stuNames+"]的剩余课时为0。";
			}else{ //单个学生点名
				errMsg = "学生：["+stuNames+"]的剩余课时为0，不允许点名";
			}
			resultMap.put("errMsg", errMsg);
			return resultMap;
		}
		return null;
	}

	private int getSysParamIntVal(String key,String defaultVal){
		String sysParamsVal = getSysParamVal(key, defaultVal);
		return Integer.parseInt(sysParamsVal);
	}

	private String getSysParamVal(String key,String defaultVal){
		key = SysParamConstant.getKey(key);
		String sysParamsVal = stringRedisTemplate.opsForValue().get(key);
		if(StringUtils.isEmpty(sysParamsVal)) sysParamsVal = defaultVal;
		return sysParamsVal;
	}
}
