package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;


/**
 * 上课记录表
 * @author 程明卫
 * @date 2019-04-20 13:08:06
 */
@Description(remark="上课记录表实体",createDate="2019-04-20 13:08:06",author="程明卫")
@Entity
@Table(name="GL_ClassGo")
@SuppressWarnings("serial")
public class ClassGoEntity extends IdBaseEntity {

	@Description(remark="是否已评价")
	@Column(name="commented" ,nullable=false )
	private Byte commented = 0;

	@Description(remark="消耗课时")
	@Column(name="uhours" ,nullable=false )
	private Integer uhours = 0;

	@Description(remark="课消金额")
	@Column(name="unamount" ,nullable=false )
	private BigDecimal unamount = new BigDecimal("0");

	@Description(remark="课次排班ID")
	@Column(name="planId" ,nullable=false )
	private Long planId;


	@Description(remark="实际下课时间")
	 @Column(name="ydownTime" )
	 private Date ydownTime;

	 @Description(remark="实际上课时间")
	 @Column(name="ygoTime" )
	 private Date ygoTime;

	 @Description(remark="应下课时间")
	 @Column(name="downTime" ,nullable=false )
	 private Date  downTime;

	 @Description(remark="应上课时间")
	 @Column(name="goTime" ,nullable=false )
	 private Date  goTime;

	 @Description(remark="状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="课程ID")
	 @Column(name="courseId" ,nullable=false )
	 private Long courseId;

	 @Description(remark="班级ID")
	 @Column(name="classId" ,nullable=false )
	 private Long classId;

	 @Description(remark="学员ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;

	@Description(remark="是否扣课时")
	@Column(name="cupHours" ,nullable=false )
	private Integer cupHours = 1;

	/**
	 * @Author cmw
	 * @Date 2019/11/16 16:10
	 */
	@Description(remark="报名ID")
	@Column(name="enrollId" )
	private Long enrollId;

	/**
	 * 获取报名ID
	 * @Author cmw
	 * @Date 2019/11/16 16:10
	 **/
	public Long getEnrollId() {
		return enrollId;
	}

	/**
	 * 设置报名ID
	 * @Author cmw
	 * @Date 2019/11/16 16:12
	 * @param enrollId	报名ID
	 */
	public void setEnrollId(Long enrollId) {
		this.enrollId = enrollId;
	}

	/**
	 * 是否扣课时
	 * @Author 肖家添
	 * @Date 2019/6/30 17:42
	 **/
	public Integer getCupHours() {
		return cupHours;
	}

	/**
	 * 是否扣课时
	 * @Author 肖家添
	 * @Date 2019/6/30 17:42
	 **/
	public void setCupHours(Integer cupHours) {
		this.cupHours = cupHours;
	}

	public ClassGoEntity() {

	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}


	public Byte getCommented() {
		return commented;
	}

	public void setCommented(Byte commented) {
		this.commented = commented;
	}

	public Integer getUhours() {
		return uhours;
	}

	public void setUhours(Integer uhours) {
		this.uhours = uhours;
	}

	public BigDecimal getUnamount() {
		return unamount;
	}

	public void setUnamount(BigDecimal unamount) {
		this.unamount = unamount;
	}

	/**
	  * 设置实际下课时间的值
	 * @param 	ydownTime	 实际下课时间
	**/
	public void setYdownTime(Date  ydownTime){
		 this.ydownTime=ydownTime;
 	}

	/**
	  * 获取实际下课时间的值
	 * @return 返回实际下课时间的值
	**/
	public Date getYdownTime(){
		 return ydownTime;
 	}

	/**
	  * 设置实际上课时间的值
	 * @param 	ygoTime	 实际上课时间
	**/
	public void setYgoTime(Date  ygoTime){
		 this.ygoTime=ygoTime;
 	}

	/**
	  * 获取实际上课时间的值
	 * @return 返回实际上课时间的值
	**/
	public Date getYgoTime(){
		 return ygoTime;
 	}

	/**
	  * 设置应下课时间的值
	 * @param 	 downTime	 应下课时间
	**/
	public void setDownTime(Date   downTime){
		 this. downTime= downTime;
 	}

	/**
	  * 获取应下课时间的值
	 * @return 返回应下课时间的值
	**/
	public Date getDownTime(){
		 return  downTime;
 	}

	/**
	  * 设置应上课时间的值
	 * @param 	 goTime	 应上课时间
	**/
	public void setGoTime(Date   goTime){
		 this. goTime= goTime;
 	}

	/**
	  * 获取应上课时间的值
	 * @return 返回应上课时间的值
	**/
	public Date getGoTime(){
		 return  goTime;
 	}

	/**
	  * 设置状态的值
	 * @param 	xstatus	 状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取状态的值
	 * @return 返回状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置课程ID的值
	 * @param 	courseId	 课程ID
	**/
	public void setCourseId(Long  courseId){
		 this.courseId=courseId;
 	}

	/**
	  * 获取课程ID的值
	 * @return 返回课程ID的值
	**/
	public Long getCourseId(){
		 return courseId;
 	}

	/**
	  * 设置班级ID的值
	 * @param 	classId	 班级ID
	**/
	public void setClassId(Long  classId){
		 this.classId=classId;
 	}

	/**
	  * 获取班级ID的值
	 * @return 返回班级ID的值
	**/
	public Long getClassId(){
		 return classId;
 	}

	/**
	  * 设置学员ID的值
	 * @param 	studentId	 学员ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取学员ID的值
	 * @return 返回学员ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}


	@Override
	public Object[] getDatas() {
		return new Object[]{ydownTime,ygoTime, downTime, goTime,xstatus,courseId,classId,studentId,cupHours};
	}

	@Override
	public String[] getFields() {
		return new String[]{"ydownTime","ygoTime"," downTime"," goTime","xstatus","courseId","classId","studentId","cupHours"};
	}

}
