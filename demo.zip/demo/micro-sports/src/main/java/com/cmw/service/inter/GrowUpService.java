package com.cmw.service.inter;


import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.GrowUpEntity;

import java.util.List;
import java.util.Map;


/**
 * 成长档案表  Service接口
 * @author 程明卫
 * @date 2019-04-20 13:52:04
 */
@Description(remark="成长档案表业务接口",createDate="2019-04-20 13:52:04",author="程明卫")
public interface GrowUpService extends IService<GrowUpEntity, Long> {

    List<Map<String,Object>> getListByStudent(Map<String, Object> params);

    /**
     * 获取老师评论列表
     * @Author 程明卫
     * @Date 2019/07/09 09:01
     */
    List<Map<String, Object>> getComments(Map<String, Object> params);

    /**
     * 获取学生上课记录
     * @Author 肖家添
     * @Date 2019/7/9 9:42
     */
    JSONObject getClassGoByStudent(Map<String, Object> params);

}
