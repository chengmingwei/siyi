package com.cmw.service.impl;



import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.CoursePlanDao;
import com.cmw.entity.CoursePlanEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.CoursePlanService;
import com.cmw.util.BeanUtil;
import com.cmw.util.SHashMap;
import com.cmw.util.UserUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;


/**
 * 教学计划  Service实现类
 * @author 程明卫
 * @date 2019-04-10 14:01:31
 */
@Description(remark="教学计划业务实现类",createDate="2019-04-10 14:01:31",author="程明卫")
@Service("coursePlanService")
public class CoursePlanServiceImpl extends AbsService<CoursePlanEntity, Long> implements  CoursePlanService {
	@Autowired
	private CoursePlanDao coursePlanDao;
	@Override
	public GenericDaoInter<CoursePlanEntity, Long> getDao() {
		return coursePlanDao;
	}


	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		CoursePlanEntity entity = null;
		try {
			entity = BeanUtil.copyValue(CoursePlanEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);

		if(null == entity.getId()){
			UserUtil.setCreateInfo(userInfo, entity);
			setCourseId(entity);
			insert(entity);
		}else{
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);
		}
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}

	/**
	 * 当FormType不等于空时，设置 courseId
	 * @param coursePlanEntity
	 */
	private void setCourseId(CoursePlanEntity coursePlanEntity){
		Integer formType = coursePlanEntity.getFormType();
		Long formId = coursePlanEntity.getFormId();
		if(null == formType || formType.intValue() == 0) return;
		Map<String,Object> pars = new HashMap<>();
		pars.put("formType", formType);
		pars.put("formId", formId);
		Long courseId = coursePlanDao.getCourseId(pars);
		coursePlanEntity.setCourseId(courseId);
	}

	private void validInfo(CoursePlanEntity entity){
		if(StringUtils.isEmpty(entity.getTitle())){
			throw new ServiceException("标题不能为空!");
		}
	}
}
