package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import java.util.Date;


/**
 * 学员跟进记录
 * @author 程明卫
 * @date 2019-04-10 13:41:05
 */
@Description(remark="学员跟进记录实体",createDate="2019-04-10 13:41:05",author="程明卫")
@Entity
@Table(name="GL_FollowUp")
@SuppressWarnings("serial")
public class FollowUpEntity extends IdBaseEntity {
	
	
	 @Description(remark="下次跟进日期")
	 @Column(name="ndate" ,nullable=false )
	 private Date ndate;

	 @Description(remark="跟进说明")
	 @Column(name="instru" ,length=500 )
	 private String instru;

	 @Description(remark="意向级别")
	 @Column(name="ilevel" )
	 private Integer ilevel;

	 @Description(remark="跟进状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="学员ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;


	public FollowUpEntity() {

	}

	
	/**
	  * 设置下次跟进日期的值
	 * @param 	ndate	 下次跟进日期
	**/
	public void setNdate(Date  ndate){
		 this.ndate=ndate;
 	}

	/**
	  * 获取下次跟进日期的值
	 * @return 返回下次跟进日期的值
	**/
	public Date getNdate(){
		 return ndate;
 	}

	/**
	  * 设置跟进说明的值
	 * @param 	instru	 跟进说明
	**/
	public void setInstru(String  instru){
		 this.instru=instru;
 	}

	/**
	  * 获取跟进说明的值
	 * @return 返回跟进说明的值
	**/
	public String getInstru(){
		 return instru;
 	}

	/**
	  * 设置意向级别的值
	 * @param 	ilevel	 意向级别
	**/
	public void setIlevel(Integer  ilevel){
		 this.ilevel=ilevel;
 	}

	/**
	  * 获取意向级别的值
	 * @return 返回意向级别的值
	**/
	public Integer getIlevel(){
		 return ilevel;
 	}

	/**
	  * 设置跟进状态的值
	 * @param 	xstatus	 跟进状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取跟进状态的值
	 * @return 返回跟进状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置学员ID的值
	 * @param 	studentId	 学员ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取学员ID的值
	 * @return 返回学员ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{ndate,instru,ilevel,xstatus,studentId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"ndate","instru","ilevel","xstatus","studentId"};
	}

}
