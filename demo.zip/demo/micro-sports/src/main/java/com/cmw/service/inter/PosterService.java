package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.PosterEntity;


/**
 * 学生海报  Service接口
 * @author 程明卫
 * @date 2019-07-10 20:19:51
 */
@Description(remark="学生海报业务接口",createDate="2019-07-10 20:19:51",author="程明卫")
public interface PosterService extends IService<PosterEntity, Long> {
    Long getMaxIdByStudentId(Long id);
}
