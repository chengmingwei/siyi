package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.ClassGoEntity;

import java.util.List;
import java.util.Map;


/**
 * 首页统计数据  Service接口
 * @author 程明卫
 * @date 2019-05-08 08:33:06
 */
@Description(remark="首页统计数据业务接口",createDate="2019-05-08 08:33:06",author="程明卫")
public interface WxHomeService extends IService<ClassGoEntity, Long> {

    /**
     * 教练端/班主任/销售端首页数据
     * @param pars  [indeptId:校区ID，当前用户]
     * @return
     */
    Map<String,Object> getHomeDataForWx(Map<String, Object> pars);

    /**
     * 班主任/销售端首页数据
     * @param pars  [userId:当前用户ID]
     * @return
     */
    Map<String,Object> getHomeDataForPc(Map<String, Object> pars);

    /**
     * 首页机构收入
     * @param pars
     * @return
     */
    Map<String, Object> getHomeInstIncomeListForPc(Map<String, Object> pars);

    /**
     * 首页课消金额
     * @param pars
     * @return
     */
    Map<String, Object> getHomeUseCountListForPc(Map<String, Object> pars);
    
    /**
     * [小程序] -> [教练端] -> [教练角色] -> [数据汇总]
     * @Author 肖家添
     * @Date 2019/8/12 16:01
     */
    Map<String, Object> getWxHomeDataOfCoach();
}
