package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.MemberDetailEntity;


/**
 * 会员详细信息表  Service接口
 * @author 程明卫
 * @date 2019-04-10 22:13:17
 */
@Description(remark="会员详细信息表业务接口",createDate="2019-04-10 22:13:17",author="程明卫")
public interface MemberDetailService extends IService<MemberDetailEntity, Long> {
}
