package com.cmw.service.impl;



import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.ClassDao;
import com.cmw.entity.ClassEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassGoService;
import com.cmw.service.inter.ClassService;
import com.cmw.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 班级  Service实现类
 * @author 程明卫
 * @date 2019-04-10 14:02:43
 */
@Description(remark="班级业务实现类",createDate="2019-04-10 14:02:43",author="程明卫")
@Service("classService")
public class ClassServiceImpl extends AbsService<ClassEntity, Long> implements  ClassService {
	@Autowired
	private ClassDao classDao;

	@Resource(name="classGoService")
	private ClassGoService classGoService;

	@Override
	public GenericDaoInter<ClassEntity, Long> getDao() {
		return classDao;
	}


	@Override
	public List<Map<String, Object>> getListByPars(Map<String, Object> params){
		return classDao.getListByPars(params);
	}



	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		ClassEntity entity = null;
		try {
			entity = BeanUtil.copyValue(ClassEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);

		int userType = userInfo.getUtype();

		if(userType == BussContant.USER_UTYPE_4){
			throw new ServiceException("您的账号[教练]暂时无权限新增班级！");
		}

		if(null == entity.getId()){
			UserUtil.setCreateInfo(userInfo, entity);
			insert(entity);
			setCode(entity);
		}else{
			Long classId = entity.getId();
			ClassEntity oldClass = get(classId);
			Long oldCourseId = oldClass.getCourseId();
			Long courseId = entity.getCourseId();
			if(!oldCourseId.equals(courseId)){
				updateClassGoCourserId(oldCourseId, courseId, classId, userInfo);
			}
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);
		}
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}

	/**
	 * 当改变了班级上的课程时，要更新上课记录里的课程ID
	 * @param oldCourseId
	 * @param courseId
	 * @param userInfo
	 */
	private void updateClassGoCourserId(Long oldCourseId, Long courseId, Long classId, UserModel userInfo){
		Map<String,Object> dataMap = new HashMap<>();
		dataMap.put("courseId", courseId);
		dataMap.put("modifier", userInfo.getId());
		String  modifyTime = DateUtil.dateFormatToStr(DateUtil.DATE_TIME_FORMAT2, new Date());
		dataMap.put("modifytime", modifyTime);
		StringBuilder sbRemark = new StringBuilder();
		sbRemark.append("用户："+userInfo.getUserName()+"于："+modifyTime+" 将原课程ID:"+oldCourseId+"改为了:").append(courseId);
		dataMap.put("remark", sbRemark.toString());
		Map<String,Object> whereMap = new HashMap<>();
		whereMap.put("classId", classId);
		whereMap.put("courseId", oldCourseId);
		classGoService.updateByPars(dataMap, whereMap);
	}


	/**
	 * 设置编号
	 * @param entity
	 */
	private void setCode(ClassEntity entity) {
		String code = CodeRule.getCodeById("C",entity.getId());
		entity.setCode(code);
		classDao.updateCode(code, entity.getId());
	}

	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(ClassEntity entity) {

		String cname = entity.getCname();
		if(StringUtils.isEmpty(cname)){
			throw new ServiceException("班级名称不能为空!");
		}
		if(null == entity.getCourseId()){
			throw new ServiceException("课程不能为空！");
		}
		if(null == entity.getCoach()){
			throw new ServiceException("教练不能为空！");
		}
		if(null == entity.getMaster()){
			throw new ServiceException("班主任不能为空！");
		}
		if(StringUtils.isEmpty(entity.getAddress())){
			throw new ServiceException("上课地点不能为空！");
		}
		if(null == entity.getSdate()){
			throw new ServiceException("开班日期不能为空！");
		}

		//-- Check for coach Id in coach spare ids. Begin
		Long coach = entity.getCoach();
		String coachSpareIds = entity.getCoachSpareIds();

		if(StringHandler.isValidObj(coach) && StringHandler.isValidStr(coachSpareIds)){
			try{
				String[] coachSpareIdsArr = coachSpareIds.split(",");

				for (int i = 0; i < coachSpareIdsArr.length; i++) {
					if(coachSpareIdsArr[i] == coach.toString()){
						throw new ServiceException("教练和教练副本选择冲突！");
					}
				}
			}catch (ServiceException exception){
				throw new ServiceException("请检查副教练Id是否正确！");
			}
		}

		//-- Check for coach Id in coach spare ids. End
	}
}
