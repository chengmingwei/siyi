package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.EnrollEntity;
import com.cmw.entity.StudentDetailEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.model.global.ResultModel;
import com.cmw.model.global.ResultUtil;
import com.cmw.service.inter.*;
import com.cmw.util.*;
import com.cmw.util.export.ExcelExport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 学员信息  ACTION类
 * @author 程明卫
 * @date 2019-04-10 11:33:10
 */
@Slf4j
@Description(remark="学员信息ACTION",createDate="2019-04-10 11:33:10",author="程明卫")
@Api(value = "学员信息微服务", description = "#CONTROLLER# 2019-04-10 11:33:10 程明卫")
@RestController
@RequestMapping({"/student"})
public class StudentController{
	@Autowired
	private StudentService studentService;
    @Autowired
    StudentDetailService studentDetailService;

    @Resource(name="courseService")
    private CourseService courseService;

    /**
     * 处理手机号相同的学生没有产生帐号的问题
     * @return 返回 JsonObjects 对象
     */
    @ApiOperation("处理手机号相同的学生没有产生帐号的问题")
    @GetMapping("updateErrData")
    public JSONObject updateErrData(@RequestParam Map<String,Object> params){
       Integer upcount = studentService.updateErrData();
       return PageHandler.getSuccessJson("successCount", upcount);
    }

    /**
     *
     * -- PC班级详情
     * -- 班级学员
     *  /student/pc/list
     *   classId ：班级ID
     * @param params [classId] 班级ID
     * @return
     */
    @ApiOperation("根据班级ID获取学生列表API")
    @PostMapping(value = "/pc/list")
    public JSONObject getListMapByClassId(@RequestParam Map<String,Object> params) {
        List<Map<String, Object>> list = null;
        Object btagObj = params.get("btag");
        if (null == btagObj) {
            return PageHandler.getFailureJson("参数：btag 不能为空！");
        }
        Integer btag = Integer.parseInt(btagObj.toString());
        switch (btag.intValue()) {
            case 1: { //通过班级ID获取班级信息
                Object classIdObj = params.get("classId");
                Long classId = Long.parseLong(classIdObj.toString());
                params.put("classId", classId);
                list = studentService.getListMapByClassId(params);
                break;
            }
        }

        return PageHandler.getJson(list);
    }


    /**
     * /student/info
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @GetMapping(value = "/info")
    public ResultModel<Map<String, Object>> info(@ApiParam("学员信息ID") @RequestParam("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        StudentEntity obj = studentService.get(id);
        if(null == obj) return ResultUtil.getFailure("无学生信息!");
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("imgPath", obj.getImgPath());
        resultMap.put("name", obj.getSname());
        resultMap.put("sex", obj.getSex());
        resultMap.put("phone", obj.getPhone());
        ResultModel<Map<String, Object>> resultModel = ResultUtil.getSuccess(resultMap);
        return resultModel;
    }


    /**
     * 微信端获取当前登录用户的学生列表信息
     * @return 返回 JsonObjects 对象
     */
    @ApiOperation("分页查询用户信息列表API")
    @PostMapping("wxlist")
    public JSONObject listForWx(@RequestParam Map<String,Object> params){
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = getRightSql(userObj);
        params.put("rightCondition", rightCondition);

        List<Map<String,Object>> list = studentService.getListMap(params);

        if(list == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(list);
    }

    private String getRightSql(UserModel userObj){
        String tabAsName = "A"; //表别名
        String rightCondition = UserUtil.getRightSql(tabAsName, userObj);
        Integer utype = userObj.getUtype();
        Long departmentId = userObj.getIndeptId();
        Long compId = userObj.getIncompId();
        int userType = userObj.getUtype();
        Long userId = userObj.getId();
        Long coach = userObj.getInempId();
        if(null != utype && utype.intValue() == BussContant.USER_UTYPE_4){
            rightCondition = "and ("+tabAsName+".id in ("+
          "  SELECT DISTINCT A.studentId FROM gl_classchoose AS A " +
          " INNER JOIN gl_class AS B ON A.classId = B.id left join gl_tempplan as C on A.classId=C.classId" +
          " WHERE A.isenabled = 1 AND B.isenabled = 1 and A.xstatus != 3 AND (B.coach = '"+coach+"' or C.coach='"+coach+"')" +
          ") or A.creator='"+userId+"')";
        } else  if((userType == BussContant.USER_UTYPE_2 || userType == BussContant.USER_UTYPE_6) && StringHandler.isValidObj(departmentId)){
            if(null != compId && compId != -1){
                rightCondition = " and ( A.orgId = '"+compId+"') or A.creator='"+userId+"' ";
            }else{
                rightCondition = " and  A.creator='"+userId+"' ";
            }
        }
        return rightCondition;
    }

    /**
     * 分页查询
     * 返回状态码：
     *
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询用户信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        Object bdate_obj = params.get("bdate");

        if(StringHandler.isValidObj(bdate_obj)){
            ArrayList<String> list  =(ArrayList<String>) bdate_obj;
            if(list.size() > 0){
                String timeOne = list.get(0);
                int lastIndexOf_01 = timeOne.lastIndexOf("-");
                if(lastIndexOf_01 != -1){
                    timeOne = timeOne.substring(0, lastIndexOf_01 + 3);
                }
                params.put("bdate_start",timeOne);
            }
            if(list.size() > 1){
                String timeTwo = list.get(1);

                int lastIndexOf_02 = timeTwo.lastIndexOf("-");

                if(lastIndexOf_02 != -1){
                    timeTwo = timeTwo.substring(0, lastIndexOf_02 + 3);
                }
                params.put("bdate_end",timeTwo);
            }
        }

        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = getRightSql(userObj);
        Integer utype = userObj.getUtype();

        params.put("rightCondition", rightCondition);

        PageResult<List<Map<String,Object>>> result = studentService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }

    /**
     * 数据导出
     * @Author 肖家添
     * @Date 2019/6/19 12:41
     */
    @ApiOperation("数据导出")
    @PostMapping("/exportData")
    public void exportData(HttpServletRequest request, HttpServletResponse response, @RequestParam Map<String, Object> params){
        List<Map<String, Object>> dataList_LM = ExcelExport.getExportData(this.list(params));

        if(null == dataList_LM) return;

        studentService.exportData(request, response, dataList_LM);
    }

    @Resource(name="enrollService")
    private EnrollService enrollService;

    @Resource(name="classGoService")
    private ClassGoService classGoService;

    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取学员信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("学员信息ID") @PathVariable("id") Long id){
      	if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        StudentEntity obj = studentService.get(id);
        Map<String,Object> pars = new HashMap<>();
        pars.put("mystudentId",id);
        List<Map<String,Object>> courseList = courseService.getListMap(pars);
        String bdate = DateUtil.dateFormatToStr("yyyy-MM-dd", obj.getBdate());

        pars.clear();
        pars.put("studentId", obj.getId());
        StudentDetailEntity studentDetail = studentDetailService.getByPars(pars);
        Integer useCount = classGoService.getDoCount(pars);
        if(null == useCount) useCount = 0;
        Long enrollId = studentDetail.getEnrollId();
        EnrollEntity enrollEntity = enrollService.get(enrollId);
        Long courseId = null;
        String courseName = null;
        if(null != enrollEntity){
            pars.clear();
            courseId = enrollEntity.getCourseId();
            Map<String,Object> n_courseInfo = null;
            for(Map<String,Object> map : courseList){
                Long _courseId = Long.parseLong(map.get("id").toString());
                if(courseId.equals(_courseId)){
                    n_courseInfo = map;
                    break;
                }
            }
            courseName = n_courseInfo.get("name").toString();
        }

        Long attachId = studentDetail.getAttachId();
        if(StringUtils.isEmpty(obj.getSchool())){
            obj.setSchool("");
        }
        if(StringUtils.isEmpty(obj.getAddress())){
            obj.setAddress("");
        }
        if(StringUtils.isEmpty(obj.getRemark())){
            obj.setRemark("");
        }
        JSONObject jsonObject = PageHandler.getJson(obj);
        jsonObject.put("enrollId",studentDetail.getEnrollId());
        jsonObject.put("courseId", courseId);
        jsonObject.put("courseName", courseName);
        jsonObject.put("courseList", courseList);
        jsonObject.put("attachId", attachId);
        jsonObject.put("policyNo", studentDetail.getPolicyNo());
        jsonObject.put("useCount", useCount);
        JSONObject datas = jsonObject.getJSONObject("datas");
        datas.put("bdate", bdate);
        datas.remove("datas");
        datas.remove("fields");
        jsonObject.put("datas", datas);

        return jsonObject;
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存学员信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
       try{
           Map<String, Object> dataResult = (Map<String, Object>)studentService.doComplexBusss(new SHashMap(params));
           return PageHandler.getJson(dataResult);
       }catch (ServiceException ex){
           ex.printStackTrace();
           return PageHandler.getFailureJson(ex.getMessage());
       }
    }

    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
       return save(param);
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除学员信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("学生ID") @PathVariable("id")  Long id) throws Exception{
        Map<String,Object> pars = new HashMap<>();
        pars.put("studentId", id);
        StudentDetailEntity studentDetailEntity = studentDetailService.getByPars(pars);

        String errorMsg = deleteBeforeValidation(studentDetailEntity);
        if(StringHandler.isValidStr(errorMsg)){
            return PageHandler.getFailureJson(errorMsg);
        }

        studentService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }

    /**
     * 根据多个ID删除学员信息
     * @Author 肖家添
     * @Date 2019/6/24 18:03
     */
    @ApiOperation("根据多个ID删除学员信息")
    @PostMapping(value = "/deleteByIds")
    public JSONObject deleteByIds(@RequestParam Map<String, Object> params){
        try{
            SHashMap params_SH = new SHashMap(params);

            String ids = params_SH.getvalAsStr("ids");
            String[] idArr = ids.split(",");

            for(String id : idArr){
                params.clear();
                params.put("studentId", id);

                StudentDetailEntity studentDetailEntity = studentDetailService.getByPars(params);

                String errorMsg = deleteBeforeValidation(studentDetailEntity);
                if(StringHandler.isValidStr(errorMsg)){
                    return PageHandler.getFailureJson(errorMsg);
                }
            }

            studentService.enabledByIds(ids, -1);

            return PageHandler.getSuccessJson();
        }catch (Exception ex){
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    private String deleteBeforeValidation(StudentDetailEntity studentDetailEntity){
        Long studentId = studentDetailEntity.getStudentId();

        StudentEntity student = studentService.get(studentId);

        String phone = student.getPhone();

        if(null != studentDetailEntity.getFuppId() || null != studentDetailEntity.getTracerId()){
            return "手机号码为："+ phone +"的学生已有跟进记录，不能删除!";
        }
        if(null != studentDetailEntity.getEnrollId()){
            return "手机号码为："+ phone +"的学生已经报名，不能删除!";
        }
        if(null != studentDetailEntity.getClassId()){
            return "手机号码为："+ phone +"的学生已经分配了班级，不能删除!";
        }

        return null;
    }
	
}
