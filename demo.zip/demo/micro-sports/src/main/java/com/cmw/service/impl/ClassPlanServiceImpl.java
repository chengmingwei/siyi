package com.cmw.service.impl;



import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.ClassPlanDao;
import com.cmw.entity.ClassPlanEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassPlanService;
import com.cmw.util.BeanUtil;
import com.cmw.util.SHashMap;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;


/**
 * 循环排班表  Service实现类
 * @author 程明卫
 * @date 2019-04-20 18:24:24
 */
@Description(remark="循环排班表业务实现类",createDate="2019-04-20 18:24:24",author="程明卫")
@Service("classPlanService")
public class ClassPlanServiceImpl extends AbsService<ClassPlanEntity, Long> implements  ClassPlanService {
	@Autowired
	private ClassPlanDao classPlanDao;
	@Override
	public GenericDaoInter<ClassPlanEntity, Long> getDao() {
		return classPlanDao;
	}
	
	@Override
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		ClassPlanEntity entity = null;
		try {
			entity = BeanUtil.copyValue(ClassPlanEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		if(null == entity.getId()){
			insert(entity);
		}else{
			update(entity);
		}

		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}


	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(ClassPlanEntity entity) {
				if(StringUtils.isEmpty(entity.getEtime())){
			throw new ServiceException("下课时间不能为空!");
		}


		if(StringUtils.isEmpty(entity.getStime())){
			throw new ServiceException("上课时间不能为空!");
		}


		if(StringUtils.isEmpty(entity.getRuleVals())){
			throw new ServiceException("循环规则不能为空!");
		}

		if(StringUtils.isEmpty(entity.getRuleVals()) &&
				entity.getRuleVals().length() > 100){
			throw new ServiceException("循环规则长度不能超过100!");
		}

		if(StringUtils.isEmpty(entity.getRuleNames())){
			throw new ServiceException("循环规则名称不能为空!");
		}

		if(StringUtils.isEmpty(entity.getRuleNames()) &&
				entity.getRuleNames().length() > 100){
			throw new ServiceException("循环规则名称长度不能超过100!");
		}

		if(null == entity.getSetId()){
			throw new ServiceException("排班设置ID不能为空!");
		}


	}
}
