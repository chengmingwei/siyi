package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.CoursePlanEntity;


/**
 * 教学计划  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 14:01:31
 */
@Description(remark="教学计划DAO Mapper接口",createDate="2019-04-10 14:01:31",author="程明卫")
@Mapper
public interface CoursePlanDao extends GenericDaoInter<CoursePlanEntity, Long>{

    Long getCourseId(Map<String,Object> map);
}
