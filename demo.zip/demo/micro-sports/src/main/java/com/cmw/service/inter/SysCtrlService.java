package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.AttachmentEntity;


/**
 * 系统控制面板  Service接口
 * @author 程明卫
 * @date 2019-11-12 21:20:30
 */
@Description(remark="系统控制面板业务接口",createDate="2019-11-12 21:20:30",author="程明卫")
public interface SysCtrlService{
    /**
     * 根据GL_TempPlan 表课次ID重新生成学生上课记录
     * @param planIds   planIds:课次ID（多个以“,”号隔开）
     */
    void rebulidClassGo(String planIds);

    void synchroUhours2Enroll(Long studentId, Long courseId);
}
