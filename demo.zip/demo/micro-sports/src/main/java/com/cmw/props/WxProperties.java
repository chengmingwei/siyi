package com.cmw.props;

import org.springframework.beans.factory.annotation.Value;

/**
 * @Author: chengmingwei
 * @Time: 2019-08-25 14:53
 * @Feature: 微信配置属性
 */
//@Configuration
// @RefreshScope
// @Data
public class WxProperties {
    /**
     * 公众号appid
     */
    @Value("${wx.gzh.appid}")
    private String gzhAppId;
    /**
     * 公众号sercet
     */
    @Value("${wx.gzh.sercet.key}")
    private String gzhSercetKey;

    /**
     * 公众号 AccessToken api
     */
    @Value("${wx.gzh.url.api-token}")
    private String apiAccessToken;

    /**
     * 批量获取公众号用户基本信息列表 GET API
     */
    @Value("${wx.gzh.url.api-user-infos}")
    private String apiUserInfos;
}
