package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.EnrollEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.EnrollService;
import com.cmw.util.DateUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 学生报名  ACTION类
 * @author 程明卫
 * @date 2019-04-10 14:07:54
 */
@Description(remark="学生报名ACTION",createDate="2019-04-10 14:07:54",author="程明卫")
@Api(value = "学生报名微服务", description = "#CONTROLLER# 2019-04-10 14:07:54 程明卫")
@RestController
@RequestMapping({"/enroll"})
public class EnrollController{
	@Resource(name="enrollService")
	private EnrollService enrollService;

    @Autowired
    private StringRedisTemplate redisTemplate;

    private static final String REDIS_LOCKER_KEY = "REDIS_LOCK:ENROLL_SAVE:STUDENTID_";


    /**
     * 根据学生ID和课程ID获取该学生当前课程是否有可用课时
     * @param
     * @param  studentId 学生ID
     * @param  courseId 课程ID
     * @return
     */
    @ApiOperation("根据学生ID和课程ID获取该学生当前课程是否有可用课时")
    @PostMapping(value = "/{studentId}/{courseId}")
    public JSONObject getUseHours(@PathVariable("studentId") Long studentId, @PathVariable("courseId") Long courseId){
        Map<String,Object> params = new HashMap<>();
        params.put("studentId",studentId);
        params.put("courseId",courseId);
        params.put("source","changeChoose");
        List<EnrollEntity> list = enrollService.getList(params);
        Integer totalZhours = 0;
        if(null != list && list.size() > 0){
            for(EnrollEntity enrollEntity : list){
                Integer hours = enrollEntity.getHours();
                Integer ghours = enrollEntity.getGhours();
                Integer thours = enrollEntity.getThours();
                Integer stockHours = enrollEntity.getStockUhours();
                Integer uhours = enrollEntity.getUhours();
                if(null == hours) hours = 0;
                if(null == ghours) ghours = 0;
                if(null == thours) thours = 0;
                if(null == stockHours) stockHours = 0;
                if(null == uhours) uhours = 0;
                Integer zhours = hours + ghours - thours - stockHours - uhours;
                totalZhours += zhours;
            }
        }
        return PageHandler.getSuccessJson("totalZhours",totalZhours);
    }

    /**
     * 分页查询
     * 返回状态码：
     * 404 : 没有查询到任何数据
     *
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询订单表信息列表API")
    @PostMapping("/sys/list")
    public JSONObject list(@RequestBody Map<String, Object> params) {
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        //UserModel userObj = LoginInterceptor.getLoginUser();
        //String rightCondition = UserUtil.getRightSql("A", userObj);
       // params.put("rightCondition", rightCondition);
        params.put("bussSource","auditOrder");
        PageResult<List<Map<String, Object>>> result = enrollService.getPageByPars(params, page, pageSize);
        if (result == null) {
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }

    /**
     * 获取转课报名所需的信息
     * @param
     * @return
     */
    @ApiOperation("销售订单列表API 小程序")
    @PostMapping(value = "/wx/diffinfo")
    public JSONObject wx_diffInfo(@RequestParam Long studentId, @RequestParam Long oldClsId, @RequestParam Long classId){
        Map<String,Object> dataMap = enrollService.getDiffInfo(studentId, oldClsId, classId);
        int errCode = (Integer) dataMap.get("errCode");
        if(errCode == -1){
            return PageHandler.getFailureJson("当前学员是体验学员，还未报名不允许转班！");
        }
        return PageHandler.getJson(dataMap);
    }

    /**
     * 获取当前用户的报名订单记录
     * @param
     * @return
     */
    @ApiOperation("销售订单列表API 小程序")
    @PostMapping(value = "/wx/list")
    public JSONObject wx_list(@RequestParam Map<String,Object> params){
        UserModel userModel = LoginInterceptor.getLoginUser();
        String payDate = (String) params.get("payDate");
        if(!StringUtils.isEmpty(payDate)){
            payDate = DateUtil.dateFormatToStr(DateUtil.dateFormat(payDate));
            params.put("payDate", payDate);
        }
        Integer utype = userModel.getUtype();
        if(null != utype && utype.intValue() == BussContant.USER_UTYPE_2){
            params.put("deptId", userModel.getIndeptId());
        }else{
            params.put("userId",userModel.getId());
        }

        List<Map<String,Object>> list = enrollService.getListMap(params);
        return PageHandler.getJson(list);
    }

    /**
     * 获取指定学生的报名订单记录
     * @param
     * @param  studentId 学生ID
     * @return
     */
    @ApiOperation("学员跟进记录列表API PC")
    @PostMapping(value = "/list/{studentId}")
    public JSONObject sys_list(@PathVariable("studentId") Long studentId){
        Map<String,Object> params = new HashMap<>();
        params.put("studentId",studentId);
        List<Map<String,Object>> list = enrollService.getListMap(params);
        return PageHandler.getJson(list);
    }

    /**
     * 家长端通过小程序海报报名（免登录）
     * /enroll/poster/save
     * @param param
     * @return
     * @throws Exception
     */
    @PostMapping(value = "/poster/save")
    public JSONObject saveByPoster(@RequestParam   Map<String,String> param) throws Exception {
        try{
            Map<String, Object> dataResult = (Map<String, Object>)enrollService.doComplexBusssByPoster(param);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }



    /**
     * 保存数据
     * /enroll/save
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("学员报名")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params) throws Exception{
        try{
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = LoginInterceptor.getLoginUser();
            pars.put(SysContant.USER_INFO, userInfo);
            Long studentId = pars.getvalAsLng("studentId");
            //**--- 根据学生ID来加锁，防止老师2秒内重复点击提交 ---**//
            String lockerKey = REDIS_LOCKER_KEY+studentId;
            JSONObject lockerResult = PageHandler.lockerCheck(redisTemplate, lockerKey);
            if(null != lockerResult) return lockerResult;
            Integer btype = pars.getvalAsInt("btype");
            if(null == btype) btype = 1;
            Map<String,Object> _pars = new HashMap<>();
            _pars.put("studentId",studentId);
            _pars.put("btype", btype);
            String remark = params.get("remark");
            pars.put("explains", remark);
            //List<EnrollEntity>  entityList =enrollService.getList(_pars);
            //if(null != entityList && entityList.size() > 0){
                //return PageHandler.getFailureJson("该学员已经报过名!");
            //}

            Map<String, Object> dataResult = (Map<String, Object>)enrollService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param) throws Exception {
        return save(param);
    }

    @PostMapping(value = "sys/audit")
    public JSONObject sys_audit(@RequestBody  Map<String,String> param) throws Exception {
        try{
            UserModel userInfo = LoginInterceptor.getLoginUser();
            SHashMap<String,Object> pars = new SHashMap<>();
            pars.put(SysContant.USER_INFO, userInfo);
            pars.put("orderId", param.get("orderId"));
            pars.put("axstatus", param.get("axstatus"));
            pars.put("remark",  param.get("remark"));
            enrollService.audit(pars);
            return PageHandler.getSuccessJson();
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }


    @PostMapping(value = "sys/stock")
    public JSONObject sys_stock(@RequestBody  Map<String,String> param) throws Exception {
        try{
            UserModel userInfo = LoginInterceptor.getLoginUser();
            Object obj_enrollId = param.get("enrollId");
            Object obj_stockUhours = param.get("stockUhours");
            Object remark = param.get("remark");
            if(null == obj_enrollId) throw new ServiceException("参数：enrollId 不能为空！");
            if(null == obj_stockUhours) throw new ServiceException("参数：stockUhours 不能为空！");
            EnrollEntity enrollEntity = enrollService.get(Long.parseLong(obj_enrollId.toString()));
            enrollEntity.setStockUhours(Integer.parseInt(obj_stockUhours.toString()));
           if(null != remark) enrollEntity.setRemark(remark.toString());
            UserUtil.setModifyInfo(userInfo, enrollEntity);
            enrollService.update(enrollEntity);
            return PageHandler.getSuccessJson();
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    /**
     * 报名审批确认  (小程序端)
     * 参数：{
     *     enrollId:报名单ID
     *     axstatus:审批状态     [1:审批通过,2:不通过]
     *     remark: 备注
     * }
     * @param orderId
     * @param axstatus  [0:待审批,1:审批通过,2:不通过]
     * @param remark
     * @return
     */
    @ApiOperation("保存学员跟进记录")
    @PostMapping(value = "/audit/{orderId}")
    public JSONObject audit(@PathVariable("orderId") Long orderId, @RequestParam("axstatus") Integer axstatus,
                           @RequestParam( value = "remark",required = false) String remark) throws Exception{
        try{
            UserModel userInfo = LoginInterceptor.getLoginUser();
            SHashMap<String,Object> pars = new SHashMap<>();
            pars.put(SysContant.USER_INFO, userInfo);
            pars.put("orderId", orderId);
            pars.put("axstatus", axstatus);
            pars.put("remark", remark);
            enrollService.audit(pars);
            return PageHandler.getSuccessJson();
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }


    /**
     * 根据订单ID获取报名订单详情
     * @param
     * @param  id 报名订单Id
     * @return
     */
    @ApiOperation("根据订单ID获取报名订单详情")
    @PostMapping(value = "/{id}")
    public JSONObject get(@PathVariable("id") Long id){
        Map<String,Object> params = new HashMap<>();
        params.put("id",id);
        List<Map<String,Object>> list = enrollService.getListMap(params);
        return PageHandler.getJson(list);
    }


    /**
     *  为转过班的报名记录设置转班时间 （CMW : 2020-07-11 20:12 ADD）
     * @param
     * @return
     */
    @ApiOperation(" 为转过班的报名记录设置转班时间 （CMW : 2020-07-11 20:12 ADD）")
    @GetMapping(value = "/roll-time")
    public JSONObject initRollTime(){
        enrollService.initRollTimeDatas();
        return PageHandler.getSuccessJson();
    }
}
