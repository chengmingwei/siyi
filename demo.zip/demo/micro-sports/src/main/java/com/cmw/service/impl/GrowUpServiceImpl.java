package com.cmw.service.impl;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.annotation.UserCache;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.ClassGoDao;
import com.cmw.dao.GrowUpDao;
import com.cmw.entity.GrowUpEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.AttachmentService;
import com.cmw.service.inter.ClassGoService;
import com.cmw.service.inter.GrowUpService;
import com.cmw.service.inter.StudentService;
import com.cmw.util.*;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;


/**
 * 成长档案表  Service实现类
 * @author 程明卫
 * @date 2019-04-20 13:52:04
 */
@Description(remark="成长档案表业务实现类",createDate="2019-04-20 13:52:04",author="程明卫")
@Service("growUpService")
public class GrowUpServiceImpl extends AbsService<GrowUpEntity, Long> implements  GrowUpService {

	@Resource
	private GrowUpDao growUpDao;

	@Autowired
	private AttachmentService attachmentService;

	@Autowired
	private StudentService studentService;

	@Resource
	private ClassGoDao classGoDao;

	@Override
	public GenericDaoInter<GrowUpEntity, Long> getDao() {
		return growUpDao;
	}
	
	@Override
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		GrowUpEntity entity = null;
		try {
			entity = BeanUtil.copyValue(GrowUpEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		if(null == entity.getId()){
			
			UserUtil.setCreateInfo(userInfo, entity);
			insert(entity);
		}else{
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);
		}

		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}


	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(GrowUpEntity entity) {
		if(null == entity.getCreatorType()){
			throw new ServiceException("创建人类型不能为空!");
		}

		if(!StringUtils.isEmpty(entity.getVedioPath()) && entity.getVedioPath().length() > 150){
			throw new ServiceException("视频长度不能超过150!");
		}

		if(!StringUtils.isEmpty(entity.getImgPath()) && entity.getImgPath().length() > 150){
			throw new ServiceException("图片长度不能超过150!");
		}

		if(StringUtils.isEmpty(entity.getDescribes())){
			throw new ServiceException("描述不能为空!");
		}else if(entity.getDescribes().length() > 500){
			throw new ServiceException("描述长度不能超过500!");
		}

		if(null == entity.getStudentId()){
			throw new ServiceException("学生ID不能为空!");
		}
	}

	@Override
	@UserCache(cmns={"creatorName"})
	public List<Map<String,Object>> getListByStudent(Map<String, Object> params){
		List<Map<String,Object>> list = getListMap(params);

		if(null == list || list.isEmpty()) return null;
		for(Map<String,Object> dataMap : list){
			String imgPath = (String)dataMap.get("imgPath");
			String vedioPath = (String)dataMap.get("vedioPath");
			fillFilePaths(dataMap, "imgPath", imgPath);
			fillFilePaths(dataMap, "vedioPath", vedioPath);
		}
		return list;
	}

	@Override
	public List<Map<String, Object>> getComments(Map<String, Object> params) {
		return growUpDao.getComments(params);
	}

	private void fillFilePaths(Map<String, Object> dataMap, String key ,String imgPath) {
		if(!StringUtils.isEmpty(imgPath)){
			String[] imgPathArr = StringHandler.splitStr(imgPath, ",");
			if(null != imgPathArr && imgPathArr.length > 0){
				imgPath = attachmentService.getFilePathsByIds(imgPathArr);
				dataMap.put(key,imgPath);
			}
		}
	}

	/**
	 * 获取学生上课记录
	 * @Author 肖家添
	 * @Date 2019/7/9 9:42
	 */
	@Override
	public JSONObject getClassGoByStudent(Map<String, Object> params) {
		try{
			SHashMap<String, Object> params_SH = new SHashMap<>(params);

			Long studentId = params_SH.getvalAsLng("studentId");

			if(!StringHandler.isValidObj(studentId)){
				return PageHandler.getFailureJson("参数 studentId 不能为空");
			}

			StudentEntity student = studentService.get(studentId);

			if(!StringHandler.isValidObj(student) || !StringHandler.isValidObj(student.getId()) || student.getIsenabled() != 1){
				return PageHandler.getFailureJson(String.format("编号为 %s 的学生似乎不存在", studentId));
			}

			JSONArray returnArr = new JSONArray();

			params.put("groupBy", true);
			List<Map<String,Object>> classList = classGoDao.getClassByParams(params);

			classList.forEach(new Consumer<Map<String, Object>>() {
				@Override
				public void accept(Map<String, Object> classMap) {
					JSONObject returnJSON = new JSONObject();

					SHashMap classMap_SH = new SHashMap<>(classMap);

					Long classId = classMap_SH.getvalAsLng("classId");

					params.clear();
					params.put("classId", classId);
					params.put("studentId", studentId);

					List<Map<String,Object>> classTimeList = classGoDao.getClassByParams(params);

					returnJSON.put("class", classMap);
					returnJSON.put("classTime", classTimeList);

					returnArr.add(returnJSON);
				}
			});

			return PageHandler.getJson(returnArr);
		}catch (Exception ex){
			return PageHandler.getFailureJson(ex.getMessage());
		}
	}
}
