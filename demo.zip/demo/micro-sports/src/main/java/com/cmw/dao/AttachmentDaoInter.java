package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.AttachmentEntity;
import org.apache.ibatis.annotations.Mapper;


/**
 * 附件表  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 22:18:30
 */
@Description(remark="附件表DAO Mapper接口",createDate="2019-04-10 22:18:30",author="程明卫")
@Mapper
public interface AttachmentDaoInter extends GenericDaoInter<AttachmentEntity, Long>{

    /**
     * 根据附件ID查询文件路径
     * @param idList    附件ID列表
     * @return
     */
    String[] getFilePathsByIds(String[] idList);

}
