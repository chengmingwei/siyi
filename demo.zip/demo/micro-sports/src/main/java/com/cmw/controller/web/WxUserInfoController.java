package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

import com.cmw.util.SHashMap;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.vo.PageResult;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;

import com.cmw.entity.WxUserInfoEntity;
import com.cmw.service.inter.WxUserInfoService;


/**
 * 公众号用户信息  Conntroller类
 * @author 程明卫
 * @date 2019-08-24 17:10:59
 */
@Description(remark="公众号用户信息Conntroller",createDate="2019-08-24 17:10:59",author="程明卫")
@Api(value = "公众号用户信息微服务", description = "#CONTROLLER# 2019-08-24 17:10:59 程明卫")
@RestController
@RequestMapping({"/wxuserinfo"})
public class WxUserInfoController{
	@Resource(name="wxUserInfoService")
	private WxUserInfoService wxUserInfoService;
	

    /**
     * 跳转列表页面
     * @param request
     * @param response
     * @return
     */
     @ApiOperation("公众号用户信息列表API")
    @GetMapping(value = "/list")
    public JSONObject list(HttpServletRequest request, HttpServletResponse response){
        List<WxUserInfoEntity> list = wxUserInfoService.getListAll();
        return PageHandler.getJson(list);
    }
    
      /**
     * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询公众号用户信息信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = wxUserInfoService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }


	/**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取公众号用户信息信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("公众号用户信息ID") @PathVariable("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        WxUserInfoEntity obj = wxUserInfoService.get(id);
        JSONObject jsonObject = PageHandler.getJson(obj);
        return   jsonObject;
    }
    

    
    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存公众号用户信息信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
        try{
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = LoginInterceptor.getLoginUser();
            pars.put(SysContant.USER_INFO, userInfo);
            Map<String, Object> dataResult = (Map<String, Object>)wxUserInfoService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }

    }
    
    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
        return save(param);
    }
    
    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除公众号用户信息信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("#DESCRIPTIONID") @PathVariable("id")  Long id) throws Exception{
        wxUserInfoService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }
    
}
