package com.cmw.util.export;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmw.util.DateUtil;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.HorizontalAlignment;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 数据导出
 * @Author 肖家添
 * @Date 2019/6/26 17:23
 */
public class ExcelExport {

    HttpServletRequest request;
    HttpServletResponse response;

    public ExcelExport(HttpServletRequest request, HttpServletResponse response){
        this.request = request;
        this.response = response;
    }

    /**
     * 数据导出
     * @Author 肖家添
     * @Date 2019/6/26 18:59
     */
    public void export(String[] cellVal, String[] dataKeys, List<Map<String, Object>> data){
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("EXPORT");
        HSSFRow row = sheet.createRow((int) 0);

        //创建单元格，并设置值表头 设置表头居中
        HSSFCellStyle style = wb.createCellStyle();

        style.setAlignment(HorizontalAlignment.CENTER);

        HSSFCell cell = row.createCell((short) 0);

        for (int i = 0; i < cellVal.length; i++) {
            cell.setCellValue(cellVal[i]);
            cell.setCellStyle(style);
            cell = row.createCell((short) i + 1);
        }

        for(int i = 0; i < data.size(); i++){
            row = sheet.createRow((int) i + 1);

            SHashMap pushData = new SHashMap(data.get(i));

            for(int j = 0; j < dataKeys.length; j++) {
                String dataKey = dataKeys[j];

                String dataVal = pushData.getvalAsStr(dataKey);

                row.createCell((short) j).setCellValue(dataVal);
            }
        }

        // 将文件存到指定位置
        response.setCharacterEncoding("utf-8");
        response.setContentType("application/x-download");// 设置为下载application/x-download
        String filedisplay = null;
        try {
            String thisTime = DateUtil.dateFormatToStr("yyyyMMddHHmmss", new Date());
            filedisplay = URLEncoder.encode("EXPORT_" + thisTime + ".xls", "UTF-8");
            // 下载文件时显示的文件保存名称
            response.setHeader("Content-Disposition", "attachment;filename=" + filedisplay + ";");
            OutputStream output = response.getOutputStream();
            output.flush();
            wb.write(output);
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取分页查询数据的导出内容
     * pageList = PageResult<List<Map<String,Object>>>
     * @Author 肖家添
     * @Date 2019/6/28 17:20
     */
    public static List<Map<String, Object>> getExportData(JSONObject pageList){
        if(!StringHandler.isValidObj(pageList))
            return null;

        JSONObject pageData = pageList.getJSONObject("datas");
        if(!StringHandler.isValidObj(pageData))
            return null;

        JSONArray dataList = pageData.getJSONArray("list");
        if(!StringHandler.isValidObj(dataList))
            return null;

        List<Map<String, Object>> studentList_LM = (List) JSON.parseArray(dataList.toString(), Map.class);

        return studentList_LM;
    }

    /**
     * 获取分页查询数据的导出内容
     * dataList = List<Map<String,Object>>
     * @Author 肖家添
     * @Date 2019/6/28 17:20
     */
    public static List<Map<String, Object>> getExportData_listMap(JSONObject returnJSON){
        if(!StringHandler.isValidObj(returnJSON))
            return null;

        JSONArray dataList = returnJSON.getJSONArray("datas");
        if(!StringHandler.isValidObj(dataList))
            return null;

        List<Map<String, Object>> studentList_LM = (List) JSON.parseArray(dataList.toString(), Map.class);

        return studentList_LM;
    }
}
