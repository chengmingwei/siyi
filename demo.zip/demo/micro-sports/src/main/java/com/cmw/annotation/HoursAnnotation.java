package com.cmw.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 课时拦截器注解
 */
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface HoursAnnotation {
    /**
     * 注解开关是否启用(true:启用,false:禁用)
     * @return
     */
    boolean flag() default  true;

    /**
     * 要替换的旧SQL字符串
     * @return
     */
    String oldCmns();
    /**
     * 要替换的新SQL字符串列
     * @return
     */
    String replaceCmns();
}