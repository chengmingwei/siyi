package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.MemberEntity;


/**
 * 会员信息  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 22:07:38
 */
@Description(remark="会员信息DAO Mapper接口",createDate="2019-04-10 22:07:38",author="程明卫")
@Mapper
public interface MemberDao extends GenericDaoInter<MemberEntity, Long>{

}
