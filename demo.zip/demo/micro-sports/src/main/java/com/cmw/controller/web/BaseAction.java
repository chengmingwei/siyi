package com.cmw.controller.web;

import com.alibaba.fastjson.JSONObject;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;

import java.util.Map;

/**
 * 请求处理
 * @Author 肖家添
 * @Date 2019/5/13 17:28
 */
public class BaseAction {

    /**
     * 处理成功
     * @Author 肖家添
     * @Date 2019/5/13 17:29
     */
    protected JSONObject success(){
        return success(null);
    }

    /**
     * 处理成功
     * @Author 肖家添
     * @Date 2019/5/13 17:29
     */
    protected JSONObject success(String msg){
        return PageHandler.getSuccessJson(msg);
    }

    /**
     * 处理失败
     * @Author 肖家添
     * @Date 2019/5/13 17:29
     */
    protected JSONObject fail(Exception ex){
        ex.printStackTrace();

        return fail("系统异常");
    }

    /**
     * 处理失败
     * @Author 肖家添
     * @Date 2019/5/13 17:30
     */
    protected JSONObject fail(String msg){
        return PageHandler.getFailureJson(msg);
    }

    /**
     * 字符串为空返回true
     * @Author 肖家添
     * @Date 2019/5/13 17:34
     */
    protected boolean isNilStr(String str){
        return !StringHandler.isValidStr(str);
    }

    /**
     * 对象为空返回true
     * @Author 肖家添
     * @Date 2019/5/13 17:34
     */
    protected boolean isNilObj(Object obj){
        return !StringHandler.isValidObj(obj);
    }

    /**
     * 获取Map里面的Integer值
     * @Author 肖家添
     * @Date 2019/6/5 11:33
     */
    protected Integer getMapInt(Map params, String key, Integer returnNull){
        try{
            if(!isNilObj(params)){
                Object val = params.get(key);

                if(!isNilObj(val)){
                    return Integer.parseInt(val.toString());
                }
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }

        return null;
    }

    protected String getMapStr(Map params, String key, String returnNull){
        try{
            if(!isNilObj(params)){
                Object val = params.get(key);

                if(!isNilObj(val)){
                    return val.toString();
                }
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }

        return returnNull;
    }

}
