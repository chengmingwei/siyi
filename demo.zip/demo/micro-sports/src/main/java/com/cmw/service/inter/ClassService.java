package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.ClassEntity;

import java.util.List;
import java.util.Map;


/**
 * 班级  Service接口
 * @author 程明卫
 * @date 2019-04-10 14:02:43
 */
@Description(remark="班级业务接口",createDate="2019-04-10 14:02:43",author="程明卫")
public interface ClassService extends IService<ClassEntity, Long> {

    List<Map<String, Object>> getListByPars(Map<String, Object> params);
}
