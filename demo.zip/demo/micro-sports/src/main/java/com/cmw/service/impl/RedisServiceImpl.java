package com.cmw.service.impl;

import com.cmw.client.UserClient;
import com.cmw.constant.GlobalConstant;
import com.cmw.core.cache.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ClassName RedisServiceImpl
 * @Description: Redis Service 公共业务类
 * @Author cheng
 * @Date 2020/8/31
 * @Version V1.0
 **/
@Service("redisService")
public class RedisServiceImpl extends RedisService {
    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private UserClient userClient;

    @Override
    public void loadUserList(List<String> userIdList) {
        userClient.load(userIdList, GlobalConstant.FEIGN_REQUEST_KEY);
    }

    @Override
    public RedisTemplate getRedisTemplate() {
        return redisTemplate;
    }
}
