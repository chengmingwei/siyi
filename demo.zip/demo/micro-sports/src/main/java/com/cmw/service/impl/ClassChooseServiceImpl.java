package com.cmw.service.impl;


import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.ClassChooseDao;
import com.cmw.entity.ClassChooseEntity;
import com.cmw.entity.StudentDetailEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassChooseService;
import com.cmw.service.inter.ClassGoService;
import com.cmw.service.inter.StudentDetailService;
import com.cmw.service.inter.StudentService;
import com.cmw.util.BeanUtil;
import com.cmw.util.DateUtil;
import com.cmw.util.SHashMap;
import com.cmw.util.UserUtil;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 选/转班表  Service实现类
 * @author 程明卫
 * @date 2019-04-20 12:06:21
 */
@Description(remark="选/转班表业务实现类",createDate="2019-04-20 12:06:21",author="程明卫")
@Service("classChooseService")
public class ClassChooseServiceImpl extends AbsService<ClassChooseEntity, Long> implements  ClassChooseService {
	@Autowired
	private ClassChooseDao classChooseDao;

	@Autowired
	private StudentDetailService studentDetailService;

	@Autowired
	private ClassGoService classGoService;

	@Autowired
	private StudentService studentService;

	@Override
	public GenericDaoInter<ClassChooseEntity, Long> getDao() {
		return classChooseDao;
	}



	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		return saveClassChooseByImport(params);
	}

	@Override
	public Map<String,Object> saveClassChooseByImport(SHashMap<String, Object> params) {
		ClassChooseEntity entity = null;

		try {
			entity = BeanUtil.copyValue(ClassChooseEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
		validInfo(entity);
		Integer xstatus = entity.getXstatus();
		Long oldClassId = entity.getOldClassId();
		String remark = "选班";
		if((xstatus != null && xstatus.intValue() == BussContant.CLASSCHOOSE_XSTATUS_1) && null != oldClassId){
			ClassChooseEntity _centity = getClassChooseEntity(oldClassId, entity.getStudentId(),true);
			entity.setId(_centity.getId());
			remark = "转班";
			String goTime = DateUtil.dateFormatToStr(DateUtil.DATE_TIME_FORMAT2, new Date());
			Map<String,Object> _pars = new HashMap<>();
			_pars.put("id", entity.getId());
			_pars.put("goTime", goTime);
			deleteByPars(_pars);
		}
		if(xstatus != null && xstatus.intValue() == BussContant.CLASSCHOOSE_XSTATUS_3){ //退班
			ClassChooseEntity _centity = getClassChooseEntity(entity.getClassId(), entity.getStudentId(),false);
			entity.setId(_centity.getId());
		}

		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		if(null == entity.getId()){
			UserUtil.setCreateInfo(userInfo, entity);
			insert(entity);
		}else{
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);
		}
		Map<String,Object> pars = new HashMap<>();
		pars.put("studentId", entity.getStudentId());
		StudentDetailEntity studentDetailEntity = studentDetailService.getByPars(pars);
		UserUtil.setModifyInfo(userInfo, studentDetailEntity);
		if(xstatus != null && xstatus.intValue() == BussContant.CLASSCHOOSE_XSTATUS_3){
			studentDetailEntity.setClassId(null);
			remark ="学员于:"+ DateUtil.dateFormatToStr(DateUtil.DATE_TIME_FORMAT2,new Date()) +"已退班";
			Map<String,Object> _pars = new HashMap<>();
			_pars.put("id", entity.getId());
			deleteByPars(_pars);
		}else{
			studentDetailEntity.setClassId(entity.getClassId());
		}
		studentDetailEntity.setRemark(remark);
		studentDetailService.update(studentDetailEntity);
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}

	private ClassChooseEntity getClassChooseEntity(Long oldClassId,Long studentId, boolean isTrans) {
		String msg1 = null;
		String msg2 = null;
		Map<String,Object> pars = new HashMap<>();
		if(isTrans){
			msg1 = "转班时，原转班ID参数:oldClassId 不能为空!";
			msg2 = "转班时，根据oldClassId="+oldClassId+" 找不到选班记录!";
		}else{
			msg1 = "退班时，原转班ID参数:classId 不能为空!";
			msg2 = "退班时，根据classId="+oldClassId+" 找不到选班记录!";
			pars.put("xtag","doing");
		}
		if(null == oldClassId) throw new ServiceException(msg1);

		pars.put("classId", oldClassId);
		pars.put("studentId", studentId);
		List<ClassChooseEntity> _centitys = getList(pars);
		if(null == _centitys || _centitys.size() == 0) throw new ServiceException(msg2);
		return _centitys.get(0);
	}


	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(ClassChooseEntity entity) {
		Long studentId = entity.getStudentId();
		if(null == studentId){
			throw new ServiceException("学生ID不能为空！");
		}
		if(null == entity.getClassId()){
			throw new ServiceException("班级ID不能为空！");
		}
		Integer xstatus =entity.getXstatus();
		if((null == xstatus || xstatus.intValue() == BussContant.CLASSCHOOSE_XSTATUS_0) && entity.getId() == null){
			Map<String,Object> pars = new HashMap<>();
			pars.put("classId", entity.getClassId());
			pars.put("studentId", entity.getStudentId());
			pars.put("xtag", "doing");
			List<ClassChooseEntity> _entitys = getList(pars);
			if(null != _entitys && _entitys.size() > 0){
				throw new ServiceException("当前学生已分配到了你选择的班级!");
			}
		}
		StudentEntity studentEntity = studentService.get(studentId);
		Integer s_xstatus = studentEntity.getXstatus();
//		if(s_xstatus.intValue() < BussContant.STUDENT_XSTATUS_4){
//			throw new ServiceException("当前学生还未报名我们的课程，请先报名!");
//		}

		if(s_xstatus.intValue() != BussContant.STUDENT_XSTATUS_2 && s_xstatus.intValue() != BussContant.STUDENT_XSTATUS_3 &&
				s_xstatus.intValue() != BussContant.STUDENT_XSTATUS_4 && s_xstatus.intValue() != BussContant.STUDENT_XSTATUS_5){
			throw new ServiceException("当前学生还未报名我们的课程，请先报名!");
		}
	}

	@Override
	public List<Map<String, Object>> getStudents(Map<String, Object> pars) {
		return classChooseDao.getStudents(pars);
	}

	@Override
	@Transactional
	public void deleteByPars(Map<String, Object> params) throws ServiceException {
		Long id = (Long)params.get("id");
		UserModel userInfo = (UserModel) params.get("userInfo");
		String goTime = (String)params.get("goTime");
		ClassChooseEntity classChooseEntity = get(id);
		Long studentId = classChooseEntity.getStudentId();
		Long classId = classChooseEntity.getClassId();

		Map<String,Object> pars = new HashMap<>();
		pars.put("studentId", studentId);
		pars.put("classId", classId);
		if(!StringUtils.isEmpty(goTime)) pars.put("goTime", goTime);
//		Integer fcount = classGoService.getFinishCount(pars);
//		if(null != fcount && fcount.intValue() > 0){
//			throw new ServiceException("当前学员已经在本班有上课记录，不能移除或退班！");
//		}

		classChooseEntity.setIsenabled(SysContant.ISENABLED_DEL_1);
		classChooseEntity.setXstatus(BussContant.CLASSCHOOSE_XSTATUS_3);
		UserUtil.setModifyInfo(userInfo, classChooseEntity);
		update(classChooseEntity);
		classGoService.deleteByPars(pars);
	}
}
