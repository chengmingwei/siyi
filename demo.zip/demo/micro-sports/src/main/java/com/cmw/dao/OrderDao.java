package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.OrderEntity;
import org.springframework.stereotype.Component;


/**
 * 订单表  Mapper接口
 * @author 程明卫
 * @date 2019-05-07 21:22:03
 */
@Description(remark="订单表DAO Mapper接口",createDate="2019-05-07 21:22:03",author="程明卫")
@Component
@Mapper
public interface OrderDao extends GenericDaoInter<OrderEntity, Long>{

    /**
     * 获取订单列表
     * @Author 肖家添
     * @Date 2019/6/13 17:46
     */
    List<Map<String, Object>> getOrderList(Map<String, Object> params);

    /**
     * 获取订单课程
     * @Author 肖家添
     * @Date 2019/6/14 15:44
     */
    List<Map<String, Object>> getOrderCourse(Long orderId);
    
    /**
     * 获取订单列表 -> 根据课程Id和学生Id分组
     * @Author 肖家添
     * @Date 2019/9/9 11:22
     */
    List<Map<String, Object>> getOrderListGroupByCourseAndStu(Map<String, Object> params);

}
