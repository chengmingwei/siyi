package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.AttachmentEntity;


/**
 * 附件表  Service接口
 * @author 程明卫
 * @date 2019-04-10 22:18:30
 */
@Description(remark="附件表业务接口",createDate="2019-04-10 22:18:30",author="程明卫")
public interface AttachmentService extends IService<AttachmentEntity, Long> {

    String getFilePathsByIds(String[] idList);

}
