package com.cmw.entity;


import com.cmw.constant.back.BussContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;


/**
 * 学生报名
 * @author 程明卫
 * @date 2019-04-10 14:07:54
 */
@Description(remark="学生报名实体",createDate="2019-04-10 14:07:54",author="程明卫")
@Entity
@Table(name="GL_Enroll")
@SuppressWarnings("serial")
public class EnrollEntity extends IdBaseEntity {

	@Description(remark="审批状态")
	@Column(name="axstatus" ,nullable=false )
	private Integer axstatus= AXSTATUS_0;

	@Description(remark="付款方式")
	@Column(name="payType" ,nullable=false )
	private Integer payType= PAYTYPE_0;

	@Description(remark="订单编号")
	@Column(name="code" )
	private String code = "000000";
	
	 @Description(remark="订单支付时间")
	 @Column(name="payDate" )
	 private Date payDate;

	@Description(remark="已用课时")
	@Column(name="uhours" ,nullable=false )
	private Integer uhours = 0;

	@Description(remark="存量消耗课时")
	@Column(name="stockUhours" ,nullable=false )
	private Integer stockUhours = 0;

	@Description(remark="订单类型")
	@Column(name="otype" ,nullable=false )
	private Integer otype= BussContant.ENROLL_OTYPE_0;

	 @Description(remark="订单状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus= BussContant.ENROLL_XSTATUS_0;

	 @Description(remark="课时有效期")
	 @Column(name="endDate" ,nullable=false )
	 private Date endDate;

	 @Description(remark="课时有效期")
	 @Column(name="startDate" ,nullable=false )
	 private Date startDate;

	 @Description(remark="实际价格")
	 @Column(name="payPrice" ,nullable=false ,scale=2)
	 private BigDecimal payPrice = new BigDecimal("0.00");

	 @Description(remark="订单总价")
	 @Column(name="totalPrice" ,nullable=false ,scale=2)
	 private BigDecimal totalPrice = new BigDecimal("0.00");

	 @Description(remark="赠送课时")
	 @Column(name="ghours" ,nullable=false )
	 private Integer ghours = 0;

	 @Description(remark="购买课时")
	 @Column(name="hours" ,nullable=false )
	 private Integer hours = 0;

	 @Description(remark="购买方式")
	 @Column(name="btype" ,nullable=false )
	 private Integer btype = BussContant.ENROLL_BTYPE_1;

	 @Description(remark="课程单价")
	 @Column(name="price" ,nullable=false ,scale=2)
	 private BigDecimal price  = new BigDecimal("0.00");

	 @Description(remark="课程ID")
	@Column(name="courseId" ,nullable=false )
	private Long courseId;

	 @Description(remark=" 学员ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;
	/**----- 转课用到 Date:2019-08-06 12:20 CODE START -----**/
	@Description(remark="转出课时")
	@Column(name="thours" ,nullable=false)
	private Integer thours = 0;

	@Description(remark="是否补差价",defaultVals = "0:无,1:不补差价,2:补差价")
	@Column(name="diffPrice")
	private Byte diffPrice = new Byte("0");

	@Description(remark="转班ID",defaultVals = "FK GL_ClassChoose 表ID")
	@Column(name="cchooseId")
	private Long cchooseId;

	// Date:2020-07-11 13:47
	@Description(remark="转出时间")
	@Column(name="rollTime")
	private Date rollTime;
	/**----- 转课用到 Date:2019-08-06 12:20 CODE END -----**/

	@Description(remark="审批人",defaultVals = "FK TS_User 表ID")
	@Column(name="auditUser")
	private Long auditUser;

	@Description(remark="审批时间")
	@Column(name="auditTime")
	private Date auditTime;

	@Description(remark="审批内容")
	@Column(name="content", length = 200)
	private String content;
	/**----- 赠送课时审批用到 Date:2019-10-15 15:06 CODE END -----**/

	@Description(remark="报名说明")
	@Column(name="explains", length = 200)
	private String explains;


	public EnrollEntity() {

	}

	public Date getRollTime() {
		return rollTime;
	}

	public void setRollTime(Date rollTime) {
		this.rollTime = rollTime;
	}

	public String getExplains() {
		return explains;
	}

	public void setExplains(String explains) {
		this.explains = explains;
	}

	public Long getAuditUser() {
		return auditUser;
	}

	public void setAuditUser(Long auditUser) {
		this.auditUser = auditUser;
	}

	public Date getAuditTime() {
		return auditTime;
	}

	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getStockUhours() {
		return stockUhours;
	}

	public void setStockUhours(Integer stockUhours) {
		this.stockUhours = stockUhours;
	}

	public Integer getUhours() {
		return uhours;
	}

	public void setUhours(Integer uhours) {
		this.uhours = uhours;
	}

	public Integer getAxstatus() {
		return axstatus;
	}

	public void setAxstatus(Integer axstatus) {
		this.axstatus = axstatus;
	}

	public Integer getPayType() {
		return payType;
	}

	public void setPayType(Integer payType) {
		this.payType = payType;
	}

	public Integer getOtype() {
		return otype;
	}

	public void setOtype(Integer otype) {
		this.otype = otype;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	/**
	  * 设置订单支付时间的值
	 * @param 	payDate	 订单支付时间
	**/
	public void setPayDate(Date  payDate){
		 this.payDate=payDate;
 	}

	/**
	  * 获取订单支付时间的值
	 * @return 返回订单支付时间的值
	**/
	public Date getPayDate(){
		 return payDate;
 	}

	/**
	  * 设置订单状态的值
	 * @param 	xstatus	 订单状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取订单状态的值
	 * @return 返回订单状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置课时有效期的值
	 * @param 	endDate	 课时有效期
	**/
	public void setEndDate(Date  endDate){
		 this.endDate=endDate;
 	}

	/**
	  * 获取课时有效期的值
	 * @return 返回课时有效期的值
	**/
	public Date getEndDate(){
		 return endDate;
 	}

	/**
	  * 设置课时有效期的值
	 * @param 	startDate	 课时有效期
	**/
	public void setStartDate(Date  startDate){
		 this.startDate=startDate;
 	}

	/**
	  * 获取课时有效期的值
	 * @return 返回课时有效期的值
	**/
	public Date getStartDate(){
		 return startDate;
 	}

	/**
	  * 设置实际价格的值
	 * @param 	payPrice	 实际价格
	**/
	public void setPayPrice(BigDecimal  payPrice){
		 this.payPrice=payPrice;
 	}

	/**
	  * 获取实际价格的值
	 * @return 返回实际价格的值
	**/
	public BigDecimal getPayPrice(){
		 return payPrice;
 	}

	/**
	  * 设置订单总价的值
	 * @param 	totalPrice	 订单总价
	**/
	public void setTotalPrice(BigDecimal  totalPrice){
		 this.totalPrice=totalPrice;
 	}

	/**
	  * 获取订单总价的值
	 * @return 返回订单总价的值
	**/
	public BigDecimal getTotalPrice(){
		 return totalPrice;
 	}

	/**
	  * 设置赠送课时的值
	 * @param 	ghours	 赠送课时
	**/
	public void setGhours(Integer  ghours){
		 this.ghours=ghours;
 	}

	/**
	  * 获取赠送课时的值
	 * @return 返回赠送课时的值
	**/
	public Integer getGhours(){
		 return ghours;
 	}

	/**
	  * 设置购买课时的值
	 * @param 	hours	 购买课时
	**/
	public void setHours(Integer  hours){
		 this.hours=hours;
 	}

	/**
	  * 获取购买课时的值
	 * @return 返回购买课时的值
	**/
	public Integer getHours(){
		 return hours;
 	}

	/**
	  * 设置购买方式的值
	 * @param 	btype	 购买方式
	**/
	public void setBtype(Integer  btype){
		 this.btype=btype;
 	}

	/**
	  * 获取购买方式的值
	 * @return 返回购买方式的值
	**/
	public Integer getBtype(){
		 return btype;
 	}

	/**
	  * 设置课程单价的值
	 * @param 	price	 课程单价
	**/
	public void setPrice(BigDecimal  price){
		 this.price=price;
 	}

	/**
	  * 获取课程单价的值
	 * @return 返回课程单价的值
	**/
	public BigDecimal getPrice(){
		 return price;
 	}

	/**
	  * 设置课程ID的值
	 * @param 	courseId	 课程ID
	**/
	public void setCourseId(Long  courseId){
		 this.courseId=courseId;
 	}

	/**
	  * 获取课程ID的值
	 * @return 返回课程ID的值
	**/
	public Long getCourseId(){
		 return courseId;
 	}

	/**
	  * 设置 学员ID的值
	 * @param 	studentId	  学员ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取 学员ID的值
	 * @return 返回 学员ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}

	public Integer getThours() {
		return thours;
	}

	public void setThours(Integer thours) {
		this.thours = thours;
	}

	public Byte getDiffPrice() {
		return diffPrice;
	}

	public void setDiffPrice(Byte diffPrice) {
		this.diffPrice = diffPrice;
	}

	public Long getCchooseId() {
		return cchooseId;
	}

	public void setCchooseId(Long cchooseId) {
		this.cchooseId = cchooseId;
	}

	@Override
	public Object[] getDatas() {
		return new Object[]{payDate,xstatus,endDate,startDate,payPrice,totalPrice,ghours,hours,btype,price,courseId,studentId,rollTime};
	}

	@Override
	public String[] getFields() {
		return new String[]{"payDate","xstatus","endDate","startDate","payPrice","totalPrice","ghours","hours","btype","price","courseId","studentId","rollTime"};
	}

	/**
	 *        @Description(remark="审批状态")
	 * 	@Column(name="axstatus" ,nullable=false )
	 * 	private Integer axstatus= 0;
	 *
	 * 	@Description(remark="付款方式")
	 * 	@Column(name="payType" ,nullable=false )
	 * 	private Integer payType= 0;
	 */
	/**
	 *
	 * 	审批状态 [0:未审批]
	 */
	public static final int AXSTATUS_0 = 0;
	/**
	 * 	审批状态 [1:审批通过]
	 */
	public static final int AXSTATUS_1 = 1;
	/**
	 * 	审批状态 [2:审批不通过]
	 */
	public static final int AXSTATUS_2 = 2;

	/**
	 *
	 * 	付款方式 [0:线下付]
	 */
	public static final int PAYTYPE_0 = 0;
	/**
	 *
	 * 	付款方式 [1:微信付款]
	 */
	public static final int PAYTYPE_1 = 1;
	/**
	 *
	 * 	付款方式 [2:支付宝]
	 */
	public static final int PAYTYPE_2 = 2;

}
