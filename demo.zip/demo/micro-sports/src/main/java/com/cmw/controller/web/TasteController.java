package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.entity.TasteEntity;
import com.cmw.service.inter.TasteService;
import com.cmw.util.DateUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.Map;


/**
 * 学员体验记录  ACTION类
 * @author 程明卫
 * @date 2019-04-10 13:48:24
 */
@Description(remark="学员体验记录ACTION",createDate="2019-04-10 13:48:24",author="程明卫")
@Api(value = "学员体验记录微服务", description = "#CONTROLLER# 2019-04-10 13:48:24 程明卫")
@RestController
@RequestMapping({"/taste"})
public class TasteController{
	@Resource(name="tasteService")
	private TasteService tasteService;


    /**
     * 保存数据
     * /taste/save
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存体验记录信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
        try{
            Map<String, Object> dataResult = (Map<String, Object>)tasteService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }

    }

    @PostMapping(value = "/poster/save")
    public JSONObject saveByPoster(@RequestParam  Map<String,String> param){
        return save(param);
    }

    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
        return save(param);
    }

    /**
     * 详细信息
     * @param  params [id:体验记录ID,studentId:学生ID]
     * @return
     */
    @PostMapping(value = "/get")
    public JSONObject get(@RequestParam Map<String, Object> params){
        String studentId = (String)params.get("studentId");
        String id = (String)params.get("id");
        if(StringUtils.isEmpty(studentId) && StringUtils.isEmpty(id)){
            return PageHandler.getFailureJson("参数：studentId 或 id 两者必须传一个!");
        }
        TasteEntity tasteEntity = tasteService.getByPars(params);
        if(null == tasteEntity){
            return PageHandler.getFailureJson("没有指定的体验记录！");
        }
        Date ndate = tasteEntity.getNdate();
        String ndateStr = null;
        if(null != ndate){
            ndateStr = DateUtil.dateFormatToStr(ndate);
        }
        JSONObject jsonObject = PageHandler.getJson(tasteEntity);
        JSONObject datas = (JSONObject)jsonObject.getJSONObject("datas");
        if(null != datas){
            datas.put("ndate", ndateStr);
            jsonObject.put("datas", datas);
        }
        return jsonObject;
    }
	
}
