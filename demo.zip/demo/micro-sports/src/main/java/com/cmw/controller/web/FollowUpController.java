package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.entity.FollowUpEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.FollowUpService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 学员跟进记录  ACTION类
 * @author 程明卫
 * @date 2019-04-10 13:41:05
 */
@Description(remark="学员跟进记录ACTION",createDate="2019-04-10 13:41:05",author="程明卫")
@Api(value = "学员跟进记录微服务", description = "#CONTROLLER# 2019-04-10 13:41:05 程明卫")
@RestController
@RequestMapping({"/followup"})
public class FollowUpController{
	@Resource(name="followUpService")
	private FollowUpService followUpService;
	
	 /**
     * 跳转主页面
     * @param params
     * @return
     */
     @ApiOperation("学员跟进记录首页API")
    @GetMapping(value = "/home")
    public JSONObject home(Map<String, Object> params) throws Exception{
       List<FollowUpEntity> list = followUpService.getListAll();
       return PageHandler.getJson(list);
    }

    /**
     * 跳转列表页面
     * @param
     * @param params {btype:业务类型[1:根据学生ID获取其跟进记录,2:获取当前用户的跟进记录]
     *               ,studentId:学生ID(当btype=1时必传),
     *               xstatus : 状态[0:待跟进,1:跟进中,2:预约体验,3:已体验,4:跟进结束]
     *               }
     * @return  /followup/wx/list
     */
     @ApiOperation("学员跟进记录列表API")
    @PostMapping(value = "/wx/list")
    public JSONObject list(@RequestParam Map<String,Object> params){
         //studentId,userId,xstatus
         if(null == params.get("btype")){
           return  PageHandler.getFailureJson("参数：btype 不能为空!");
         }
         Integer btype = Integer.parseInt(params.get("btype").toString());
         if(null != btype && btype.intValue() == 2){
             UserModel userInfo = LoginInterceptor.getLoginUser();
             params.put("userId", userInfo.getId());
         }
        List<Map<String,Object>> list = followUpService.getListMap(params);
        return PageHandler.getJson(list);
    }

    /**
     * 跳转列表页面
     * @param
     * @param params {btype:业务类型[1:根据学生ID获取其跟进记录,2:获取当前用户的跟进记录]
     *               ,studentId:学生ID(当btype=1时必传),
     *               xstatus : 状态[0:待跟进,1:跟进中,2:预约体验,3:已体验,4:跟进结束]
     *               }
     * @return
     */
    @ApiOperation("学员跟进记录列表API PC")
    @PostMapping(value = "/list")
    public JSONObject sys_list(@RequestBody Map<String,Object> params){
        Integer btype = Integer.parseInt(params.get("btype").toString());
        if(null != btype && btype.intValue() == 2){
            UserModel userInfo = LoginInterceptor.getLoginUser();
            params.put("userId", userInfo.getId());
        }
        List<Map<String,Object>> list = followUpService.getListMap(params);
        return PageHandler.getJson(list);
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存学员跟进记录")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params) throws Exception{
        try{
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = LoginInterceptor.getLoginUser();
            pars.put(SysContant.USER_INFO, userInfo);
            Map<String, Object> dataResult = (Map<String, Object>)followUpService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param) throws Exception {
        return save(param);
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除学员跟进记录")
    @DeleteMapping(value = "/remove")
    public JSONObject remove(@ApiParam("会员ID") @RequestParam Long id) throws Exception{
        followUpService.delete(id);
        return PageHandler.getSuccessJson();
    }
	
}
