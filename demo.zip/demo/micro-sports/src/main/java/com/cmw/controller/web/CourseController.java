package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.CourseEntity;
import com.cmw.entity.CoursePlanEntity;
import com.cmw.service.inter.CoursePlanService;
import com.cmw.service.inter.CourseService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.export.ExcelExport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 课程信息  ACTION类
 * @author 程明卫
 * @date 2019-04-10 13:59:08
 */
@Description(remark="课程信息ACTION",createDate="2019-04-10 13:59:08",author="程明卫")
@Api(value = "课程信息微服务", description = "#CONTROLLER# 2019-04-10 13:59:08 程明卫")
@RestController
@RequestMapping({"/course"})
public class CourseController{
	@Resource(name="courseService")
    private CourseService courseService;

    @Resource(name="coursePlanService")
    private CoursePlanService coursePlanService;

    /**
     * 获取下拉框等简单控件的数据源
     * @return
     */
    @ApiOperation("根据当前用户和其所在校区课程列表信息，供下拉框等控件使用")
    @PostMapping(value = "/ds")
    public JSONObject getDataSource(@RequestParam Map<String, Object> params){
        params.remove("ids");

        if(null != params.get("experienceCourse")){
            params.put("ids", 87);
        }

        List<Map<String,Object>> dataSource = courseService.getListMap(params);
        JSONObject jsonObject = PageHandler.getJson(dataSource);
        return   jsonObject;
    }


    /**
     * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询用户信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        PageResult<List<Map<String,Object>>> result = courseService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }

    /**
     * 数据导出
     * @Author 肖家添
     * @Date 2019/6/28 17:10
     */
    @ApiOperation("数据导出")
    @PostMapping("/exportData")
    public void exportData(HttpServletRequest request, HttpServletResponse response, @RequestParam Map<String, Object> params){
        List<Map<String, Object>> dataList_LM = ExcelExport.getExportData(this.list(params));

        if(null == dataList_LM) return;

        courseService.exportData(request, response, dataList_LM);
    }

    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取课程信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("学员信息ID") @PathVariable("id") Long id, @RequestParam Map<String,Object> params){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        CourseEntity obj = courseService.get(id);
        JSONObject jsonObject = PageHandler.getJson(obj);
        if(null == obj){
            return PageHandler.getFailureJson(String.format("找不到ID:%s的课程信息！", id.toString()));
        }

        Integer formType = params.get("formType") == null ? null : Integer.parseInt(params.get("formType").toString());
        Long formId = params.get("formId") == null ? null : Long.parseLong(params.get("formId").toString());
        Long classSetId = params.get("classSetId") == null ? null : Long.parseLong(params.get("classSetId").toString());
        CoursePlanEntity coursePlan = null;
        Map<String,Object> pars = new HashMap<>();
        if(null == formId && null == formType){
            pars.put("formType", "0");
            pars.put("courseId", id);
            coursePlan = coursePlanService.getByPars(pars);
        }else{
            pars.put("formType", formType);
            pars.put("formId", formId);
            coursePlan = coursePlanService.getByPars(pars); //上课课程上查找课程计划
            if(null == coursePlan && null != classSetId){  //上课课程上没有，就根据排课设置去找课程计划
                pars.put("formType", 1);
                pars.put("formId", classSetId);
                coursePlan = coursePlanService.getByPars(pars);
            }
        }
       if(null != coursePlan){
           JSONObject datas = jsonObject.getJSONObject("datas");
           datas.put("coursePlan", coursePlan);
           jsonObject.put("datas", datas);
       }

        return   jsonObject;
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存课程信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
        try{
            Map<String, Object> dataResult = (Map<String, Object>)courseService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }

    }

    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
        return save(param);
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除课程信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("课程ID") @PathVariable("id")  Long id) throws Exception{
        courseService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }
}
