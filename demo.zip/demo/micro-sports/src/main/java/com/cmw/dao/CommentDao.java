package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.CommentEntity;


/**
 * 评论表  Mapper接口
 * @author 程明卫
 * @date 2019-04-20 13:35:01
 */
@Description(remark="评论表DAO Mapper接口",createDate="2019-04-20 13:35:01",author="程明卫")
@Mapper
public interface CommentDao extends GenericDaoInter<CommentEntity, Long>{

    /**
     * 获取评论
     * @Author 肖家添
     * @Date 2019/7/4 4:39 PM
     */
    List<Map<String, Object>> getCommentByPars(Map<String, Object> params);

}
