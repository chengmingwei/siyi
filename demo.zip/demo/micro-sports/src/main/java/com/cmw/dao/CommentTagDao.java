package com.cmw.dao;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.CommentTagEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 评论标签DAO Mapper接口
 * @Author 肖家添
 * @Date 2019/8/13 17:17
 */
@Description(remark="评论标签DAO Mapper接口",createDate="2019-08-13 16:40",author="肖家添")
@Mapper
public interface CommentTagDao extends GenericDaoInter<CommentTagEntity, Long> {
    
    /**
     * 获评论标签
     * @Author 肖家添
     * @Date 2019/8/13 17:17
     */
    List<CommentTagEntity> getCommentTag(Map<String, Object> params);
}
