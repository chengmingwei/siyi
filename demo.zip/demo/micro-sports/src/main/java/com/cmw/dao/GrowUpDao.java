package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.GrowUpEntity;


/**
 * 成长档案表  Mapper接口
 * @author 程明卫
 * @date 2019-04-20 13:52:04
 */
@Description(remark="成长档案表DAO Mapper接口",createDate="2019-04-20 13:52:04",author="程明卫")
@Mapper
public interface GrowUpDao extends GenericDaoInter<GrowUpEntity, Long>{

    /**
     * 获取老师评论列表
     * @Author 程明卫
     * @Date 2019/07/09 09:01
     */
    List<Map<String, Object>> getComments(Map<String, Object> params);
}
