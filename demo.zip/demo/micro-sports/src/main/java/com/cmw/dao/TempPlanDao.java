package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.TempPlanEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;


/**
 * 课次排班表  Mapper接口
 * @author 程明卫
 * @date 2019-04-20 18:25:05
 */
@Description(remark="课次排班表DAO Mapper接口",createDate="2019-04-20 18:25:05",author="程明卫")
@Component
@Mapper
public interface
TempPlanDao extends GenericDaoInter<TempPlanEntity, Long>{

    /**
     * 获取没有生成上课记录或少生成上课记录的数据
     * @param
     * @return
     */
    List<Map<String,Object>> getNoClassGoPlanIds();
    /**
     * 获取要删除的已生成的排课课次
     * @param pars
     * @return
     */
    List<Map<String,Object>> getDellIds(Map<String, Object> pars);

    Long exist(@Param("startTime") String startTime, @Param("endTime") String endTime, @Param("classId") Long classId);

    Date getLastDate(Long classId);

    List<Map<String,Object>> getListMapByClassId(Long classId);

    Long getFinshCount(Map<String, Object> pars);



    /**
     * 根据老师ID获取课次详情
     * @Author 程明卫
     * @Date 2019/5/22 10:56
     */
    List<Map<String, Object>> getListMapByTeacherId(Map<String,Object> params);

    /**
     * 获取课次详情
     * @Author 肖家添
     * @Date 2019/5/17 10:56
     */
    List<Map<String, Object>> getTempPlanDetail(@Param(value = "tempPlanId") Long tempPlanId);

    /**
     * 获取课程表中的课程
     * @Author 肖家添
     * @Date 2019/6/4 18:20
     */
    List<Map<String, Object>> getTempPlanByClassScheduleCard(Map<String, Object> params);
}
