package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.client.UserClient;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.dao.TeacherDao;
import com.cmw.entity.TeacherEntity;
import com.cmw.entity.TempPlanEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.TempPlanService;
import com.cmw.util.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 课次排班表  Conntroller类
 *
 * @author 程明卫
 * @date 2019-04-20 18:25:05
 */
@Description(remark = "课次排班表Conntroller", createDate = "2019-04-20 18:25:05", author = "程明卫")
@Api(value = "课次排班表微服务", description = "#CONTROLLER# 2019-04-20 18:25:05 程明卫")
@RestController
@RequestMapping({"/tempplan"})
public class TempPlanController {

    @Resource(name = "tempPlanService")
    private TempPlanService tempPlanService;

    @Autowired
    TeacherDao teacherDao;

    @Autowired
    private UserClient userClient;

    /**
     * /tempplan/wx/list/{classId}
     * 根据班级ID获取上课情况列表
     *
     * @param classId 班级ID
     * @return
     */
    @ApiOperation("课次排班表列表API")
    @PostMapping(value = "/wx/list/{classId}")
    public JSONObject getListMapByClassId(@PathVariable("classId") Long classId) {
        List<Map<String, Object>> dataList = tempPlanService.getListMapByClassId(classId);
        return PageHandler.getJson(dataList);
    }

    /**
     *
     * -- PC教师详情
     * -- 上课记录
     *  /tempplan/pc/list
     *   teacherId ：
     * @param params [teacherId] 老师ID
     * @return
     */
    @ApiOperation("课次排班表列表API")
    @PostMapping(value = "/pc/list")
    public JSONObject getListMapByTeacherId(@RequestParam Map<String,Object> params) {
        List<Map<String, Object>> list = null;
        Object btagObj = params.get("btag");
        if (null == btagObj) {
            return PageHandler.getFailureJson("参数：btag 不能为空！");
        }
        Integer btag = Integer.parseInt(btagObj.toString());
        switch (btag.intValue()) {
            case 1: { //通过老师ID获取班级信息
                Object teacherIdObj = params.get("teacherId");
                Long teacherId = Long.parseLong(teacherIdObj.toString());
                params.put("teacherIds", teacherId+"");
                list = tempPlanService.getListMapByTeacherId(params);
                break;
            }
        }

        return PageHandler.getJson(list);
    }


    /**
     * 小程序课程表列表查询
     *
     * @param params (className:课程名称,userId:用户ID,xstatus:状态,startTime:时间)
     * @return
     */
    @ApiOperation("课次排班表列表API")
    @PostMapping(value = "/wx/list")
    public JSONObject wx_list(@RequestParam Map<String, Object> params) {
        //  className,userId,xstatus,startTime
        UserModel userModel = LoginInterceptor.getLoginUser();
        Integer utype = userModel.getUtype();
        if(null != utype && utype.intValue() != BussContant.USER_UTYPE_3 ){
            switch (utype){
                case BussContant.USER_UTYPE_2:{ //区域管理员或校长
                    params.put("schoolId", userModel.getIndeptId());
                    break;
                } case BussContant.USER_UTYPE_4:{ //教练
                    params.put("coachId", userModel.getInempId());
                    break;
                } case BussContant.USER_UTYPE_5:{ //班主任
                    params.put("masterId", userModel.getInempId());
                    break;
                }default:{
                    params.put("userId", userModel.getId());
                    break;
                }
            }
        }
//        if(null == utype || utype.intValue() != BussContant.USER_UTYPE_3){
//            params.put("schoolId", userModel.getIndeptId());
//        }

//        Long useId = userModel.getId();
//
//        JSONObject userJSON = userClient.getUserById(useId).getJSONObject("datas");
//        if(null == userJSON){
//            return PageHandler.getFailureJson("无数据");
//        }
//        String userPhone = userJSON.getString("phone");
//
//        Map<String, Object> getTeacherMap = new HashMap<>();
//        getTeacherMap.put("phone", userPhone);
//
//        TeacherEntity teacher = teacherDao.getByPars(getTeacherMap);
//
//        Long teacherId = teacher.getId();
//        Long schoolId = teacher.getSchoolId();
//
//        params.put("right_userId", useId);
//        params.put("right_teacherId", teacherId);
//        params.put("right_teacherSchoolId", schoolId);
//        params.put("notFuzzySearch", "TRUE");

        List<Map<String, Object>> dataList = tempPlanService.getListMap(params);
        return PageHandler.getJson(dataList);
    }

    /**
     * 微信首页即将开始的课程
     *
     * @return
     */
    @ApiOperation("课次排班表列表API")
    @PostMapping(value = "/wx/start")
    public JSONObject home_start(@RequestParam(value = "startTime", required = false) String startTime) {
        if (StringUtils.isEmpty(startTime)) {
            startTime = DateUtil.getDateStr();
        }
        Map<String, Object> params = new HashMap<>();
        params.put("startTime", startTime);
        params.put("xstatus", BussContant.TEMPPLAN_XSTATUS_0);
        return wx_list(params);
    }

    /**
     * 微信首页历史的课程
     *
     * @return
     */
    @ApiOperation("课次排班表列表API")
    @PostMapping(value = "/wx/hist")
    public JSONObject home_hist(@RequestParam(value = "startTime", required = false) String startTime) {
        //  className,userId,xstatus,startTime
        if (StringUtils.isEmpty(startTime)) {
            startTime = DateUtil.getDateStr();
        }
        Map<String, Object> params = new HashMap<>();
        params.put("startTime", startTime);
        params.put("xtag", "finish"); //已经开始
        return wx_list(params);
    }


    /**
     * 分页查询
     * 返回状态码：
     * 404 : 没有查询到任何数据
     *
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询课次排班表信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String, Object> params) {
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String, Object>>> result = tempPlanService.getPageByPars(params, page, pageSize);
        if (result == null) {
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }


    /**
     * 跳转详细页面
     *
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取课次排班表信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("课次排班表ID") @PathVariable("id") Long id) {
        if (!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        TempPlanEntity obj = tempPlanService.get(id);
        JSONObject jsonObject = PageHandler.getJson(obj);
        return jsonObject;
    }


    /**
     * 保存数据
     *
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存课次排班表信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params) {
        try {
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = LoginInterceptor.getLoginUser();
            pars.put(SysContant.USER_INFO, userInfo);
            Map<String, Object> dataResult = (Map<String, Object>) tempPlanService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        } catch (ServiceException ex) {
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }

    }

    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody Map<String, String> param) {
        return save(param);
    }

    /**
     * 移除数据
     *
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除课次排班表信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("#DESCRIPTIONID") @PathVariable("id") Long id) throws Exception {
        tempPlanService.enabled(id, -1);
        return PageHandler.getSuccessJson();
    }

    /**
     * 根据课次ID查询课次详情信息
     * @Author 肖家添
     * @Date 2019/5/17 11:04
     */
    @ApiOperation("根据课次ID查询课次详情信息")
    @PostMapping("/getTempPlanDetail")
    public JSONObject getTempPlanDetail(@RequestParam Map<String, Object> params){
        try{
            Object tempPlanId = params.get("tempPlanId");

            if(StringHandler.isValidObj(tempPlanId)){
                List<Map<String, Object>> tempPlanDetail = tempPlanService.getTempPlanDetail(Long.parseLong(tempPlanId.toString()));

                return PageHandler.getJson(tempPlanDetail);
            }else{
                return PageHandler.getFailureJson("缺少参数");
            }
        }catch (Exception ex){
            ex.printStackTrace();

            return PageHandler.getFailureJson("系统异常");
        }
    }

    /**
     * 更新课次状态
     * @Author 肖家添
     * @Date 2019/6/17 15:05
     */
    @ApiOperation("更新课次状态")
    @PostMapping("/updateTempPlanStatus")
    public JSONObject updateTempPlanStatus(@RequestParam Map<String, Object> params){
        SHashMap params_SH = new SHashMap(params);

        Long tempPlanId = params_SH.getvalAsLng("tempPlanId");
        Integer xStatus = params_SH.getvalAsInt("xstatus");

        if(StringHandler.isValidObj(tempPlanId) && StringHandler.isValidObj(xStatus)){

            TempPlanEntity tempPlan = tempPlanService.get(tempPlanId);

            if(StringHandler.isValidObj(tempPlan) && tempPlan.getId() != null){
                if(xStatus == -1){
                    //-- 取消停课
                    xStatus = this.getXStatusByEntity(tempPlan);
                }

                tempPlan.setXstatus(xStatus);

                tempPlanService.update(tempPlan);

                return PageHandler.getSuccessJson();
            }else{
                return PageHandler.getFailureJson("未找到该课次");
            }
        }else{
            return PageHandler.getFailureJson("参数非法");
        }
    }

    private Integer getXStatusByEntity(TempPlanEntity tempPlan){
        Date startTime = tempPlan.getStartTime();
        Date endTime = tempPlan.getEndTime();

        String pattern = "yyyyMMddHHmmss";

        String newStartTime = DateUtil.dateFormatToStr(pattern, startTime);
        String newEndTime = DateUtil.dateFormatToStr(pattern, endTime);
        String nowTime = DateUtil.dateFormatToStr(pattern, new Date());

        Long newStartTime_Int = Long.parseLong(newStartTime);
        Long newEndTime_Int = Long.parseLong(newEndTime);
        Long nowTime_Int = Long.parseLong(nowTime);

        if(newEndTime_Int < nowTime_Int){
            return 2;
        }else if(newStartTime_Int < nowTime_Int){
            return 1;
        }else {
            return 0;
        }
    }
}
