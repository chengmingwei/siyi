package com.cmw.service.impl;


import com.cmw.client.UserClient;
import com.cmw.constant.SysParamConstant;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.ClassSetDao;
import com.cmw.entity.ClassEntity;
import com.cmw.entity.ClassSetEntity;
import com.cmw.entity.TempPlanEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassGoService;
import com.cmw.service.inter.ClassService;
import com.cmw.service.inter.ClassSetService;
import com.cmw.service.inter.TempPlanService;
import com.cmw.util.*;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.*;

import static com.cmw.constant.SysParamConstant.CLASSSET_CLASSGO_TYPEDEL_VAL_0;


/**
 * 排班设置表  Service实现类
 * @author 程明卫
 * @date 2019-04-20 18:21:37
 */
@Description(remark="排班设置表业务实现类",createDate="2019-04-20 18:21:37",author="程明卫")
@Service("classSetService")
public class ClassSetServiceImpl extends AbsService<ClassSetEntity, Long> implements  ClassSetService {
	@Autowired
	private ClassSetDao classSetDao;

	@Autowired
	private ClassService classService;

	@Autowired
	private TempPlanService tempPlanService;

	@Resource(name="classGoService")
	private ClassGoService classGoService;

	@Autowired
	private StringRedisTemplate stringRedisTemplate;

	@Autowired
	private UserClient userClient;

	@Override
	public GenericDaoInter<ClassSetEntity, Long> getDao() {
		return classSetDao;
	}



	@Override
	@Transactional
	public void deleteByPars(Map<String, Object> params) throws ServiceException {
		Long id = (Long)params.get("id");
		UserModel userInfo = (UserModel)params.get(SysContant.USER_INFO);
		//validInfoOnDel(id);
		Map<String,Object> pars = new HashMap<>();
		pars.put("sid", id);

		Long fcount = tempPlanService.getFinshCount(pars);
		if(null != fcount && fcount.intValue() > 0){
			//throw new ServiceException("当前排班设置已经有排课并且已经有上课记录，不能删除!");
			//tempPlanService.enabledByPars(pars,-1);
			delClassGoBySysParams(id);
		}
		enabled(id, -1);
	}

	void delClassGoBySysParams(Long classSetId){
		Map<String,Object> pars = new HashMap<>();
		pars.put("sid", classSetId);
		String typeDel = getSysparamsByCache();
		pars.put("currTime", DateUtil.dateFormatToStr("yyyy-MM-dd HH:mm", new Date()));
		pars.put("typeDel", typeDel);
		String ids = tempPlanService.getDellIds(pars);
		if(StringUtils.isEmpty(ids)){
			log.info("GL_TempPlan 表没有要删除的排课记录！");
			return;
		}
		pars.clear();
		pars.put("ids", ids);
		tempPlanService.enabledByPars(pars,-1);
		pars.clear();
		pars.put("planIds", ids);
		classGoService.enabledByPars(pars, -1);
	}

	/**
	 *	从Redis 中获取排课删除类型
	 * @return
	 */
	private String getSysparamsByCache() {
		String key = SysParamConstant.getKey(SysParamConstant.CLASSSET_CLASSGO_TYPEDEL);
		String typeDel = stringRedisTemplate.opsForValue().get(key);
		if(StringUtils.isEmpty(typeDel)){
			userClient.loadSysparamsToRedis(SysParamConstant.CLASSSET_CLASSGO_TYPEDEL);
			typeDel = stringRedisTemplate.opsForValue().get(key);
		}
		if(StringUtils.isEmpty(typeDel)){
			typeDel = CLASSSET_CLASSGO_TYPEDEL_VAL_0;
		}
		return typeDel;
	}


	private void validInfoOnDel(Long classSetId) {
		Map<String,Object> pars = new HashMap<>();
		pars.put("sid", classSetId);
		pars.put("xstatus", 1);
		Long total = tempPlanService.getTotals(pars);
		if(null != total && total >0){
			throw new ServiceException("本次排课信息不能删除，因为已经有了上课记录！");
		}
	}

	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		ClassSetEntity entity = null;
		try {
			entity = BeanUtil.copyValue(ClassSetEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
		if(null == entity.getPtype()) entity.setPtype(BussContant.CLASSSET_PTYPE_1);
		if(null == entity.getRuleVals()) entity.setRuleVals("0");
		String ruleNames = getRuleNames(entity);
		entity.setRuleNames(ruleNames);
		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		if(null == entity.getId()){
			UserUtil.setCreateInfo(userInfo, entity);
			insert(entity);
		}else{
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);
		}

		ClassEntity classEntity = classService.get(entity.getClassId());
		Date lastDate = doPlanClasses(classEntity, userInfo);
		if(null != lastDate){
			updateClass(classEntity, userInfo, lastDate, entity.getPtype());
		}
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}



	/**
	 * 更新 Class 表排课类型
	 * @param  entity
	 * @param userInfo
	 * @param lastDate
	 * @param ptype
	 * @return
	 */
	private void updateClass(ClassEntity entity,UserModel userInfo,Date lastDate, Integer ptype){
//		UserUtil.setModifyInfo(userInfo, entity);
//		entity.setPtype(ptype);
//		entity.setLastDate(lastDate);

		Map<String,Object> whereParams = new HashMap<>();
		whereParams.put("id", entity.getId());

		Map<String,Object> params = new HashMap<>();
		params.put("id", entity.getId());
		params.put("ptype", ptype);
		params.put("lastDate", lastDate);
		params.put("modifytime", new Date());
		params.put("modifier", userInfo.getId());


		classService.updateByPars(params, whereParams);
		//classService.update(entity);
		//return entity;
	}

	private String getRuleNames(ClassSetEntity entity) {
		String ruleVals = entity.getRuleVals();
		if(StringUtils.isEmpty(ruleVals) || ruleVals.equals("0")){
			return "每天";
		}else{
			String[] rvals = ruleVals.split(",");
			StringBuilder sbWk = new StringBuilder();
			for(String r : rvals){
				int w_v = Integer.parseInt(r);
				switch (w_v){
					case BussContant.WEEK_VAL_ONE :{
						sbWk.append(BussContant.WEEK_NAME_ONE).append(",");
						break;
					}case BussContant.WEEK_VAL_TWO :{
						sbWk.append(BussContant.WEEK_NAME_TWO).append(",");
						break;
					}case BussContant.WEEK_VAL_THREE :{
						sbWk.append(BussContant.WEEK_NAME_THREE).append(",");
						break;
					}case BussContant.WEEK_VAL_FOUR :{
						sbWk.append(BussContant.WEEK_NAME_FOUR).append(",");
						break;
					}case BussContant.WEEK_VAL_FIVE :{
						sbWk.append(BussContant.WEEK_NAME_FIVE).append(",");
						break;
					}case BussContant.WEEK_VAL_SIX :{
						sbWk.append(BussContant.WEEK_NAME_SIX).append(",");
						break;
					}case BussContant.WEEK_VAL_SEVEN :{
						sbWk.append(BussContant.WEEK_NAME_SEVEN).append(",");
						break;
					}
				}
			}
			return  StringHandler.RemoveStr(sbWk);
		}
	}


	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(ClassSetEntity entity) {
		if(StringUtils.isEmpty(entity.getEtime())){
			throw new ServiceException("下课时间不能为空!");
		}

		if(StringUtils.isEmpty(entity.getStime())){
			throw new ServiceException("上课时间不能为空!");
		}

		if(StringUtils.isEmpty(entity.getRuleVals())){
			throw new ServiceException("循环规则值不能为空!");
		}

		if(!StringUtils.isEmpty(entity.getRuleVals()) && entity.getRuleVals().length() > 100){
			throw new ServiceException("循环规则值长度不能超过100!");
		}

		if(StringUtils.isEmpty(entity.getRuleNames())){
			throw new ServiceException("循环规则名称不能为空!");
		}

		if(!StringUtils.isEmpty(entity.getRuleNames()) && entity.getRuleNames().length() > 100){
			throw new ServiceException("循环规则名称长度不能超过100!");
		}

		if(null == entity.getPtype()){
			throw new ServiceException("排课类型不能为空!");
		}

		if(null == entity.getClassId()){
			throw new ServiceException("班级ID不能为空!");
		}
		String stimeStr = entity.getStime();
		String etimeStr = entity.getEtime();
		int stime = convertMinutes(stimeStr);
		int etime = convertMinutes(etimeStr);
		if(etime <= stime){
			throw new ServiceException("结束时间必须大于开始时间！");
		}
		checkRepeat(entity);
	}

	/**
	 * 根据排班设置生成课次排班表
	 * @param
	 * @param userInfo
	 */
	public Date doPlanClasses(ClassEntity classEntity, UserModel userInfo){

		Date sdate = classEntity.getSdate();
		Long classId = classEntity.getId();
		Long master = classEntity.getMaster();
		Long coach = classEntity.getCoach();
		Object[] datas = getTempPlanDatas(classEntity, sdate);
		if(null == datas) return null;
		List<Object[]> planDateList  = (List<Object[]>)datas[0];
		Date n_lastTime =  (Date)datas[1];

		for(Object[] seDates : planDateList){
			Date startTime = (Date)seDates[0];
			Date endTime = (Date)seDates[1];
			Long sid = (Long)seDates[2];
			TempPlanEntity tempPlanEntity = new TempPlanEntity();
			tempPlanEntity.setSid(sid);
			tempPlanEntity.setClassId(classId);
			tempPlanEntity.setCoach(coach);
			tempPlanEntity.setMaster(master);
			tempPlanEntity.setStartTime(startTime);
			tempPlanEntity.setEndTime(endTime);
			tempPlanEntity.setCtype(3);
			tempPlanEntity.setXstatus(0);
			if(null != userInfo){
				UserUtil.setCreateInfo(userInfo, tempPlanEntity);
			}else{
				UserUtil.setCreateInfoBySystem(tempPlanEntity);
			}
			tempPlanService.insert(tempPlanEntity);
		}
		return n_lastTime;
	}

	private Object[] getTempPlanDatas(ClassEntity classEntity, Date sdate) {
		Long classId = classEntity.getId();
		Date lastDate = classEntity.getLastDate();
		Date makeDate = sdate;
		if(null != lastDate){
			makeDate = lastDate;
		}
		List<Object[]> planDateList  = new ArrayList<>();
		Date n_lastTime = makeDate;
		int sdate_week = DateUtil.getDayOfWeek(sdate);
		Map<String,Object> map = new HashMap<>();
		map.put("classId", classId);
		List<ClassSetEntity> setList = getList(map);
		if(null == setList || setList.size() == 0) return null;
		List<TempPlanEntity> tplanList = tempPlanService.getList(map);
		for(ClassSetEntity classSetObj : setList){
			String ruleVals = classSetObj.getRuleVals();
			String[] rvArr = ruleVals.split(",");
			for(String rv : rvArr){
				int rv_week = Integer.parseInt(rv);
				if(rv_week < sdate_week) continue;
				String stimeStr = classSetObj.getStime();
				String etimeStr = classSetObj.getEtime();
				int z_day = rv_week - sdate_week;
				if(z_day < 0) z_day = 0;
				int[] s_hm = getHourAndMinute(stimeStr);
				int[] e_hm = getHourAndMinute(etimeStr);
				Date n_date = DateUtil.addDaysToDate(makeDate, z_day);
				Date startTime = DateUtil.addHourAndMinute(n_date,s_hm[0],s_hm[1]);
				Date endTime = DateUtil.addHourAndMinute(n_date,e_hm[0],e_hm[1]);
				if(isBreak(tplanList, startTime, endTime)) continue;
				if(startTime.getTime() < makeDate.getTime()) continue;	//当开始时间小于开班时间时，跳过。
				if(endTime.getTime() <= new Date().getTime()){//当排课结止时间小于或等于当前时间时，跳过。
					log.error(DateUtil.dateFormatToStr("["+DateUtil.DATE_TIME_FORMAT2,endTime)+"]截止时间小于当前时间，排课过期");
					continue;
				}
				if(endTime.getTime() > n_lastTime.getTime()){
					n_lastTime = endTime;
				}
				Object[] dateArr = {startTime, endTime, classSetObj.getId()};
				planDateList.add(dateArr);
			}
		}
		return new Object[]{planDateList, n_lastTime};
	}

	/**
	 * 如果以前生成过排课计划，则跳过。否则，会重复生成
	 * @param tplanList
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	private boolean isBreak(List<TempPlanEntity> tplanList, Date startTime, Date endTime){
		boolean flag = false;
		if(null == tplanList || tplanList.isEmpty()) return flag;
		for(TempPlanEntity tplanObj : tplanList){
			Date _startTime = tplanObj.getStartTime();
			Date _endTime = tplanObj.getEndTime();
			if(_startTime.getTime() == startTime.getTime() &&
			 _endTime.getTime() == endTime.getTime()){
				flag = true;
				break;
			}
		}
		return flag;
	}

	private int[] getHourAndMinute(String stime){
		String[] hmArr = stime.split(":");
		int hour = Integer.parseInt(hmArr[0]);
		int minute = Integer.parseInt(hmArr[1]);
		return new int[]{hour, minute};
	}

	/**
	 * 检查排课时间是否存在冲突
	 * @param classSetObj
	 */
	private void checkRepeat(ClassSetEntity classSetObj){
		Long classId = classSetObj.getClassId();
		Map<String,Object> pars = new HashMap<>();
		pars.put("classId",classId);
		List<ClassSetEntity> osetList = classSetDao.getList(pars);
		if(null == osetList || osetList.isEmpty()) return;
		boolean flag = hasRepeat(classSetObj, osetList);
		if(flag){
			throw new ServiceException("排课时间存在冲突!");
		}
	}

	/**
	 * 排课时间上是否存在冲突
	 * @param classSetObj
	 * @param osetList
	 * @return
	 */
	private boolean hasRepeat(ClassSetEntity classSetObj, List<ClassSetEntity> osetList) {
		String n_ruleVals = classSetObj.getRuleVals();
		String[] n_rvArr = n_ruleVals.split(",");
		int n_stime = convertMinutes(classSetObj.getStime());
		int n_etime = convertMinutes(classSetObj.getEtime());
		for(ClassSetEntity classSetEntity : osetList){
			boolean isSame = getSameDay(n_rvArr, classSetEntity);
			if(!isSame) continue;
			String stimeStr = classSetEntity.getStime();
			String etimeStr = classSetEntity.getEtime();
			int stime = convertMinutes(stimeStr);
			int etime = convertMinutes(etimeStr);
			if(n_stime >= stime && n_stime <= etime){
				return true;
			}
			if(n_etime >= stime && n_etime <= etime){
				return true;
			}
		}
		return false;
	}

	/**
	 * 将时间字符串转换成分钟比较时间大小
	 * @param timeStr
	 * @return
	 */
	private int convertMinutes(String timeStr){
		String[] hmStr = timeStr.split(":");
		int h = Integer.parseInt(hmStr[0]);
		int m = Integer.parseInt(hmStr[1]);
		return m + h * 60;
	}

	private boolean getSameDay(String[] n_rvArr, ClassSetEntity classSetEntity) {
		String ruleVals = classSetEntity.getRuleVals();
		String[] rvArr = ruleVals.split(",");
		for(String rv : rvArr){
			for(String n_rv : n_rvArr){
				if(rv.equals(n_rv)){
					return true;
				}
			}
		}
		return false;
	}
}
