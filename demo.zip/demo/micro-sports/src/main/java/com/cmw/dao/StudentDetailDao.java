package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.StudentDetailEntity;


/**
 * 学员详细信息  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 11:39:22
 */
@Description(remark="学员详细信息DAO Mapper接口",createDate="2019-04-10 11:39:22",author="程明卫")
@Mapper
public interface StudentDetailDao extends GenericDaoInter<StudentDetailEntity, Long>{

}
