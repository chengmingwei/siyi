package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import java.util.Date;


/**
 * 会员详细信息表
 * @author 程明卫
 * @date 2019-04-10 22:13:17
 */
@Description(remark="会员详细信息表实体",createDate="2019-04-10 22:13:17",author="程明卫")
@Entity
@Table(name="GL_MemberDetail")
@SuppressWarnings("serial")
public class MemberDetailEntity extends IdBaseEntity {
	
	
	 @Description(remark="注册来源")
	 @Column(name="rsource" ,nullable=false )
	 private Integer rsource = 1;

	 @Description(remark="推荐人手机号")
	 @Column(name="sphone" ,length=20 )
	 private String sphone;

	 @Description(remark="邀请码")
	 @Column(name="shareCode" ,length=20 )
	 private String shareCode;

	 @Description(remark="登录日志ID")
	 @Column(name="logId" ,nullable=false )
	 private Long logId;

	 @Description(remark="锁定时长")
	 @Column(name="duration" )
	 private String duration;

	 @Description(remark="解锁时间")
	 @Column(name="unlockTime" )
	 private Date unlockTime;

	 @Description(remark="锁定时间")
	 @Column(name="lockTime" )
	 private Date lockTime;

	 @Description(remark="密码错误次数")
	 @Column(name="ecount" ,nullable=false )
	 private Integer ecount = 0;

	 @Description(remark="是否锁定")
	 @Column(name="locked" ,nullable=false )
	 private Integer locked = 0;

	 @Description(remark="会员ID")
	 @Column(name="memberId" ,nullable=false )
	 private Long memberId;


	public MemberDetailEntity() {

	}

	
	/**
	  * 设置注册来源的值
	 * @param 	rsource	 注册来源
	**/
	public void setRsource(Integer  rsource){
		 this.rsource=rsource;
 	}

	/**
	  * 获取注册来源的值
	 * @return 返回注册来源的值
	**/
	public Integer getRsource(){
		 return rsource;
 	}

	/**
	  * 设置推荐人手机号的值
	 * @param 	sphone	 推荐人手机号
	**/
	public void setSphone(String  sphone){
		 this.sphone=sphone;
 	}

	/**
	  * 获取推荐人手机号的值
	 * @return 返回推荐人手机号的值
	**/
	public String getSphone(){
		 return sphone;
 	}

	/**
	  * 设置邀请码的值
	 * @param 	shareCode	 邀请码
	**/
	public void setShareCode(String  shareCode){
		 this.shareCode=shareCode;
 	}

	/**
	  * 获取邀请码的值
	 * @return 返回邀请码的值
	**/
	public String getShareCode(){
		 return shareCode;
 	}

	/**
	  * 设置登录日志ID的值
	 * @param 	logId	 登录日志ID
	**/
	public void setLogId(Long  logId){
		 this.logId=logId;
 	}

	/**
	  * 获取登录日志ID的值
	 * @return 返回登录日志ID的值
	**/
	public Long getLogId(){
		 return logId;
 	}

	/**
	  * 设置锁定时长的值
	 * @param 	duration	 锁定时长
	**/
	public void setDuration(String  duration){
		 this.duration=duration;
 	}

	/**
	  * 获取锁定时长的值
	 * @return 返回锁定时长的值
	**/
	public String getDuration(){
		 return duration;
 	}

	/**
	  * 设置解锁时间的值
	 * @param 	unlockTime	 解锁时间
	**/
	public void setUnlockTime(Date  unlockTime){
		 this.unlockTime=unlockTime;
 	}

	/**
	  * 获取解锁时间的值
	 * @return 返回解锁时间的值
	**/
	public Date getUnlockTime(){
		 return unlockTime;
 	}

	/**
	  * 设置锁定时间的值
	 * @param 	lockTime	 锁定时间
	**/
	public void setLockTime(Date  lockTime){
		 this.lockTime=lockTime;
 	}

	/**
	  * 获取锁定时间的值
	 * @return 返回锁定时间的值
	**/
	public Date getLockTime(){
		 return lockTime;
 	}

	/**
	  * 设置密码错误次数的值
	 * @param 	ecount	 密码错误次数
	**/
	public void setEcount(Integer  ecount){
		 this.ecount=ecount;
 	}

	/**
	  * 获取密码错误次数的值
	 * @return 返回密码错误次数的值
	**/
	public Integer getEcount(){
		 return ecount;
 	}

	/**
	  * 设置是否锁定的值
	 * @param 	locked	 是否锁定
	**/
	public void setLocked(Integer  locked){
		 this.locked=locked;
 	}

	/**
	  * 获取是否锁定的值
	 * @return 返回是否锁定的值
	**/
	public Integer getLocked(){
		 return locked;
 	}

	/**
	  * 设置会员ID的值
	 * @param 	memberId	 会员ID
	**/
	public void setMemberId(Long  memberId){
		 this.memberId=memberId;
 	}

	/**
	  * 获取会员ID的值
	 * @return 返回会员ID的值
	**/
	public Long getMemberId(){
		 return memberId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{rsource,sphone,shareCode,logId,duration,unlockTime,lockTime,ecount,locked,memberId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"rsource","sphone","shareCode","logId","duration","unlockTime","lockTime","ecount","locked","memberId"};
	}

}
