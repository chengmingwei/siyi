package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.WxUserInfoEntity;


/**
 * 公众号用户信息  Service接口
 * @author 程明卫
 * @date 2019-08-24 17:10:59
 */
@Description(remark="公众号用户信息业务接口",createDate="2019-08-24 17:10:59",author="程明卫")
public interface WxUserInfoService extends IService<WxUserInfoEntity, Long> {
}
