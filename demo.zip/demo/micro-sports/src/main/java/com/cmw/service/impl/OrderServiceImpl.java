package com.cmw.service.impl;



import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.annotation.UserCache;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.OrderDao;
import com.cmw.entity.EnrollEntity;
import com.cmw.entity.OrderEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.OrderService;
import com.cmw.util.*;
import com.cmw.util.export.ExcelExport;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;


/**
 * 订单表  Service实现类
 * @author 程明卫
 * @date 2019-05-07 21:22:03
 */
@Description(remark="订单表业务实现类",createDate="2019-05-07 21:22:03",author="程明卫")
@Service("orderService")
public class OrderServiceImpl extends AbsService<OrderEntity, Long> implements  OrderService {
	@Autowired
	private OrderDao orderDao;
	@Override
	public GenericDaoInter<OrderEntity, Long> getDao() {
		return orderDao;
	}
	
	@Override
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		OrderEntity entity = createOrder(params);
		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		if(null == entity.getId()){
			UserUtil.setCreateInfo(userInfo, entity);
			insert(entity);
			setCode(entity);
		}else{
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);
		}
		return entity;
	}

	private OrderEntity createOrder(SHashMap<String,Object> params){
		Integer formType = params.getvalAsInt("formType");
		if(null == formType) throw new ServiceException("创建订单时，参数：formType不能为空！");
		OrderEntity orderEntity = new OrderEntity();
		if(formType.intValue() == OrderEntity.FORMTYPE_1){
			EnrollEntity enrollEntity = (EnrollEntity)params.get("sourceFormObj");
			orderEntity.setFormType(formType);
			orderEntity.setFormId(enrollEntity.getId());
			orderEntity.setTotalPrice(enrollEntity.getTotalPrice());
			orderEntity.setOtype(enrollEntity.getOtype());
			orderEntity.setPayDate(enrollEntity.getPayDate());
			orderEntity.setXstatus(enrollEntity.getXstatus());
			orderEntity.setAxstatus(enrollEntity.getAxstatus());
			Integer payType = params.getvalAsInt("payType");
			if(null != payType){
				orderEntity.setPayType(payType);
			}

			//-- new insert, time as 2019-06-18 14:08, Mr.Shaw
			BigDecimal payPrice = params.getvalAsBig("payPrice");
			orderEntity.setPayPrice(payPrice);

			//-- 支付金额大于0, 审批通过
			if(null != payPrice && payPrice.intValue() > 0){
				orderEntity.setAxstatus(BussContant.ENROLL_AXSTATUS_1);
			}
			//-- Mr.Shaw end
		}
		return  orderEntity;
	}

	/**
	 * 设置编号
	 * @param entity
	 */
	private void setCode(OrderEntity entity) {
		String code = CodeRule.getCodeById("R",entity.getId());
		entity.setCode(code);
		orderDao.updateCode(code, entity.getId());
	}

	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(OrderEntity entity) {
		if(null == entity.getPayType()){
			throw new ServiceException("付款方式不能为空!");
		}

		if(null == entity.getAxstatus()){
			throw new ServiceException("审批状态不能为空!");
		}


		if(null == entity.getOtype()){
			throw new ServiceException("订单类型不能为空!");
		}

		if(null == entity.getXstatus()){
			throw new ServiceException("订单状态不能为空!");
		}

		if(null == entity.getPayPrice()){
			throw new ServiceException("实际价格不能为空!");
		}

		if(null == entity.getTotalPrice()){
			throw new ServiceException("订单总价不能为空!");
		}

		if(null == entity.getFormId()){
			throw new ServiceException("业务单ID不能为空!");
		}

		if(null == entity.getFormType()){
			throw new ServiceException("业务类型不能为空!");
		}

		if(StringUtils.isEmpty(entity.getCode())){
			throw new ServiceException("订单编号不能为空!");
		}

		if(StringUtils.isEmpty(entity.getCode()) && entity.getCode().length() > 50){
			throw new ServiceException("订单编号长度不能超过50!");
		}

	}

	@Override
	@UserCache(cmns={"trackerMan"})
	public List<Map<String, Object>> getListMap(Map<String, Object> map) throws ServiceException {
		return super.getListMap(map);
	}

	@Override
	@UserCache(cmns={"empName"})
	public List<Map<String, Object>> getOrderList(Map<String, Object> params) {

		dateBetweenHandler(params, "createPeriod", "payDateBegin", "payDateEnd");

		SHashMap params_SH = new SHashMap(params);

		Integer pageNo = params_SH.getvalAsInt("pageNo");
		Integer pageSize = params_SH.getvalAsInt("pageSize");

		if(StringHandler.isValidObj(pageNo) && pageNo > 0 && StringHandler.isValidObj(pageSize) && pageSize > 0){
			params_SH.remove("pageNo");

			params_SH.put("limit", (pageNo - 1) * pageSize);
			params_SH.put("pageSize", pageSize);
		}

		return orderDao.getOrderList(params);
	}

	@Override
	public List<Map<String, Object>> getOrderCourse(Long orderId) {
		return orderDao.getOrderCourse(orderId);
	}

	@Override
	public void exportData(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM) {
		String[] cellVal = {
				"ID",
				"订单编号",
				"学员姓名",
				"手机号",
				"缴费时间",
				"课程名称",
				"课时数",
				"赠送课时",
				"订单总价",
				"类型",
				"实际支付价格",
				"订单状态",
				"跟进人员",
				"支付方式",
				"学员备注"
		};

		String[] dataKeys = {
				"id",
				"code",
				"sname",
				"phone",
				"payDate",
				"cname",
				"hours",
				"ghours",
				"totalPrice",
				"otype",
				"payPrice",
				"xstatus",
				"empName",
				"payType",
				"studentRemark"
		};

		for(Map<String, Object> data : dataList_LM){
			SHashMap data_SH = new SHashMap<>(data);

			for(String key : dataKeys){
				String val = data_SH.getvalAsStr(key);

				val = StringHandler.isValidStr(val) ? val : "";

				switch (key) {
					//-- 类型
					case "otype":{
						switch (val){
							case "0":{
								val = "新签";
								break;
							}
							case "1":{
								val = "续签";
								break;
							}
						}
						break;
					}
					//-- 订单状态
					case "xstatus":{
						switch (val){
							case "-1":{
								val = "作废";
								break;
							}
							case "0":{
								val = "待支付";
								break;
							}
							case "1":{
								val = "支付成功";
								break;
							}
							case "2":{
								val = "支付失败";
								break;
							}
							case "3":{
								val = "已退费";
								break;
							}
							case "4":{
								val = "已超时";
								break;
							}
							case "5":{
								val = "支付处理中";
								break;
							}
						}
						break;
					}
					//-- 支付方式
					case "payType":{
						switch (val){
							case "0":{
								val = "未知";
								break;
							}
							case "1":{
								val = "线下付";
								break;
							}
							case "2":{
								val = "微信";
								break;
							}
							case "3":{
								val = "支付宝";
								break;
							}
						}
						break;
					}
				}

				data_SH.put(key, val);
			}
		}

		new ExcelExport(request, response).export(cellVal, dataKeys, dataList_LM);
	}
	
	/**
	 * 获取订单列表 -> 根据课程Id和学生Id分组
	 * @Author 肖家添
	 * @Date 2019/9/9 11:27
	 */
	@Override
	public List<Map<String, Object>> getOrderListGroupByCourseAndStu(Map<String, Object> params) {

		//-- 销课期间
		dateBetweenHandler(params, "createPeriod", "goTimeBegin", "goTimeEnd");

		//-- 缴费期间
		dateBetweenHandler(params, "payPeriod", "payDateBegin", "payDateEnd");

		return orderDao.getOrderListGroupByCourseAndStu(params);
	}

	private void dateBetweenHandler(Map<String, Object> params, String key, String beginKey, String endKey){
		SHashMap<String, Object> params_SH = new SHashMap<>(params);

		Object createPeriod = params_SH.get(key);
		if (StringHandler.isValidObj(createPeriod)) {
			params.remove(key);

			List<String> dateList = (List) createPeriod;

			if(dateList.size() == 2){
				String pattern = "yyyy-MM-dd";

				String payDateBegin = DateUtil.dateFormatToStr(DateUtil.dateFormat(pattern, dateList.get(0)));
				String endDate = dateList.get(1);
				String payDateEnd = DateUtil.addDays(endDate,1);
				//String payDateEnd = DateUtil.dateFormatToStr(DateUtil.dateFormat(pattern, ));

				params.put(beginKey, payDateBegin);
				params.put(endKey, payDateEnd);
			}
		}
	}

	@Override
	public void getOrderListGroupByCourseAndStu_exportData(HttpServletRequest request, HttpServletResponse response,  List<Map<String, Object>> dataList_LM) {
		String[] cellVal = {
				"订单Id",
				"订单编号",
				"学生姓名",
				"手机号",
				"缴费时间",
				"课程名称",
				"课时数",
				"赠送课时",
				"订单总价",
				"销课课时",
				"续课次数",
				"学员备注",
		};

		String[] dataKeys = {
				"id",
				"code",
				"sname",
				"phone",
				"payDate",
				"cname",
				"hours",
				"ghours",
				"payPrice",
				"useClassHour",
				"renewalCount",
				"studentRemark"
		};

		new ExcelExport(request, response).export(cellVal, dataKeys, dataList_LM);
	}
}
