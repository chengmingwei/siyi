package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.ExchangeGoEntity;


/**
 * 学员转派  Service接口
 * @author 程明卫
 * @date 2019-04-10 13:51:12
 */
@Description(remark="学员转派业务接口",createDate="2019-04-10 13:51:12",author="程明卫")
public interface ExchangeGoService extends IService<ExchangeGoEntity, Long> {
}
