package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.ClassPlanEntity;


/**
 * 循环排班表  Service接口
 * @author 程明卫
 * @date 2019-04-20 18:24:24
 */
@Description(remark="循环排班表业务接口",createDate="2019-04-20 18:24:24",author="程明卫")
public interface ClassPlanService extends IService<ClassPlanEntity, Long> {
}
