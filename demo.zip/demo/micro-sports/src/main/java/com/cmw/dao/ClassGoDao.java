package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.ClassGoEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * 上课记录表  Mapper接口
 * @author 程明卫
 * @date 2019-04-20 13:08:06
 */
@Description(remark="上课记录表DAO Mapper接口",createDate="2019-04-20 13:08:06",author="程明卫")
@Component
@Mapper
public interface ClassGoDao extends GenericDaoInter<ClassGoEntity, Long>{


    /**
     * 获取学生上课记录的剩余课时为0的记录
     * @param classGoIds   上课记录ID列表
     * @return
     */
    List<Map<String,Object>> getZhourList(@Param("classGoIds") String classGoIds);

    /**
     * 教练端（上课记录）根据班级ID找上课记录
     * @param classId   班级ID
     * @return
     */
    List<Map<String,Object>> getListByClassId(Long classId);

    /**
     * 获取指定学生指定课程的上课记录列表
     * @param courseId   课程ID
     * @param studentId   学生ID
     * @return
     */
    List<ClassGoEntity> getListByFinish(Long courseId, Long studentId);

    /**
     * 获取已消耗的上课数
     * @param pars
     * @return
     */
    Integer getDoCount(Map<String, Object> pars);

    Integer getFinishCount(Map<String, Object> pars);

    List<Map<String, Object>> getListByPlanId(Long planId);

    /**
     * PC端（班级详情 --> 上课记录）根据课次排班ID找上课记录
     * @param params
     * @return
     */
    List<Map<String, Object>> getListByXstatus(Map<String,Object> params);

    /**
     * PC端（班级详情 --> 上课记录 --> 请假学员）根据课次排班ID找请假学生记录
     * @param params
     * @return
     */
    List<Map<String, Object>> getLeavesByPlanId(Map<String,Object> params);

    /**
     * 获取上课班级
     * @Author 肖家添
     * @Date 2019/7/9 9:59
     */
    List<Map<String, Object>> getClassByParams(Map<String, Object> params);
    
    /**
     * 获取上课记录
     * @Author 肖家添
     * @Date 2019/7/17 11:43
     */
    List<Map<String, Object>> getClassGoByParams(Map<String, Object> params);

    /**
     * 家长端 ==> 学生课程
     * @Author 肖家添
     * @Date 2019/7/18 17:54
     */
    List<Map<String, Object>> getClassGoByStudent(Map<String, Object> params);
}
