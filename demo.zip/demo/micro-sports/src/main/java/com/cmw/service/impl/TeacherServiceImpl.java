package com.cmw.service.impl;



import com.cmw.client.UserClient;
import com.cmw.constant.back.BussContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.TeacherDao;
import com.cmw.entity.TeacherEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.TeacherService;
import com.cmw.util.*;
import com.cmw.util.export.ExcelExport;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 教师信息  Service实现类
 * @author 程明卫
 * @date 2019-04-10 13:55:46
 */
@Description(remark="教师信息业务实现类",createDate="2019-04-10 13:55:46",author="程明卫")
@Service("teacherService")
public class TeacherServiceImpl extends AbsService<TeacherEntity, Long> implements  TeacherService {
	@Autowired
	private TeacherDao teacherDao;

	@Autowired
	private UserClient userClient;

	@Override
	public GenericDaoInter<TeacherEntity, Long> getDao() {
		return teacherDao;
	}


	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		TeacherEntity teacherObj = null;
		try {
			teacherObj = BeanUtil.copyValue(TeacherEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}

		Long teacherId = teacherObj.getId();

		valid(teacherObj);

		//1.获取用户
		UserModel userInfo = LoginInterceptor.getLoginUser();
		String action = "add";
		if(null == teacherId){
			UserUtil.setCreateInfo(userInfo, teacherObj);
			insert(teacherObj);
		}else{
			action = "mod";
			UserUtil.setModifyInfo(userInfo, teacherObj);
			update(teacherObj);
		}
		saveUser(teacherObj, userInfo, action);
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", teacherObj.getId());
		return dataResult;
	}

	/**
	 * 保存用户信息
	 * @param teacher
	 */
	private void saveUser(TeacherEntity teacher, UserModel userInfo, String action){
		Long teacherId = teacher.getId();
		String phone = teacher.getPhone();
		String tname = teacher.getTname();
		Long schoolId = teacher.getSchoolId();
		Byte sex = teacher.getSex();

		String ttype = teacher.getTtype();

		String utype = getUtypes(ttype);

		Map<String,String> pars = new HashMap<>();
		pars.put("bussAction", action);
		pars.put("userName", phone);
		pars.put("phone", phone);
		pars.put("utype", utype);
		pars.put("empName", tname);
		pars.put("sex", sex+"");
		pars.put("incompId", schoolId+"");
		pars.put("indeptId", schoolId+"");
		pars.put("inempId", teacherId+"");
		userClient.save(pars, userInfo);
	}

	
	private String getUtypes(String ttypeStr){
		if(StringUtils.isEmpty(ttypeStr)) return null;
		String[] ttypes = ttypeStr.split(",");
		StringBuilder sbUtype = new StringBuilder();
		for (String ttype : ttypes) {
			switch (Integer.parseInt(ttype)){
				case BussContant.TEACHER_TTYPE_1://班主任
					sbUtype.append(BussContant.USER_UTYPE_5).append(",");
					break;
				case BussContant.TEACHER_TTYPE_2://教练
					sbUtype.append(BussContant.USER_UTYPE_4).append(",");
					break;
				case BussContant.TEACHER_TTYPE_3://校长
					sbUtype.append(BussContant.USER_UTYPE_2).append(",");
					break;
			}
		}
		return StringHandler.RemoveStr(sbUtype);
	}
	
	/**
	 * 老师信息验证
	 * @param teacherObj
	 */
	private void valid(TeacherEntity teacherObj) {
		String tname = teacherObj.getTname();
		Byte sex = teacherObj.getSex();
		String phone = teacherObj.getPhone();
		Long schoolId = teacherObj.getSchoolId();
		Byte xstatus = teacherObj.getXstatus();
		String ttype = teacherObj.getTtype();
		if(StringUtils.isEmpty(tname)){
			throw new ServiceException("老师姓名不能为空!");
		}
		if(!StringUtils.isEmpty(teacherObj.getTname()) && teacherObj.getTname().length() > 20){
			throw new ServiceException("老师姓名长度不能超过20!");
		}
		if(StringUtils.isEmpty(phone)){
			throw new ServiceException("手机号不能为空!");
		}
		if(!StringHandler.isChinaPhoneLegal(phone)){
			throw new ServiceException("手机号码("+ phone +")格式不正确!");
		}
		if(null == sex){
			throw new ServiceException("性别不能为空!");
		}
		if(null == schoolId){
			throw new ServiceException("所属校区不能为空!");
		}
		if(null == xstatus){
			throw new ServiceException("在职状态不能为空!");
		}
		if(null == ttype){
			throw new ServiceException("教师角色不能为空!");
		}
		Long id = teacherObj.getId();
		Integer count = 0;
		boolean isAdd = null == id; //是否新增 [true:新增, false:修改]
		if(isAdd){
			count = teacherDao.exist(phone, null);
			if(count > 0) throw new ServiceException("手机号"+ phone +"已经存在!");
		}else{
			count = teacherDao.exist(phone, id);
			if(count > 0) throw new ServiceException("当前修改的手机号"+ phone +"已被系统其他老师使用!");
		}
	}


	@Override
	public String getTeacheByUserId(Long userId) {
		return teacherDao.getTeacheByUserId(userId);
	}

	@Override
	public List<Map<String, Object>> getTeacherForSelect(Map<String, Object> pars) {
		return teacherDao.getTeacherForSelect(pars);
	}

	@Override
	public void exportData(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM) {
		String[] cellVal = {
				"ID",
				"教练",
				"手机",
				"性别",
				"生日",
				"工作性质",
				"在职状态",
				"所属校区",
				"创建时间"
		};

		String[] dataKeys = {
				"id",
				"tname",
				"phone",
				"sex",
				"bdate",
				"nature",
				"xstatus",
				"schoolName",
				"createTime"
		};

		for(Map<String, Object> data : dataList_LM){
			SHashMap data_SH = new SHashMap<>(data);

			for(String key : dataKeys){
				String val = data_SH.getvalAsStr(key);

				val = StringHandler.isValidStr(val) ? val : "";

				switch (key){
					case "sex":{

						switch (val){
							case "1":{
								val = "男";
								break;
							}
							case "2":{
								val = "女";
								break;
							}
						}

						break;
					}
					case "createTime":
					case "bdate":{

						if(StringHandler.isValidStr(val))
							val = DateUtil.dateFormatToStr("yyyy-MM-dd", new Date(Long.parseLong(val)));

						break;
					}
					case "nature":{

						switch (val){
							case "0":{
								val = "无";
								break;
							}
							case "1":{
								val = "全职";
								break;
							}
							case "2":{
								val = "兼职";
								break;
							}
						}

						break;
					}

					case "xstatus":{

						switch (val){
							case "0":{
								val = "无";
								break;
							}
							case "1":{
								val = "在职";
								break;
							}
							case "2":{
								val = "离职";
								break;
							}
							case "3":{
								val = "禁用";
								break;
							}
						}

						break;
					}
				}

				data_SH.put(key, val);
			}
		}

		new ExcelExport(request, response).export(cellVal, dataKeys, dataList_LM);
	}
}
