package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.ClassSetEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassSetService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 排班设置表  Conntroller类
 * @author 程明卫
 * @date 2019-04-20 18:21:37
 */
@Description(remark="排班设置表Conntroller",createDate="2019-04-20 18:21:37",author="程明卫")
@Api(value = "排班设置表微服务", description = "#CONTROLLER# 2019-04-20 18:21:37 程明卫")
@RestController
@RequestMapping({"/classset"})
public class ClassSetController{
	@Resource(name="classSetService")
	private ClassSetService classSetService;
	

    /**
     * 跳转列表页面
     * /classset/list/5
     * @param classId
     * @return
     */
     @ApiOperation("排班设置表列表API")
    @PostMapping(value = "/list/{classId}")
    public JSONObject list(@PathVariable("classId") Long classId){
         Map<String,Object> pars = new HashMap<>();
         pars.put("classId",classId);
        List<Map<String,Object>> list = classSetService.getListMap(pars);
        return PageHandler.getJson(list);
    }
    
      /**
     * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询排班设置表信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = classSetService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }


	/**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取排班设置表信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("排班设置表ID") @PathVariable("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        ClassSetEntity obj = classSetService.get(id);
        JSONObject jsonObject = PageHandler.getJson(obj);
        return   jsonObject;
    }
    

    
    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存排班设置表信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
        try{
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = LoginInterceptor.getLoginUser();
            pars.put(SysContant.USER_INFO, userInfo);
            Map<String, Object> dataResult = (Map<String, Object>)classSetService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }



    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
        return save(param);
    }
    
    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除排班设置表信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("#DESCRIPTIONID") @PathVariable("id")  Long id) throws Exception{
      try{
            Map<String,Object> pars = new HashMap<>();
            pars.put("id",id);
            UserModel userInfo = LoginInterceptor.getLoginUser();
            pars.put(SysContant.USER_INFO, userInfo);
            classSetService.deleteByPars(pars);
            return PageHandler.getSuccessJson();
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }
    
}
