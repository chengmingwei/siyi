package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.PosterImgEntity;
import org.springframework.stereotype.Component;


/**
 * 海报图片项  Mapper接口
 * @author 程明卫
 * @date 2019-07-10 20:21:28
 */
@Description(remark="海报图片项DAO Mapper接口",createDate="2019-07-10 20:21:28",author="程明卫")
@Component
@Mapper
public interface PosterImgDao extends GenericDaoInter<PosterImgEntity, Long>{

}
