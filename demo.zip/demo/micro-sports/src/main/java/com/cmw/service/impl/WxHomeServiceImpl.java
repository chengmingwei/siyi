package com.cmw.service.impl;

import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.WxHomeDao;
import com.cmw.entity.ClassGoEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.SchoolService;
import com.cmw.service.inter.WxHomeService;
import com.cmw.util.BigDecimalHandler;
import com.cmw.util.DateUtil;
import com.cmw.util.StringHandler;
import com.cmw.util.date.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * 首页数据请求
 */
@Service("homeService")
public class WxHomeServiceImpl  extends AbsService<ClassGoEntity, Long>  implements WxHomeService  {
    @Autowired
    private WxHomeDao wxHomeDao;
    @Resource(name="schoolService")
    private SchoolService schoolService;

    @Autowired
    private RedisTemplate redisTemplate;

    private static final String REDIS_KEY_PREFIX_SCHOOLER_INDEPTID = "SCHOOLER_INDEPTID_";

    private static final String REDIS_KEY_PREFIX_SALER_INDEPTID = "SALER_USERID_";

    @Override
    public GenericDaoInter<ClassGoEntity, Long> getDao() {
        return wxHomeDao;
    }

    @Override
    public Map<String, Object> getHomeDataForWx(Map<String, Object> pars) {
        Map<String,Object> dataMap = new HashMap<>();
        UserModel userModel = (UserModel)pars.get(SysContant.USER_INFO);
        Integer utype = userModel.getUtype();
        switch (utype.intValue()){
            case BussContant.USER_UTYPE_2: { //区域管理员或校长
                dataMap = getHomeDataBySchooler(userModel);
                break;
            }case BussContant.USER_UTYPE_5: {//销售
                dataMap = getHomeDataBySaler(userModel);
                break;
            }
        }
        return dataMap;
    }

    private Map<String, Object> getHomeDataBySaler(UserModel userModel) {
        Map<String,Object> dataMap = null;
        Long userId = userModel.getId();
        String key = REDIS_KEY_PREFIX_SALER_INDEPTID+userId;
        dataMap = (Map<String, Object>) redisTemplate.opsForValue().get(key);
       // if(null != dataMap && dataMap.size() > 0) return dataMap;
        dataMap = getHomeDataBySaler(userId);
        redisTemplate.opsForValue().set(key,dataMap, 5L, TimeUnit.MINUTES);
        return dataMap;
    }

    private  Map<String,Object> getHomeDataBySaler(Long userId) {
        Map<String,Object> pars = new HashMap<>();
        pars.put("userId", userId);
        //首页 本月业绩 [销售]
        Double saleByMonth = wxHomeDao.getSaleByMonth(pars);
        if(null == saleByMonth) saleByMonth = 0d;
        //首页 本月成单 [销售]
        Integer saleCountByMonth = wxHomeDao.getSaleCountByMonth(pars);
        if(null == saleCountByMonth) saleCountByMonth = 0;

        //首页 待跟进学员 [销售]
        Integer unStudentCount = wxHomeDao.getUnStudentCount(pars);
        if(null == unStudentCount) unStudentCount = 0;

        //首页 跟进中学员 [销售]
        Integer doingStudentCount = wxHomeDao.getDoingStudentCount(pars);
        if(null == doingStudentCount) doingStudentCount = 0;

        //首页 即将过期学员 [销售] (剩余课时数小于3课时)
        Integer expireStudentCount = wxHomeDao.getExpireStudentCount(pars);
        if(null == expireStudentCount) expireStudentCount = 0;

        //首页 潜在学员列表 [销售]
        List<Map<String,Object>> latentStudents = wxHomeDao.getLatentStudents(pars);

        //首页 即将过期学员列表 [销售] (剩余课时数小于3课时)
        List<Map<String,Object>> expireStudents = wxHomeDao.getExpireStudents(pars);

        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("saleByMonth", saleByMonth);      //首页 本月业绩 [销售]
        dataMap.put("saleCountByMonth",saleCountByMonth);   //首页 本月成单 [销售]
        dataMap.put("unStudentCount", unStudentCount);    //首页 待跟进学员 [销售]
        dataMap.put("doingStudentCount", doingStudentCount);     //首页 跟进中学员 [销售]
        dataMap.put("expireStudentCount", expireStudentCount);   //首页 即将过期学员 [销售] (剩余课时数小于3课时)
        dataMap.put("latentStudents", latentStudents);   //首页 潜在学员列表 [销售]
        dataMap.put("expireStudents", expireStudents);   //首页 即将过期学员列表 [销售] (剩余课时数小于3课时)
        return  dataMap;
    }

    private Map<String,Object> getHomeDataBySchooler(UserModel userModel){
        Map<String,Object> dataMap = null;
        Long indeptId = userModel.getIndeptId();
        String key = REDIS_KEY_PREFIX_SCHOOLER_INDEPTID+indeptId;
        dataMap = (Map<String, Object>) redisTemplate.opsForValue().get(key);
        //if(null != dataMap && dataMap.size() > 0) return dataMap;
        dataMap = getHomeDataBySchooler(indeptId, userModel);
        redisTemplate.opsForValue().set(key,dataMap, 30L, TimeUnit.MINUTES);
        return dataMap;
    }

    private Map<String,Object> getHomeDataBySchooler(Long indeptId, UserModel userModel){
        Map<String,Object> pars = new HashMap<>();
        pars.put("indeptId", indeptId);
        pars.put("deptId", indeptId);
        pars.put("userType", userModel.getUtype());
        pars.put("utype", userModel.getUtype());
        pars.put("userId", userModel.getId());
        pars.put("creator", userModel.getId());
        pars.put("inempId", userModel.getInempId());

        Date today = new Date();
        // 首页 本月收入
        pars.put("currDate", DateUtil.getDateStr());

        Double incomeCurrMonth = wxHomeDao.getIncomeByMonth(pars);
        if(null == incomeCurrMonth) incomeCurrMonth = 0d;
        // 首页上月收入
        pars.put("currDate", DateUtil.minusMonthToDate(today,1));
        Double incomePrevMonth = wxHomeDao.getIncomeByMonth(pars);
        if(null == incomePrevMonth) incomePrevMonth = 0d;


        String mondayStr =  DateUtil.getMondayOfThisWeekStr();
        Date tomorrow = DateUtil.addDaysToDate(new Date(),1);
        String tomorrowStr = DateUtil.dateFormatToStr(tomorrow);
        //首页 待跟进人数  (本周)
        pars.put("monday", mondayStr);
        pars.put("tomorrow", tomorrowStr);
        Integer xcountByWeek = wxHomeDao.getXCountByWeek(pars);
        if(null == xcountByWeek) xcountByWeek = 0;

        //首页 跟进中人数  (本周)
        Integer ycountByWeek = wxHomeDao.getYCountByWeek(pars);
        if(null == ycountByWeek) ycountByWeek = 0;

        //首页 体验人数 (本周)
        Integer tasteCountByWeek = wxHomeDao.getTasteCountByWeek(pars);
        if(null == tasteCountByWeek) tasteCountByWeek = 0;

        //首页 tasteCountByWeek (本周)
        Integer buyCountByWeek = wxHomeDao.getBuyCountByWeek(pars);
        if(null == buyCountByWeek) buyCountByWeek = 0;

        //首页本周课消金额 (本周)
        Integer useCountByWeek = wxHomeDao.getUseCountByWeek(pars);
        if(null == useCountByWeek) useCountByWeek = 0;

       //首页 本周上课人次
        Integer studyCountByWeek = wxHomeDao.getStudyCountByWeek(pars);
        if(null == studyCountByWeek) studyCountByWeek = 0;

        //首页 本周上课老师
        Integer spTeacherCountByWeek = wxHomeDao.getSpTeacherCountByWeek(pars);
        if(null == spTeacherCountByWeek) spTeacherCountByWeek = 0;

       //首页 本周课次安排
        Integer tplanCountByWeek = wxHomeDao.getTplanCountByWeek(pars);
        if(null == tplanCountByWeek) tplanCountByWeek = 0;

        //首页 本周已上课人数
        Integer finishStudyByWeek = wxHomeDao.getFinishStudyByWeek(pars);
        if(null == finishStudyByWeek) finishStudyByWeek = 0;

        //首页 本周续签订单数  首页 本周复购率 = 本周续签 / 本周下单
        Integer repeatOrderByWeek = wxHomeDao.getRepeatOrderByWeek(pars);

        //首页 本周下订单数 首页 本周复购率 = 本周续签 / 本周下单
        Integer orderByWeek = wxHomeDao.getOrderByWeek(pars);

        //首页 复购率
        if(null == repeatOrderByWeek) repeatOrderByWeek = 0;
        if(null == orderByWeek) orderByWeek = 0;

        Integer repeatBuyPrecen = 0;

        if(orderByWeek != 0){
            repeatBuyPrecen = (repeatOrderByWeek / orderByWeek) * 100;
        }

        //首页满班率

        //-- 2019-08-12 -> Integer fullClassByWeek = wxHomeDao.getFullClassByWeek(pars);

        Integer fullClassByWeek = getWxHomeDataOfCoach_FullShiftRate(pars);

        if(null == fullClassByWeek) fullClassByWeek = 0;
        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("incomeCurrMonth",incomeCurrMonth); //本月收入
        dataMap.put("incomePrevMonth", incomePrevMonth);    //上月收入
        dataMap.put("xcountByWeek", xcountByWeek); //跟进中人数
        dataMap.put("ycountByWeek", ycountByWeek); //跟进中人数
        dataMap.put("tasteCountByWeek", tasteCountByWeek); //体验人数
        dataMap.put("buyCountByWeek",buyCountByWeek); //缴费人数
        dataMap.put("useCountByWeek", useCountByWeek); //本周课消金额
        dataMap.put("studyCountByWeek", studyCountByWeek);    //本周上课人次
        dataMap.put("spTeacherCountByWeek", spTeacherCountByWeek);    //本周上课老师
        dataMap.put("tplanCountByWeek", tplanCountByWeek);    //本周课次安排
        dataMap.put("finishStudyByWeek", finishStudyByWeek);    //本周已上课人数
        dataMap.put("repeatBuyPrecen", repeatBuyPrecen);    //复购率
        dataMap.put("fullClassByWeek", fullClassByWeek);    //首页满班率
        return dataMap;
    }

    @Override
    public Map<String, Object> getHomeDataForPc(Map<String, Object> pars) {
        UserModel userModel = (UserModel)pars.get(SysContant.USER_INFO);
        Integer utype = userModel.getUtype();
    //    log.info("getHomeDataForPc.utype="+utype);
        Map<String,Object> params = new HashMap<>();
        params.put("utype", utype);
        if (utype == BussContant.USER_UTYPE_2 || utype == BussContant.USER_UTYPE_7) {  //超管、财务
            Long indeptId = userModel.getIndeptId();
            params.put("deptId", indeptId);
        }else if(utype == BussContant.USER_UTYPE_5){//普通用户、班主任、销售
            Long userId = userModel.getId();
            params.put("creator", userId);
        }else if(utype == BussContant.USER_UTYPE_4){  //教练
            Long inempId = userModel.getInempId();
            params.put("inempId", inempId);
        }

        //校区列表
        List<Map<String,Object>> schoolList = schoolService.getListMap(params);
        String schoolId = (String) pars.get("school");
        if (schoolId != null && !schoolId.equals("all")) {
            params.put("schoolId", Long.valueOf(schoolId));
        }

        //总招生人数
        Integer totalEnrollment = wxHomeDao.getTotalEnrollmentForPc(params);
        if(null == totalEnrollment) totalEnrollment = 0;

        //当前有效学员 [ok 2019-11-05 cmw]
        Integer nowEffStuCount = wxHomeDao.getNowEffStuCountForPc(params);
        if(null == nowEffStuCount) nowEffStuCount = 0;

        //今年报名学员
        Integer thisYearEnrStuCount = wxHomeDao.getThisYearEnrStuCountForPc(params);
        if(null == thisYearEnrStuCount) thisYearEnrStuCount = 0;
        //剩余总课次 [ok 2019-11-07 22:04 cmw]
        Integer remTotalLesson = wxHomeDao.getRemTotalLessonForPc(params);
        if(null == remTotalLesson) remTotalLesson = 0;

        params.put("currMonth", DateUtil.dateFormatToStr(DateUtil.DATE_YYYYMM_FORMAT, new Date()));
        //本月总收入
        Double thisMonthIncomeTotal = wxHomeDao.getThisMonthIncomeTotalForPc(params);
        if(null == thisMonthIncomeTotal) thisMonthIncomeTotal = 0d;
        //本月新签学员
        Integer thisMonthNewEnrStuCount = wxHomeDao.getThisMonthNewEnrStuCountForPc(params);
        if(null == thisMonthNewEnrStuCount) thisMonthNewEnrStuCount = 0;
        //本月续费学员
        Integer thisMonthAgainEnrStuCount = wxHomeDao.getThisMonthAgainEnrStuCountForPc(params);
        if(null == thisMonthAgainEnrStuCount) thisMonthAgainEnrStuCount = 0;
        //本月课消金额[ok 2019-11-07 22:23 cmw]

        Double useCountByMonth = wxHomeDao.getUseCountByMonthForPc(params);
        if(null == useCountByMonth) useCountByMonth = 0d;
        //本月授课课时
        Integer thisMonthDidTempCount = wxHomeDao.getThisMonthDidTempCountForPc(params);
        if(null == thisMonthDidTempCount) thisMonthDidTempCount = 0;
        //本月课次安排
        Integer thisMonthTempCount = wxHomeDao.getThisMonthTempCountForPc(params);
        if(null == thisMonthTempCount) thisMonthTempCount = 0;
        //机构收入
        pars.putAll(params);
        Map<String, Object> instIncomeMap = getInstIncomeList(pars);

        //课消金额
        Map<String, Object> useCountMap = getUseCountList(pars);

        //班级满班率
        Integer fullClassByMonth = getWxHomeDataOfCoach_FullShiftRate(params);
        if(null == fullClassByMonth) fullClassByMonth = 0;
//        Integer fullClassByMonth = wxHomeDao.getFullClassByMonthForPc(params);

        BigDecimal hundred = new BigDecimal("100");
        //学员续费率[ok 2019-11-08 18:46 cmw]
        BigDecimal againStudentPer = getRenewval(params);

        //跟进情况
        //待跟进
        Integer followUpReady = wxHomeDao.getFollowUpReadyByMonthForPc(params);
        if(null == followUpReady) followUpReady = 0;
        //跟进中
        Integer followUpDoing = wxHomeDao.getFollowUpDoingByMonthForPc(params);
        if(null == followUpDoing) followUpDoing = 0;
        //预约体验
        params.put("xstatus", 0);
        Integer followUpNotTaste = wxHomeDao.getFollowUpTasteByMonthForPc(params);
        if(null == followUpNotTaste) followUpNotTaste = 0;
        //已体验
        params.put("xstatus", 1);
        Integer followUpDidTaste = wxHomeDao.getFollowUpTasteByMonthForPc(params);
        if(null == followUpDidTaste) followUpDidTaste = 0;

        //已付费
        Integer followUpPay = wxHomeDao.getFollowUpPayByMonthForPc(params);
        if(null == followUpPay) followUpPay = 0;
        //全部
        Integer followUpAll = followUpReady + followUpDoing + followUpNotTaste + followUpDidTaste + followUpPay;
        followUpAll = followUpAll == 0 ? 1 : followUpAll;
        BigDecimal followUpAllBig = BigDecimal.valueOf(followUpAll);
        //待跟进比率
        BigDecimal followUpReadyPer = BigDecimal.valueOf(followUpReady);
        followUpReadyPer = followUpReadyPer.divide(followUpAllBig, 6, RoundingMode.HALF_UP);
        followUpReadyPer = followUpReadyPer.multiply(hundred);
        followUpReadyPer = followUpReadyPer.setScale(0, RoundingMode.HALF_UP);
        //跟进中比率
        BigDecimal followUpDoingPer = BigDecimal.valueOf(followUpDoing);
        followUpDoingPer = followUpDoingPer.divide(followUpAllBig, 6, RoundingMode.HALF_UP);
        followUpDoingPer = followUpDoingPer.multiply(hundred);
        followUpDoingPer = followUpDoingPer.setScale(0, RoundingMode.HALF_UP);
        //预约体验比率
        BigDecimal followUpNotTastePer = BigDecimal.valueOf(followUpNotTaste);
        followUpNotTastePer = followUpNotTastePer.divide(followUpAllBig, 6, RoundingMode.HALF_UP);
        followUpNotTastePer = followUpNotTastePer.multiply(hundred);
        followUpNotTastePer = followUpNotTastePer.setScale(0, RoundingMode.HALF_UP);
        //已体验比率
        BigDecimal followUpDidTastePer = BigDecimal.valueOf(followUpDidTaste);
        followUpDidTastePer = followUpDidTastePer.divide(followUpAllBig, 6, RoundingMode.HALF_UP);
        followUpDidTastePer = followUpDidTastePer.multiply(hundred);
        followUpDidTastePer = followUpDidTastePer.setScale(0, RoundingMode.HALF_UP);
        //已付费比率
        BigDecimal followUpPayPer = BigDecimal.valueOf(followUpPay);
        followUpPayPer = followUpPayPer.divide(followUpAllBig, 6, RoundingMode.HALF_UP);
        followUpPayPer = followUpPayPer.multiply(hundred);
        followUpPayPer = followUpPayPer.setScale(0, RoundingMode.HALF_UP);
        Map<String, Object> map = new HashMap<>();
        map.put("schoolList", schoolList);//校区列表
        map.put("totalEnrollment", totalEnrollment);//总招生人数
        map.put("nowEffStuCount", nowEffStuCount);//当前有效学员
        map.put("thisYearEnrStuCount", thisYearEnrStuCount);//今年报名学员
        map.put("remTotalLesson", remTotalLesson);//剩余总课次
        map.put("thisMonthIncomeTotal", thisMonthIncomeTotal);//本月总收入
        map.put("thisMonthNewEnrStuCount", thisMonthNewEnrStuCount);//本月新签学员
        map.put("thisMonthAgainEnrStuCount", thisMonthAgainEnrStuCount);//本月续费学员
        map.put("useCountByMonth", useCountByMonth);//本月课消金额
        map.put("thisMonthDidTempCount", thisMonthDidTempCount);//本月授课课时
        map.put("thisMonthTempCount", thisMonthTempCount);//本月课次安排
        map.putAll(instIncomeMap);//机构收入
        map.putAll(useCountMap);//课消金额
        map.put("fullClassByMonth", fullClassByMonth);//班级满班率
        map.put("againStudentPer", againStudentPer);//学员续费率
        map.put("followUpReadyPer", followUpReadyPer);//待跟进比率
        map.put("followUpDoingPer", followUpDoingPer);//跟进中比率
        map.put("followUpNotTastePer", followUpNotTastePer);//预约体验比率
        map.put("followUpDidTastePer", followUpDidTastePer);//已体验比率
        map.put("followUpPayPer", followUpPayPer);//已付费比率
        return map;
    }


    /**
     * 获取 续费率 数据
     * //上月到期的续费学员
     * //上月到期的续费学员/上月到期的学员
     * @param params
     * @return
     */
    private BigDecimal getRenewval(Map<String,Object> params){
        Date lastMonthDate = DateUtil.minusMonthToDate(new Date(),1);
        String lastMonth = DateUtil.dateFormatToStr(DateUtil.DATE_YYYYMM_FORMAT, lastMonthDate);
        params.put("prevMoth", lastMonth);
        //上月到期的学员
        List<Map<String,Object>> studentIdList = wxHomeDao.endStudentCountByLastMonthForPc(params);
        Integer endStudentCount = 0;
        //上月到期的续费学员/上月到期的学员
        BigDecimal againStudentPer = new BigDecimal("0");

        if(null != studentIdList && studentIdList.size() > 0){
            endStudentCount = studentIdList.size();
            StringBuilder sbStudentIds = new StringBuilder();
            studentIdList.forEach(map -> {
               Object studentId = map.get("studentId");
                sbStudentIds.append(studentId).append(",");
            });
            String studentIds = StringHandler.RemoveStr(sbStudentIds);
            if(StringUtils.isEmpty(studentIds)){
                return new BigDecimal("0");
            }
            params.put("studentIds", studentIds);
           Integer renewvalCount = wxHomeDao.againStudentCountByLastMonthForPc(params);
           if(null == renewvalCount) renewvalCount = 0;
            Float precent = (renewvalCount.floatValue() / endStudentCount) * 100f;
            againStudentPer = BigDecimalHandler.roundToBigDecimal(precent ,0);
        }
        return againStudentPer;
    }

    @Override
    public Map<String, Object> getHomeInstIncomeListForPc(Map<String, Object> pars) {
        UserModel userModel = (UserModel)pars.get(SysContant.USER_INFO);
        Integer utype = userModel.getUtype();
        if (utype != BussContant.USER_UTYPE_3) {
            if (utype == BussContant.USER_UTYPE_2) {
                //区域管理员或校长
                Long indeptId = userModel.getIndeptId();
                pars.put("deptId", indeptId);
            } else {
                //教练、班主任
                Long userId = userModel.getId();
                pars.put("creator", userId);
            }
        }
        String schoolId = (String) pars.get("school");
        if (schoolId != null && !schoolId.equals("all")) {
            pars.put("schoolId", Long.valueOf(schoolId));
        }
        Map<String, Object> map = getInstIncomeList(pars);
        return map;
    }

    private Map<String, Object> getInstIncomeList(Map<String, Object> pars) {
        String instIncomeTime = (String) pars.get("instIncomeTime");
        instIncomeTime = instIncomeTime == null ? "" : instIncomeTime;
        //默认 最近15天
        Calendar instIncomeCal = Calendar.getInstance();
        String instIncomeFormat = "%Y-%m-%d";
        String instIncomePattern = "yyyy-MM-dd";

        int instIncomeField = Calendar.DATE;
        int instIncomeTimeLength = 15;
        switch (instIncomeTime) {
            case "lastMonth"://最近一个月
                Calendar calEnd = Calendar.getInstance();
                calEnd.add(Calendar.MONTH, -1);
                long timeLengthLong = instIncomeCal.getTime().getTime() - calEnd.getTime().getTime();
                BigDecimal timeLengthBig = BigDecimal.valueOf(timeLengthLong);
                long onceDay = 1000 * 60 * 60 * 24;
                timeLengthBig = timeLengthBig.divide(BigDecimal.valueOf(onceDay), 0, RoundingMode.DOWN);
                instIncomeTimeLength = timeLengthBig.intValue();
                break;
            case "recent3Months"://最近3个月
                instIncomeFormat = "%Y-%m";
                instIncomePattern = "yyyy-MM";
                instIncomeField = Calendar.MONTH;
                instIncomeTimeLength = 3;
                break;
            case "recent6Months"://最近6个月
                instIncomeFormat = "%Y-%m";
                instIncomePattern = "yyyy-MM";
                instIncomeField = Calendar.MONTH;
                instIncomeTimeLength = 6;
                break;
            case "lastYear"://最近一年
                instIncomeFormat = "%Y-%m";
                instIncomePattern = "yyyy-MM";
                instIncomeField = Calendar.MONTH;
                instIncomeTimeLength = 12;
                break;
        }
        SimpleDateFormat instIncomeFt = new SimpleDateFormat(instIncomePattern);
        List<Map<String,Object>> instIncomeListNew = new ArrayList<>();
        for (int i = 0;i < instIncomeTimeLength;i++) {
            int amount = (i == 0) ? 0 : -1;
            instIncomeCal.add(instIncomeField, amount);
            String payDate = instIncomeFt.format(instIncomeCal.getTime());
            Map<String,Object> map = new HashMap<>();
            map.put("payDate", payDate);
            map.put("payPrice", 0);
            instIncomeListNew.add(0, map);
        }
        String instIncomeLastPayDate = (String) instIncomeListNew.get(0).get("payDate");
        pars.put("format", instIncomeFormat);
        pars.put("lastPayDate", instIncomeLastPayDate);
        List<Map<String,Object>> instIncomeList = wxHomeDao.getInstIncomeListMapForPc(pars);
        BigDecimal instIncomeTotal = new BigDecimal("0");
        for (int i = 0;i < instIncomeListNew.size();i++) {
            Map<String,Object> mapNew = instIncomeListNew.get(i);
            String payDateNew = (String) mapNew.get("payDate");
            for (int j = 0;j < instIncomeList.size();j++) {
                Map<String,Object> map = instIncomeList.get(j);
                String payDate = (String) map.get("payDate");
                if (payDate.equals(payDateNew)) {
                    BigDecimal payPrice = (BigDecimal) map.get("payPrice");
                    mapNew.put("payPrice", payPrice);
                    instIncomeTotal = instIncomeTotal.add(payPrice);
                }
            }
        }
        for (Map<String,Object> map : instIncomeListNew) {
            String payDate = (String) map.get("payDate");

            if("yyyy-MM-dd".equals(instIncomePattern)){
                payDate = payDate.substring(5, payDate.length());
            }

            map.put("payDate", payDate);
        }
        Map<String, Object> map = new HashMap<>();
        map.put("instIncomeTotal", instIncomeTotal);//机构总收入
        map.put("instIncomeList", instIncomeListNew);//机构收入

        UserModel userModel = (UserModel)pars.get(SysContant.USER_INFO);
        Integer utype = userModel.getUtype();

        map.put("userType", utype);  //账号类型

        return map;
    }

    @Override
    public Map<String, Object> getHomeUseCountListForPc(Map<String, Object> pars) {
        UserModel userModel = (UserModel)pars.get(SysContant.USER_INFO);
        Integer utype = userModel.getUtype();
        //-- 此处有修改,时间:2019-07-03
        if (utype != BussContant.USER_UTYPE_3 && utype != BussContant.USER_UTYPE_6) { //超级管理员 或者 区域管理员
            if (utype == BussContant.USER_UTYPE_2) {  //校长
                Long indeptId = userModel.getIndeptId();

                pars.put("deptId", indeptId);
            } else {//普通用户、教练、销售
                Long userId = userModel.getId();
                pars.put("creator", userId);
            }
        }
        String schoolId = (String) pars.get("school");
        if (schoolId != null && !schoolId.equals("all")) {
            pars.put("schoolId", Long.valueOf(schoolId));
        }
        Map<String, Object> map = getUseCountList(pars);
        return map;
    }

    private Map<String, Object> getUseCountList(Map<String, Object> pars) {
        String useCountTime = (String) pars.get("useCountTime");
        useCountTime = useCountTime == null ? "" : useCountTime;
        //默认 最近15天
        Calendar useCountCal = Calendar.getInstance();
        String useCountFormat = "%Y-%m-%d";
        String useCountPattern = "yyyy-MM-dd";
        int useCountField = Calendar.DATE;
        int useCountTimeLength = 15;
        switch (useCountTime) {
            case "lastMonth"://最近一个月
                Calendar calEnd = Calendar.getInstance();
                calEnd.add(Calendar.MONTH, -1);
                long timeLengthLong = useCountCal.getTime().getTime() - calEnd.getTime().getTime();
                BigDecimal timeLengthBig = BigDecimal.valueOf(timeLengthLong);
                long onceDay = 1000 * 60 * 60 * 24;
                timeLengthBig = timeLengthBig.divide(BigDecimal.valueOf(onceDay), 0, RoundingMode.DOWN);
                useCountTimeLength = timeLengthBig.intValue();
                break;
            case "recent3Months"://最近3个月
                useCountFormat = "%Y-%m";
                useCountPattern = "yyyy-MM";
                useCountField = Calendar.MONTH;
                useCountTimeLength = 3;
                break;
            case "recent6Months"://最近6个月
                useCountFormat = "%Y-%m";
                useCountPattern = "yyyy-MM";
                useCountField = Calendar.MONTH;
                useCountTimeLength = 6;
                break;
            case "lastYear"://最近一年
                useCountFormat = "%Y-%m";
                useCountPattern = "yyyy-MM";
                useCountField = Calendar.MONTH;
                useCountTimeLength = 12;
                break;
        }
        SimpleDateFormat ft = new SimpleDateFormat(useCountPattern);
        List<Map<String,Object>> useCountListNew = new ArrayList<>();
        for (int i = 0;i < useCountTimeLength;i++) {
            useCountCal.add(useCountField, -1);
            String useCountDate = ft.format(useCountCal.getTime());
            Map<String,Object> map = new HashMap<>();

            map.put("useCountDate", useCountDate);
            map.put("useCount", 0);
            useCountListNew.add(0, map);
        }
        String useCountLastPayDate = (String) useCountListNew.get(0).get("useCountDate");
        pars.put("format", useCountFormat);
        pars.put("lastPayDate", useCountLastPayDate);
        List<Map<String,Object>> useCountList = wxHomeDao.getUseCountListMapForPc(pars);
        for (int i = 0;i < useCountListNew.size();i++) {
            Map<String,Object> mapNew = useCountListNew.get(i);
            String useCountDateNew = (String) mapNew.get("useCountDate");
            for (int j = 0;j < useCountList.size();j++) {
                Map<String,Object> map = useCountList.get(j);
                String useCountDate = (String) map.get("useCountDate");
                if (useCountDate.equals(useCountDateNew)) {
                    BigDecimal useCount = (BigDecimal) map.get("useCount");
                    mapNew.put("useCount", useCount);
                }
            }
        }
        for (Map<String,Object> map : useCountListNew) {
            String useCountDate = (String) map.get("useCountDate");

            if("yyyy-MM-dd".equals(useCountPattern)){
                useCountDate = useCountDate.substring(5, useCountDate.length());
            }

            map.put("useCountDate", useCountDate);
        }
        Map<String, Object> map = new HashMap<>();
        map.put("useCountList", useCountListNew);//课消金额
        return map;
    }

    /**
     * [小程序] -> [教练端] -> [教练角色] -> [数据汇总]
     * @Author 肖家添
     * @Date 2019/8/12 16:01
     */
    @Override
    public Map<String, Object> getWxHomeDataOfCoach() {

        Map<String, Object> returnMap = new HashMap<>();

        String searchRangeOfTime = new DateUtils().addNowDays(-30);

        Map<String, Object> params = new HashMap<>();
        UserModel userModel = LoginInterceptor.getLoginUser();
        params.put("utype", userModel.getUtype());
        params.put("creator", userModel.getId());
        params.put("coachId", getLoginTeacherId());
        params.put("searchRangeOfTime", searchRangeOfTime);

        //-- step 1: 满班率
        Integer fullShiftRate = getWxHomeDataOfCoach_FullShiftRate(params);
        returnMap.put("fullShiftRate", fullShiftRate);

        //-- step 2: 体验成交率
        Integer experienceTurnoverRate = wxHomeDao.getWxHomeDataOfCoach_ExperienceTurnoverRate(params);
        returnMap.put("experienceTurnoverRate", experienceTurnoverRate);
        
        //-- step 3: 复购率
        Double repurchaseRate = 0d;
        List<Map<String,Object>> relist  = wxHomeDao.getWxHomeDataOfCoach_RepurchaseRate(params);
        if(null != relist && relist.size() > 1){ //如果查出来只有一笔，则没法相除。则默认为0
            Long renewCount = (Long)relist.get(0).get("xcount");
            Long allCount = (Long)relist.get(1).get("xcount");
            Double d_repurchaseRate = (renewCount.doubleValue() / allCount)*  100;
            repurchaseRate = BigDecimalHandler.round (d_repurchaseRate, 0);
        }
        returnMap.put("repurchaseRate", repurchaseRate);

        return returnMap;
    }
    
    /**
     * [数据汇总] -> [满班率]
     * @Author 肖家添
     * @Date 2019/8/12 20:25
     */
    private Integer getWxHomeDataOfCoach_FullShiftRate(Map<String, Object> params){
        params.put("coachId", getLoginTeacherId());

        params.put("searchRangeOfTime", DateUtil.minusDays(new Date(),30));
        //-- 满班率
        return wxHomeDao.getWxHomeDataOfCoach_FullShiftRate(params);

    }

    /**
     * 获取登录账号的教师Id
     * @Author 肖家添
     * @Date 2019/8/12 18:02
     */
    private Long getLoginTeacherId(){
        UserModel userModel = LoginInterceptor.getLoginUser();
        return userModel.getInempId();
    }
}
