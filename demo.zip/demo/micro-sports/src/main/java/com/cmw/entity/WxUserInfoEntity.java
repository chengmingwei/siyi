package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 公众号用户信息
 * @author 程明卫
 * @date 2019-08-24 17:10:59
 */
@Description(remark="公众号用户信息实体",createDate="2019-08-24 17:10:59",author="程明卫")
@Entity
@Table(name="GL_WxUserInfo")
@SuppressWarnings("serial")
public class WxUserInfoEntity extends IdEntity {
	
	
	 @Description(remark="备注")
	 @Column(name="remark" ,length=200 )
	 private String remark;

	 @Description(remark="修改日期")
	 @Column(name="modifyTime" )
	 private Date modifyTime;

	 @Description(remark="创建时间")
	 @Column(name="createTime" ,nullable=false )
	 private Date createTime;

	 @Description(remark="用户头像")
	 @Column(name="headimgurl" ,length=200 )
	 private String headimgurl;

	 @Description(remark="性别")
	 @Column(name="sex" ,nullable=false )
	 private Integer sex;

	 @Description(remark="用户的昵称")
	 @Column(name="nickname" ,length=75 )
	 private String nickname;

	 @Description(remark="通用ID")
	 @Column(name="unionid" ,length=100 )
	 private String unionid;

	 @Description(remark="公众号openid")
	 @Column(name="openid" ,length=100 )
	 private String openid;

	 @Description(remark="是否订阅该公众号")
	 @Column(name="subscribe" ,length=50 )
	 private String subscribe;

	 @Description(remark="会员ID")
	 @Column(name="memberId")
	 private Long memberId;


	public WxUserInfoEntity() {

	}

	
	/**
	  * 设置备注的值
	 * @param 	remark	 备注
	**/
	public void setRemark(String  remark){
		 this.remark=remark;
 	}

	/**
	  * 获取备注的值
	 * @return 返回备注的值
	**/
	public String getRemark(){
		 return remark;
 	}

	/**
	  * 设置修改日期的值
	 * @param 	modifyTime	 修改日期
	**/
	public void setModifyTime(Date  modifyTime){
		 this.modifyTime=modifyTime;
 	}

	/**
	  * 获取修改日期的值
	 * @return 返回修改日期的值
	**/
	public Date getModifyTime(){
		 return modifyTime;
 	}

	/**
	  * 设置创建时间的值
	 * @param 	createTime	 创建时间
	**/
	public void setCreateTime(Date  createTime){
		 this.createTime=createTime;
 	}

	/**
	  * 获取创建时间的值
	 * @return 返回创建时间的值
	**/
	public Date getCreateTime(){
		 return createTime;
 	}

	/**
	  * 设置用户头像的值
	 * @param 	headimgurl	 用户头像
	**/
	public void setHeadimgurl(String  headimgurl){
		 this.headimgurl=headimgurl;
 	}

	/**
	  * 获取用户头像的值
	 * @return 返回用户头像的值
	**/
	public String getHeadimgurl(){
		 return headimgurl;
 	}

	/**
	  * 设置性别的值
	 * @param 	sex	 性别
	**/
	public void setSex(Integer  sex){
		 this.sex=sex;
 	}

	/**
	  * 获取性别的值
	 * @return 返回性别的值
	**/
	public Integer getSex(){
		 return sex;
 	}

	/**
	  * 设置用户的昵称的值
	 * @param 	nickname	 用户的昵称
	**/
	public void setNickname(String  nickname){
		 this.nickname=nickname;
 	}

	/**
	  * 获取用户的昵称的值
	 * @return 返回用户的昵称的值
	**/
	public String getNickname(){
		 return nickname;
 	}

	/**
	  * 设置通用ID的值
	 * @param 	unionid	 通用ID
	**/
	public void setUnionid(String  unionid){
		 this.unionid=unionid;
 	}

	/**
	  * 获取通用ID的值
	 * @return 返回通用ID的值
	**/
	public String getUnionid(){
		 return unionid;
 	}

	/**
	  * 设置公众号openid的值
	 * @param 	openid	 公众号openid
	**/
	public void setOpenid(String  openid){
		 this.openid=openid;
 	}

	/**
	  * 获取公众号openid的值
	 * @return 返回公众号openid的值
	**/
	public String getOpenid(){
		 return openid;
 	}

	/**
	  * 设置是否订阅该公众号的值
	 * @param 	subscribe	 是否订阅该公众号
	**/
	public void setSubscribe(String  subscribe){
		 this.subscribe=subscribe;
 	}

	/**
	  * 获取是否订阅该公众号的值
	 * @return 返回是否订阅该公众号的值
	**/
	public String getSubscribe(){
		 return subscribe;
 	}

	/**
	  * 设置会员ID的值
	 * @param 	memberId	 会员ID
	**/
	public void setMemberId(Long  memberId){
		 this.memberId=memberId;
 	}

	/**
	  * 获取会员ID的值
	 * @return 返回会员ID的值
	**/
	public Long getMemberId(){
		 return memberId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{remark,modifyTime,createTime,headimgurl,sex,nickname,unionid,openid,subscribe,memberId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"remark","modifyTime","createTime","headimgurl","sex","nickname","unionid","openid","subscribe","memberId"};
	}

}
