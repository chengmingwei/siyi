package com.cmw.service.impl;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.core.vo.PageResult;
import com.cmw.core.vo.Pagination;
import com.cmw.dao.DataReportDaoInter;
import com.cmw.entity.StudentEntity;
import com.cmw.service.inter.DataReportService;
import com.cmw.util.*;
import com.cmw.util.export.ExcelExport;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * 数据报表  Service实现类
 * @author 程明卫
 * @date 2019-10-16 21:58:30
 */
@Description(remark="数据报表业务实现类",createDate="2019-10-16 21:58:30",author="程明卫")
@Slf4j
@Service("dataReportService")
public class DataReportServiceImpl extends AbsService<StudentEntity, Long> implements DataReportService{

	@Autowired
	private DataReportDaoInter dataReportDao;

	@Override
	public GenericDaoInter<StudentEntity, Long> getDao() {
		return dataReportDao;
	}

	@Override
	public PageResult<List<Map<String, Object>>> getStudentDetailReport(Map<String, Object> params, Integer currPage, Integer pageSize) {
		//-- query data
		PaginationUtil.setPagingParams(params, currPage, pageSize);
		List<Map<String, Object>> dataSourceResult = dataReportDao.getStudentDetailReport(params);

		//-- query total
		PaginationUtil.setQueryTotalParam(params);
		List<Map<String, Object>> totalResult = dataReportDao.getStudentDetailReport(params);

		//-- transfer result
		return PaginationUtil.getResult(dataSourceResult, totalResult, currPage, pageSize);
	}


	@Override
	public PageResult<List<Map<String, Object>>> getSurplusHoursReport(Map<String, Object> params, Integer currPage, Integer pageSize) {
		//-- query data
		PaginationUtil.setPagingParams(params, currPage, pageSize);
		List<Map<String, Object>> dataSourceResult = dataReportDao.getSurplusHoursReport(params);

		//-- query total
		PaginationUtil.setQueryTotalParam(params);
		List<Map<String, Object>> totalResult = dataReportDao.getSurplusHoursReport(params);

		//-- transfer result
		return PaginationUtil.getResult(dataSourceResult, totalResult, currPage, pageSize);
	}

	@Override
	public PageResult<List<Map<String, Object>>> getGoClassReport(Map<String, Object> params, Integer currPage, Integer pageSize) {
		//-- query data
		PaginationUtil.setPagingParams(params, currPage, pageSize);
		List<Map<String, Object>> dataSourceResult = dataReportDao.getGoClassReport(params);

		//-- query total
		PaginationUtil.setQueryTotalParam(params);
		List<Map<String, Object>> totalResult = dataReportDao.getGoClassReport(params);

		//-- transfer result
		return PaginationUtil.getResult(dataSourceResult, totalResult, currPage, pageSize);
	}

	@Override
	public PageResult<List<Map<String, Object>>> getGoClassHoursReport(Map<String, Object> params, Integer currPage, Integer pageSize) {
		//-- query data
		PaginationUtil.setPagingParams(params, currPage, pageSize);
		List<Map<String, Object>> dataSourceResult = dataReportDao.getGoClassHoursReport(params);

		//-- query total
		PaginationUtil.setQueryTotalParam(params);
		List<Map<String, Object>> totalResult = dataReportDao.getGoClassHoursReport(params);

		//-- transfer result
		return PaginationUtil.getResult(dataSourceResult, totalResult, currPage, pageSize);
	}

	@Override
	public PageResult<List<Map<String, Object>>> getGoClassByTeacherReport(Map<String, Object> params, Integer currPage, Integer pageSize) {
		//-- query data
		PaginationUtil.setPagingParams(params, currPage, pageSize);
		List<Map<String, Object>> dataSourceResult = dataReportDao.getGoClassByTeacherReport(params);

		//-- query total
		PaginationUtil.setQueryTotalParam(params);
		List<Map<String, Object>> totalResult = dataReportDao.getGoClassByTeacherReport(params);

		//-- transfer result
		return PaginationUtil.getResult(dataSourceResult, totalResult, currPage, pageSize);
	}

	PageResult<List<Map<String, Object>>> getPageResultByCallback(SHashMap<String, Object> params,PageCallback pageCallback){
		Integer currPage = params.getvalAsInt("currPage");
		Integer pageSize = params.getvalAsInt("pageSize");
		Map<String,Object> map = params.getMap();

		if(null == pageSize) pageSize = 10;
		Integer offset = 0;
		if(null == currPage) currPage = 0;
		currPage--;
		if(currPage < 0) currPage = 0;
		if(null != currPage && currPage.intValue() > 0){
			offset = (currPage * pageSize);
		}
		Long total = pageCallback.getTotals(map);
		if(null == total) total = 0L;
		map.put("offset", offset);
		map.put("pageSize", pageSize);
		List<Map<String,Object>> list = pageCallback.getDataSource(map);
		if(null == currPage) currPage = 0;
		Pagination pagination = new Pagination(total,currPage, pageSize);
		PageResult<List<Map<String,Object>>> pageResult = new PageResult(pagination, list);
		return pageResult;
	}


	interface PageCallback{
		List<Map<String,Object>> getDataSource(Map<String, Object>  params);
		Long getTotals(Map<String, Object>  params);
	}

	/**
	 * 数据导出
	 *
	 * bizType -> [10001: 学生详细信息报表列表, 10002: 学生剩余课时报表, 10003: 学生上课统计局报表, 10004: 学生上课课时报表, 10005: 老师上课统计报表]
	 *
	 * @Author 肖家添
	 * @Date 2019/10/29 19:16
	 */
	@Override
	public void exportData(HttpServletRequest request, HttpServletResponse response, Integer bizType, Map<String, Object> params, Integer currPage, Integer pageSize) {
		PageResult<List<Map<String, Object>>> pageResult;

		switch (bizType){
			case 10001:{
				pageResult = this.getStudentDetailReport(params, currPage, pageSize);
				break;
			}
			case 10002:{
				pageResult = this.getSurplusHoursReport(params, currPage, pageSize);
				break;
			}
			case 10003:{
				pageResult = this.getGoClassReport(params, currPage, pageSize);
				break;
			}
			case 10004:{
				pageResult = this.getGoClassHoursReport(params, currPage, pageSize);
				break;
			}
			case 10005:{
				pageResult = this.getGoClassByTeacherReport(params, currPage, pageSize);
				break;
			}
			default: throw new ServiceException("数据导出业务类型异常！");
		}

		if (null == pageResult) return;
		List<Map<String, Object>> dataList_LM = ExcelExport.getExportData(PageHandler.getJson(pageResult));

		switch (bizType){
			case 10001:{
				exportData_studentDetail(request, response, dataList_LM);
				break;
			}
			case 10002:{
				exportData_getSurplusHoursReport(request, response, dataList_LM);
				break;
			}
			case 10003:{
				exportData_getGoClassReport(request, response, dataList_LM);
				break;
			}
			case 10004:{
				exportData_getGoClassHoursReport(request, response, dataList_LM);
				break;
			}
			case 10005:{
				exportData_getGoClassByTeacherReport(request, response, dataList_LM);
				break;
			}
		}
	}

	/**
	 * 数据导出 -> 学生详情
	 * @Author 肖家添
	 * @Date 2019/10/29 19:16
	 */
	private void exportData_studentDetail(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM){
		String[] cellVal = {
				"学生ID",
				"学生姓名",
				"性别",
				"手机号",
				"录入时间",
				"报名课程",
				"报读班级",
				"最近缴费时间",
				"最近缴费金额",
				"迟到",
				"累计缴费金额",
				"累计购买课时",
				"累计赠送课时",
				"累计总课时",
				"累计剩余课时",
				"累计已用课时",
				"到课",
				"未到",
				"请假",
				"班主任",
				"教练",
		};

		String[] dataKeys = {
				"studentId",
				"sname",
				"sex",
				"phone",
				"createTime",
				"courseName",
				"className",
				"payDate",
				"payPrice",
				"lateCount",
				"grandAmunt",
				"totalBuyHours",
				"totalGhours",
				"totalHours",
				"totalZhours",
				"totalUhours",
				"goCount",
				"yetCount",
				"leaveCount",
				"masterName",
				"coachName"
		};

		exportData_transferSex(dataList_LM, dataKeys);
		new ExcelExport(request, response).export(cellVal, dataKeys, dataList_LM);
	}

	/**
	 * 数据导出 -> 学生剩余课时
	 * @Author 肖家添
	 * @Date 2019/10/29 19:16
	 */
	private void exportData_getSurplusHoursReport(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM){
		String[] cellVal = {
				"学生ID",
				"学生姓名",
				"性别",
				"课程名称",
				"剩余课时",
				"存量消耗",
				"消耗课时",
				"剩余金额",
				"到课",
				"迟到",
				"未到",
				"请假",
				"报名ID",
				"课程ID"
		};

		String[] dataKeys = {
				"studentId",
				"studentName",
				"sex",
				"courseName",
				"totalZhours",
				"stockUhours",
				"totalUsehours",
				"totalZamount",
				"goCount",
				"lateCount",
				"ungoCount",
				"leaveCount",
				"enrollId",
				"courseId"
		};

		exportData_transferSex(dataList_LM, dataKeys);
		new ExcelExport(request, response).export(cellVal, dataKeys, dataList_LM);
	}

	/**
	 * 数据导出 -> 学生上课统计
	 * @Author 肖家添
	 * @Date 2019/10/29 19:17
	 */
	private void exportData_getGoClassReport(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM){
		String[] cellVal = {
				"学生姓名",
				"手机号",
				"性别",
				"课程名称",
				"班级名称",
				"上课金额",
				"存量消耗",
				"消耗课时",
				"到课",
				"迟到",
				"未到",
				"请假"
		};

		String[] dataKeys = {
				"studentName",
				"phone",
				"sex",
				"courseName",
				"className",
				"goAmount",
				"stockUhours",
				"totalUsehours",
				"goCount",
				"lateCount",
				"ungoCount",
				"leaveCount"
		};

		exportData_transferSex(dataList_LM, dataKeys);
		new ExcelExport(request, response).export(cellVal, dataKeys, dataList_LM);
	}

	/**
	 * 数据导出 -> 学员上课课时（按课时）
	 * @Author 肖家添
	 * @Date 2019/10/29 19:36
	 */
	private void exportData_getGoClassHoursReport(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM){
		String[] cellVal = {
				"学生ID",
				"学生姓名",
				"手机号",
				"性别",
				"平均单价(元)",
				"总订单金额",
				"总课时",
				"存量消耗",
				"上月累计消耗课时",
				"上月剩余课时",
				"上月剩余课时金额",
				"本月报名课时",
				"本月报名金额",
				"本月总上课课时",
				"本月剩余课时",
				"上月累计消耗金额",
				"本月上课金额",
				"本月消耗课时",
				"本月剩余课时金额"
		};

		String[] dataKeys = {
				"studentId",
				"studentName",
				"phone",
				"sex",
				"sum_price",
				"totalPayPrice",
				"totalHours",
				"stockUhours",
				"prevUseCount",
				"prevZcount",
				"prevZamunt",
				"currentTotalHours",
				"currentTotalPayPrice",
				"currentUpGoHours",
				"currentZcount",
				"prevUseAmount",
				"currentGoAmount",
				"currentGoHours",
				"currentZamunt"
		};

		exportData_transferSex(dataList_LM, dataKeys);
		new ExcelExport(request, response).export(cellVal, dataKeys, dataList_LM);
	}

	/**
	 * 数据导出 -> 老师上课统计
	 * @Author 肖家添
	 * @Date 2019/10/29 20:01
	 */
	private void exportData_getGoClassByTeacherReport(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM){
		String[] cellVal = {
				"老师ID",
				"老师姓名",
				"手机号",
				"课程名称",
				"班级名称",
				"到课",
				"身份类型",
				"课程ID",
				"班级ID"
		};

		String[] dataKeys = {
				"teacherId",
				"teacherName",
				"phone",
				"courseName",
				"className",
				"goCount",
				"roleType",
				"courseId",
				"classId"
		};

		new ExcelExport(request, response).export(cellVal, dataKeys, dataList_LM);
	}

	/**
	 * 数据导出 -> 性别转换
	 * @Author 肖家添
	 * @Date 2019/10/29 20:02
	 */
	private void exportData_transferSex(List<Map<String, Object>> dataList_LM, String[] dataKeys){
		for(Map<String, Object> student : dataList_LM){
			SHashMap student_SH = new SHashMap<>(student);

			for(String key : dataKeys){
				String val = student_SH.getvalAsStr(key);

				val = StringHandler.isValidStr(val) ? val : "";

				if("sex".equals(key)){
					switch (val){
						case "1": {
							val = "男";
							break;
						}
						case "2": {
							val = "女";
							break;
						}
					}
				}

				student.put(key, val);
			}
		}
	}
}
