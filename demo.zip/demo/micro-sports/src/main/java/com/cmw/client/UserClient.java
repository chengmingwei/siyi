package com.cmw.client;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cmw.model.back.UserModel;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

/**
 *
 * @Author: chengmingwei
 * @Time: 2019-04-16 19:53
 * @Feature: 用户feignclient
 */
@FeignClient(value = "micro-sysbase")
public interface UserClient {

    /**
     * 保存用户信息
     * @param pars  Map
     * @return  返回JSONObject
     */
    @PostMapping("/user/saveByRemote")
    JSONObject save(@RequestParam Map<String,String> pars, UserModel userInfo);

    /**
     * 获取角色
     * @Param params ==> name
     * @Author 肖家添
     * @Date 2019/6/10 16:13
     */
    @PostMapping("/role/getRoleByParams")
    JSONObject getRoleByParams(@RequestParam Map<String, Object> params);

    /**
     * 保存角色关联信息
     * @param reqParams ==> userId,roleId
     * @Author 肖家添
     * @Date 2019/6/10 16:13
     */
    @PostMapping("/urole/saveUserRolesByRemote")
    JSONObject saveUserRolesByRemote(@RequestParam("reqParams") Map<String, Object> reqParams);

    /**
     * 获取用户
     * @Param id ==> 用户Id
     * @Author 肖家添
     * @Date 2019/6/24 14:30
     */
    @GetMapping("/user/getById")
    JSONObject getUserById(@RequestParam(value = "id", required = true) Long id);

    /**
     * 加载系统参数到缓存中
     * @Param id ==> 用户Id
     * @Author 肖家添
     * @Date 2019/6/24 14:30
     */
    @GetMapping("/sysparams/load-by-recode")
    void loadSysparamsToRedis(@RequestParam(value = "recode", required = true) String recode);

    /**
     * 加载指定ID的用户信息至缓存当中
     * @Param id ==> 用户Id列表
     * @Author cmw
     * @Date 2020/09/07 17:30
     */
    @GetMapping("/user/feign/load")
    void load(@RequestParam(value = "userIds") List<String> userIds, @RequestParam(value = "feignKey") String feignKey);

    /**
     * 更新订单项的商品ID为校区ID
     * @Param params ==> 商品ID关联Map
     * @Author cmw
     * @Date 2020/10/18 10:26
     */
    @PutMapping("/custorderitem/feign/update")
    void updateOrderItems(@RequestParam  Map<String, String> params, @RequestParam(value = "feignKey") String feignKey);

    /**
     * 保存Post
     * @Param params ==> Post 数据Map
     * @Author cmw
     * @Date 2020/10/18 10:26
     */
    @PostMapping("/post/feign/trans")
    void savePost(@RequestParam  Map<String, String> params, @RequestParam(value = "feignKey") String feignKey);
}
