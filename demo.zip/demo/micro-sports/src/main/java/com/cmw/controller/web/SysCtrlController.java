package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.dao.TeacherDao;
import com.cmw.entity.*;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.*;
import com.cmw.util.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;


/**
 * 系统控制面板API  ACTION类
 * @author 程明卫
 * @date 2019-11-12 21:16:43
 */
@Description(remark="系统控制面板ACTION",createDate="2019-11-12 21:16:43",author="程明卫")
@RestController
@RequestMapping({"/sys-ctrl"})
public class SysCtrlController extends BaseAction{

    @Autowired
    private SysCtrlService sysCtrlService;

    /**
     * 根据课次ID重新生成上课记录API
     * /sys-ctrl/rebulid-class-go
     * @param params
     * @return 返回 PageResult 对象
     */
    @ApiOperation("根据课次ID重新生成上课记录API")
    @PostMapping("rebulid-class-go")
    public JSONObject rebulidClassGo(@RequestBody Map<String,Object> params){
        String planIds = (String)params.get("planIds");
        sysCtrlService.rebulidClassGo(planIds);
        return PageHandler.getSuccessJson();
    }

    /**
     * 同步报名表课时
     * /sys-ctrl/synchro-uhours
     * @return 返回 PageResult 对象
     */
    @ApiOperation("根据课次ID重新生成上课记录API")
    @PostMapping("synchro-uhours")
    public JSONObject synchroUhours2Enroll(@RequestParam(value = "studentId", required = false) Long studentId, @RequestParam(value = "courseId", required = false) Long courseId){
        sysCtrlService.synchroUhours2Enroll(studentId, courseId);
        return PageHandler.getSuccessJson();
    }

}
