package com.cmw.service.impl;



import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import org.springframework.util.StringUtils;

import org.apache.http.HttpStatus;
import com.cmw.util.BeanUtil;
import com.cmw.util.SHashMap;

import java.util.HashMap;
import java.util.Map;
import com.cmw.constant.back.SysContant;
import com.cmw.model.back.UserModel;


import com.cmw.entity.PosterImgEntity;
import com.cmw.dao.PosterImgDao;
import com.cmw.service.inter.PosterImgService;


/**
 * 海报图片项  Service实现类
 * @author 程明卫
 * @date 2019-07-10 20:21:28
 */
@Description(remark="海报图片项业务实现类",createDate="2019-07-10 20:21:28",author="程明卫")
@Service("posterImgService")
public class PosterImgServiceImpl extends AbsService<PosterImgEntity, Long> implements  PosterImgService {
	@Autowired
	private PosterImgDao posterImgDao;
	@Override
	public GenericDaoInter<PosterImgEntity, Long> getDao() {
		return posterImgDao;
	}
	
	@Override
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		PosterImgEntity entity = null;
		try {
			entity = BeanUtil.copyValue(PosterImgEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		if(null == entity.getId()){
			insert(entity);
		}else{
			update(entity);
		}

		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}


	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(PosterImgEntity entity) {
				if(null == entity.getCreateTime()){
			throw new ServiceException("创建日期不能为空!");
		}

		if(null == entity.getIsenabled()){
			throw new ServiceException("可用标志不能为空!");
		}

		if(null == entity.getUpldate()){
			throw new ServiceException("图片上传日期不能为空!");
		}

		if(StringUtils.isEmpty(entity.getImgPath())){
			throw new ServiceException("图片地址不能为空!");
		}

			if(StringUtils.isEmpty(entity.getImgPath()) && entity.getImgPath().length() > 200){
			throw new ServiceException("图片地址长度不能超过200!");
			}

		if(null == entity.getPflag()){
			throw new ServiceException("是否封面图片不能为空!");
		}

		if(null == entity.getPosterId()){
			throw new ServiceException("海报ID不能为空!");
		}


	}
}
