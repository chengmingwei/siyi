package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 评论标签实体
 * @Author 肖家添
 * @Date 2019/8/13 16:30
 */
@Description(remark="评论标签实体",createDate="2019-08-13 16:30:08",author="肖家添")
@Entity
@Table(name="GL_CommentTag")
public class CommentTagEntity extends IdEntity {

    @Description(remark="标签名称")
    @Column(name="tagName", length=50)
    private String tagName;

    @Description(remark="用户Id")
    @Column(name="userId", nullable = false)
    private Long userId;

    @Description(remark="创建日期")
    @Column(name="createTime", nullable = false)
    private Date createTime = new Date();

    @Description(remark="可用标志")
    @Column(name="isenabled", nullable = false)
    private Byte isenabled = 1;

    public CommentTagEntity() { }

    public CommentTagEntity(String tagName, Long userId) {
        this.tagName = tagName;
        this.userId = userId;
    }

    /**
     * 标签名称
     * @return
     */
    public String getTagName() {
        return tagName;
    }

    /**
     * 标签名称
     * @return
     */
    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    /**
     * 用户Id
     * @return
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 用户Id
     * @return
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 创建日期
     * @return
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建日期
     * @return
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 可用标志
     * @return
     */
    public Byte getIsenabled() {
        return isenabled;
    }

    /**
     * 可用标志
     * @return
     */
    public void setIsenabled(Byte isenabled) {
        this.isenabled = isenabled;
    }

    @Override
    public Object[] getDatas() {
        return new Object[]{tagName, userId, createTime, isenabled};
    }

    @Override
    public String[] getFields() {
        return new String[]{"tagName", "userId", "createTime", "isenabled"};
    }
}

/**
     CREATE TABLE `GL_CommentTag`  (
     `id` bigint(20) NOT NULL AUTO_INCREMENT,
     `tagName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '标签名称',
     `userId` bigint(11) NOT NULL COMMENT '用户Id',
     `createTime` datetime NOT NULL COMMENT '创建日期',
     `isenabled` tinyint(11) NOT NULL COMMENT '可用标志',
     PRIMARY KEY (`id`) USING BTREE
     ) ENGINE = InnoDB AUTO_INCREMENT = 103 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '评论标签' ROW_FORMAT = Compact;
 */