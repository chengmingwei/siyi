package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.ClassGoEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassGoService;
import com.cmw.service.inter.StudentService;
import com.cmw.util.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.spring.web.json.Json;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 上课记录表  Conntroller类
 * @author 程明卫
 * @date 2019-04-20 13:08:28
 */
@Description(remark="上课记录表Conntroller",createDate="2019-04-20 13:08:28",author="程明卫")
@Api(value = "上课记录表微服务", description = "#CONTROLLER# 2019-04-20 13:08:28 程明卫")
@RestController
@RequestMapping({"/classgo"})
public class ClassGoController{

	@Resource(name="classGoService")
	private ClassGoService classGoService;

	@Resource
    private StudentService studentService;

    /**
     *   PC端（班级详情 --> 上课记录 --> 请假学员）根据课次排班ID找请假学生记录
     *  /classgo/pc/leaves
     * @param  planId   课次排班ID
     * @return
     */
    @ApiOperation("上课记录表列表API")
    @PostMapping(value = "/pc/leaves")
    public JSONObject getLeavesByPlanId(@RequestParam(value = "planId") Long planId){
        Map<String,Object> pars = new HashMap<>();
        pars.put("planId",planId);
        List<Map<String,Object>> list = classGoService.getLeavesByPlanId(pars);
        return PageHandler.getJson(list);
    }


    /**
     *  PC端（班级详情 --> 上课记录）根据课次排班ID找上课记录
     *  /classgo/pc/list
     * @param  btag 状态标识码   [1:到课学员,2:未到学员,3:请假学员,4:未到上课时间]
     * @param  planId   课次排班ID
     * @return
     */
    @ApiOperation("上课记录表列表API")
    @PostMapping(value = "/pc/list")
    public JSONObject getListByXstatus(@RequestParam(value = "btag") Integer btag,
                                     @RequestParam(value = "planId") Long planId){
        Map<String,Object> pars = new HashMap<>();
        pars.put("btag", btag);
        pars.put("planId",planId);
        List<Map<String,Object>> list = classGoService.getListByXstatus(pars);
        return PageHandler.getJson(list);
    }

    /**
     *  家长端（首页课程安排)
     *  /classgo/wx/home
     * @return
     */
    @ApiOperation("上课记录表列表API")
    @PostMapping(value = "/wx/home")
    public JSONObject wx_parent_home(@RequestParam(value = "startTime", required = false) String startTime){
        UserModel userModel = LoginInterceptor.getLoginUser();
        Long memberId = userModel.getId();
        Map<String,Object> pars = new HashMap<>();
        pars.put("memberId", memberId);
        pars.put("bussTag","wx_index");
        if(StringUtils.isEmpty(startTime)){ //提前两天的课程显示出来
            startTime = DateUtil.dateFormatToStr(DateUtil.addDaysToDate(new Date(), 2));
        }
        pars.put("goTime_start", startTime);
        List<Map<String,Object>> list = classGoService.getListMap(pars);
        return PageHandler.getJson(list);
    }

    /**
     *  家长端上课记录（上课记录则倒序并取最近3个月（到今天的3个月的上课记录）)
     *
     * @return
     *
     */
    @ApiOperation("上课记录表列表API")
    @PostMapping(value = "/wx/list")
    public JSONObject wx_parent_list(@RequestParam(required = false, value = "studentId") Long studentId){
        UserModel userModel = LoginInterceptor.getLoginUser();
        Long memberId = userModel.getId();
        Map<String,Object> pars = new HashMap<>();
        if(null != studentId){
            pars.put("studentId", studentId);
        }else{
            pars.put("memberId", memberId);
        }

        Date today = new Date();
        Date startDate = DateUtil.minusMonthToDate(today, 3);
        String goTime_start = DateUtil.dateFormatToStr(startDate);
        String goTime_end = DateUtil.dateFormatToStr(today);
        String goTime_tommorw = DateUtil.addDays(goTime_end,1);
        pars.put("goTime_start", goTime_start);
        pars.put("goTime_end",goTime_tommorw);
        List<Map<String,Object>> list = classGoService.getListMap(pars);
        JSONObject dataResult = PageHandler.getJson(list);
        dataResult.put("goTime_start", goTime_start);
        dataResult.put("goTime_end", goTime_end);
        return dataResult;
    }


    /**
     *  学生点名前的检查
     *  /classgo/roll/1  [单笔点名]
     *  /classgo/roll/2  [批量点名]
     * @param rollType 点名方式[1:单笔点名,2:批量]
     * @param classGoIds 上课记录ID列表
     * @return
     */
    @ApiOperation("学生点名前的检查")
    @PostMapping(value = "/roll/{rollType}")
    public JSONObject checkRoll(@PathVariable("rollType") Integer rollType, @RequestParam("classGoIds") String  classGoIds
            , @RequestParam("cupHours") Integer  cupHours){
        if(null == rollType) return PageHandler.getFailureJson("参数rollType不能为空！");
        if(!StringHandler.isValidStr(classGoIds)) return PageHandler.getFailureJson("参数classGoIds不能为空！");
        Map<String,Object> dataResult = classGoService.checkRoll(rollType, classGoIds, cupHours);

        if(null != dataResult && dataResult.size() > 0){
            String errMsg = (String)dataResult.get("errMsg");
            String _classGoIds = (String)dataResult.get("classGoIds");
           JSONObject errJson = PageHandler.getFailureJson(errMsg);
            errJson.put("classGoIds", _classGoIds);
           return  errJson;
        }
        return PageHandler.getSuccessJson();
    }

    /**
     *  教练端学生点名
     *  /classgo/wx/roll
     * @param id 上课记录ID
     * @param xstatus 到课状态 [,1:正常,2:迟到,3:旷课,4:请假]
     * @return
     */
    @ApiOperation("教练端学生点名")
    @PostMapping(value = "/wx/roll")
    public JSONObject roll(@RequestParam("id") Long id, @RequestParam("xstatus") Integer xstatus, HttpServletRequest request){

        String cupHours = request.getParameter("cupHours");

        UserModel userModel = LoginInterceptor.getLoginMember();
        SHashMap<String,Object> pars = new SHashMap<>();

        pars.put("id", id);
        pars.put("xstatus", xstatus);
        pars.put("userInfo", userModel);
        pars.put("cupHours", cupHours);

        classGoService.doComplexBusss(pars);
        return PageHandler.getSuccessJson();
    }

    /**
     *  教练端一键批量学生点名
     *  /classgo/batch/roll
     * @param planId 排班课次ID
     * @return
     */
    @ApiOperation("教练端学生点名")
    @PostMapping(value = "/batch/roll")
    public JSONObject batchRoll(@RequestParam("planId") Long planId, @RequestParam("classGoIds") String  classGoIds){
        Integer xstatus = BussContant.CLASSGO_XSTATUS_0;
        Map<String,Object> params = new HashMap<>();
        params.put("xstatus",xstatus);
        params.put("planId", planId);
        if(StringUtils.isEmpty(classGoIds)){
            params.put("classGoIds", classGoIds);
        }
        //-- 新增条件
        params.put("appendConditions", true);

        List<ClassGoEntity> list = classGoService.getList(params);
        if(null == list  || list.isEmpty()){
            return PageHandler.getFailureJson("没有需要批量点名的上课记录!");
        }
        UserModel userModel = LoginInterceptor.getLoginMember();
        SHashMap<String,Object> pars = new SHashMap<>();
        pars.put("xstatus", BussContant.CLASSGO_XSTATUS_1);
        pars.put("userInfo", userModel);
        for(ClassGoEntity entity : list){
            Long id = entity.getId();
            pars.put("id", id);
            classGoService.doComplexBusss(pars);
        }
        return PageHandler.getSuccessJson();
    }


    /**
     *  教练端（上课记录）根据班级ID找上课记录
     *  /classgo/16
     *  根据班级ID获取上课记录列表
     * @param classId 班级ID
     * @return
     */
     @ApiOperation("上课记录表列表API")
    @PostMapping(value = "/class/{classId}")
    public JSONObject list(@PathVariable Long classId){
        List<Map<String,Object>> list = classGoService.getListByClassId(classId);
        return PageHandler.getJson(list);
    }

    /**
     *  教练端（上课记录）根据课次排班ID找上课记录
     *  /classgo/16
     *  根据班级ID获取上课记录列表
     * @param planId 班级ID
     * @return
     */
    @ApiOperation("上课记录表列表API")
    @PostMapping(value = "/plan/{planId}")
    public JSONObject listByTempPlan(@PathVariable Long planId){
        List<Map<String,Object>> list = classGoService.getListByPlanId(planId);
        return PageHandler.getJson(list);
    }
    /**
     *
     * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，
     *               参数含：[studentId:学生ID，
     *               goTime_start：开始日期，
     *               goTime_end：结束日期，
     *               courseId：课程ID，
     *               xstatus：状态，
     *               pageSize : 每页大小,
     *               page：当前页])
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询上课记录表信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
      //  String rightCondition = UserUtil.getRightSql("A", userObj);
        //params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = classGoService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }

    /**
     * 获取上课记录里已点名的课时总数
     * @param studentId 学生ID
     * @return
     */
    @ApiOperation("获取上课记录里已点名的课时总数")
    @PostMapping(value = "/uhours/{studentId}")
    public JSONObject getUhours(@ApiParam("上课记录表ID") @PathVariable("studentId") Long studentId,
                                @RequestParam(required = false) Long courseId,
                                @RequestParam(required = false) String goTime_start,
                                @RequestParam(required = false) String goTime_end){
        if(!StringHandler.isValidObj(studentId)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        if(StringUtils.isNotEmpty(goTime_end)){
            goTime_end = DateUtil.addDays(goTime_end, 1);
        }
        Map<String,Object> pars = new HashMap<>();
        pars.put("studentId", studentId);
        pars.put("courseId", courseId);
        pars.put("goTime_start", goTime_start);
        pars.put("goTime_end", goTime_end);
        pars.put("actionType","getUhours");
        Long totals = classGoService.getTotals(pars);
        JSONObject jsonObject = PageHandler.getSuccessJson("useHours", totals);
        return   jsonObject;
    }


	/**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取上课记录表信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("上课记录表ID") @PathVariable("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        ClassGoEntity obj = classGoService.get(id);
        JSONObject jsonObject = PageHandler.getJson(obj);
        return   jsonObject;
    }

    /**
     * 获取上课记录
     * @Author 肖家添
     * @Date 2019/7/17 11:54
     */
    @PostMapping("/getClassGo")
    @ApiOperation("获取上课记录")
    public JSONObject getClassGo(@RequestParam Map<String, Object> params){
        return PageHandler.getJson(classGoService.getClassGoByParams(params));
    }

    /**
     * 家长端 ==> 获取上课记录
     * @Author 肖家添
     * @Date 2019/7/18 17:58
     */
    @ApiOperation("家长端 ==> 获取上课记录")
    @PostMapping("/getClassGoByStudent")
    public JSONObject getClassGoByStudent(@RequestParam(required = false) Long classGoId){
        try{
            UserModel loginUser = LoginInterceptor.getLoginMember();

            if(!StringHandler.isValidObj(loginUser)){
                return PageHandler.getFailureJson("请先登录再进行操作");
            }

            SHashMap<String, Object> params_SH = new SHashMap<>();

            Long memberId = loginUser.getId();

            params_SH.put("memberId", memberId);

            StudentEntity studentEntity = studentService.getByPars(params_SH.getMap());

            if(!StringHandler.isValidObj(studentEntity)){
                return PageHandler.getFailureJson("未找到学生信息");
            }

            params_SH.clear();
            params_SH.put("studentId", studentEntity.getId());
//            params_SH.put("classGoId", classGoId);

            return PageHandler.getJson(classGoService.getClassGoByStudent(params_SH.getMap()));
        }catch (Exception ex){
            ex.printStackTrace();

            return PageHandler.getFailureJson("系统异常，日志：" + ex.getMessage());
        }
    }

    /**
     * 重置应上课时间，应下课时间
     * @Author 肖家添
     * @Date 2019/7/19 10:17
     */
        @PostMapping("/resetTimeToTempPlan")
    public void resetTimeToTempPlan(){
        classGoService.resetTimeToTempPlan();
    }
}
