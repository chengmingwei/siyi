package com.cmw.controller.web;

import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.service.inter.TeacherService;
import com.cmw.service.inter.TempPlanService;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cmw.util.date.DateUtils;

import javax.annotation.Resource;

/**
 * 课程表
 * @Author 肖家添
 * @Date 2019/6/4 16:47
 */
@Description(remark="课程表Controller",createDate="2019-06-04 16:47:20",author="肖家添")
@Api(value = "课程表微服务", description = "#CONTROLLER# 2019-06-04 16:47:20 肖家添")
@RestController
@RequestMapping({"/classScheduleCard"})
@Slf4j
public class ClassScheduleCardController extends BaseAction{

    @Resource(name = "tempPlanService")
    private TempPlanService tempPlanService;

    @Resource(name="teacherService")
    private TeacherService teacherService;

    /**
     * 获取课程表
     * @Author 肖家添
     * @Date 2019/6/4 16:54
     */
    @PostMapping("/getClassScheduleCard")
    public JSONObject getClassScheduleCard(@RequestParam Map<String, Object> params){
        try{
            Integer weekType = getMapInt(params, "weekType", null);
            Integer searchType = getMapInt(params, "searchType", null);

            if(isNilObj(weekType)){
                return fail("必填项不能为空_wt");

            }else if(weekType != 1 && weekType != 2 && weekType != 3){
                return fail("非法参数_wt");

            }else if(isNilObj(searchType)){
                return fail("必填项不能为空_st");

            }else if(searchType != 1 && searchType != 2){
                return fail("非法参数_st");

            }else{
                DateUtils dateUtils = new DateUtils();

                List<String> times = dateUtils.getWeekTime(weekType);

                if(!isNilObj(times) && times.size() > 0){
                    return getClassScheduleCard(times, searchType, params);
                }else{
                    return fail("时间获取失败");
                }
            }

        }catch (Exception ex){
            ex.printStackTrace();

            return fail("系统异常");
        }
    }

    private JSONObject getClassScheduleCard(List<String> times, int searchType, Map<String, Object> params){
        JSONObject returnJSON = success();

        List<List<String>> rows = new ArrayList<>();

        //-- 添加头部
        addTableHeader(rows, times);

        //-- copy一个新集合
        List newTimes = new ArrayList<>();
        newTimes.addAll(times);

        //-- 生成表格
        generateRow(rows, newTimes, searchType, params);

        //-- 头部可视化
        updateChineseHeader(rows);

        returnJSON.put("datas", rows);

        return returnJSON;
    }

    private void addTableHeader(List<List<String>> rows, List<String> times){
        times.add(0, "");

        rows.add(times);
    }

    /**
     * 更新头部日期为周几
     * @Author 肖家添
     * @Date 2019/6/4 18:16
     */
    private void updateChineseHeader(List<List<String>> rows){
        if(!isNilObj(rows) && rows.size() > 0){
            List<String> times = rows.get(0);

            for(int i = 1; i < times.size(); i++){
                String time = times.get(i);

                String weekName = "";
                switch (i){
                    case 1:{
                        weekName = "周一";
                        break;
                    }
                    case 2:{
                        weekName = "周二";
                        break;
                    }
                    case 3:{
                        weekName = "周三";
                        break;
                    }
                    case 4:{
                        weekName = "周四";
                        break;
                    }
                    case 5:{
                        weekName = "周五";
                        break;
                    }
                    case 6:{
                        weekName = "周六";
                        break;
                    }
                    case 7:{
                        weekName = "周日";
                        break;
                    }
                }

                times.set(i, weekName + "("+ time +")");
            }

            rows.set(0, times);
        }
    }

    private void generateRow(List<List<String>> rows, List<String> times, int searchType, Map<String, Object> params){
        String[] colArr = getCol(searchType, params);

        times.remove(0);

        if(!isNilObj(colArr)){
            for(String colName : colArr){
                if(StringUtils.isEmpty(colName)) continue;
                List<String> row = new ArrayList<>();

                row.add(colName);

                for(String time : times){

                    switch (searchType){
                        case 1:{
                            params.remove("startTime");

                            params.put("startTime", time + " " + colName);
                            params.put("startTime_timeFormat", "%Y-%m-%d %H");
                            break;
                        }
                        case 2:{
                            params.remove("teacherId");

                            String[] idAndNameArr = colName.split("#IdNameLF#", 2);

                            String teacherId = idAndNameArr[0];
                            String teacherName = idAndNameArr[1];

                            params.put("startTime", time);
                            params.put("startTime_timeFormat", "%Y-%m-%d");
                            params.put("teacherId", teacherId);

                            if(row.size() == 1){
                                row.remove(0);
                                row.add(teacherName);
                            }

                            break;
                        }
                    }

                    time = "";

                    List<Map<String, Object>> result = tempPlanService.getTempPlanByClassScheduleCard(params);

                    for(int i = 0; i < result.size(); i++){
                        Map<String, Object> item = result.get(i);

                        String courseName = getMapStr(item, "courseName", "");
                        String coachName = getMapStr(item, "coachName", "");
                        String masterName = getMapStr(item, "masterName", "");

                        time += (i + 1) + "、" + courseName.toString() + "#br#" + coachName.toString() + masterName.toString() + "#br#";

                        if((i + 1) != result.size()){
                            time += "#br#";
                        }
                    }

                    row.add(time);
                }

                rows.add(row);
            }
        }
    }

    private String[] getCol(int searchType, Map<String, Object> params){
        String splitChar = "#br#";

        switch (searchType){
            case 1:{
                //-- 时间课表

                String timeStrs = "";
                for(int i = 6; i <= 22; i++) {
                    timeStrs += (i < 10 ? "0" + i : i) + ":00" + splitChar;
                }

                return timeStrs.split(splitChar);
            }
            case 2:{
                //-- 教师课表

                List<Map<String, Object>> getTeacherForSelect = teacherService.getTeacherForSelect(params);

                String teacherStr = "";
                for(int i = 0; i < getTeacherForSelect.size(); i++){
                    Map<String, Object> teacher = getTeacherForSelect.get(i);

                    String id = getMapStr(teacher, "id", "");
                    String tname = getMapStr(teacher, "tname", "");

                    teacherStr += id + "#IdNameLF#" + tname + splitChar;
                }

                return teacherStr.split(splitChar);
            }
            default:
                return null;
        }
    }
}