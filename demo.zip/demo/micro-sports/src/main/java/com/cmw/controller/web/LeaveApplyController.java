package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.LeaveApplyEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.LeaveApplyService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 请假表  Conntroller类
 * @author 程明卫
 * @date 2019-04-20 13:26:16
 */
@Description(remark="请假表Conntroller",createDate="2019-04-20 13:26:16",author="程明卫")
@Api(value = "请假表微服务", description = "#CONTROLLER# 2019-04-20 13:26:16 程明卫")
@RestController
@RequestMapping({"/leaveapply"})
public class LeaveApplyController{
	@Resource(name="leaveApplyService")
	private LeaveApplyService leaveApplyService;

    /**
     * 跳转列表页面
     * @param params
     * @return
     */
     @ApiOperation("请假表列表API")
    @PostMapping(value = "/wx/list")
    public JSONObject wx_list(@RequestParam Map<String,Object> params){
        List<Map<String,Object>> list = leaveApplyService.getListMap(params);
        return PageHandler.getJson(list);
    }
    
      /**
     * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询请假表信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = leaveApplyService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }


	/**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取请假表信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("请假表ID") @PathVariable("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        LeaveApplyEntity obj = leaveApplyService.get(id);
        JSONObject jsonObject = PageHandler.getJson(obj);
        return   jsonObject;
    }

    /**
     * 请假审批
     * /sports/leaveapply/audit
     * {id:记录ID,xstatus:状态[1:同意,2不同意], remark:审批内容}
     * @param pars {id:记录ID,xstatus:状态[1:同意,2不同意], remark:审批内容}
     * @return
     */
    @ApiOperation("根据ID获取请假表信息")
    @PostMapping(value = "/audit")
    public JSONObject audit(@RequestParam Map<String,Object> pars){
            //@ApiParam("请假表ID") @PathVariable("id") Long id){

        if(!StringHandler.isValidObj(pars.get("id"))) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        UserModel userInfo = LoginInterceptor.getLoginUser();
        pars.put(SysContant.USER_INFO, userInfo);
        leaveApplyService.audit(pars);
        return   PageHandler.getSuccessJson();
    }


    
    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存请假表信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
        try{
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = LoginInterceptor.getLoginMember();
            pars.put(SysContant.USER_INFO, userInfo);
            Map<String, Object> dataResult = (Map<String, Object>)leaveApplyService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }
    
    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
        return save(param);
    }
    
    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除请假表信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("#DESCRIPTIONID") @PathVariable("id")  Long id) throws Exception{
        leaveApplyService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }

    /**
     * 获取请假记录
     * @Author 肖家添
     * @Date 2019/7/17 15:58
     */
    @ApiOperation("获取请假记录")
    @PostMapping("/getLeaveApply")
    public JSONObject getLeaveApply(@RequestParam Map<String, Object> params){
        return PageHandler.getJson(leaveApplyService.getLeaveApplyByPars(params));
    }
    
}
