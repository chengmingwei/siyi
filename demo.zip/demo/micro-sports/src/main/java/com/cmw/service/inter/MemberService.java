package com.cmw.service.inter;


import com.alibaba.fastjson.JSONArray;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.MemberEntity;
import com.cmw.model.back.UserModel;

import java.util.Map;


/**
 * 会员信息  Service接口
 * @author 程明卫
 * @date 2019-04-10 22:07:38
 */
@Description(remark="会员信息业务接口",createDate="2019-04-10 22:07:38",author="程明卫")
public interface MemberService extends IService<MemberEntity, Long> {

    /**
     * 根据 openid 登录
     * @param openid
     * @param  memberId 会员ID
     * @return
     * @throws ServiceException
     */
    UserModel login(String openid, Long memberId) throws ServiceException;

    JSONArray login(String username, String password, Integer ltype,
                    String ipAddr, Integer isource, String openid) throws ServiceException;

    /**
     * 修改密码
     * @Author 肖家添
     * @Date 2019/7/15 14:28
     */
    void editPassword(Map<String, Object> params);
}
