package com.cmw.service.impl;



import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.cmw.entity.ExchangeGoEntity;
import com.cmw.dao.ExchangeGoDao;
import com.cmw.service.inter.ExchangeGoService;


/**
 * 学员转派  Service实现类
 * @author 程明卫
 * @date 2019-04-10 13:51:12
 */
@Description(remark="学员转派业务实现类",createDate="2019-04-10 13:51:12",author="程明卫")
@Service("exchangeGoService")
public class ExchangeGoServiceImpl extends AbsService<ExchangeGoEntity, Long> implements  ExchangeGoService {
	@Autowired
	private ExchangeGoDao exchangeGoDao;
	@Override
	public GenericDaoInter<ExchangeGoEntity, Long> getDao() {
		return exchangeGoDao;
	}

}
