package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.ClassGoEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassGoService;
import com.cmw.service.inter.WxHomeService;
import com.cmw.util.DateUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 上课记录表  Conntroller类
 * @author 程明卫
 * @date 2019-04-20 13:08:28
 */
@Description(remark="上课记录表Conntroller",createDate="2019-04-20 13:08:28",author="程明卫")
@Api(value = "上课记录表微服务", description = "#CONTROLLER# 2019-04-20 13:08:28 程明卫")
@Slf4j
@RestController
@RequestMapping({"/home"})
public class HomeController {
	@Resource(name="homeService")
	private WxHomeService homeService;

    /**
     *  家长端（首页课程安排)
     *  //home/wx
     * @return
     */
    @ApiOperation("小程序校长&销售首页数据API")
    @PostMapping(value = "/wx")
    public JSONObject getWxHomeData(){
        UserModel userModel = LoginInterceptor.getLoginUser();
        Map<String,Object> params = new HashMap<>();
        params.put(SysContant.USER_INFO, userModel);
        Map<String,Object> dataMap = homeService.getHomeDataForWx(params);
        return PageHandler.getJson(dataMap);
    }

    /**
     *  PC端（首页统计数据)
     *
     * @return
     */
    @ApiOperation("PC端首页数据API")
    @PostMapping(value = "/pc")
    public JSONObject getPcHomeData(@RequestBody Map<String,Object> params){
        UserModel userModel = LoginInterceptor.getLoginUser();
        Object obj_utype = params.get("utype");
        Integer _utype = userModel.getUtype();
        if(StringHandler.isValidObj(obj_utype) && _utype.equals(0)){
            Integer utype = Integer.parseInt(obj_utype.toString());
            userModel.setUtype(utype);
        }
        params.put(SysContant.USER_INFO, userModel);
        Map<String,Object> dataMap = homeService.getHomeDataForPc(params);
        return PageHandler.getJson(dataMap);
    }

    /**
     *  PC端（首页统计数据)
     *
     * @return
     */
    @ApiOperation("PC端首页机构收入API")
    @PostMapping(value = "/pc/instIncomeList")
    public JSONObject getPcHomeInstIncomeList(@RequestBody Map<String,Object> params){
        UserModel userModel = LoginInterceptor.getLoginUser();
        params.put(SysContant.USER_INFO, userModel);
        Map<String,Object> dataMap = homeService.getHomeInstIncomeListForPc(params);
        return PageHandler.getJson(dataMap);
    }

    /**
     *  PC端（首页统计数据)
     *
     * @return
     */
    @ApiOperation("PC端首页课消金额API")
    @PostMapping(value = "/pc/useCountList")
    public JSONObject getPcHomeUseCountList(@RequestBody Map<String,Object> params){
        UserModel userModel = LoginInterceptor.getLoginUser();
        params.put(SysContant.USER_INFO, userModel);
        Map<String,Object> dataMap = homeService.getHomeUseCountListForPc(params);
        return PageHandler.getJson(dataMap);
    }

    /**
     * [小程序] -> [教练端] -> [教练角色] -> [数据汇总]
     * @Author 肖家添
     * @Date 2019/8/12 15:59
     */
    @ApiOperation("[小程序] -> [教练端] -> [教练角色] -> [数据汇总]")
    @PostMapping("/wx/coach/getWxHomeDataOfCoach")
    public JSONObject getWxHomeDataOfCoach(){
        Map<String, Object> returnMap = homeService.getWxHomeDataOfCoach();

        return PageHandler.getJson(returnMap);
    }
}
