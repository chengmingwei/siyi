package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.ClassChooseEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * 选/转班表  Mapper接口
 * @author 程明卫
 * @date 2019-04-20 12:06:21
 */
@Description(remark="选/转班表DAO Mapper接口",createDate="2019-04-20 12:06:21",author="程明卫")
@Component
@Mapper
public interface ClassChooseDao extends GenericDaoInter<ClassChooseEntity, Long>{

    List<Map<String, Object>> getStudents(Map<String, Object> pars);
}
