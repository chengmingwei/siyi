package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.dao.TeacherDao;
import com.cmw.entity.*;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.*;
import com.cmw.util.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;


/**
 * 班级  ACTION类
 * @author 程明卫
 * @date 2019-04-10 14:02:43
 */
@Description(remark="班级ACTION",createDate="2019-04-10 14:02:43",author="程明卫")
@Api(value = "班级微服务", description = "#CONTROLLER# 2019-04-10 14:02:43 程明卫")
@RestController
@RequestMapping({"/class"})
public class ClassController extends BaseAction{
	@Resource(name="classService")
	private ClassService classService;

    @Resource(name="courseService")
    private CourseService courseService;

    @Resource(name = "tempPlanService")
    private TempPlanService tempPlanService;

    @Autowired
    private ClassSetService classSetService;

    @Autowired
    private SchoolService schoolService;

    @Autowired
    TeacherDao teacherDao;

    /**
     *
     * -- 教师详情
     * -- 授课班级
     * /class/pc/list
     * @param params
     * @return 返回 PageResult 对象
     */
    @ApiOperation("查询班级信息列表API")
    @PostMapping("pc/list")
    public JSONObject getClassByTeacher(@RequestParam Map<String,Object> params){
        List<Map<String,Object>> list = null;
                Object btagObj = params.get("btag");
        if(null == btagObj){
            return PageHandler.getFailureJson("参数：btag 不能为空！");
        }
        Integer btag = Integer.parseInt(btagObj.toString());
        switch (btag.intValue()){
            case 1:{ //通过老师ID获取班级信息
                Object teacherIdObj = params.get("teacherId");
                Long teacherId = Long.parseLong(teacherIdObj.toString());
//                TeacherEntity teacherEntity = teacherDao.get(teacherId);
                params.put("teacherIds", teacherId);
                list = classService.getListByPars(params);
                break;
            }
        }

        return PageHandler.getJson(list);
    }


    /**
     * 小程序获取当前用户所创建的班级（如果当前用户是该班级教练或班主任也会显示）
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("查询班级信息列表API")
    @PostMapping("wx/list")
    public JSONObject wxlist(@RequestParam Map<String,Object> params){
        UserModel userInfo = LoginInterceptor.getLoginUser();
        Object courseId = params.get("courseId");
        Object otherCls = params.get("otherCls");
        if(StringHandler.isValidObj(otherCls) && otherCls.toString().equals("0")){
            params.remove("otherCls");
        }
        if(null == courseId || courseId.equals("")){
            Long userId = userInfo.getId();
            params.put("userId", userId);
            params.put("inempId", userInfo.getInempId());
        }
        List<Map<String,Object>> list = classService.getListMap(params);
        return PageHandler.getJson(list);
    }

    /**
     * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询班级信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = getRightSql(userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = classService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }

    private String getRightSql(UserModel userObj){
        String tabAsName = "A"; //表别名
        String rightCondition = UserUtil.getRightSql(tabAsName, userObj);
        Integer utype = userObj.getUtype();
        if(null != utype && utype.intValue() == BussContant.USER_UTYPE_2){
            Long indeptId = userObj.getIndeptId();
            rightCondition = "and (C.id = '"+indeptId+"' or D.schoolId='"+indeptId+"') ";
        }else if(null != utype && utype.intValue() == BussContant.USER_UTYPE_4){
            Long creator = userObj.getId();
            Long inempId = userObj.getInempId();
            rightCondition = " AND ("+tabAsName+".coach='"+inempId+"'" +
                    " or "+tabAsName+".id in (select DISTINCT classId from gl_tempplan where isenabled=1 and coach='"+inempId+"')) ";
        }else if(null != utype && utype.intValue() == BussContant.USER_UTYPE_5){
            Long creator = userObj.getId();
            Long inempId = userObj.getInempId();
            rightCondition = " and ("+tabAsName+".creator = '"+creator+"' or A.master='"+inempId+"' or A.coach='"+inempId+"') ";
        }
        return rightCondition;
    }




    /**
     * 跳转详细页面
     * @param id 记录ID
     * @param btag 业务标识[1：以课次ID查找班级信息 planId,  否则， id为班级ID]
     * @return
     */
    @ApiOperation("根据ID获取班级信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("班级信息ID") @PathVariable("id") Long id,
                          @RequestParam(value = "btag", required = false) Integer btag){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        ClassEntity obj = null;
        String sdTime = "";
        Long planId = null;
        Long classSetId = null;
        Long coach = null;
        Long master = null;
        Long oldCoach = null;
        if(null != btag && btag.intValue() == 1){
            TempPlanEntity tempPlanEntity = tempPlanService.get(id);
            classSetId = tempPlanEntity.getSid();
            Long classId = tempPlanEntity.getClassId();
            ClassEntity classEntity = classService.get(classId);

            coach = classEntity.getCoach();
            oldCoach = tempPlanEntity.getOldCoach();
            master = classEntity.getMaster();

            Date startTime = tempPlanEntity.getStartTime();
            Date endTime = tempPlanEntity.getEndTime();
            String startTimeStr = DateUtil.dateFormatToStr("yyyy-MM-dd HH:mm", startTime);
            String endTimeStr = DateUtil.dateFormatToStr("HH:mm", endTime);
            sdTime = startTimeStr + " - " + endTimeStr;
            planId = id;
            obj = classService.get(tempPlanEntity.getClassId());
        }else{
            obj = classService.get(id);
        }

        CourseEntity courseEntity = courseService.get(obj.getCourseId());
        JSONObject jsonObject = PageHandler.getJson(obj);
        Date sdate = obj.getSdate();
        if(null != sdate){
           String dateStr = DateUtil.dateFormatToStr(sdate);
            JSONObject datas = jsonObject.getJSONObject("datas");
            datas.put("sdate", dateStr);
            jsonObject.put("datas", datas);
        }
//        Long coach = obj.getCoach();
//        Long master = obj.getMaster();
        TeacherEntity coachEntity = teacherDao.get(coach);
        TeacherEntity masterEntity = teacherDao.get(master);
        String coachName = "----";
        String masterName = "----";
        if(null != coachEntity){
            coachName = coachEntity.getTname();
            if(oldCoach != null) coachName += "【临】";

            //-- Coach spare ids handler. begin
            String coachSpareIds = obj.getCoachSpareIds();
            if(StringHandler.isValidStr(coachSpareIds)){
                String[] coachSpareIdsArr = coachSpareIds.split(",");

                coachName += String.format("(%s个)", coachSpareIdsArr.length + 1);
            }
            //-- Coach spare ids handler. end
        }
        if(null != masterEntity){
            masterName = masterEntity.getTname();
        }

        Long schoolId = obj.getSid();

        if(StringHandler.isValidObj(schoolId)){
            SchoolEntity school = schoolService.get(schoolId);

            jsonObject.put("school", school);
        }

        jsonObject.put("coachName", coachName);
        jsonObject.put("masterName", masterName);
        jsonObject.put("planId", planId);
        jsonObject.put("classSetId", classSetId);
        jsonObject.put("sdTime", sdTime);
        jsonObject.put("courseName", courseEntity.getCname());
        jsonObject.put("courseImg",courseEntity.getImgPath());
        jsonObject.put("describes",courseEntity.getDescribes());
        return jsonObject;
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存班级信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
        try{
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = LoginInterceptor.getLoginUser();
            pars.put(SysContant.USER_INFO, userInfo);
            Map<String, Object> dataResult = (Map<String, Object>)classService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }

    }

    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
        return save(param);
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除班级信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("班级ID") @PathVariable("id")  Long id) throws Exception{
        Map<String,Object> pars = new HashMap<>();
        pars.put("classId",id);
        List<ClassSetEntity> classSetList = classSetService.getList(pars);
        if(null != classSetList  && classSetList.size() > 0){
            PageHandler.getFailureJson("当前班级下已经排课，不能删除！");
        }
        classService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }
    /**
     * 根据部门名称获取
     * @param request
     * @param response
     * @return
     */
    @ApiOperation("根据班级名称获取")
    @RequestMapping(value = "/getByClassName")
    public JSONObject getByClassName(HttpServletRequest request, HttpServletResponse response){
        String name = request.getParameter("name");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("cname",name);
        List<ClassEntity> list = new ArrayList<ClassEntity>();
        if (StringHandler.isValidStr(name)){
            list  =classService.getList(map);
        }else {
            list = classService.getListAll();
        }

        return PageHandler.getJson(list);
    }

    /**
     * 添加临时教练
     * @Author 肖家添
     * @Date 2019/6/17 16:54
     */
    @ApiOperation("添加临时教练")
    @PostMapping(value = "/addTempCoach")
    public JSONObject addTempCoach(@RequestParam Map<String, Object> params){
        try{
            SHashMap<String, Object> params_SH = new SHashMap<>(params);

            Long teacherId = params_SH.getvalAsLng("teacherId");
            Long classId = params_SH.getvalAsLng("classId");
            Long planId = params_SH.getvalAsLng("planId");
            if(isNilObj(teacherId)){
                return fail("教练编号不能为空");
            }else if(isNilObj(classId)){
                return fail("班级编号不能为空");
            }else{
                TeacherEntity teacher = teacherDao.get(teacherId);
                TempPlanEntity tempPlanEntity = tempPlanService.get(planId);
               // ClassEntity cls = classService.get(classId);

                if(isNilObj(teacher) || teacher.getIsenabled() != 1){
                    return fail("该教练无效");
                }else if(isNilObj(tempPlanEntity) || tempPlanEntity.getIsenabled() != 1){
                    return fail("本次上课记录无效");
                }else{
                    Long coachId = tempPlanEntity.getCoach();

                    tempPlanEntity.setOldCoach(coachId);
                    tempPlanEntity.setCoach(teacherId);
                    tempPlanService.update(tempPlanEntity);
                    //classService.update(cls);

                    return success("添加成功");
                }
            }
        }catch (Exception ex){
            ex.printStackTrace();

            return fail("系统异常");
        }
    }

    /**
     * 获取班级下拉框
     * @Author 肖家添
     * @Date 2019/6/20 0:09
     **/
    @ApiOperation("获取班级下拉框")
    @PostMapping("/getClassForSelect")
    public JSONObject getClassForSelect(){
        return PageHandler.getJson(classService.getListAll());
    }
}
