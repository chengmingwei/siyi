package com.cmw.config;

import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.RoundRobinRule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @ClassName RestConfig
 * @Description: TODO
 * @Author cheng
 * @Date 2020/9/22
 * @Version V1.0
 **/
@Configuration
public class RestConfig {

    @Bean
    public IRule iRule(){
        return new RoundRobinRule();
    }
}
