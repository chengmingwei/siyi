package com.cmw.service.impl;



import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.entity.PosterImgEntity;
import com.cmw.service.inter.PosterImgService;
import com.cmw.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;
import com.cmw.constant.back.SysContant;
import com.cmw.model.back.UserModel;


import com.cmw.entity.PosterEntity;
import com.cmw.dao.PosterDao;
import com.cmw.service.inter.PosterService;

import javax.annotation.Resource;


/**
 * 学生海报  Service实现类
 * @author 程明卫
 * @date 2019-07-10 20:19:51
 */
@Description(remark="学生海报业务实现类",createDate="2019-07-10 20:19:51",author="程明卫")
@Service("posterService")
public class PosterServiceImpl extends AbsService<PosterEntity, Long> implements  PosterService {
	@Autowired
	private PosterDao posterDao;

	@Resource(name="posterImgService")
	private PosterImgService posterImgService;

	@Override
	public GenericDaoInter<PosterEntity, Long> getDao() {
		return posterDao;
	}
	
	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		PosterEntity entity = null;
		Long studentId = params.getvalAsLng("studentId");
		Long groId = params.getvalAsLng("groId");
		Integer ptype = params.getvalAsInt("ptype");
		Map<String,Object> pars = new HashMap<>();
		pars.put("studentId", studentId);
		pars.put("groId", groId);
		pars.put("ptype", ptype);
//		entity = getByPars(pars);
//		if(null != entity) {
//			delete(entity.getId());
//			Map<String,Object> ps = new HashMap<>();
//			pars.put("posterId", entity.getId());
//			posterImgService.deleteByPars(ps);
//			entity = null;
//		}
		if(null == entity){
			try {
				entity = BeanUtil.copyValue(PosterEntity.class, params.getMap());
			} catch (UtilException e) {
				e.printStackTrace();
				throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
			}

			validInfo(entity);
			insert(entity);
		}else{
			String comment1 = params.getvalAsStr("comment1");
			String comment2 = params.getvalAsStr("comment2");
			entity.setComment1(comment1);
			entity.setComment2(comment2);
			update(entity);
		}
		PosterImgEntity selPosterImgObj = batchPostImgs(entity, params);
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("posterId", entity.getId());
		if(null == selPosterImgObj) return  dataResult;
		dataResult.put("posterImgId", selPosterImgObj.getId());
		dataResult.put("imgPath", selPosterImgObj.getImgPath());
		dataResult.put("posterObj", entity);
		return dataResult;
	}

	/**
	 * 	批量保存海报图片项
	 */
	private PosterImgEntity batchPostImgs(PosterEntity posterEntity, SHashMap<String, Object> params){
		String posterImgs = params.getvalAsStr("posterImgs");
		Integer selImgIndex = params.getvalAsInt("selImgIndex");
		Long posterId = posterEntity.getId();

		if(StringUtils.isEmpty(posterImgs)) return null;
		JSONArray jsonArray = FastJsonUtil.convertStrToJSONArr(posterImgs);
		PosterImgEntity selPosterImgObj = null;
		for(int i=0, count=jsonArray.size(); i<count; i++){
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			String date = jsonObject.getString("date");
			String imgPath = jsonObject.getString("imgPath");
			Byte pflag = (selImgIndex.intValue() == i) ? (byte)1 : (byte)0;
			PosterImgEntity posterImgObj = new PosterImgEntity();
			posterImgObj.setPosterId(posterId);
			posterImgObj.setPflag(pflag);
			posterImgObj.setImgPath(imgPath);
			posterImgObj.setUpldate(date);
			posterImgService.insert(posterImgObj);
			if(pflag.intValue() == 1){
				selPosterImgObj = posterImgObj;
			}
		}
		return selPosterImgObj;
	}

	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(PosterEntity entity) {
		if(null == entity.getCreateTime()){
			throw new ServiceException("创建日期不能为空!");
		}

		if(null == entity.getIsenabled()){
			throw new ServiceException("可用标志不能为空!");
		}

		if(null == entity.getAcount()){
			throw new ServiceException("访问量不能为空!");
		}

		if(!StringUtils.isEmpty(entity.getComment2()) && entity.getComment2().length() > 200){
			throw new ServiceException("老师评价2长度不能超过200!");
		}

		if(!StringUtils.isEmpty(entity.getComment1()) && entity.getComment1().length() > 200){
			throw new ServiceException("老师评价1长度不能超过200!");
		}

		if(!StringUtils.isEmpty(entity.getPosterImg()) && entity.getPosterImg().length() > 200){
			throw new ServiceException("海报分享图片长度不能超过200!");
		}

		if(null == entity.getGroId()){
			throw new ServiceException("成长档案ID不能为空!");
		}

		if(null == entity.getPtype()){
			throw new ServiceException("海报类型不能为空!");
		}

		if(null == entity.getStudentId()){
			throw new ServiceException("学生ID不能为空!");
		}


	}

	@Override
	public Long getMaxIdByStudentId(Long id) {
		return posterDao.getMaxIdByStudentId(id);
	}
}
