package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.util.BeanUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

import com.cmw.entity.StudentDetailEntity;
import com.cmw.service.inter.StudentDetailService;


/**
 * 学员详细信息  ACTION类
 * @author 程明卫
 * @date 2019-04-10 11:39:22
 */
@Description(remark="学员详细信息ACTION",createDate="2019-04-10 11:39:22",author="程明卫")
@Api(value = "学员详细信息微服务", description = "#CONTROLLER# 2019-04-10 11:39:22 程明卫")
@RestController
@RequestMapping({"/studentdetail"})
public class StudentDetailController{
	@Resource(name="studentDetailService")
	private StudentDetailService studentDetailService;
	
	 /**
     * 跳转主页面
     * @param params
     * @return
     */
     @ApiOperation("学员详细信息首页API")
    @GetMapping(value = "/home")
    public JSONObject home(Map<String, Object> params) throws Exception{
       List<StudentDetailEntity> list = studentDetailService.getListAll();
       return PageHandler.getJson(list);
    }

    /**
     * 跳转列表页面
     * @param request
     * @param response
     * @return
     */
     @ApiOperation("学员详细信息列表API")
    @GetMapping(value = "/list")
    public JSONObject list(HttpServletRequest request, HttpServletResponse response){
        List<StudentDetailEntity> list = studentDetailService.getListAll();
        return PageHandler.getJson(list);
    }

    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取学员详细信息")
    @GetMapping(value = "/info")
    public JSONObject info(@ApiParam("学员详细信息ID") @RequestParam Long id){
      	if(StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        StudentDetailEntity obj = studentDetailService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存学员详细信息")
    @PostMapping(value = "/save")
    public JSONObject save(Map<String, Object> params) throws Exception{
        StudentDetailEntity entity = BeanUtil.copyValue(StudentDetailEntity.class, params);
        studentDetailService.insert(entity);
        return PageHandler.getSuccessJson();
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除学员详细信息")
    @DeleteMapping(value = "/remove")
    public JSONObject remove(@ApiParam("会员ID") @RequestParam Long id) throws Exception{
        studentDetailService.delete(id);
        return PageHandler.getSuccessJson();
    }
	
}
