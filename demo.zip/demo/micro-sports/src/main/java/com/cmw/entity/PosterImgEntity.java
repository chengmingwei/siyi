package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;

import java.util.Date;


/**
 * 海报图片项
 * @author 程明卫
 * @date 2019-07-10 20:21:28
 */
@Description(remark="海报图片项实体",createDate="2019-07-10 20:21:28",author="程明卫")
@Entity
@Table(name="GL_PosterImg")
@SuppressWarnings("serial")
public class PosterImgEntity extends IdEntity {
	
	
	 @Description(remark="创建日期")
	 @Column(name="createTime" ,nullable=false )
	 private Date createTime = new Date();

	 @Description(remark="可用标志")
	 @Column(name="isenabled" ,nullable=false )
	 private Byte isenabled = 1;

	 @Description(remark="图片上传日期")
	 @Column(name="upldate" ,nullable=false, length = 20)
	 private String upldate;

	 @Description(remark="图片地址")
	 @Column(name="imgPath" ,nullable=false ,length=200 )
	 private String imgPath;

	 @Description(remark="是否封面图片")
	 @Column(name="pflag" ,nullable=false )
	 private Byte pflag = 0;

	 @Description(remark="海报ID")
	 @Column(name="posterId" ,nullable=false )
	 private Long posterId;


	public PosterImgEntity() {

	}

	
	/**
	  * 设置创建日期的值
	 * @param 	createTime	 创建日期
	**/
	public void setCreateTime(Date  createTime){
		 this.createTime=createTime;
 	}

	/**
	  * 获取创建日期的值
	 * @return 返回创建日期的值
	**/
	public Date getCreateTime(){
		 return createTime;
 	}

	/**
	  * 设置可用标志的值
	 * @param 	isenabled	 可用标志
	**/
	public void setIsenabled(Byte  isenabled){
		 this.isenabled=isenabled;
 	}

	/**
	  * 获取可用标志的值
	 * @return 返回可用标志的值
	**/
	public Byte getIsenabled(){
		 return isenabled;
 	}

	/**
	  * 设置图片上传日期的值
	 * @param 	upldate	 图片上传日期
	**/
	public void setUpldate(String  upldate){
		 this.upldate=upldate;
 	}

	/**
	  * 获取图片上传日期的值
	 * @return 返回图片上传日期的值
	**/
	public String getUpldate(){
		 return upldate;
 	}

	/**
	  * 设置图片地址的值
	 * @param 	imgPath	 图片地址
	**/
	public void setImgPath(String  imgPath){
		 this.imgPath=imgPath;
 	}

	/**
	  * 获取图片地址的值
	 * @return 返回图片地址的值
	**/
	public String getImgPath(){
		 return imgPath;
 	}

	/**
	  * 设置是否封面图片的值
	 * @param 	pflag	 是否封面图片
	**/
	public void setPflag(Byte  pflag){
		 this.pflag=pflag;
 	}

	/**
	  * 获取是否封面图片的值
	 * @return 返回是否封面图片的值
	**/
	public Byte getPflag(){
		 return pflag;
 	}

	/**
	  * 设置海报ID的值
	 * @param 	posterId	 海报ID
	**/
	public void setPosterId(Long  posterId){
		 this.posterId=posterId;
 	}

	/**
	  * 获取海报ID的值
	 * @return 返回海报ID的值
	**/
	public Long getPosterId(){
		 return posterId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{createTime,isenabled,upldate,imgPath,pflag,posterId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"createTime","isenabled","upldate","imgPath","pflag","posterId"};
	}

}
