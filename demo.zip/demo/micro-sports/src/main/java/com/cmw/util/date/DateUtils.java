package com.cmw.util.date;

import com.cmw.util.StringHandler;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;

@Slf4j
public class DateUtils {

    /**
     * 获取日期
     *
     * 本周日期 type = 1
     * 上周日期 type = 2
     * 下周日期 type = 3
     * else error
     *
     * @author 肖家添
     * 2019年6月4日 下午2:45:34
     */
    public List<String> getWeekTime(int type){
        try {
            long mondayTimeOfThisWeek = getMondayOfThisWeek();

            List<String> times = null;

            switch(type) {
                case 1:{
                    log.info("获取本周所有日期 ==>");

                    times = getThisWeek(mondayTimeOfThisWeek);
                    break;
                }
                case 2:{
                    log.info("获取上周所有日期 ==>");

                    times = getPrevWeek(mondayTimeOfThisWeek);
                    break;
                }
                case 3:{
                    log.info("获取下周所有日期 ==>");

                    times = getNextWeek(mondayTimeOfThisWeek);
                    break;
                }
                default:{
                    throw new Exception("get times error, the type not found!");
                }
            }

            if(StringHandler.isValidObj(times) && times.size() > 0) {

                log.info("获取日期结束");

                return times;
            }

        }catch(Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public String addNowDays(int days){
        Calendar calendar = Calendar.getInstance();

        calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + days);

        return getTimeForCalendar(calendar);
    }

    /**
     * 获取本周星期一的日期
     * @author 肖家添
     * 2019年6月7日 上午11:36:21
     */
    private long getMondayOfThisWeek() {
        Calendar cale = Calendar.getInstance();
        int day_of_week = cale.get(Calendar.DAY_OF_WEEK) - 1;
        if (day_of_week == 0)
            day_of_week = 7;

        cale.add(Calendar.DATE, -day_of_week + 1);

        return cale.getTimeInMillis();
    }

    /**
     * 获取本周所有日期
     * @author 肖家添
     * 2019年6月4日 上午11:59:12
     */
    private List<String> getThisWeek(long mondayOfThisWeek) {
        Calendar cale = Calendar.getInstance();

        List<String> times = new ArrayList<String>();

        for(int i = 0; i < 7; i++) {

            cale.setTimeInMillis(mondayOfThisWeek);

            int day = getDay(cale);

            cale.set(Calendar.DAY_OF_MONTH, day + i);

            times.add(getTimeForCalendar(cale));
        }

        return times;
    }

    /**
     * 获取上周所有日期
     * @author 肖家添
     * 2019年6月4日 上午11:58:33
     */
    private List<String> getPrevWeek(long mondayOfThisWeek) {
        Calendar cale = Calendar.getInstance();

        List<String> times = new ArrayList<String>();

        for(int i = 7; i > 0; i--) {
            cale.setTimeInMillis(mondayOfThisWeek);

            int day = getDay(cale);

            cale.set(Calendar.DAY_OF_MONTH, day - i);

            times.add(getTimeForCalendar(cale));
        }

        return times;
    }

    /**
     * 获取下周所有日期
     * @author 肖家添
     * 2019年6月4日 下午1:59:09
     */
    private List<String> getNextWeek(long mondayOfThisWeek) {
        Calendar cale = Calendar.getInstance();

        cale.setTimeInMillis(mondayOfThisWeek);
        cale.set(Calendar.DAY_OF_MONTH, getDay(cale) + 7);

        mondayOfThisWeek = cale.getTimeInMillis();

        List<String> times = new ArrayList<String>();

        for(int i = 0; i < 7; i++) {

            cale.setTimeInMillis(mondayOfThisWeek);

            int day = getDay(cale);

            cale.set(Calendar.DAY_OF_MONTH, day + i);

            times.add(getTimeForCalendar(cale));
        }

        return times;
    }

    /**
     * 获取年月日
     * @author 肖家添
     * 2019年6月4日 上午11:52:24
     */
    private String getTimeForCalendar(Calendar cale) {
        int year = getYear(cale);
        int month = getMonth(cale);
        int day = getDay(cale);

        String result = year + "-" + ifLessThanTen(month) + "-" + ifLessThanTen(day);

        System.out.println(result);

        return result;
    }

    /**
     * 获取年
     * @author 肖家添
     * 2019年6月4日 下午12:05:36
     */
    private int getYear(Calendar cale) {
        return cale.get(Calendar.YEAR);
    }

    /**
     * 获取月
     * @author 肖家添
     * 2019年6月4日 下午12:05:28
     */
    private int getMonth(Calendar cale) {
        return cale.get(Calendar.MONTH) + 1;
    }

    /**
     * 获取日
     * @author 肖家添
     * 2019年6月4日 下午12:05:16
     */
    private int getDay(Calendar cale) {
        return cale.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * 如果一个数只有个位则十位加'0'，如2019-1-1 ==> 2019-01-01
     * @author 肖家添
     * 2019年6月4日 上午11:52:46
     */
    private String ifLessThanTen(int num) {
        return num < 10 ? "0" + num : num + "";
    }
}