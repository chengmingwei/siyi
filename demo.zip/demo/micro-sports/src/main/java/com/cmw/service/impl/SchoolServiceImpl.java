package com.cmw.service.impl;



import com.cmw.client.UserClient;
import com.cmw.constant.GlobalConstant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.util.*;
import io.seata.core.context.RootContext;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpStatus;
import org.omg.CORBA.OBJ_ADAPTER;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmw.entity.SchoolEntity;
import com.cmw.dao.SchoolDao;
import com.cmw.service.inter.SchoolService;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;


/**
 * 学校信息  Service实现类
 * @author 程明卫
 * @date 2019-04-10 13:57:41
 */
@Description(remark="学校信息业务实现类",createDate="2019-04-10 13:57:41",author="程明卫")
@Service("schoolService")
public class SchoolServiceImpl extends AbsService<SchoolEntity, Long> implements  SchoolService {
	@Autowired
	private SchoolDao schoolDao;

	@Autowired
	private AmqpTemplate amqpTemplate;

	@Autowired
	private UserClient userClient;

	@Override
	public GenericDaoInter<SchoolEntity, Long> getDao() {
		return schoolDao;
	}

	@RabbitListener(bindings = @QueueBinding(
			value = @Queue(value = GlobalConstant.TASK_QUEUE_ORDER_ITEM_SCHOOL_UPDATE_QUEUE,durable = "true"),
			exchange = @Exchange(value = GlobalConstant.TASK_ORDER_ITEM_SCHOOL_UPDATE_EXCHANGE,ignoreDeclarationExceptions = "true"),
			key = {GlobalConstant.TASK_ORDER_ITEM_SCHOOL_UPDATE_KEY}
	))
	@GlobalTransactional(name = "fsp-update-order", rollbackFor = Exception.class)
	@Transactional(rollbackFor = Exception.class)
	public void buySchoolsNotify(Map<String,Object> msg){
		String xid = RootContext.getXID();
		log.info("buySchoolsNotify.xid = {}", xid);
		Date endDate = (Date)msg.get("endDate");
		UserModel userModel = (UserModel)msg.get(SysContant.USER_INFO);
		List<Map<String, Object>> itemList = (List<Map<String, Object>>)msg.get("itemList");
		List<Long> retainSchoolIds = new ArrayList<>();
		Map<String, String> schoolMap = new HashMap<>();
		itemList.forEach(item -> {
			String goodName = (String)item.get("goodName");
			Long orderItemId = (Long)item.get("orderItemId");
			Long goodId = (Long)item.get("goodId");
			boolean isUpdate = false;
			SHashMap<String,Object> pars = new SHashMap<>();
			if(null != goodId && goodId.longValue() != -1){
				pars.put("id",goodId);
				isUpdate = true;
			}
			pars.put("sname",goodName);
			pars.put(SysContant.USER_INFO, userModel);
			pars.put("isenabled",1);
			Map<String,Object> dataResult = (Map<String,Object>)doComplexBusss(pars);
			goodId = (Long)dataResult.get("id");
			retainSchoolIds.add(goodId);
			if(!isUpdate){
				schoolMap.put(orderItemId.toString(), goodId.toString());
			}
		});
		disabledSchools(retainSchoolIds, userModel);
		log.info("校区创建完成.xid = {}", xid);
		if(null == schoolMap || schoolMap.size() == 0) return;

		//通过 feign 更新商品与校区进行关联
		log.info("开始调用关联订单项ID和校区ID方法.xid = {}", xid);
		userClient.updateOrderItems(schoolMap,GlobalConstant.FEIGN_REQUEST_KEY);
		//2.发消息更新订单项商品ID以便将商品与校区进行关联
		//this.amqpTemplate.convertAndSend(GlobalConstant.TASK_SCHOOL_ORDER_ITEM_UPDATE_EXCHANGE,GlobalConstant.TASK_SCHOOL_ORDER_ITEM_UPDATE_KEY,schoolMap);
	}

	/**
	 * 禁用那些未续费的校区
	 * @param retainSchoolIds
	 */
	private void disabledSchools(List<Long> retainSchoolIds, UserModel userModel) {
		Map<String,Object> dataMap = new HashMap<>();
		Map<String,Object> whereMap = new HashMap<>();
		whereMap.put("ids", StringHandler.join(retainSchoolIds));
		dataMap.put("isenabled",SysContant.ISENABLED_0);//将未续费校区设为禁用
		dataMap.put("modifytime", new Date());
		dataMap.put("modifier", userModel.getId());
		String remark = String.format("机构用户：%s在%s进行产品续费时，没有为当前校区续费，故系统自动停用当前校区！",
				userModel.getUserName(),DateUtil.dateFormatToStr(DateUtil.DATE_TIME_FORMAT2, new Date()));
		dataMap.put("remark", remark);
		this.updateByPars(dataMap, whereMap);

	}

	@Override
	@GlobalTransactional(name = "fsp-update-order", rollbackFor = Exception.class)
	public void test_trans(SHashMap<String, Object> params){
		String xid = RootContext.getXID();
		log.info("开始事务测试。调用：test_trans.xid = {}", xid);
		String sname = params.getvalAsStr("sname");
		doComplexBusss(params);
		log.info("学校：{}插入成功", sname);
		Map<String,String> pars = new HashMap<>();
		pars.put("name", sname);
		log.info("开始调用：userClient.savePost ，插入职位：{}", sname);
		userClient.savePost(pars,GlobalConstant.FEIGN_REQUEST_KEY);
		log.info("调用：userClient.savePost 后，职位：{}插入成功", sname);
//		if(1==1){
//			String exMsg = "手工摸拟异常";
//			log.error(exMsg);
//			throw new ServiceException(exMsg);
//		}
	}

	@Override
	public void test_trans2(SHashMap<String, Object> params){
		String xid = RootContext.getXID();
		log.info("开始事务测试。调用：test_trans.xid = {}", xid);
		String sname = params.getvalAsStr("sname");
		doComplexBusss(params);
		log.info("学校：{}插入成功", sname);
		if(1==1){
			throw new ServiceException("学校异常，XID="+RootContext.getXID());
		}

//		if(1==1){
//			String exMsg = "手工摸拟异常";
//			log.error(exMsg);
//			throw new ServiceException(exMsg);
//		}
	}

	@Override
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		SchoolEntity entity = null;
		try {
			entity = BeanUtil.copyValue(SchoolEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
		valid(entity);
		//1.获取用户
		UserModel userInfo = LoginInterceptor.getLoginUser();
		if(null == userInfo) userInfo = (UserModel)params.get(SysContant.USER_INFO);
		Long id = entity.getId();


		if(null == id){
			IdGeneratorUtils idGeneratorUtils = new IdGeneratorUtils();
			String code = "S"+idGeneratorUtils.nextId();
			entity.setCode(code);
			if(null != userInfo){
				UserUtil.setCreateInfo(userInfo, entity);
			}else{
				UserUtil.setCreateInfoBySysAdmin(entity);
			}

			insert(entity);
			id = entity.getId();
		}else{
			if(null != userInfo){
				UserUtil.setModifyInfo(userInfo, entity);
			}else{
				UserUtil.setModifyInfoBySysAdmin(entity);
			}

			update(entity);
		}
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", id);
		return dataResult;
	}

	private void valid(SchoolEntity entity){
		String sname = entity.getSname();
		if(StringUtils.isEmpty(sname)){
			throw new ServiceException("学校名称不能为空！");
		}
		if(sname.length() > 50){
			throw new ServiceException("学校名称长度不能超过50个字符！");
		}
	}

	@Override
	public List<Map<String, Object>> getSchoolBySelect(Map<String, Object> params) {
		return schoolDao.getSchoolBySelect(params);
	}
}
