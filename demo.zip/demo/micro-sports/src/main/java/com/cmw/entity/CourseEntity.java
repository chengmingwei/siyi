package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import java.math.BigDecimal;


/**
 * 课程信息
 * @author 程明卫
 * @date 2019-04-10 13:59:08
 */
@Description(remark="课程信息实体",createDate="2019-04-10 13:59:08",author="程明卫")
@Entity
@Table(name="GL_Course")
@SuppressWarnings("serial")
public class CourseEntity extends IdBaseEntity {
	
	
	 @Description(remark="课程图片附件ID")
	 @Column(name="attachId" )
	 private Long attachId;

	 @Description(remark="课程图片")
	 @Column(name="imgPath" ,length=150 )
	 private String imgPath;

	 @Description(remark="课程描述")
	 @Column(name="describes" ,length=500 )
	 private String describes;

	 @Description(remark="课程单价")
	 @Column(name="price" ,nullable=false ,scale=2)
	 private BigDecimal price = new BigDecimal("0.00");

	 @Description(remark="学生数量(最多)")
	 @Column(name="maxCount" ,nullable=false )
	 private Integer maxCount;

	 @Description(remark="学生数量(最少)")
	 @Column(name="minCount" ,nullable=false )
	 private Integer minCount = 0;

	@Description(remark="适用校区")
	@Column(name="schoolId" )
	private Long schoolId;

	 @Description(remark="区")
	 @Column(name="areaId" )
	 private Long areaId;

	 @Description(remark="市")
	 @Column(name="cityId" )
	 private Long cityId;

	 @Description(remark="省")
	 @Column(name="provinceId" )
	 private Long provinceId;

	 @Description(remark="课程对象")
	 @Column(name="obj" ,length=50 )
	 private String obj;

	 @Description(remark="课程名称")
	 @Column(name="cname" ,nullable=false ,length=100 )
	 private String cname;


	public CourseEntity() {

	}


	public Long getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}

	/**
	  * 设置课程图片附件ID的值
	 * @param 	attachId	 课程图片附件ID
	**/
	public void setAttachId(Long  attachId){
		 this.attachId=attachId;
 	}

	/**
	  * 获取课程图片附件ID的值
	 * @return 返回课程图片附件ID的值
	**/
	public Long getAttachId(){
		 return attachId;
 	}

	/**
	  * 设置课程图片的值
	 * @param 	imgPath	 课程图片
	**/
	public void setImgPath(String  imgPath){
		 this.imgPath=imgPath;
 	}

	/**
	  * 获取课程图片的值
	 * @return 返回课程图片的值
	**/
	public String getImgPath(){
		 return imgPath;
 	}

	/**
	  * 设置课程描述的值
	 * @param 	describes	 课程描述
	**/
	public void setDescribes(String  describes){
		 this.describes=describes;
 	}

	/**
	  * 获取课程描述的值
	 * @return 返回课程描述的值
	**/
	public String getDescribes(){
		 return describes;
 	}

	/**
	  * 设置课程单价的值
	 * @param 	price	 课程单价
	**/
	public void setPrice(BigDecimal  price){
		 this.price=price;
 	}

	/**
	  * 获取课程单价的值
	 * @return 返回课程单价的值
	**/
	public BigDecimal getPrice(){
		 return price;
 	}

	/**
	  * 设置学生数量(最多)的值
	 * @param 	maxCount	 学生数量(最多)
	**/
	public void setMaxCount(Integer  maxCount){
		 this.maxCount=maxCount;
 	}

	/**
	  * 获取学生数量(最多)的值
	 * @return 返回学生数量(最多)的值
	**/
	public Integer getMaxCount(){
		 return maxCount;
 	}

	/**
	  * 设置学生数量(最少)的值
	 * @param 	minCount	 学生数量(最少)
	**/
	public void setMinCount(Integer  minCount){
		 this.minCount=minCount;
 	}

	/**
	  * 获取学生数量(最少)的值
	 * @return 返回学生数量(最少)的值
	**/
	public Integer getMinCount(){
		 return minCount;
 	}

	/**
	  * 设置区的值
	 * @param 	areaId	 区
	**/
	public void setAreaId(Long  areaId){
		 this.areaId=areaId;
 	}

	/**
	  * 获取区的值
	 * @return 返回区的值
	**/
	public Long getAreaId(){
		 return areaId;
 	}

	/**
	  * 设置市的值
	 * @param 	cityId	 市
	**/
	public void setCityId(Long  cityId){
		 this.cityId=cityId;
 	}

	/**
	  * 获取市的值
	 * @return 返回市的值
	**/
	public Long getCityId(){
		 return cityId;
 	}

	/**
	  * 设置省的值
	 * @param 	provinceId	 省
	**/
	public void setProvinceId(Long  provinceId){
		 this.provinceId=provinceId;
 	}

	/**
	  * 获取省的值
	 * @return 返回省的值
	**/
	public Long getProvinceId(){
		 return provinceId;
 	}

	/**
	  * 设置课程对象的值
	 * @param 	obj	 课程对象
	**/
	public void setObj(String  obj){
		 this.obj=obj;
 	}

	/**
	  * 获取课程对象的值
	 * @return 返回课程对象的值
	**/
	public String getObj(){
		 return obj;
 	}

	/**
	  * 设置课程名称的值
	 * @param 	cname	 课程名称
	**/
	public void setCname(String  cname){
		 this.cname=cname;
 	}

	/**
	  * 获取课程名称的值
	 * @return 返回课程名称的值
	**/
	public String getCname(){
		 return cname;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{attachId,imgPath,describes,price,maxCount,minCount,areaId,cityId,provinceId,obj,cname};
	}

	@Override
	public String[] getFields() {
		return new String[]{"attachId","imgPath","describes","price","maxCount","minCount","areaId","cityId","provinceId","obj","cname"};
	}

}
