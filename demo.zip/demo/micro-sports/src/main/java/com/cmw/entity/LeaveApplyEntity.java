package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 请假表
 * @author 程明卫
 * @date 2019-04-20 13:26:16
 */
@Description(remark="请假表实体",createDate="2019-04-20 13:26:16",author="程明卫")
@Entity
@Table(name="GL_LeaveApply")
@SuppressWarnings("serial")
public class LeaveApplyEntity extends IdBaseEntity {
	
	
	 @Description(remark=" 状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="审批老师(班主任)")
	 @Column(name="teacherId" )
	 private Long teacherId;

	@Description(remark="审批老师(教练)")
	@Column(name="coach" )
	private Long coach;

	 @Description(remark="请假原因")
	 @Column(name="reason" ,length=200 )
	 private String reason;

	 @Description(remark="结束时间")
	 @Column(name=" endTime" ,nullable=false )
	 private Date endTime;

	 @Description(remark="请假起始时间")
	 @Column(name=" startTime" ,nullable=false )
	 private Date  startTime;

	 @Description(remark="上课记录ID")
	 @Column(name="cgoId" ,nullable=false )
	 private Long cgoId;

	 @Description(remark="学员ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;


	public LeaveApplyEntity() {

	}

	public Long getCoach() {
		return coach;
	}

	public void setCoach(Long coach) {
		this.coach = coach;
	}

	/**
	  * 设置 状态的值
	 * @param 	xstatus	  状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取 状态的值
	 * @return 返回 状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置审批老师的值
	 * @param 	teacherId	 审批老师
	**/
	public void setTeacherId(Long  teacherId){
		 this.teacherId=teacherId;
 	}

	/**
	  * 获取审批老师的值
	 * @return 返回审批老师的值
	**/
	public Long getTeacherId(){
		 return teacherId;
 	}

	/**
	  * 设置请假原因的值
	 * @param 	reason	 请假原因
	**/
	public void setReason(String  reason){
		 this.reason=reason;
 	}

	/**
	  * 获取请假原因的值
	 * @return 返回请假原因的值
	**/
	public String getReason(){
		 return reason;
 	}

	/**
	  * 设置结束时间的值
	 * @param 	 endTime	 结束时间
	**/
	public void setEndTime(Date   endTime){
		 this. endTime= endTime;
 	}

	/**
	  * 获取结束时间的值
	 * @return 返回结束时间的值
	**/
	public Date getEndTime(){
		 return  endTime;
 	}

	/**
	  * 设置请假起始时间的值
	 * @param 	 startTime	 请假起始时间
	**/
	public void setStartTime(Date   startTime){
		 this. startTime= startTime;
 	}

	/**
	  * 获取请假起始时间的值
	 * @return 返回请假起始时间的值
	**/
	public Date getStartTime(){
		 return  startTime;
 	}

	/**
	  * 设置上课记录ID的值
	 * @param 	cgoId	 上课记录ID
	**/
	public void setCgoId(Long  cgoId){
		 this.cgoId=cgoId;
 	}

	/**
	  * 获取上课记录ID的值
	 * @return 返回上课记录ID的值
	**/
	public Long getCgoId(){
		 return cgoId;
 	}

	/**
	  * 设置学员ID的值
	 * @param 	studentId	 学员ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取学员ID的值
	 * @return 返回学员ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}

	/**
	 * 0:审批中,1:同意,2不同意
	 * 状态 [0:审批中]
	 */
 	public static final int XSTATUS_0 = 0;
	/**
	 * 状态 [1:同意]
	 */
	public static final int XSTATUS_1 = 1;
	/**
	 * 状态 [2:不同意]
	 */
	public static final int XSTATUS_2 = 2;


	@Override
	public Object[] getDatas() {
		return new Object[]{xstatus,teacherId,reason, endTime, startTime,cgoId,studentId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"xstatus","teacherId","reason"," endTime"," startTime","cgoId","studentId"};
	}

}
