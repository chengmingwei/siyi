package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 班级
 *
 * @author 程明卫
 * @date 2019-04-10 14:02:43
 */
@Description(remark = "班级实体", createDate = "2019-04-10 14:02:43", author = "程明卫")
@Entity
@Table(name = "GL_Class")
@SuppressWarnings("serial")
public class ClassEntity extends IdBaseEntity {

    @Description(remark = "最后一次排课时间")
    @Column(name = "lastDate")
    private Date lastDate;

    @Description(remark = "排课类型")
    @Column(name = "ptype", nullable = false)
    private Integer ptype = 0;

    @Description(remark = "状态")
    @Column(name = "xstatus", nullable = false)
    private Integer xstatus = 0;

    @Description(remark = "扣课时规则")
    @Column(name = "crule", nullable = false)
    private Integer crule = 2;

    @Description(remark = "开班日期")
    @Column(name = "sdate", nullable = false)
    private Date sdate;

    @Description(remark = "上课学校ID")
    @Column(name = "sid")
    private Long sid;

    @Description(remark = "上课地点")
    @Column(name = "address", length = 150)
    private String address;

    @Description(remark = "上课地点类型")
    @Column(name = "atype", nullable = false)
    private Integer atype = 1;

    @Description(remark = "容量")
    @Column(name = "capacity", nullable = false)
    private Integer capacity = 0;

    @Description(remark = "班主任ID")
    @Column(name = "master")
    private Long master;

    @Description(remark = "教练ID")
    @Column(name = "coach", nullable = false)
    private Long coach;

    @Description(remark = "班级名称")
    @Column(name = "cname", nullable = false, length = 100)
    private String cname;

    @Description(remark = "关联课程ID")
    @Column(name = "courseId", nullable = false)
    private Long courseId;

    @Description(remark = "编号")
    @Column(name = "code", nullable = false, length = 30)
    private String code = "000000";

    //作废，已将 旧教练 放到了 TempPlanEntity处
    @Description(remark = "旧教练")
    @Column(name = "oldCoach")
    private Long oldCoach;

    /**
     *
     * alter table gl_class add coachSpareIds varchar(300) default '';
     *
     * @Author 肖家添
     * @Date 2019/8/12 12:01
     */
    @Description(remark = "副教练，多个以英文逗号 [,]隔开； 新增字段，新需求[一个班级，需添加多个教练]", createDate = "2019-08-12 09:22", author = "Mr.Shaw")
    @Column(name = "coachSpareIds", length = 300)
    private String coachSpareIds;

    public ClassEntity() {

    }

    /**
     * 返回最后一次记录的排课时间
     *
     * @return
     */
    public Date getLastDate() {
        return lastDate;
    }

    /**
     * 设置最后一次记录的排课时间
     *
     * @param lastDate 最后一次记录的排课时间
     */
    public void setLastDate(Date lastDate) {
        this.lastDate = lastDate;
    }

    /**
     * 设置排课类型的值
     *
     * @param ptype 排课类型
     **/
    public void setPtype(Integer ptype) {
        this.ptype = ptype;
    }

    /**
     * 获取排课类型的值
     *
     * @return 返回排课类型的值
     **/
    public Integer getPtype() {
        return ptype;
    }

    /**
     * 设置状态的值
     *
     * @param xstatus 状态
     **/
    public void setXstatus(Integer xstatus) {
        this.xstatus = xstatus;
    }

    /**
     * 获取状态的值
     *
     * @return 返回状态的值
     **/
    public Integer getXstatus() {
        return xstatus;
    }

    /**
     * 设置扣课时规则的值
     *
     * @param crule 扣课时规则
     **/
    public void setCrule(Integer crule) {
        this.crule = crule;
    }

    /**
     * 获取扣课时规则的值
     *
     * @return 返回扣课时规则的值
     **/
    public Integer getCrule() {
        return crule;
    }

    /**
     * 设置开班日期的值
     *
     * @param sdate 开班日期
     **/
    public void setSdate(Date sdate) {
        this.sdate = sdate;
    }

    /**
     * 获取开班日期的值
     *
     * @return 返回开班日期的值
     **/
    public Date getSdate() {
        return sdate;
    }

    /**
     * 设置上课学校ID的值
     *
     * @param sid 上课学校ID
     **/
    public void setSid(Long sid) {
        this.sid = sid;
    }

    /**
     * 获取上课学校ID的值
     *
     * @return 返回上课学校ID的值
     **/
    public Long getSid() {
        return sid;
    }

    /**
     * 设置上课地点的值
     *
     * @param address 上课地点
     **/
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * 获取上课地点的值
     *
     * @return 返回上课地点的值
     **/
    public String getAddress() {
        return address;
    }

    /**
     * 设置上课地点类型的值
     *
     * @param atype 上课地点类型
     **/
    public void setAtype(Integer atype) {
        this.atype = atype;
    }

    /**
     * 获取上课地点类型的值
     *
     * @return 返回上课地点类型的值
     **/
    public Integer getAtype() {
        return atype;
    }

    /**
     * 设置容量的值
     *
     * @param capacity 容量
     **/
    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    /**
     * 获取容量的值
     *
     * @return 返回容量的值
     **/
    public Integer getCapacity() {
        return capacity;
    }

    /**
     * 设置班主任ID的值
     *
     * @param master 班主任ID
     **/
    public void setMaster(Long master) {
        this.master = master;
    }

    /**
     * 获取班主任ID的值
     *
     * @return 返回班主任ID的值
     **/
    public Long getMaster() {
        return master;
    }

    /**
     * 设置教练ID的值
     *
     * @param coach 教练ID
     **/
    public void setCoach(Long coach) {
        this.coach = coach;
    }

    /**
     * 获取教练ID的值
     *
     * @return 返回教练ID的值
     **/
    public Long getCoach() {
        return coach;
    }

    /**
     * 设置班级名称的值
     *
     * @param cname 班级名称
     **/
    public void setCname(String cname) {
        this.cname = cname;
    }

    /**
     * 获取班级名称的值
     *
     * @return 返回班级名称的值
     **/
    public String getCname() {
        return cname;
    }

    /**
     * 设置关联课程ID的值
     *
     * @param courseId 关联课程ID
     **/
    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    /**
     * 获取关联课程ID的值
     *
     * @return 返回关联课程ID的值
     **/
    public Long getCourseId() {
        return courseId;
    }

    /**
     * 设置编号的值
     *
     * @param code 编号
     **/
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 获取编号的值
     *
     * @return 返回编号的值
     **/
    public String getCode() {
        return code;
    }

    /**
     * 旧教练
     * @Author 肖家添
     * @Date 2019/6/17 17:01
     */
    public Long getOldCoach() {
        return oldCoach;
    }

    /**
     * 旧教练
     * @Author 肖家添
     * @Date 2019/6/17 17:01
     */
    public void setOldCoach(Long oldCoach) {
        this.oldCoach = oldCoach;
    }

    /**
     * 副教练，多个以英文逗号 [,]隔开
     * @Author 肖家添
     * @Date 2019/8/12 9:19
     */
    public String getCoachSpareIds() {
        return coachSpareIds;
    }

    /**
     * 副教练，多个以英文逗号 [,]隔开
     * @Author 肖家添
     * @Date 2019/8/12 9:19
     */
    public void setCoachSpareIds(String coachSpareIds) {
        this.coachSpareIds = coachSpareIds;
    }

    @Override
    public Object[] getDatas() {
        return new Object[]{ptype, xstatus, crule, sdate, sid, address, atype, capacity, master, coach, cname, courseId, code, oldCoach, coachSpareIds};
    }

    @Override
    public String[] getFields() {
        return new String[]{"ptype", "xstatus", "crule", "sdate", "sid", "address", "atype", "capacity", "master", "coach", "cname", "courseId", "code", "oldCoach", "coachSpareIds"};
    }

}
