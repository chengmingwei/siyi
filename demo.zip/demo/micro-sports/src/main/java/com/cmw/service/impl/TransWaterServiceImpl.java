package com.cmw.service.impl;



import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.cmw.entity.TransWaterEntity;
import com.cmw.dao.TransWaterDao;
import com.cmw.service.inter.TransWaterService;


/**
 * 交易流水  Service实现类
 * @author 程明卫
 * @date 2019-04-10 14:08:45
 */
@Description(remark="交易流水业务实现类",createDate="2019-04-10 14:08:45",author="程明卫")
@Service("transWaterService")
public class TransWaterServiceImpl extends AbsService<TransWaterEntity, Long> implements  TransWaterService {
	@Autowired
	private TransWaterDao transWaterDao;
	@Override
	public GenericDaoInter<TransWaterEntity, Long> getDao() {
		return transWaterDao;
	}

}
