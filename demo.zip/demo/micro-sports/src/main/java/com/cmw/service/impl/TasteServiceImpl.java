package com.cmw.service.impl;


import com.alibaba.fastjson.JSONObject;
import com.cmw.client.UserClient;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.TasteDao;
import com.cmw.entity.PosterEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.entity.TasteEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.PosterService;
import com.cmw.service.inter.StudentService;
import com.cmw.service.inter.TasteService;
import com.cmw.util.BeanUtil;
import com.cmw.util.SHashMap;
import com.cmw.util.UserUtil;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * 学员体验记录  Service实现类
 * @author 程明卫
 * @date 2019-04-10 13:48:24
 */
@Description(remark="学员体验记录业务实现类",createDate="2019-04-10 13:48:24",author="程明卫")
@Service("tasteService")
public class TasteServiceImpl extends AbsService<TasteEntity, Long> implements  TasteService {
	@Autowired
	private TasteDao tasteDao;

	@Autowired
	private StudentService studentService;

	@Resource(name="posterService")
	private PosterService posterService;

	@Autowired
	private UserClient userClient;


	@Override
	public GenericDaoInter<TasteEntity, Long> getDao() {
		return tasteDao;
	}

	/**
	 * 保存学生信息
	 *
	 * @param methodPars
	 * @return
	 */
	private Map<String, Object> saveStudentInfo(SHashMap<String,Object> methodPars){
		Long sourceId =  methodPars.getvalAsLng("sourceId");
		SHashMap<String,Object> pars = new SHashMap<>();
		pars.put("source", BussContant.STUDENT_SOURCE_4);
		pars.put("sourceId", sourceId);
		pars.put("phone", methodPars.getvalAsStr("phone"));
		StudentEntity studentEntity = studentService.getBySource(pars);
		if(null != studentEntity){
			String phone = studentEntity.getPhone();
			String sname = methodPars.getvalAsStr("sname");
			throw new ServiceException(String.format("手机号为：%s的学生%s已经预约体验，请不要重复预约!", phone,sname));
		}

		SHashMap<String, Object> saveStudentParams = new SHashMap<>();

		UserModel userModel = getCreator(sourceId);

		saveStudentParams.putAll(methodPars.getMap());
		saveStudentParams.put(SysContant.USER_INFO, userModel);
		saveStudentParams.put("source", BussContant.STUDENT_SOURCE_4);
		saveStudentParams.put("xstatus", BussContant.STUDENT_XSTATUS_2);		//体验学员

		Map<String, Object> dataResult = (Map<String, Object>)studentService.doComplexBusss(saveStudentParams);
		return dataResult;
	}

	private UserModel getCreator(Long sourceId) {
		StudentEntity studentEntity;
		PosterEntity posterEntity = posterService.get(sourceId);
		Long studentId = posterEntity.getStudentId();
		studentEntity = studentService.get(studentId);
		Long creator = studentEntity.getCreator();
		JSONObject jsonObject = userClient.getUserById(creator);
		jsonObject = jsonObject.getJSONObject("datas");
		Long userId = jsonObject.getLong("userId");
		String userName = jsonObject.getString("userName");
		Long indeptId = jsonObject.getLong("indeptId");
		Long incompId = jsonObject.getLong("incompId");
		Long inempId = jsonObject.getLong("inempId");
		//4.用户名密码都正确
		UserModel userModel = new UserModel(userId,userName,indeptId,incompId, inempId, 0);
		return userModel;
	}

	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		TasteEntity entity = null;
		Map<String,Object> dataResult = null;
		boolean isPoster = false; //是否通过家长端海报填写的预约体验
		try {
			Integer source = params.getvalAsInt("source");
			if(null != source && source.intValue() == BussContant.TASTE_SOURCE_1){
				isPoster = true;
				dataResult =  saveStudentInfo(params);
				Long studentId = (Long)dataResult.get("id");
				params.put("studentId", studentId);
			}
			params.put("source", source);
			entity = BeanUtil.copyValue(TasteEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(entity);
		//1.获取用户
		UserModel userInfo = LoginInterceptor.getLoginUser();

		if(null == entity.getId()){
			if(isPoster){
				if(null == entity.getNdate()){
					entity.setNdate(new Date());
				}
				if(null == entity.getXstatus()){
					entity.setXstatus(0);
				}
			}

			UserUtil.setCreateInfo(userInfo, entity);

			insert(entity);
			updateStudentXstatus(userInfo, entity);
		}else{
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);

		}

		Map<String,Object> dataMap = new HashMap<String, Object>();
		dataMap.put("id", entity.getId());
		if(null != dataResult && dataResult.size() > 0){
			String cookieName = (String)dataResult.get("cookieName");
			String token = (String)dataResult.get(cookieName);
			Integer maxAge = (Integer)dataResult.get("maxAge");
			dataMap.put(cookieName, token);
			dataMap.put("maxAge", maxAge);
			dataMap.put("sid", entity.getStudentId());
		}
		return dataMap;
	}


	private void updateStudentXstatus(UserModel userModel, TasteEntity tasteEntity){
		Long studentId = tasteEntity.getStudentId();
		Integer xstatus = tasteEntity.getXstatus();
		Integer studentXstatus = BussContant.STUDENT_XSTATUS_2;
		if(null != xstatus && xstatus.intValue() == 1){
			studentXstatus = BussContant.STUDENT_XSTATUS_3;
		}else{
			studentXstatus = BussContant.STUDENT_XSTATUS_2;
		}
		StudentEntity studentEntity = studentService.get(studentId);
		UserUtil.setModifyInfo(userModel, studentEntity);
		studentEntity.setXstatus(studentXstatus);
		studentService.update(studentEntity);
	}


	private void validInfo(TasteEntity tasteEntity){

		if(null == tasteEntity.getStudentId()){
			throw new ServiceException("体验学员不能为空！");
		}

//		if(null == tasteEntity.getSchoolId()){
//			throw new ServiceException("体验校区不能为空！");
//		}
//
//		if(null == tasteEntity.getClassId()){
//			throw new ServiceException("体验班级不能为空！");
//		}

	}

}
