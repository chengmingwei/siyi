package com.cmw.service.impl;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.AttachmentDaoInter;
import com.cmw.entity.AttachmentEntity;
import com.cmw.service.inter.AttachmentService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * 附件表  Service实现类
 * @author 程明卫
 * @date 2019-04-10 22:18:30
 */
@Description(remark="附件表业务实现类",createDate="2019-04-10 22:18:30",author="程明卫")
@Slf4j
@Service("attachmentService")
public class AttachmentServiceImpl extends AbsService<AttachmentEntity, Long> implements  AttachmentService {
	@Autowired
	private AttachmentDaoInter attachmentDao;


	@Override
	public GenericDaoInter<AttachmentEntity, Long> getDao() {
		return attachmentDao;
	}

	@Override
	public String getFilePathsByIds(String[] idList){
		String[] filePathArr = attachmentDao.getFilePathsByIds(idList);
		if(null == filePathArr || filePathArr.length == 0) return "";
		return StringUtils.join(filePathArr, ",");
	}

}
