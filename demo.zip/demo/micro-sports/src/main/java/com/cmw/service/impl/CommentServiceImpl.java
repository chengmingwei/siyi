package com.cmw.service.impl;


import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.CommentDao;
import com.cmw.entity.ClassGoEntity;
import com.cmw.entity.CommentEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.entity.TeacherEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassGoService;
import com.cmw.service.inter.CommentService;
import com.cmw.service.inter.StudentService;
import com.cmw.service.inter.TeacherService;
import com.cmw.util.BeanUtil;
import com.cmw.util.SHashMap;
import com.cmw.util.UserUtil;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 评论表  Service实现类
 * @author 程明卫
 * @date 2019-04-20 13:35:01
 */
@Description(remark="评论表业务实现类",createDate="2019-04-20 13:35:01",author="程明卫")
@Service("commentService")
public class CommentServiceImpl extends AbsService<CommentEntity, Long> implements  CommentService {
	@Autowired
	private CommentDao commentDao;

	@Autowired
	private ClassGoService classGoService;

	@Autowired
	StudentService studentService;

	@Autowired
	TeacherService teacherService;

	@Override
	public GenericDaoInter<CommentEntity, Long> getDao() {
		return commentDao;
	}
	
	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		CommentEntity entity = null;
		try {
			entity = BeanUtil.copyValue(CommentEntity.class, params.getMap());
			entity.setCreateTime(new Date());
			entity.setIsenabled(SysContant.ISENABLED_1);
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(entity);
		UserModel userInfo = (UserModel)params.get(SysContant.USER_INFO);
		if(null == entity.getId()){
			entity.setCreateTime(new Date());
			setPorps(entity, params.getvalAsLng("toManId"));
			insert(entity);
			updateClassGo(entity, userInfo);
		}else{
			update(entity);
		}

		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}


	private void setPorps(CommentEntity commentEntity,Long toManId){
		Integer ctype = commentEntity.getCtype();
		String toMan = null;
		if(null != ctype && ctype.intValue() == CommentEntity.CTYPE_2){
			StudentEntity studentEntity = studentService.get(toManId);
			toMan = studentEntity.getSname();
		}else{
			TeacherEntity teacherEntity = teacherService.get(toManId);
			toMan = teacherEntity.getTname();
		}
		commentEntity.setToMan(toMan);
		commentEntity.setToManId(toManId);
	}

	private void updateClassGo(CommentEntity entity, UserModel userInfo){
		Long classGoId = entity.getClassGoId();
		if(null == classGoId){
			log.error("参数：classGoId = null!");
			return;
		}
		ClassGoEntity classGoEntity = classGoService.get(classGoId);
		if(null == classGoEntity){
			return;
		}
		classGoEntity.setCommented((byte)1);
		UserUtil.setModifyInfo(userInfo, classGoEntity);
		classGoService.update(classGoEntity);
	}


	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(CommentEntity entity) {

		if(StringUtils.isEmpty(entity.getContent())){
			throw new ServiceException("内容不能为空!");
		}
		if(!StringUtils.isEmpty(entity.getContent()) && entity.getContent().length() > 250){
			throw new ServiceException("内容长度不能超过250!");
		}
		if(null == entity.getStars()){
			throw new ServiceException("得分不能为空!");
		}
		if(null == entity.getCperson()){
			throw new ServiceException("评论人不能为空!");
		}
		if(null == entity.getCtype()){
			throw new ServiceException(" 评论人类型不能为空!");
		}

	}

	@Override
	public List<Map<String, Object>> getCommentByPars(Map<String, Object> params) {
		return commentDao.getCommentByPars(params);
	}
}
