package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.SchoolEntity;
import com.cmw.util.SHashMap;

import java.util.List;
import java.util.Map;


/**
 * 学校信息  Service接口
 * @author 程明卫
 * @date 2019-04-10 13:57:41
 */
@Description(remark="学校信息业务接口",createDate="2019-04-10 13:57:41",author="程明卫")
public interface SchoolService extends IService<SchoolEntity, Long> {

    /**
     * 获取Ant Design
     * @Author 肖家添
     * @Date 2019/7/15 16:36
     */
    List<Map<String, Object>> getSchoolBySelect(Map<String, Object> params);

    void test_trans(SHashMap<String, Object> params);

    void test_trans2(SHashMap<String, Object> stringObjectSHashMap);
}
