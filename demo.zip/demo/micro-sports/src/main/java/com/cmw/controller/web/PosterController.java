package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.client.UploadClient;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.*;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.*;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;


/**
 * 学生海报  Conntroller类
 * @author 程明卫
 * @date 2019-07-10 20:19:51
 */
@Description(remark="学生海报Conntroller",createDate="2019-07-10 20:19:51",author="程明卫")
@Api(value = "学生海报微服务", description = "#CONTROLLER# 2019-07-10 20:19:51 程明卫")
@Slf4j
@RestController
@RequestMapping({"/poster"})
public class PosterController{
	@Resource(name="posterService")
	private PosterService posterService;

    @Resource(name="growUpService")
    private GrowUpService growUpService;

    @Resource(name="classService")
    private ClassService classService;

    @Resource(name="classGoService")
    private ClassGoService classGoService;

    @Resource(name="posterImgService")
    private PosterImgService posterImgService;

    @Autowired
    private StudentService studentService;

    @Autowired
    UploadClient uploadClient;

    /**
     * 跳转列表页面
     * @param request
     * @param response
     * @return
     */
     @ApiOperation("学生海报列表API")
    @GetMapping(value = "/list")
    public JSONObject list(HttpServletRequest request, HttpServletResponse response){
        List<PosterEntity> list = posterService.getListAll();
        return PageHandler.getJson(list);
    }
    
      /**
     * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询学生海报信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = posterService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }


	/**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取学生海报信息")
    @PostMapping(value = "/detail")
    public JSONObject get(@ApiParam("学生海报ID") @RequestParam("id") Long id, @RequestParam(value="source",required = false) String source){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        log.info("id="+id+", source="+source);
        String sname = "";
        if(!StringUtils.isEmpty(source) && source.equals("1")){ //通过二维码扫码（此时的 id 实际为学生ID）
           Long  maxPostId = posterService.getMaxIdByStudentId(id);
           id = maxPostId;
        }
        PosterEntity obj = posterService.get(id);
        Long posterId = obj.getId();
        Map<String,String> dataMap = getClassName(obj);

        JSONObject jsonObject = PageHandler.getJson(obj);
        JSONObject datasJson = jsonObject.getJSONObject("datas");
        if(null != dataMap && dataMap.size() > 0){
            datasJson.putAll(dataMap);
        }
        datasJson.put("posterId", posterId);
//        datasJson.put("sname", sname);
//        datasJson.put("className", className);
        setImgItems(posterId, datasJson);
        jsonObject.put("datas", datasJson);
        return   jsonObject;
    }

    private void setImgItems( Long posterId, JSONObject datasJson){
        Map<String,Object> pars = new HashMap<>();
        pars.put("posterId", posterId);
        List<PosterImgEntity> posterImgList = posterImgService.getList(pars);
        Map<String,String> mainPosterImg = null;
        List<Map<String,String>> posterImgMapList = new ArrayList<>();
        Iterator<PosterImgEntity> it = posterImgList.iterator();
        while(it.hasNext()){
            PosterImgEntity _mainPosterImg = it.next();
            Byte pflag = _mainPosterImg.getPflag();
            if(null != pflag && pflag.intValue() == 1){
                mainPosterImg = convert2Map(_mainPosterImg);
                it.remove();
            }else{
                posterImgMapList.add(convert2Map(_mainPosterImg));
            }
        }
        datasJson.put("mainPosterImg", mainPosterImg);
        datasJson.put("imgItems", posterImgMapList);
    }

    private Map<String,String> convert2Map(PosterImgEntity posterImgObj){
        Map<String,String> mainPosterImg = new HashMap<>();
        String upldate = posterImgObj.getUpldate();
        String imgPath = posterImgObj.getImgPath();
        mainPosterImg.put("upldate", upldate);
        mainPosterImg.put("imgPath", imgPath);
        return  mainPosterImg;
    }



    private  Map<String,String> getClassName(PosterEntity obj) {
        Long groId = obj.getGroId();
        GrowUpEntity growUpEntity = growUpService.get(groId);
        Long ccId = growUpEntity.getCcId();
        ClassGoEntity classGoEntity = classGoService.get(ccId);
        Long classId = classGoEntity.getClassId();
        ClassEntity classObj = classService.get(classId);
        String cname = classObj.getCname();
        Long studentId = classGoEntity.getStudentId();
        StudentEntity studentEntity = studentService.get(studentId);
        String sname = "";
        if(null != studentEntity) sname = studentEntity.getSname();
        Map<String,String> dataMap = new HashMap<>();
        dataMap.put("className", cname);
        dataMap.put("sname", sname);
        return dataMap;
    }


    /**
     * 保存数据
     * /poster/save
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存学生海报信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
        try{
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = LoginInterceptor.getLoginUser();
            pars.put(SysContant.USER_INFO, userInfo);
            Map<String, Object> dataResult = (Map<String, Object>)posterService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }



    /**
     * 更新学生海报分享图片
     * /poster/update
     * @param id 海报ID
     * @param posterImg 图片地址
     * @return
     */
    @ApiOperation("更新学生海报分享图片")
    @PostMapping(value = "/update/{id}")
    public JSONObject update(@PathVariable("id") Long id, @RequestParam("posterImg")  String posterImg){
        try{
            PosterEntity posterEntity = posterService.get(id);
            if(null == posterEntity){
                return PageHandler.getFailureJson("根据ID="+id+"找不到学生海报记录！");
            }
            posterEntity.setPosterImg(posterImg);
            posterService.update(posterEntity);
            return PageHandler.getSuccessJson();
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }
    
    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
        return save(param);
    }
    
    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除学生海报信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("#DESCRIPTIONID") @PathVariable("id")  Long id) throws Exception{
        posterService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }
    
}
