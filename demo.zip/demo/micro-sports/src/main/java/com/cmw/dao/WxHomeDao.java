package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.ClassGoEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * 校长端首页  Mapper接口
 * @author 程明卫
 * @date 2019-05-06 08:53:06
 */
@Description(remark="上校长端首页DAO Mapper接口",createDate="2019-05-06 08:53:06",author="程明卫")
@Component
@Mapper
public interface WxHomeDao extends GenericDaoInter<ClassGoEntity, Long>{

    /**
     * 首页 本月收入 上月收入
     * @param pars  [indeptId:校区ID，currDate:当前日期｛本月，上月｝]
     * @return
     */
    Double getIncomeByMonth(Map<String, Object> pars);

    /**
     * 首页 待跟进人数  (本周)
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getXCountByWeek(Map<String, Object> pars);

    /**
     *  首页 跟进中人数  (本周)
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getYCountByWeek(Map<String, Object> pars);

    /**
     * 首页 体验人数 (本周)
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getTasteCountByWeek(Map<String, Object> pars);

    /**
     * 首页 缴费人数 (本周)
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getBuyCountByWeek(Map<String, Object> pars);

    /**
     * 首页本周课消金额 (本周)
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getUseCountByWeek(Map<String, Object> pars);

    /**
     * 首页 本周上课人次
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getStudyCountByWeek(Map<String, Object> pars);

    /**
     *  首页 本周上课老师
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getSpTeacherCountByWeek(Map<String, Object> pars);

    /**
     * 首页 本周课次安排
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getTplanCountByWeek(Map<String, Object> pars);

    /**
     * 首页 本周已上课人数
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getFinishStudyByWeek(Map<String, Object> pars);

    /**
     *  首页 本周续签订单数  首页 本周复购率 = 本周续签 / 本周下单
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getRepeatOrderByWeek(Map<String, Object> pars);

    /**
     *  首页 本周下订单数 首页 本周复购率 = 本周续签 / 本周下单
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getOrderByWeek(Map<String, Object> pars);

    /**
     *  首页满班率
     * @param pars  [indeptId:校区ID]
     * @return
     */
    Integer getFullClassByWeek(Map<String, Object> pars);


    /***** 班主任/销售 首页  CODE START *******/
    /**
     *  首页 本月业绩 [销售]
     * @param pars  [userId:当前用户ID]
     * @return
     */
    Double getSaleByMonth(Map<String, Object> pars);

    /**
     *   首页 本月成单 [销售]
     * @param pars  [userId:当前用户ID]
     * @return
     */
    Integer getSaleCountByMonth(Map<String, Object> pars);

    /**
     *   首页 待跟进学员 [销售]
     * @param pars  [userId:当前用户ID]
     * @return
     */
    Integer getUnStudentCount(Map<String, Object> pars);

    /**
     *  首页 跟进中学员 [销售]
     * @param pars  [userId:当前用户ID]
     * @return
     */
    Integer getDoingStudentCount(Map<String, Object> pars);

    /**
     * 首页 即将过期学员 [销售] (剩余课时数小于3课时)
     * @param pars  [userId:当前用户ID]
     * @return
     */
    Integer getExpireStudentCount(Map<String, Object> pars);

    /**
     * 首页 潜在学员列表 [销售]
     * @param pars  [userId:当前用户ID]
     * @return
     */
    List<Map<String,Object>> getLatentStudents(Map<String, Object> pars);


    /**
     *首页 即将过期学员列表 [销售] (剩余课时数小于3课时)
     * @param pars  [userId:当前用户ID]
     * @return
     */
    List<Map<String,Object>> getExpireStudents(Map<String, Object> pars);

    /**
     * PC首页 总招生人数
     * @return
     * @param params
     */
    Integer getTotalEnrollmentForPc(Map<String, Object> params);

    /**
     * PC首页 当前有效学员
     * @param params
     * @return
     */
    Integer getNowEffStuCountForPc(Map<String, Object> params);

    /**
     * PC首页 今年报名学员
     * @param params
     * @return
     */
    Integer getThisYearEnrStuCountForPc(Map<String, Object> params);

    /**
     * PC首页 剩余总课次
     * @param params
     * @return
     */
    Integer getRemTotalLessonForPc(Map<String, Object> params);

    /**
     * PC首页 本月总收入
     * @param params
     * @return
     */
    Double getThisMonthIncomeTotalForPc(Map<String, Object> params);

    /**
     * PC首页 本月新签学员
     * @param params
     * @return
     */
    Integer getThisMonthNewEnrStuCountForPc(Map<String, Object> params);

    /**
     * PC首页 本月续费学员
     * @param params
     * @return
     */
    Integer getThisMonthAgainEnrStuCountForPc(Map<String, Object> params);

    /**
     * PC首页 本月课消金额
     * @param params
     * @return
     */
    Double getUseCountByMonthForPc(Map<String, Object> params);

    /**
     * PC首页 本月授课课时
     * @param params
     * @return
     */
    Integer getThisMonthDidTempCountForPc(Map<String, Object> params);

    /**
     * PC首页 本月课次安排
     * @param params
     * @return
     */
    Integer getThisMonthTempCountForPc(Map<String, Object> params);

    /**
     * PC首页 机构收入
     * @param params
     * @return
     */
    List<Map<String, Object>> getInstIncomeListMapForPc(Map<String, Object> params);

    /**
     * PC首页 课消金额
     * @param params
     * @return
     */
    List<Map<String, Object>> getUseCountListMapForPc(Map<String, Object> params);

    /**
     * PC首页 班级满班率
     * @param params
     * @return
     */
    Integer getFullClassByMonthForPc(Map<String, Object> params);

    /**
     * 上月到期的续费学员
     * @param params
     * @return
     */
    Integer againStudentCountByLastMonthForPc(Map<String, Object> params);

    /**
     * 上月到期的学员
     * @param params
     * @return
     */
    List<Map<String,Object>> endStudentCountByLastMonthForPc(Map<String, Object> params);

    /**
     * 跟进情况 待跟进
     * @param params
     * @return
     */
    Integer getFollowUpReadyByMonthForPc(Map<String, Object> params);

    /**
     * 跟进情况 跟进中
     * @param params
     * @return
     */
    Integer getFollowUpDoingByMonthForPc(Map<String, Object> params);

    /**
     * 跟进情况 预约体验/已体验
     * @param params
     * @return
     */
    Integer getFollowUpTasteByMonthForPc(Map<String, Object> params);

    /**
     * 跟进情况 已付费
     * @param params
     * @return
     */
    Integer getFollowUpPayByMonthForPc(Map<String, Object> params);
    
    /**
     * [数据汇总] -> [满班率]
     * @Author 肖家添
     * @Date 2019/8/12 17:26
     */
    Integer getWxHomeDataOfCoach_FullShiftRate(Map<String, Object> params);
    
    /**
     * [数据汇总] -> [复购率]
     * @Author 肖家添
     * @Date 2019/8/12 19:53
     */
    List<Map<String,Object>> getWxHomeDataOfCoach_RepurchaseRate(Map<String, Object> params);
    
    /**
     * [数据汇总] -> [体验成交率]
     * @Author 肖家添
     * @Date 2019/8/12 20:44
     */
    Integer getWxHomeDataOfCoach_ExperienceTurnoverRate(Map<String, Object> params);
}