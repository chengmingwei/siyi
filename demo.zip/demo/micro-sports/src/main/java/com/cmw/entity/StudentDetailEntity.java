package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 学员详细信息
 * @author 程明卫
 * @date 2019-04-10 11:39:22
 */
@Description(remark="学员详细信息实体",createDate="2019-04-10 11:39:22",author="程明卫")
@Entity
@Table(name="GL_StudentDetail")
@SuppressWarnings("serial")
public class StudentDetailEntity extends IdBaseEntity {
	
	
	 @Description(remark="学员头像附件ID")
	 @Column(name="attachId" )
	 private Long attachId;

	 @Description(remark="跟进记录ID")
	 @Column(name="fuppId" )
	 private Long fuppId;

	 @Description(remark="跟进人ID")
	 @Column(name="tracerId" )
	 private Long tracerId;

	 @Description(remark="当前报读班级")
	 @Column(name="classId" )
	 private Long classId;

	 @Description(remark="学员ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;

	@Description(remark="报名ID")
	@Column(name="enrollId" )
	private Long enrollId;

	@Description(remark="保险单号")
	@Column(name="policyNo")
	private String policyNo;

	@Description(remark="来源ID")
	@Column(name="sourceId")
	private Long sourceId;

	public StudentDetailEntity() {

	}

	public Long getSourceId() {
		return sourceId;
	}

	public void setSourceId(Long sourceId) {
		this.sourceId = sourceId;
	}

	/**
	 * 获取报名ID
	 * @return	返回报名ID
	 */
	public Long getEnrollId() {
		return enrollId;
	}

	/**
	 * 设置报名ID
	 * @param enrollId 报名ID
	 */
	public void setEnrollId(Long enrollId) {
		this.enrollId = enrollId;
	}

	/**
	  * 设置学员头像附件ID的值
	 * @param 	attachId	 学员头像附件ID
	**/
	public void setAttachId(Long  attachId){
		 this.attachId=attachId;
 	}

	/**
	  * 获取学员头像附件ID的值
	 * @return 返回学员头像附件ID的值
	**/
	public Long getAttachId(){
		 return attachId;
 	}

	/**
	  * 设置跟进记录ID的值
	 * @param 	fuppId	 跟进记录ID
	**/
	public void setFuppId(Long  fuppId){
		 this.fuppId=fuppId;
 	}

	/**
	  * 获取跟进记录ID的值
	 * @return 返回跟进记录ID的值
	**/
	public Long getFuppId(){
		 return fuppId;
 	}

	/**
	  * 设置跟进人ID的值
	 * @param 	tracerId	 跟进人ID
	**/
	public void setTracerId(Long  tracerId){
		 this.tracerId=tracerId;
 	}

	/**
	  * 获取跟进人ID的值
	 * @return 返回跟进人ID的值
	**/
	public Long getTracerId(){
		 return tracerId;
 	}

	/**
	  * 设置当前报读班级的值
	 * @param 	classId	 当前报读班级
	**/
	public void setClassId(Long  classId){
		 this.classId=classId;
 	}

	/**
	  * 获取当前报读班级的值
	 * @return 返回当前报读班级的值
	**/
	public Long getClassId(){
		 return classId;
 	}

	/**
	  * 设置学员ID的值
	 * @param 	studentId	 学员ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取学员ID的值
	 * @return 返回学员ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}

	/**
	 * 获取保险单号的值
	 * @return 返回保险单号的值
	 **/
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * 设置保险单号的值
	 * @param 	policyNo	 保险单号
	 **/
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	@Override
	public Object[] getDatas() {
		return new Object[]{attachId,fuppId,tracerId,classId,studentId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"attachId","fuppId","tracerId","classId","studentId"};
	}

}
