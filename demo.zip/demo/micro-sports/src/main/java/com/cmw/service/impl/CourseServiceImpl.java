package com.cmw.service.impl;



import com.cmw.constant.back.BussContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.entity.StudentDetailEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.util.*;
import com.cmw.util.export.ExcelExport;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.cmw.entity.CourseEntity;
import com.cmw.dao.CourseDao;
import com.cmw.service.inter.CourseService;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 课程信息  Service实现类
 * @author 程明卫
 * @date 2019-04-10 13:59:08
 */
@Description(remark="课程信息业务实现类",createDate="2019-04-10 13:59:08",author="程明卫")
@Service("courseService")
public class CourseServiceImpl extends AbsService<CourseEntity, Long> implements  CourseService {
	@Autowired
	private CourseDao courseDao;
	@Override
	public GenericDaoInter<CourseEntity, Long> getDao() {
		return courseDao;
	}


	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		CourseEntity courseEntity = null;
		try {
			courseEntity = BeanUtil.copyValue(CourseEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(courseEntity);
		//1.获取用户
		UserModel userInfo = LoginInterceptor.getLoginUser();
		if(null == courseEntity.getId()){
			UserUtil.setCreateInfo(userInfo, courseEntity);
			insert(courseEntity);
		}else{
			UserUtil.setModifyInfo(userInfo, courseEntity);
			update(courseEntity);
		}
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", courseEntity.getId());
		return dataResult;
	}

	private void validInfo(CourseEntity courseEntity) {
		UserModel userInfo = LoginInterceptor.getLoginUser();

		int userType = userInfo.getUtype();

		if(userType != BussContant.USER_UTYPE_3 && userType != BussContant.USER_UTYPE_6){
			throw new ServiceException("您没有权限新增课程！");
		}

		String cname = courseEntity.getCname();
		if(StringUtils.isEmpty(cname)){
			throw new ServiceException("课程名称不能为空！");
		}

//		if(null == courseEntity.getProvinceId() || null == courseEntity.getCityId() || null == courseEntity.getAreaId()){
//			throw new ServiceException("适配区域不能为空！");
//		}
		if(null == courseEntity.getProvinceId()){
			throw new ServiceException("适配区域不能为空！");
		}

//		if(null == courseEntity.getSchoolId()){
//			throw new ServiceException("校区不能为空！");
//		}
		if(null == courseEntity.getMinCount() || courseEntity.getMinCount() <= 0
		|| null == courseEntity.getMaxCount() || courseEntity.getMaxCount() <= 0){
			throw new ServiceException("学生数量不能为空且必须大于O！");
		}
		if(courseEntity.getMinCount() > courseEntity.getMaxCount()){
			throw new ServiceException("学生最小数量不能超过最大可容纳数量！");
		}
		if(null == courseEntity.getPrice() || courseEntity.getPrice().intValue() <= 0){
			throw new ServiceException("课程单价必须大于0!");
		}
	}

	@Override
	public void exportData(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM) {
		String[] cellVal = {
				"ID",
				"课程名称",
				"使用班级数量",
				"课程单价",
				"创建日期",
				"适配区域",
				"课程对象",
				"报课学员",
				"在读学员",
				"启用状态"
		};

		String[] dataKeys = {
				"id",
				"cname",
				"gcount",
				"price",
				"createTime",
				"areaName",
				"obj",
				"tcount",
				"Hcount",
				"isenabled"
		};

		for(Map<String, Object> data : dataList_LM){
			SHashMap data_SH = new SHashMap<>(data);

			for(String key : dataKeys){
				String val = data_SH.getvalAsStr(key);

				val = StringHandler.isValidStr(val) ? val : "";

				switch (key){
					case "price":{

						val += "元";

						break;
					}
					case "createTime":{

						if(StringHandler.isValidStr(val))
							val = DateUtil.dateFormatToStr("yyyy-MM-dd", new Date(Long.parseLong(val)));

						break;
					}
					case "isenabled":{

						switch (val){
							case "-1":{
								val = "作废";
								break;
							}
							case "0":{
								val = "下架";
								break;
							}
							case "1":{
								val = "上架";
								break;
							}
						}

						break;
					}
				}

				data_SH.put(key, val);
			}
		}

		new ExcelExport(request, response).export(cellVal, dataKeys, dataList_LM);
	}
}
