package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.TeacherEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * 教师信息  Service接口
 * @author 程明卫
 * @date 2019-04-10 13:55:46
 */
@Description(remark="教师信息业务接口",createDate="2019-04-10 13:55:46",author="程明卫")
public interface TeacherService extends IService<TeacherEntity, Long> {
    /**
     * 根据用户ID获取老师名
     * @param userId
     * @return
     */
    String getTeacheByUserId(Long userId);

    /**
     * 获取教师下拉框
     * @Author 肖家添
     * @Date 2019/6/4 16:35
     */
    List<Map<String, Object>> getTeacherForSelect(Map<String, Object> pars);

    /**
     * 导出数据
     * @Author 肖家添
     * @Date 2019/6/26 19:04
     */
    void exportData(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM);
}
