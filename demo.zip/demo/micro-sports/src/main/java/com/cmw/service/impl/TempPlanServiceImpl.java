package com.cmw.service.impl;


import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.TempPlanDao;
import com.cmw.entity.ClassEntity;
import com.cmw.entity.TempPlanEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassService;
import com.cmw.service.inter.TempPlanService;
import com.cmw.util.*;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 课次排班表  Service实现类
 * @author 程明卫
 * @date 2019-04-20 18:25:05
 */
@Description(remark="课次排班表业务实现类",createDate="2019-04-20 18:25:05",author="程明卫")
@Service("tempPlanService")
public class TempPlanServiceImpl extends AbsService<TempPlanEntity, Long> implements  TempPlanService {
	@Autowired
	private TempPlanDao tempPlanDao;

	@Autowired
	private ClassService classService;

	@Override
	public GenericDaoInter<TempPlanEntity, Long> getDao() {
		return tempPlanDao;
	}

	@Override
	public String getDellIds(Map<String, Object> pars) {
		List<Map<String, Object>> idListMap = tempPlanDao.getDellIds(pars);
		if(null == idListMap || idListMap.size() == 0) return null;
		StringBuilder sbIds = new StringBuilder();
		idListMap.forEach(item -> {
			Object id = item.get("id");
			if(null != id){
				sbIds.append(id.toString()).append(",");
			}
		});
		return StringHandler.RemoveStr(sbIds);
	}

	@Override
	public List<Map<String, Object>> getListMapByClassId(Long classId){
		return tempPlanDao.getListMapByClassId(classId);
	}

	@Override
	public Long getFinshCount(Map<String, Object> pars) {
		return tempPlanDao.getFinshCount(pars);
	}

	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		TempPlanEntity entity = null;
		try {
			entity = BeanUtil.copyValue(TempPlanEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
		ClassEntity classEntity =classService.get(entity.getClassId());
		setProps(params, entity, classEntity);
		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		if(null == entity.getId()){
			entity.setCtype(BussContant.TEMPPLAN_CTYPE_2);
			UserUtil.setCreateInfo(userInfo, entity);
			insert(entity);
		}else{
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);
		}
		updateLastDate(userInfo, classEntity);
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}

	private void updateLastDate(UserModel userInfo, ClassEntity classEntity){
		Long classId = classEntity.getId();
		Date lastDate = tempPlanDao.getLastDate(classId);
		UserUtil.setModifyInfo(userInfo, classEntity);
		classEntity.setLastDate(lastDate);
		classEntity.setRemark("临时排课，更新lastDate="+ DateUtil.dateFormatToStr(DateUtil.DATE_TIME_FORMAT2,lastDate));
		classService.update(classEntity);
	}


	private void setProps(SHashMap<String,Object> params, TempPlanEntity entity, ClassEntity classEntity){
		Long coach = classEntity.getCoach();
		Long master = classEntity.getMaster();
		entity.setCoach(coach);
		entity.setMaster(master);
		String startDateStr = params.getvalAsStr("startDate");
		String stime = params.getvalAsStr("stime");
		String etime = params.getvalAsStr("etime");
		String startDateTime = startDateStr+" "+stime;
		String endDateTime = startDateStr+" "+etime;
		Date today = new Date();
		String d_fmt = "yyyy-MM-dd HH:mm";
		Date startDate = DateUtil.dateFormat(d_fmt, startDateTime);
		Date endDate = DateUtil.dateFormat(d_fmt, endDateTime);
		if(startDate.getTime() <= today.getTime()){
			throw new ServiceException("临时课次开始时间不能小于当前时间!");
		}
		if(startDate.getTime() >= endDate.getTime()){
			throw new ServiceException("临时课次开始时间不能大于或等于结束时间!");
		}

		entity.setStartTime(startDate);
		entity.setEndTime(endDate);
	}

	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(TempPlanEntity entity) {
		if(null == entity.getXstatus()){
			throw new ServiceException("状态不能为空!");
		}

		if(null == entity.getEndTime()){
			throw new ServiceException("下课结束时间不能为空!");
		}

		if(null == entity.getStartTime()){
			throw new ServiceException("上课开始时间不能为空!");
		}

		if(null == entity.getClassId()){
			throw new ServiceException("班级ID不能为空!");
		}
		String fmt = "yyyy-MM-dd HH:mm";
		Date startTime = entity.getStartTime();
		Date endTime = entity.getEndTime();
		Long scount = tempPlanDao.exist(
				DateUtil.dateFormatToStr(fmt,startTime),
				DateUtil.dateFormatToStr(fmt,endTime),
				entity.getClassId()
		);
		if(null != scount && scount.intValue() > 0){
			throw new ServiceException("临时课次排课时间存在冲突!");
		}
	}

	@Override
	public List<Map<String, Object>> getTempPlanDetail(Long tempPlanId) {
		return tempPlanDao.getTempPlanDetail(tempPlanId);
	}

	@Override
	public List<Map<String, Object>> getListMapByTeacherId(Map<String, Object> params) {
		return tempPlanDao.getListMapByTeacherId(params);
	}

	@Override
	public List<Map<String, Object>> getTempPlanByClassScheduleCard(Map<String, Object> params) {
		return tempPlanDao.getTempPlanByClassScheduleCard(params);
	}
}
