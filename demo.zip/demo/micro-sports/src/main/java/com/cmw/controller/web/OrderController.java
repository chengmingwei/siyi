package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.GlobalConstant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.vo.PageResult;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.OrderService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import com.cmw.util.export.ExcelExport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 订单表  Conntroller类
 *
 * @author 程明卫
 * @date 2019-05-07 21:22:03
 */
@Description(remark = "订单表Conntroller", createDate = "2019-05-07 21:22:03", author = "程明卫")
@Api(value = "订单表微服务", description = "#CONTROLLER# 2019-05-07 21:22:03 程明卫")
@RestController
@RequestMapping({"/order"})
public class OrderController {

    @Resource(name = "orderService")
    private OrderService orderService;

    /**
     * 获取学员订单列表API 家长端
     *
     * @param /order/list/{studentId}
     * @param studentId               学生ID
     * @param orderXstatus            订单状态
     * @return
     */
    @ApiOperation("学员订单列表API 家长端")
    @PostMapping(value = "/list/{studentId}")
    public JSONObject sys_list(@PathVariable("studentId") Long studentId, @RequestParam(value = "orderXstatus", defaultValue = "all") String orderXstatus) {
        Map<String, Object> params = new HashMap<>();
        params.put("studentId", studentId);
        params.put("orderXstatus", orderXstatus);
        List<Map<String, Object>> list = orderService.getListMap(params);
        return PageHandler.getJson(list);
    }

    /**
     * 获取订单列表
     * @Author 肖家添
     * @Date 2019/6/13 17:44
     */
    @ApiOperation("订单表列表API")
    @RequestMapping(value = "/getOrderList")
    public JSONObject getOrderList(@RequestBody Map<String, Object> params) {
        List<Map<String, Object>> list = orderService.getOrderList(params);
        return PageHandler.getJson(list);
    }

    /**
     * 分页查询
     * 返回状态码：
     * 404 : 没有查询到任何数据
     *
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询订单表信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String, Object> params) {
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String, Object>>> result = orderService.getPageByPars(params, page, pageSize);
        if (result == null) {
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }


    /**
     * 根据订单ID获取报名订单详情
     *
     * @param
     * @param id 报名订单Id
     * @return
     */
    @ApiOperation("根据订单ID获取报名订单详情")
    @PostMapping(value = "/{id}")
    public JSONObject get(@PathVariable("id") Long id) {
        Map<String, Object> params = new HashMap<>();
        params.put("id", id);
        List<Map<String, Object>> list = orderService.getListMap(params);
        return PageHandler.getJson(list);
    }

    /**
     * 上架/下架/删除
     * @Author 肖家添
     * @Date 2019/5/23 16:49
     */
    @ApiOperation("上架/下架/删除")
    @PostMapping("/isEnabled")
    public JSONObject isEnabled(HttpServletRequest request){
        try{
            String[] ids = request.getParameterValues("id");
            String isEnabled = request.getParameter("isenabled");

            if(StringHandler.isValidObj(ids) && StringHandler.isValidStr(isEnabled)){
                String beachParam = "";
                for (String id : ids) {
                    beachParam += id + ",";
                }

                if(beachParam.length() > 0){
                    beachParam = beachParam.substring(0, beachParam.lastIndexOf(","));
                }

                orderService.enabledByIds(beachParam, Integer.parseInt(isEnabled));

                return PageHandler.getSuccessJson();
            }else{
                return PageHandler.getFailureJson("缺少参数");
            }
        }catch (Exception ex){
            return PageHandler.getFailureJson("系统异常");
        }
    }

    @ApiOperation("获取订单课程")
    @PostMapping("/getOrderCourse")
    public JSONObject getOrderCourse(@RequestParam Map<String, Object> params){

        SHashMap<String, Object> sParams = new SHashMap<>(params);

        Long orderId = sParams.getvalAsLng("orderId");

        if(StringHandler.isValidObj(orderId)){
            List<Map<String, Object>> orderCourse = orderService.getOrderCourse(orderId);

            return PageHandler.getJson(orderCourse);
        }else{
            return PageHandler.getFailureJson("订单编号不能为空");
        }
    }

    /**
     * 数据导出
     * @Author 肖家添
     * @Date 2019/6/19 12:41
     */
    @ApiOperation("订单导出")
    @PostMapping("/exportData")
    public void exportData(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> params){
        List<Map<String, Object>> dataList_LM = ExcelExport.getExportData_listMap(this.getOrderList(params));

        if(null == dataList_LM) return;

        orderService.exportData(request, response, dataList_LM);
    }
    
    /**
     * 获取订单报表
     * @Author 肖家添
     * @Date 2019/9/9 11:29
     */
    @PostMapping("/getOrderListGroupByCourseAndStu")
    @ApiOperation("获取订单列表 -> 根据课程Id和学生Id分组")
    public JSONObject getOrderListGroupByCourseAndStu(@RequestBody Map<String, Object> params){
        try {
            List<Map<String, Object>> orderData = orderService.getOrderListGroupByCourseAndStu(params);

            return PageHandler.getJson(orderData);
        }catch(Exception ex){
            ex.printStackTrace();

            return PageHandler.getFailureJson(GlobalConstant.SYS_ERR_MSG);
        }
    }

    /**
     * 订单报表_数据导出
     * @Author 肖家添
     * @Date 2019/9/19 9:53
     */
    @ApiOperation("订单报表_数据导出")
    @PostMapping("/getOrderListGroupByCourseAndStu_exportData")
    public void getOrderListGroupByCourseAndStu_exportData(
            HttpServletRequest request,
            HttpServletResponse response,
            @RequestBody Map<String, Object> params
    ){
        List<Map<String, Object>> dataList_LM = ExcelExport.getExportData_listMap(this.getOrderListGroupByCourseAndStu(params));

        if(null == dataList_LM) return;

        orderService.getOrderListGroupByCourseAndStu_exportData(request, response, dataList_LM);
    }
}