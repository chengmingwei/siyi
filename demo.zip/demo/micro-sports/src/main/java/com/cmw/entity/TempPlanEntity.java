package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 课次排班表
 * @author 程明卫
 * @date 2019-04-20 18:25:05
 */
@Description(remark="课次排班表实体",createDate="2019-04-20 18:25:05",author="程明卫")
@Entity
@Table(name="GL_TempPlan")
@SuppressWarnings("serial")
public class TempPlanEntity extends IdBaseEntity {

	 @Description(remark="应到人数")
	 @Column(name="xcount" ,nullable=false )
	 private Integer xcount = 0;

	@Description(remark="实到人数")
	 @Column(name="ycount" ,nullable=false )
	 private Integer ycount = 0;


	 @Description(remark="状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="班主任ID")
	 @Column(name="master" )
	 private Long master;

	 @Description(remark="教练ID")
	 @Column(name="coach" )
	 private Long coach;

	//作废，已将 旧教练 放到了 TempPlanEntity处
	@Description(remark = "旧教练")
	@Column(name = "oldCoach")
	private Long oldCoach;

	 @Description(remark="下课开始时间")
	 @Column(name="endTime" ,nullable=false )
	 private Date endTime;

	 @Description(remark="上课开始时间")
	 @Column(name="startTime" ,nullable=false )
	 private Date startTime;

	 @Description(remark="课次类型")
	 @Column(name="ctype" )
	 private Integer ctype = 1;

	 @Description(remark="班级ID")
	 @Column(name="classId" ,nullable=false )
	 private Long classId;

	@Description(remark="排班设置ID")
	@Column(name="sid")
	private Long sid;

	public Integer getXcount() {
		return xcount;
	}

	public void setXcount(Integer xcount) {
		this.xcount = xcount;
	}

	public Integer getYcount() {
		return ycount;
	}

	public void setYcount(Integer ycount) {
		this.ycount = ycount;
	}

	/**
	 * 获取排班设置ID
	 * @return	返回排班设置ID
	 */
	public Long getSid() {
		return sid;
	}

	/**
	 * 设置排班设置ID
	 * @param sid
	 */
	public void setSid(Long sid) {
		this.sid = sid;
	}

	public TempPlanEntity() {

	}

	
	/**
	  * 设置状态的值
	 * @param 	xstatus	 状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取状态的值
	 * @return 返回状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置班主任ID的值
	 * @param 	master	 班主任ID
	**/
	public void setMaster(Long  master){
		 this.master=master;
 	}

	/**
	  * 获取班主任ID的值
	 * @return 返回班主任ID的值
	**/
	public Long getMaster(){
		 return master;
 	}

	/**
	  * 设置教练ID的值
	 * @param 	coach	 教练ID
	**/
	public void setCoach(Long  coach){
		 this.coach=coach;
 	}

	/**
	  * 获取教练ID的值
	 * @return 返回教练ID的值
	**/
	public Long getCoach(){
		 return coach;
 	}

	/**
	  * 设置下课开始时间的值
	 * @param 	endTime	 下课开始时间
	**/
	public void setEndTime(Date  endTime){
		 this.endTime=endTime;
 	}

	/**
	  * 获取下课开始时间的值
	 * @return 返回下课开始时间的值
	**/
	public Date getEndTime(){
		 return endTime;
 	}

	/**
	  * 设置上课开始时间的值
	 * @param 	startTime	 上课开始时间
	**/
	public void setStartTime(Date  startTime){
		 this.startTime=startTime;
 	}

	/**
	  * 获取上课开始时间的值
	 * @return 返回上课开始时间的值
	**/
	public Date getStartTime(){
		 return startTime;
 	}

	/**
	  * 设置课次类型的值
	 * @param 	ctype	 课次类型
	**/
	public void setCtype(Integer  ctype){
		 this.ctype=ctype;
 	}

	/**
	  * 获取课次类型的值
	 * @return 返回课次类型的值
	**/
	public Integer getCtype(){
		 return ctype;
 	}

	/**
	  * 设置班级ID的值
	 * @param 	classId	 班级ID
	**/
	public void setClassId(Long  classId){
		 this.classId=classId;
 	}

	/**
	  * 获取班级ID的值
	 * @return 返回班级ID的值
	**/
	public Long getClassId(){
		 return classId;
 	}

	/**
	 * 旧教练
	 * @Author 肖家添
	 * @Date 2019/6/17 17:01
	 */
	public Long getOldCoach() {
		return oldCoach;
	}

	/**
	 * 旧教练
	 * @Author 肖家添
	 * @Date 2019/6/17 17:01
	 */
	public void setOldCoach(Long oldCoach) {
		this.oldCoach = oldCoach;
	}


	@Override
	public Object[] getDatas() {
		return new Object[]{xstatus,master,coach,endTime,startTime,ctype,classId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"xstatus","master","coach","endTime","startTime","ctype","classId"};
	}

}
