package com.cmw.service.impl;



import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.cmw.entity.MemberDetailEntity;
import com.cmw.dao.MemberDetailDao;
import com.cmw.service.inter.MemberDetailService;


/**
 * 会员详细信息表  Service实现类
 * @author 程明卫
 * @date 2019-04-10 22:13:17
 */
@Description(remark="会员详细信息表业务实现类",createDate="2019-04-10 22:13:17",author="程明卫")
@Service("memberDetailService")
public class MemberDetailServiceImpl extends AbsService<MemberDetailEntity, Long> implements  MemberDetailService {
	@Autowired
	private MemberDetailDao memberDetailDao;
	@Override
	public GenericDaoInter<MemberDetailEntity, Long> getDao() {
		return memberDetailDao;
	}

}
