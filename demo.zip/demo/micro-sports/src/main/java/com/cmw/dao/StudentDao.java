package com.cmw.dao;


import com.cmw.annotation.HoursAnnotation;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.StudentEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 学员信息  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 11:33:06
 */
@Description(remark="学员信息DAO Mapper接口",createDate="2019-04-10 11:33:06",author="程明卫")
@Component
@Mapper
public interface StudentDao extends GenericDaoInter<StudentEntity, Long> {

    @Override
    List<Map<String, Object>> getPageByPars(Map<String, Object> map);

    /**
     * 获取相同手机号的数据
     * @return
     */
     List<StudentEntity> getSamePhoneStudents();

    /**
     * 判断手机号存在
     * @param phone  手机号
     * @param sname 学生姓名
     * @param id ID
     * @return 返回 Integer [0:不存在,1:存在]
     */
     Integer exist(String phone, String sname, Long id);

     List<Map<String, Object>> getListMapByClassId(Map<String, Object> params);

     StudentEntity getBySource(HashMap<String, Object> map);
}
