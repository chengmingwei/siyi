package com.cmw.entity;


import com.alibaba.fastjson.annotation.JSONField;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 教师信息
 * @author 程明卫
 * @date 2019-04-10 13:55:46
 */
@Description(remark="教师信息实体",createDate="2019-04-10 13:55:46",author="程明卫")
@Entity
@Table(name="GL_Teacher")
@SuppressWarnings("serial")
public class TeacherEntity extends IdBaseEntity {

	@Description(remark="所属校区")
	@Column(name="schoolId" )
	private Long schoolId;
	
	 @Description(remark="老师头像附件ID")
	 @Column(name="attachId" )
	 private Long attachId;

	 @Description(remark="教师介绍")
	 @Column(name="intro" ,length=500 )
	 private String intro;

	 @Description(remark="教师角色")
	 @Column(name="ttype" )
	 private String ttype;

	 @Description(remark="工作性质")
	 @Column(name="nature" )
	 private Byte nature;

	 @Description(remark="在职状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Byte xstatus = 0;

	 @Description(remark="老师头像")
	 @Column(name="imgPath" ,length=150 )
	 private String imgPath;

	 @Description(remark="出生日期")
	 @Column(name="bdate" )
	 @JSONField(format="yyyy-MM-dd")
	 private Date bdate;

	 @Description(remark="手机")
	 @Column(name="phone" ,length=20 )
	 private String phone;

	 @Description(remark="性别")
	 @Column(name="sex" ,nullable=false )
	 private Byte sex = 0;

	 @Description(remark="姓名")
	 @Column(name="tname" ,nullable=false ,length=20 )
	 private String tname;

	@Description(remark="精彩瞬间照片")
	@Column(name="wonderful" ,length=200 )
	private String wonderful;


	public TeacherEntity() {

	}

	/**
	 * 获取精彩瞬间照片的值
	 * @return 返回精彩瞬间照片的值
	 **/
	public String getWonderful() {
		return wonderful;
	}

	/**
	 * 设置精彩瞬间照片的值
	 * @param 	wonderful	 精彩瞬间照片
	 **/
	public void setWonderful(String wonderful) {
		this.wonderful = wonderful;
	}

	/**
	  * 设置老师头像附件ID的值
	 * @param 	attachId	 老师头像附件ID
	**/
	public void setAttachId(Long  attachId){
		 this.attachId=attachId;
 	}

	/**
	  * 获取老师头像附件ID的值
	 * @return 返回老师头像附件ID的值
	**/
	public Long getAttachId(){
		 return attachId;
 	}

	/**
	  * 设置教师介绍的值
	 * @param 	intro	 教师介绍
	**/
	public void setIntro(String  intro){
		 this.intro=intro;
 	}

	/**
	  * 获取教师介绍的值
	 * @return 返回教师介绍的值
	**/
	public String getIntro(){
		 return intro;
 	}

	/**
	  * 设置教师角色的值
	 * @param 	ttype	 教师角色
	**/
	public void setTtype(String  ttype){
		 this.ttype=ttype;
 	}

	/**
	  * 获取教师角色的值
	 * @return 返回教师角色的值
	**/
	public String getTtype(){
		 return ttype;
 	}

	/**
	  * 设置工作性质的值
	 * @param 	nature	 工作性质
	**/
	public void setNature(Byte  nature){
		 this.nature=nature;
 	}

	/**
	  * 获取工作性质的值
	 * @return 返回工作性质的值
	**/
	public Byte getNature(){
		 return nature;
 	}

	/**
	  * 设置在职状态的值
	 * @param 	xstatus	 在职状态
	**/
	public void setXstatus(Byte  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取在职状态的值
	 * @return 返回在职状态的值
	**/
	public Byte getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置老师头像的值
	 * @param 	imgPath	 老师头像
	**/
	public void setImgPath(String  imgPath){
		 this.imgPath=imgPath;
 	}

	/**
	  * 获取老师头像的值
	 * @return 返回老师头像的值
	**/
	public String getImgPath(){
		 return imgPath;
 	}

	/**
	  * 设置出生日期的值
	 * @param 	bdate	 出生日期
	**/
	public void setBdate(Date  bdate){
		 this.bdate=bdate;
 	}

	/**
	  * 获取出生日期的值
	 * @return 返回出生日期的值
	**/
	public Date getBdate(){
		 return bdate;
 	}

	/**
	  * 设置手机的值
	 * @param 	phone	 手机
	**/
	public void setPhone(String  phone){
		 this.phone=phone;
 	}

	/**
	  * 获取手机的值
	 * @return 返回手机的值
	**/
	public String getPhone(){
		 return phone;
 	}

	/**
	  * 设置性别的值
	 * @param 	sex	 性别
	**/
	public void setSex(Byte  sex){
		 this.sex=sex;
 	}

	/**
	  * 获取性别的值
	 * @return 返回性别的值
	**/
	public Byte getSex(){
		 return sex;
 	}

	/**
	  * 设置姓名的值
	 * @param 	tname	 姓名
	**/
	public void setTname(String  tname){
		 this.tname=tname;
 	}

	/**
	  * 获取姓名的值
	 * @return 返回姓名的值
	**/
	public String getTname(){
		 return tname;
 	}


	/**
	 * 获取所属校区的值
	 * @return 返回所属校区的值
	 **/
	public Long getSchoolId() {
		return schoolId;
	}

	/**
	 * 设置所属校区的值
	 * @param schoolId	所属校区
	 */
	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}

	@Override
	public Object[] getDatas() {
		return new Object[]{attachId,intro,ttype,nature,xstatus,imgPath,bdate,phone,sex,tname};
	}

	@Override
	public String[] getFields() {
		return new String[]{"attachId","intro","ttype","nature","xstatus","imgPath","bdate","phone","sex","tname"};
	}

}
