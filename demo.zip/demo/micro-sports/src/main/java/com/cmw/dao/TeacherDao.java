package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.TeacherEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;


/**
 * 教师信息  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 13:55:46
 */
@Description(remark="教师信息DAO Mapper接口",createDate="2019-04-10 13:55:46",author="程明卫")
@Mapper
public interface TeacherDao extends GenericDaoInter<TeacherEntity, Long>{

    /**
     * 判断手机号存在
     * @param phone  手机号
     * @param id ID
     * @return 返回 Integer [0:不存在,1:存在]
     */
    Integer exist(String phone, Long id);

    String getTeacheByUserId(Long userId);

    Map<String,Object> getTeacherMap(Map<String,Object> pars);

    /**
     *
     * 根据学校ID获取老师ID列表
     * @param pars
     * @return
     */
    List<Long> getIds(Map<String,Object> pars);

    /**
     * 获取教师下拉框
     * @Author 肖家添
     * @Date 2019/6/4 16:35
     */
    List<Map<String, Object>> getTeacherForSelect(Map<String, Object> pars);
}
