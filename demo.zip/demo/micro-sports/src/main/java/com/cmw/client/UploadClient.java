package com.cmw.client;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(value = "micro-upload")
public interface UploadClient {

    @PostMapping("/attachment/ossFileTransfer")
    JSONObject ossFileTransfer();

}
