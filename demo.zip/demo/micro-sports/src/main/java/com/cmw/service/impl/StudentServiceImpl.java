package com.cmw.service.impl;


import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.StudentDao;
import com.cmw.entity.MemberEntity;
import com.cmw.entity.StudentDetailEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.props.JwtProperties;
import com.cmw.service.inter.MemberService;
import com.cmw.service.inter.StudentDetailService;
import com.cmw.service.inter.StudentService;
import com.cmw.util.*;
import com.cmw.util.export.ExcelExport;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 学员信息  Service实现类
 * @author 程明卫
 * @date 2019-04-10 11:33:10
 */
@Description(remark="学员信息业务实现类",createDate="2019-04-10 11:33:10",author="程明卫")
@Service("studentService")
public class StudentServiceImpl extends AbsService<StudentEntity, Long> implements  StudentService {
	@Autowired
	StudentDao studentDao;

	@Autowired
	StudentDetailService studentDetailService;

	@Autowired
	MemberService memberService;

	@Autowired
	private JwtProperties jwtProperties;

	@Override
	public GenericDaoInter<StudentEntity, Long> getDao() {
		return studentDao;
	}

	Integer upcount = 0;
	@Override
	public Integer updateErrData() {
		List<StudentEntity> samePhonesStus = studentDao.getSamePhoneStudents();
		if(null == samePhonesStus || samePhonesStus.size() == 0){
			log.error("没有手机号相同的学生数据！");
			return  0;
		}
		upcount = 0;
		samePhonesStus.forEach(stu -> {
			if(existAccount(stu)) return;
			UserModel userInfo = new UserModel();
			userInfo.setId(stu.getCreator());
			userInfo.setIndeptId(stu.getDeptId());
			userInfo.setIncompId(stu.getOrgid());
			userInfo.setInempId(-9999L);
			String phone = stu.getPhone();
			String enc_phone = GenPass.Encrypt(phone);
			MemberEntity memberEntity = saveMember(userInfo, stu, enc_phone);
			stu.setMemberId(memberEntity.getId());
			studentDao.update(stu);
			upcount++;
		});
		return upcount;
	}

	private boolean existAccount(StudentEntity stu) {
		String sname = stu.getSname();
		Long memberId = stu.getMemberId();
		Map<String,Object> pars = new HashMap<>();
		pars.put("memberId", memberId);
		pars.put("rname", sname);
		MemberEntity memberEntity = memberService.getByPars(pars);
		return null == memberEntity ? false : true;
	}

	@Override
	@Transactional
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		Map<String, Object> dataResult = saveStudentByImport(params);
		return dataResult;
	}

	@Override
	public Map<String, Object> saveStudentByImport(SHashMap<String, Object> params) {
		StudentEntity student = null;
		try {
			student = BeanUtil.copyValue(StudentEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
		log.info("=== 验证学生信息 ===");
		validStudentInfo(student);
		//1.获取用户
		UserModel userInfo = (UserModel)params.get(SysContant.USER_INFO);
		if(null == userInfo){
			userInfo = LoginInterceptor.getLoginUser();
		}
		MemberEntity memberEntity = saveMemberInfo(userInfo, student);
		Long memberId = memberEntity.getId();
		student.setMemberId(memberId);
		Long studentId = student.getId();
		StudentDetailEntity studentDetail = null;

		setAge(student);
		if(null == studentId){
			UserUtil.setCreateInfo(userInfo, student);
			insert(student);
			studentId = student.getId();
		}else{
			UserUtil.setModifyInfo(userInfo, student);
			//UserUtil.setModifyInfo(userInfo, studentDetail);
			//获取原来的状态，重新更新回去。（因为，有些学生已经报名了。要修改手机号。这时，原来的状态不应该变） ADD ：cmw 2019-12-01 16:04
			StudentEntity orginStudent = get(studentId);
			if(null != orginStudent){
				Integer xstatus = orginStudent.getXstatus();
				student.setXstatus(xstatus);
			}
			update(student);

		}
		saveStudentDetail(params, studentId, userInfo);
		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", student.getId());
		dataResult.put("memberId", memberId);
		putMemberToken(params, dataResult ,student, memberEntity);
		return dataResult;
	}

	/**
	 * 当有学生从分享的海报报名或预约体验时，保存学生信息后就立即生成登录的Token
	 * @param params
	 * @param dataResult
	 * @param studentEntity
	 * @param memberEntity
	 */
	private void putMemberToken(SHashMap<String, Object> params, Map<String,Object> dataResult ,StudentEntity studentEntity, MemberEntity memberEntity){
		Integer source = params.getvalAsInt("source");
		Long sourceId = params.getvalAsLng("sourceId");
		if((null != source && source.intValue() == BussContant.STUDENT_SOURCE_4) && null != sourceId){
			UserModel userModel = getUserModel(memberEntity, studentEntity.getId());
			int expire = jwtProperties.getExpire();
			try {
				String token = JwtUtils.generateToken(userModel, jwtProperties.getPrivateKey(), expire);
				Integer maxAge = jwtProperties.getCookieMaxAge();
				String cookieName = jwtProperties.getCookieName();
				dataResult.put("cookieName", cookieName);
				dataResult.put(cookieName, token);
				dataResult.put("maxAge", maxAge);
			} catch (Exception e) {
				e.printStackTrace();
				log.error(e.getMessage());
			}
		}
	}

	private UserModel getUserModel(MemberEntity member, Long studentId) {
		Map<String, Object> pars = new HashMap<>();
		pars.put("memberId", member.getId());
		//4.用户名密码都正确
		UserModel userModel = new UserModel(
				member.getId(), member.getAccount(), SysContant.MEMBER_DEFAULT_DEPTID,
				SysContant.ADMIN_DEFAULT_DEPTID, studentId, BussContant.USER_UTYPE_MEMBER
		);
		return userModel;
	}


	private void setAge(StudentEntity studentEntity){
		Date bdate = studentEntity.getBdate();
		if(null == bdate) return;
		int age = new Date().getYear() - bdate.getYear();
		studentEntity.setAge(age);
	}

	private void saveStudentDetail(SHashMap<String, Object> params, Long studentId, UserModel userInfo) {
		log.info("=== invoke saveStudentDetail ===");
		Map<String,Object> pars = new HashMap<>();
		pars.put("studentId", studentId);
		StudentDetailEntity studentDetail = studentDetailService.getByPars(pars);
		Long attachId = params.getvalAsLng("attachId");
		if(null != studentDetail){
			Long orgin_attachId = studentDetail.getAttachId();
			String policyNO = params.getvalAsStr("policyNo");
//			if(orgin_attachId.equals(attachId)) return;
			studentDetail.setAttachId(attachId);
			studentDetail.setPolicyNo(policyNO);
			UserUtil.setModifyInfo(userInfo, studentDetail);
			studentDetailService.update(studentDetail);
			log.info("=== update studentDetail.success ===");
		}else{
		    String policyNO = params.getvalAsStr("policyNo");
		    Long sourceId = params.getvalAsLng("sourceId");
			studentDetail = new StudentDetailEntity();
			UserUtil.setCreateInfo(userInfo, studentDetail);
			studentDetail.setStudentId(studentId);
			studentDetail.setAttachId(attachId);
            studentDetail.setPolicyNo(policyNO);
			studentDetail.setSourceId(sourceId);
			studentDetailService.insert(studentDetail);
			log.info("=== insert studentDetail.success ===");
		}
	}

	private MemberEntity saveMemberInfo(UserModel userInfo,StudentEntity student){
		String phone = student.getPhone();
		String enc_phone = GenPass.Encrypt(phone);
		Long orgin_memberId = student.getMemberId();
		String sname = student.getSname();
		MemberEntity memberEntity = getMember(sname, enc_phone, orgin_memberId);
		log.info("=== saveMemberInfo ===");
		if(null != memberEntity){
			String account = memberEntity.getAccount();
			if(account.equals(enc_phone)) return memberEntity;
			memberEntity.setAccount(enc_phone);
			memberEntity.setPhone(enc_phone);
			memberEntity.setRname(student.getSname());
			UserUtil.setModifyInfo(userInfo, memberEntity);
			memberService.update(memberEntity);
			log.info("saveMemberInfo.update success");
		}else{
			memberEntity = saveMember(userInfo, student, enc_phone);
		}
		return memberEntity;
	}

	private MemberEntity saveMember(UserModel userInfo, StudentEntity student, String enc_phone) {
		MemberEntity memberEntity;
		String pwd = SysContant.DEFAULT_PWD;
		String encodePassword = CodecUtils.passwordBcryptEncode(student.getPhone().trim(),pwd);
		memberEntity = new MemberEntity();
		memberEntity.setAccount(enc_phone);
		memberEntity.setPhone(enc_phone);
		memberEntity.setRname(student.getSname());
		memberEntity.setImgPath(student.getImgPath());
		memberEntity.setPwd(encodePassword);
		UserUtil.setCreateInfo(userInfo, memberEntity);
		memberService.insert(memberEntity);
		log.info("saveMemberInfo.insert success");
		return memberEntity;
	}

	private MemberEntity getMember(String sname,String enc_phone, Long orgin_memberId) {
		MemberEntity memberEntity;
		if(null == orgin_memberId){
			Map<String,Object> pars = new HashMap<>();
			pars.put("account", enc_phone);
			pars.put("rname", sname);
			memberEntity = memberService.getByPars(pars);
		}else{
			memberEntity = memberService.get(orgin_memberId);
		}
		return memberEntity;
	}


	/**
	 * 验证学生信息
	 */
	private void validStudentInfo(StudentEntity student) {
		String sname = student.getSname();
		Byte sex = student.getSex();
		String phone = student.getPhone();
		if(StringUtils.isEmpty(sname)){
			throw new ServiceException("学生姓名不能为空!");
		}
		if(null == sex){
			throw new ServiceException("学生性别不能为空!");
		}
		if(StringUtils.isEmpty(phone)){
			throw new ServiceException("手机号不能为空!");
		}
		if(!StringHandler.isChinaPhoneLegal(phone)){
			throw new ServiceException("手机号("+ phone +")格式错误!");
		}

		Long id = student.getId();
		Integer count = 0;
		boolean isAdd = null == id; //是否新增 [true:新增, false:修改]
		if(isAdd){
			count = studentDao.exist(phone,sname, null);
			if(count > 0) throw new ServiceException("系统中已经在存姓名为："+sname+",手机号为："+ phone +"的学生!");
		}else{
			count = studentDao.exist(phone,sname, id);
			if(count > 0) throw new ServiceException("当前修改的学生名："+sname+"和手机号："+ phone +" 在系统中已经存在!");
		}
	}

	@Override
	public List<Map<String, Object>> getListMapByClassId(Map<String, Object> params) {
		return studentDao.getListMapByClassId(params);
	}

	@Override
	public void exportData(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> studentList_LM) {
		String[] cellVal = {
				"ID",
				"手机号",
				"姓名",
				"性别",
				"下级状态",
				"生日",
				"年级",
				"来源",
				"最新报名时间",
				"报名课程",
				"剩余课时",
				"班主任",
				"教练"
		};

		String[] dataKeys = {
				"id",
				"phone",
				"sname",
				"sex",
				"xstatus",
				"bdate",
				"grade",
				"source",
				"enrollDate",
				"courseName",
				"totalZhours",
				"master",
				"coach"
		};

		for(Map<String, Object> student : studentList_LM){
			SHashMap student_SH = new SHashMap<>(student);

			for(String key : dataKeys){
				String val = student_SH.getvalAsStr(key);

				val = StringHandler.isValidStr(val) ? val : "";

				switch (key){
					case "xstatus":{

						switch (val){
							case "0":{
								val = "未跟进";
								break;
							}
							case "1":{
								val = "跟进中";
								break;
							}
							case "2":{
								val = "预约体验";
								break;
							}
							case "3":{
								val = "已体验";
								break;
							}
							case "4":{
								val = "正式学员";
								break;
							}
							case "5":{
								val = "历史学员";
								break;
							}
						}

						break;
					}
					case "source":{

						switch (val){
							case "1":{
								val = "地推";
								break;
							}
							case "2":{
								val = "转介绍";
								break;
							}
							case "3":{
								val = "官网";
								break;
							}
							case "4":{
								val = "微信";
								break;
							}
							case "5":{
								val = "电话邀约";
								break;
							}
							case "6":{
								val = "门店到访";
								break;
							}
							case "7":{
								val = "其他合作渠道";
								break;
							}
							case "8":{
								val = "其他相关渠道";
								break;
							}
						}

						break;
					}
					case "bdate":
					case "enrollDate": {

						if(StringHandler.isValidStr(val))
							val = DateUtil.dateFormatToStr("yyyy-MM-dd", new Date(Long.parseLong(val)));

						break;
					}
					case "grade": {

						switch (val){
							case "1":{
								val = "学前";
								break;
							}
							case "2":{
								val = "一年级";
								break;
							}
							case "3":{
								val = "二年级";
								break;
							}
							case "4":{
								val = "三年级";
								break;
							}
							case "5":{
								val = "四年级";
								break;
							}
							case "6":{
								val = "五年级";
								break;
							}
							case "7":{
								val = "六年级";
								break;
							}
							case "8":{
								val = "初一";
								break;
							}
							case "9":{
								val = "初二";
								break;
							}
							case "10":{
								val = "初三";
								break;
							}
						}

						break;
					}
					case "sex": {

						switch (val){
							case "1": {
								val = "男";
								break;
							}
							case "2": {
								val = "女";
								break;
							}
						}

						break;
					}
				}

				student.put(key, val);
			}
		}

		new ExcelExport(request, response).export(cellVal, dataKeys, studentList_LM);
	}

	/**
	 *     StudentEntity getBySource(SHashMap<String, Object> pars);
	 * @param pars
	 * @return
	 */
	@Override
	public StudentEntity getBySource(SHashMap<String, Object> pars) {
		return studentDao.getBySource(pars.getMap());
	}

	@Transactional
	@Override
	public void enabled(Long id, Integer isenabled) throws ServiceException {
		super.enabled(id, isenabled);
		if(null != isenabled && isenabled.intValue() == SysContant.ISENABLED_DEL_1){
			StudentEntity studentEntity = get(id);
			deleteMember(studentEntity.getMemberId());
		}
	}

	private void deleteMember(Long memberId)  {
		memberService.enabled(memberId, (int) SysContant.ISENABLED_DEL_1);
	}

	@Transactional
	@Override
	public void enabledByIds(String ids, Integer isenabled) throws ServiceException {
		super.enabledByIds(ids, isenabled);
		if(!StringUtils.isEmpty(ids) && null != isenabled && isenabled.intValue() == SysContant.ISENABLED_DEL_1){
			String[] idsArr = ids.split(",");
			for(String id : idsArr){
				StudentEntity studentEntity = get(Long.parseLong(id));
				deleteMember(studentEntity.getMemberId());
			}

		}
	}
}

