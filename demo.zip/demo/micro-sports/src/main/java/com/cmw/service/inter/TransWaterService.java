package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.TransWaterEntity;


/**
 * 交易流水  Service接口
 * @author 程明卫
 * @date 2019-04-10 14:08:45
 */
@Description(remark="交易流水业务接口",createDate="2019-04-10 14:08:45",author="程明卫")
public interface TransWaterService extends IService<TransWaterEntity, Long> {
}
