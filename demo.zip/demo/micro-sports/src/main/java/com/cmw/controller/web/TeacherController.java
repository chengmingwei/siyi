package com.cmw.controller.web;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.core.vo.Pagination;
import com.cmw.entity.ClassEntity;
import com.cmw.entity.TeacherEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.model.global.ResultModel;
import com.cmw.model.global.ResultUtil;
import com.cmw.service.inter.AttachmentService;
import com.cmw.service.inter.ClassService;
import com.cmw.service.inter.TeacherService;
import com.cmw.util.*;
import com.cmw.util.export.ExcelExport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 教师信息  ACTION类
 * @author 程明卫
 * @date 2019-04-10 13:55:46
 */
@Description(remark="教师信息ACTION",createDate="2019-04-10 13:55:46",author="程明卫")
@Api(value = "教师信息微服务", description = "#CONTROLLER# 2019-04-10 13:55:46 程明卫")
@RestController
@RequestMapping({"/teacher"})
public class TeacherController{
	@Resource(name="teacherService")
	private TeacherService teacherService;

	@Autowired
    ClassService classService;

    @Autowired
    AttachmentService attachmentService;


    /**
     * 根据班级ID获取班级老师信息
     * -- 班级详情
     *      -- 班级老师
     *      /teacher/pc/list
     * @param  classId 班级ID
     * @return
     */
    @ApiOperation("根据班级ID获取班级老师信息")
    @PostMapping(value = "/pc/list")
    public JSONObject getTeachersByClassId(@RequestParam("classId") Long classId){

        ClassEntity classEntity = classService.get(classId);
        Long coach = classEntity.getCoach();
        Long master = classEntity.getMaster();
        StringBuilder sbTeacherIds = new StringBuilder();
        if(null != coach){
            sbTeacherIds.append(coach).append(",");
        }
        if(null != master){
            sbTeacherIds.append(master).append(",");
        }

        String teacherIds = StringHandler.RemoveStr(sbTeacherIds);
        Map<String,Object> params = new HashMap<>();
        params.put("teacherIds", teacherIds);
        List<Map<String,Object>> dataSource = teacherService.getListMap(params);
        JSONObject jsonObject = PageHandler.getJson(dataSource);
        return   jsonObject;
    }


    /**
     * 获取下拉框等简单控件的数据源
     * @return
     */
    @ApiOperation("根据当前用户和其所在校区老师列表信息，供下拉框等控件使用")
    @PostMapping(value = "/ds/{ttype}")
    public JSONObject getDataSource(@PathVariable("ttype") Integer ttype, @RequestParam Map<String, Object> params){
        UserModel userInfo = LoginInterceptor.getLoginUser();

        SHashMap<String, Object> params_SH = new SHashMap<>(params);

        String teacherName = params_SH.getvalAsStr("teacherName");

        params_SH.clear();

        params_SH.put("tname", teacherName);            //教师名称
      //  params_SH.put("userId", userInfo.getId());
       // params_SH.put("ttype", ttype);

        List<Map<String,Object>> dataSource = teacherService.getListMap(params_SH.getMap());
        JSONObject jsonObject = PageHandler.getJson(dataSource);
        return   jsonObject;
    }

    /**
     * 获取下拉框等简单控件的数据源
     * 可根据 老师名：tname 去查询
     * @return
     */
    @ApiOperation("转派选择校区老师列表信息，供下拉框等控件使用")
    @PostMapping(value = "/go")
    public JSONObject getDataSource(@RequestBody Map<String, Object> params){
        params.put("ttype", BussContant.TEACHER_TTYPE_1);
        List<Map<String,Object>> dataSource = teacherService.getListMap(params);
        JSONObject jsonObject = PageHandler.getJson(dataSource);
        return   jsonObject;
    }

    /**
     * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询老师信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = getRightSql(userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = teacherService.getPageByPars(params,page, pageSize);

        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }

    /**
     * 数据导出
     * @Author 肖家添
     * @Date 2019/6/28 17:10
     */
    @ApiOperation("数据导出")
    @PostMapping("/exportData")
    public void exportData(HttpServletRequest request, HttpServletResponse response, @RequestParam Map<String, Object> params){
        List<Map<String, Object>> dataList_LM = ExcelExport.getExportData(this.list(params));

        if(null == dataList_LM) return;

        teacherService.exportData(request, response, dataList_LM);
    }

    private String getRightSql(UserModel userObj){
        String tabAsName = "A"; //表别名
        String rightCondition = UserUtil.getRightSql(tabAsName, userObj);
        Integer utype = userObj.getUtype();
        if(null != utype && utype.intValue() == BussContant.USER_UTYPE_2){
            Long indeptId = userObj.getIndeptId();
            rightCondition = "and "+tabAsName+".schoolId ='"+indeptId+"' ";
        }
        return rightCondition;
    }

    /**
     * 跳转详细页面
     * /teacher/info
     * @param id 记录ID
     * @return
     */
    @GetMapping(value = "/info")
    public ResultModel<Map<String, Object>> info(@ApiParam("老师信息ID") @RequestParam("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        TeacherEntity obj = teacherService.get(id);
        if(null == obj) return ResultUtil.getFailure("无老师信息!");
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("imgPath", obj.getImgPath());
        resultMap.put("name", obj.getTname());
        resultMap.put("sex", obj.getSex());
        resultMap.put("phone", obj.getPhone());
        resultMap.put("intro", obj.getIntro());

        String wonderful = obj.getWonderful();

        resultMap.put("wonderful", wonderful);

        if(StringHandler.isValidObj(wonderful)){
            if(wonderful.lastIndexOf(",") != wonderful.length() - 1){
                String[] ids = wonderful.split(",");

                String wonderful_path = attachmentService.getFilePathsByIds(ids);

                resultMap.put("wonderful_path", wonderful_path);
            }
        }

        ResultModel<Map<String, Object>> resultModel = ResultUtil.getSuccess(resultMap);
        return resultModel;
    }

    /**
     * 更新教师精彩瞬间照片
     * @param id 记录ID
     * @return
     */
    @PostMapping(value = "/wonderful/{id}")
    public JSONObject updateWonderful(@ApiParam("教师ID") @PathVariable("id") Long id, @RequestParam("wonderful") String wonderful){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        TeacherEntity obj = teacherService.get(id);
        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("wonderful", wonderful);
        Map<String,Object> wherePars = new HashMap<>();
        wherePars.put("id", id);
        teacherService.updateByPars(dataMap, wherePars);
        obj.setWonderful(wonderful);
        return PageHandler.getJson(obj);
    }


    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("学员信息ID") @PathVariable("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        TeacherEntity obj = teacherService.get(id);
        String bdate = DateUtil.dateFormatToStr("yyyy-MM-dd", obj.getBdate());
        JSONObject jsonObject = PageHandler.getJson(obj);
        JSONObject datas = jsonObject.getJSONObject("datas");
        datas.put("bdate", bdate);
        jsonObject.put("datas", datas);
        return jsonObject;
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存教师信息")
    @PostMapping(value = "sys/save")
    public JSONObject save(@RequestBody Map<String, Object> params) throws Exception{
        try{
            Map<String, Object> dataResult = (Map<String, Object>)teacherService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除学员信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("教师ID") @PathVariable("id")  Long id) throws Exception{
        teacherService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }

    @ApiOperation("获取教师下拉框")
    @PostMapping("/getTeacherForSelect")
    public JSONObject getTeacherForSelect(@RequestParam Map<String, Object> params){
        try{
            List<Map<String, Object>> getTeacherForSelect = teacherService.getTeacherForSelect(params);

            return PageHandler.getJson(getTeacherForSelect);
        }catch (Exception ex){
            ex.printStackTrace();
        }

        return PageHandler.getFailureJson("数据读取失败");
    }
}
