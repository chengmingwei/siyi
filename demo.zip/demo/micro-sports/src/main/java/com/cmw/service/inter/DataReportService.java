package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.AttachmentEntity;
import com.cmw.util.SHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * 数据报表  Service接口
 * @author 程明卫
 * @date 2019-10-16 21:16:53
 */
@Description(remark="数据报表业务接口",createDate="2019-10-16 21:16:53",author="程明卫")
public interface DataReportService {

    /**
     * 学生详细信息报表
     * @param params
     * @return
     */
    PageResult<List<Map<String,Object>>> getStudentDetailReport(Map<String, Object> params, Integer currPage, Integer pageSize);

    /**
     * 学员剩余课时报表
     * @param params
     * @return
     */
    PageResult<List<Map<String,Object>>> getSurplusHoursReport(Map<String, Object> params, Integer currPage, Integer pageSize);

    /**
     * 学员上课统计报表
     * @param params
     * @return
     */
    PageResult<List<Map<String,Object>>> getGoClassReport(Map<String, Object> params, Integer currPage, Integer pageSize);

    /**
     * 学员上课课时（按课时）报表
     * @param params
     * @return
     */
    PageResult<List<Map<String,Object>>> getGoClassHoursReport(Map<String, Object> params, Integer currPage, Integer pageSize);

    /**
     * 老师上课统计报表
     * @param params
     * @return
     */
    PageResult<List<Map<String, Object>>> getGoClassByTeacherReport(Map<String, Object> params, Integer currPage, Integer pageSize);

    /**
     * 导出数据
     * @Author 肖家添
     * @Date 2019/6/26 19:04
     */
    void exportData(HttpServletRequest request, HttpServletResponse response, Integer bizType, Map<String, Object> params, Integer currPage, Integer pageSize);
}
