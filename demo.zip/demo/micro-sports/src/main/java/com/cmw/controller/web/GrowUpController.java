package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.GrowUpEntity;
import com.cmw.entity.MemberEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.*;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.*;


/**
 * 成长档案表  Conntroller类
 * @author 程明卫
 * @date 2019-04-20 13:52:04
 */
@Description(remark="成长档案表Conntroller",createDate="2019-04-20 13:52:04",author="程明卫")
@Api(value = "成长档案表微服务", description = "#CONTROLLER# 2019-04-20 13:52:04 程明卫")
@RestController
@RequestMapping({"/growup"})
public class GrowUpController extends BaseAction{
	@Resource(name="growUpService")
	private GrowUpService growUpService;

    @Resource(name="studentService")
    private StudentService studentService;

    @Autowired
    private AttachmentService attachmentService;

    @Autowired
    private TeacherService teacherService;

    @Autowired
    MemberService memberService;

    @Autowired
    private ClassGoService classGoService;

    /**
     * 获取指定学生的成长档案表列表API
     * /growup/comments/{teacherUserId}
     * @param
     * @param  groId 学生ID
     * @return
     */
    @ApiOperation("海报页获取老师评论列表API")
    @PostMapping(value = "/comments/{groId}")
    public JSONObject wx_comments(@PathVariable("groId") Long groId){
        Map<String,Object> params = new HashMap<>();
        GrowUpEntity growUpEntity = growUpService.get(groId);
        Long studentId = growUpEntity.getStudentId();
        Long ccId = growUpEntity.getCcId();
        if(null == ccId) ccId = -1L;
        params.put("ccId",ccId);
        params.put("groId",groId);
        params.put("studentId",studentId);
        List<Map<String,Object>> list = growUpService.getComments(params);
        Collection<List<Map<String,Object>>> gpList = groupComments(list);
        return PageHandler.getJson(gpList);
    }

    private Collection<List<Map<String,Object>>> groupComments(List<Map<String,Object>> list){
        if(null == list || list.isEmpty()) return null;
        Map<Long,Long> lockMap = new HashMap<>();
        Map<Long,List<Map<String,Object>>> groupMapList = new LinkedHashMap<>();
        list.stream().forEach(item -> {
           Long creator = Long.parseLong(item.get("creator").toString());
           if(lockMap.keySet().size() <=2){
               lockMap.put(creator,creator);
           }

           if(lockMap.containsKey(creator)){
               if(!groupMapList.containsKey(creator)){
                   List<Map<String,Object>> subList =  new ArrayList<Map<String,Object>>();
                   groupMapList.put(creator, subList);
               }
               groupMapList.get(creator).add(item);
           }
        });
        Collection<List<Map<String,Object>>> gpList = groupMapList.values();
        return gpList;
    }

    /**
     * 获取指定学生的成长档案表列表API
     * /growup/list/{studentId}
     * @param
     * @param  studentId 学生ID
     * @return
     */
    @ApiOperation("成长档案表列表API")
    @PostMapping(value = "/list/{studentId}")
    public JSONObject sys_list(@PathVariable("studentId") Long studentId){
        Map<String,Object> params = new HashMap<>();
        params.put("studentId",studentId);
        List<Map<String,Object>> list = growUpService.getListByStudent(params);
        return PageHandler.getJson(list);
    }



      /**
     * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询成长档案表信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = growUpService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }



	/**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取成长档案表信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("成长档案表ID") @PathVariable("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        GrowUpEntity obj = growUpService.get(id);
        String studentName = "";
        String creatorName = "";
        if(null != obj){
            String imgPath = obj.getImgPath();
            if(StringHandler.isValidStr(imgPath)){
                imgPath = attachmentService.getFilePathsByIds(StringHandler.splitStr(imgPath,","));
                obj.setImgPath(imgPath);
            }
            String vedioPath = obj.getVedioPath();
            if(StringHandler.isValidStr(vedioPath)){
                vedioPath = attachmentService.getFilePathsByIds(StringHandler.splitStr(vedioPath,","));
                obj.setVedioPath(vedioPath);
            }
            Long studentId = obj.getStudentId();
            StudentEntity studentEntity = studentService.get(studentId);
            studentName = studentEntity.getSname();
            Byte creatorType = obj.getCreatorType();
            Long creator = obj.getCreator();
            if(null != creatorType && creatorType.intValue() == 1){ //老师
                creatorName = teacherService.getTeacheByUserId(creator);
            }else{
                MemberEntity memberEntity = memberService.get(creator);
                if(null != memberEntity){
                    creatorName = memberEntity.getRname();
                }
            }
        }
        JSONObject jsonObject = PageHandler.getJson(obj);
        JSONObject datas = jsonObject.getJSONObject("datas");
        datas.put("studentName", studentName);
        datas.put("creatorName", creatorName);
        jsonObject.put("datas", datas);
        return   jsonObject;
    }
    

    
    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存成长档案表信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
        try{
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = LoginInterceptor.getLoginUser();
            pars.put(SysContant.USER_INFO, userInfo);
            Map<String, Object> dataResult = (Map<String, Object>)growUpService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }

    }
    
    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
        return save(param);
    }
    
    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除成长档案表信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("#DESCRIPTIONID") @PathVariable("id")  Long id) throws Exception{
        growUpService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }

    /**
     * 查询学生上课记录
     * @Author 肖家添
     * @Date 2019/7/9 9:27
     */
    @ApiOperation("/查询学生上课记录")
    @PostMapping("/getClassGoByStudent")
    public JSONObject getClassGoByStudent(@RequestParam Map<String, Object> params){
        return growUpService.getClassGoByStudent(params);
    }
    
}
