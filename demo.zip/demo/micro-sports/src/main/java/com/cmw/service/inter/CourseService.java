package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.CourseEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * 课程信息  Service接口
 * @author 程明卫
 * @date 2019-04-10 13:59:08
 */
@Description(remark="课程信息业务接口",createDate="2019-04-10 13:59:08",author="程明卫")
public interface CourseService extends IService<CourseEntity, Long> {

    /**
     * 导出数据
     * @Author 肖家添
     * @Date 2019/6/26 19:04
     */
    void exportData(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM);

}
