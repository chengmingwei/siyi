package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.LeaveApplyEntity;

import java.util.List;
import java.util.Map;


/**
 * 请假表  Service接口
 * @author 程明卫
 * @date 2019-04-20 13:26:16
 */
@Description(remark="请假表业务接口",createDate="2019-04-20 13:26:16",author="程明卫")
public interface LeaveApplyService extends IService<LeaveApplyEntity, Long> {
    /**
     * 请假审批
     * @param pars
     */
    void audit(Map<String, Object> pars);

    /**
     * 获取请假记录
     * @Author 肖家添
     * @Date 2019/7/17 16:00
     */
    List<Map<String, Object>> getLeaveApplyByPars(Map<String, Object> params);
}
