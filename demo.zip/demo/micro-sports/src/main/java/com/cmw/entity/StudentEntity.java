package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 学员信息
 * @author 程明卫
 * @date 2019-04-10 11:33:05
 */
@Description(remark="学员信息实体",createDate="2019-04-10 11:33:05",author="程明卫")
@Entity
@Table(name="GL_Student")
@SuppressWarnings("serial")
public class StudentEntity extends IdBaseEntity {
	
	
	 @Description(remark="会员ID")
	 @Column(name="memberId" ,nullable=false )
	 private Long memberId;

	 @Description(remark="姓名")
	 @Column(name="sname" ,nullable=false ,length=20 )
	 private String sname;

	 @Description(remark="性别")
	 @Column(name="sex" ,nullable=false )
	 private Byte sex = 0;

	 @Description(remark="手机")
	 @Column(name="phone" ,nullable=false ,length=20 )
	 private String phone;

	 @Description(remark="出生日期")
	 @Column(name="bdate" )
	 private Date bdate;

	@Description(remark="年龄")
	@Column(name="age" )
	private Integer age;

	 @Description(remark="学员头像")
	 @Column(name="imgPath" ,length=150 )
	 private String imgPath;

	 @Description(remark="是否正式学员")
	 @Column(name="formal" ,nullable=false )
	 private Byte formal = 0;

	 @Description(remark="学生来源")
	 @Column(name="source" )
	 private Long source;

	 @Description(remark="所属学校")
	 @Column(name="school" ,length=50 )
	 private String school;

	 @Description(remark="学员年级")
	 @Column(name="grade" )
	 private Long grade;

	 @Description(remark="家庭住址")
	 @Column(name="address" ,length=150 )
	 private String address;

	@Description(remark="状态")
	@Column(name="xstatus")
	private Integer xstatus = 0;

	public StudentEntity() {

	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	/**
	 * 返回状态的值
	 * @return 	xstatus	 状态
	 **/
	public Integer getXstatus() {
		return xstatus;
	}

	/**
	 * 设置状态的值
	 * @param  	xstatus	 状态
	 **/
	public void setXstatus(Integer xstatus) {
		this.xstatus = xstatus;
	}

	/**
	  * 设置会员ID的值
	 * @param 	memberId	 会员ID
	**/
	public void setMemberId(Long  memberId){
		 this.memberId=memberId;
 	}

	/**
	  * 获取会员ID的值
	 * @return 返回会员ID的值
	**/
	public Long getMemberId(){
		 return memberId;
 	}

	/**
	  * 设置姓名的值
	 * @param 	sname	 姓名
	**/
	public void setSname(String  sname){
		 this.sname=sname;
 	}

	/**
	  * 获取姓名的值
	 * @return 返回姓名的值
	**/
	public String getSname(){
		 return sname;
 	}

	/**
	  * 设置性别的值
	 * @param 	sex	 性别
	**/
	public void setSex(Byte  sex){
		 this.sex=sex;
 	}

	/**
	  * 获取性别的值
	 * @return 返回性别的值
	**/
	public Byte getSex(){
		 return sex;
 	}

	/**
	  * 设置手机的值
	 * @param 	phone	 手机
	**/
	public void setPhone(String  phone){
		 this.phone=phone;
 	}

	/**
	  * 获取手机的值
	 * @return 返回手机的值
	**/
	public String getPhone(){
		 return phone;
 	}

	/**
	  * 设置出生日期的值
	 * @param 	bdate	 出生日期
	**/
	public void setBdate(Date bdate){
		 this.bdate=bdate;
 	}

	/**
	  * 获取出生日期的值
	 * @return 返回出生日期的值
	**/
	public Date getBdate(){
		 return bdate;
 	}

	/**
	  * 设置学员头像的值
	 * @param 	imgPath	 学员头像
	**/
	public void setImgPath(String  imgPath){
		 this.imgPath=imgPath;
 	}

	/**
	  * 获取学员头像的值
	 * @return 返回学员头像的值
	**/
	public String getImgPath(){
		 return imgPath;
 	}

	/**
	  * 设置是否正式学员的值
	 * @param 	formal	 是否正式学员
	**/
	public void setFormal(Byte  formal){
		 this.formal=formal;
 	}

	/**
	  * 获取是否正式学员的值
	 * @return 返回是否正式学员的值
	**/
	public Byte getFormal(){
		 return formal;
 	}

	/**
	  * 设置学生来源的值
	 * @param 	source	 学生来源
	**/
	public void setSource(Long  source){
		 this.source=source;
 	}

	/**
	  * 获取学生来源的值
	 * @return 返回学生来源的值
	**/
	public Long getSource(){
		 return source;
 	}

	/**
	  * 设置所属学校的值
	 * @param 	school	 所属学校
	**/
	public void setSchool(String  school){
		 this.school=school;
 	}

	/**
	  * 获取所属学校的值
	 * @return 返回所属学校的值
	**/
	public String getSchool(){
		 return school;
 	}

	/**
	  * 设置学员年级的值
	 * @param 	grade	 学员年级
	**/
	public void setGrade(Long  grade){
		 this.grade=grade;
 	}

	/**
	  * 获取学员年级的值
	 * @return 返回学员年级的值
	**/
	public Long getGrade(){
		 return grade;
 	}

	/**
	  * 设置家庭住址的值
	 * @param 	address	 家庭住址
	**/
	public void setAddress(String  address){
		 this.address=address;
 	}

	/**
	  * 获取家庭住址的值
	 * @return 返回家庭住址的值
	**/
	public String getAddress(){
		 return address;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{memberId,sname,sex,phone,bdate,imgPath,formal,source,school,grade,address,xstatus};
	}

	@Override
	public String[] getFields() {
		return new String[]{"memberId","sname","sex","phone","bdate","imgPath","formal","source","school","grade","address","xstatus"};
	}

}
