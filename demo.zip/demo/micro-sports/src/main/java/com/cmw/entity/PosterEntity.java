package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;

import java.util.Date;



/**
 * 学生海报
 * @author 程明卫
 * @date 2019-07-10 20:19:51
 */
@Description(remark="学生海报实体",createDate="2019-07-10 20:19:51",author="程明卫")
@Entity
@Table(name="GL_Poster")
@SuppressWarnings("serial")
public class PosterEntity extends IdEntity {
	
	
	 @Description(remark="创建日期")
	 @Column(name="createTime" ,nullable=false )
	 private Date createTime = new Date();

	 @Description(remark="可用标志")
	 @Column(name="isenabled" ,nullable=false )
	 private Byte isenabled = 1;

	 @Description(remark="访问量")
	 @Column(name="acount" ,nullable=false )
	 private Integer acount = 0;

	 @Description(remark="老师评价2")
	 @Column(name="comment2" ,length=200 )
	 private String comment2;

	 @Description(remark="老师评价1")
	 @Column(name="comment1" ,length=200 )
	 private String comment1;

	 @Description(remark="海报分享图片")
	 @Column(name="posterImg" ,length=200 )
	 private String posterImg;

	 @Description(remark="成长档案ID")
	 @Column(name="groId" ,nullable=false )
	 private Long groId;

	 @Description(remark="海报类型")
	 @Column(name="ptype" ,nullable=false )
	 private Integer ptype;

	 @Description(remark="学生ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;


	public PosterEntity() {

	}

	
	/**
	  * 设置创建日期的值
	 * @param 	createTime	 创建日期
	**/
	public void setCreateTime(Date  createTime){
		 this.createTime=createTime;
 	}

	/**
	  * 获取创建日期的值
	 * @return 返回创建日期的值
	**/
	public Date getCreateTime(){
		 return createTime;
 	}

	/**
	  * 设置可用标志的值
	 * @param 	isenabled	 可用标志
	**/
	public void setIsenabled(Byte  isenabled){
		 this.isenabled=isenabled;
 	}

	/**
	  * 获取可用标志的值
	 * @return 返回可用标志的值
	**/
	public Byte getIsenabled(){
		 return isenabled;
 	}

	/**
	  * 设置访问量的值
	 * @param 	acount	 访问量
	**/
	public void setAcount(Integer  acount){
		 this.acount=acount;
 	}

	/**
	  * 获取访问量的值
	 * @return 返回访问量的值
	**/
	public Integer getAcount(){
		 return acount;
 	}

	/**
	  * 设置老师评价2的值
	 * @param 	comment2	 老师评价2
	**/
	public void setComment2(String  comment2){
		 this.comment2=comment2;
 	}

	/**
	  * 获取老师评价2的值
	 * @return 返回老师评价2的值
	**/
	public String getComment2(){
		 return comment2;
 	}

	/**
	  * 设置老师评价1的值
	 * @param 	comment1	 老师评价1
	**/
	public void setComment1(String  comment1){
		 this.comment1=comment1;
 	}

	/**
	  * 获取老师评价1的值
	 * @return 返回老师评价1的值
	**/
	public String getComment1(){
		 return comment1;
 	}

	/**
	  * 设置海报分享图片的值
	 * @param 	posterImg	 海报分享图片
	**/
	public void setPosterImg(String  posterImg){
		 this.posterImg=posterImg;
 	}

	/**
	  * 获取海报分享图片的值
	 * @return 返回海报分享图片的值
	**/
	public String getPosterImg(){
		 return posterImg;
 	}

	/**
	  * 设置成长档案ID的值
	 * @param 	groId	 成长档案ID
	**/
	public void setGroId(Long  groId){
		 this.groId=groId;
 	}

	/**
	  * 获取成长档案ID的值
	 * @return 返回成长档案ID的值
	**/
	public Long getGroId(){
		 return groId;
 	}

	/**
	  * 设置海报类型的值
	 * @param 	ptype	 海报类型
	**/
	public void setPtype(Integer  ptype){
		 this.ptype=ptype;
 	}

	/**
	  * 获取海报类型的值
	 * @return 返回海报类型的值
	**/
	public Integer getPtype(){
		 return ptype;
 	}

	/**
	  * 设置学生ID的值
	 * @param 	studentId	 学生ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取学生ID的值
	 * @return 返回学生ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{createTime,isenabled,acount,comment2,comment1,posterImg,groId,ptype,studentId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"createTime","isenabled","acount","comment2","comment1","posterImg","groId","ptype","studentId"};
	}

}
