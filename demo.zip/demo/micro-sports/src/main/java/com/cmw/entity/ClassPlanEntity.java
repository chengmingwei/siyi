package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 循环排班表
 * @author 程明卫
 * @date 2019-04-20 18:24:24
 */
@Description(remark="循环排班表实体",createDate="2019-04-20 18:24:24",author="程明卫")
@Entity
@Table(name="GL_ClassPlan")
@SuppressWarnings("serial")
public class ClassPlanEntity extends IdEntity {
	
	
	 @Description(remark="下课时间")
	 @Column(name="etime" ,nullable=false )
	 private String etime;

	 @Description(remark="上课时间")
	 @Column(name="stime" ,nullable=false )
	 private String stime;

	 @Description(remark="循环规则")
	 @Column(name="ruleVals" ,nullable=false ,length=100 )
	 private String ruleVals;

	 @Description(remark="循环规则名称")
	 @Column(name="ruleNames" ,nullable=false ,length=100 )
	 private String ruleNames;

	 @Description(remark="排班设置ID")
	 @Column(name="setId" ,nullable=false )
	 private Long setId;


	public ClassPlanEntity() {

	}

	
	/**
	  * 设置下课时间的值
	 * @param 	etime	 下课时间
	**/
	public void setEtime(String  etime){
		 this.etime=etime;
 	}

	/**
	  * 获取下课时间的值
	 * @return 返回下课时间的值
	**/
	public String getEtime(){
		 return etime;
 	}

	/**
	  * 设置上课时间的值
	 * @param 	stime	 上课时间
	**/
	public void setStime(String  stime){
		 this.stime=stime;
 	}

	/**
	  * 获取上课时间的值
	 * @return 返回上课时间的值
	**/
	public String getStime(){
		 return stime;
 	}

	/**
	  * 设置循环规则的值
	 * @param 	ruleVals	 循环规则
	**/
	public void setRuleVals(String  ruleVals){
		 this.ruleVals=ruleVals;
 	}

	/**
	  * 获取循环规则的值
	 * @return 返回循环规则的值
	**/
	public String getRuleVals(){
		 return ruleVals;
 	}

	/**
	  * 设置循环规则名称的值
	 * @param 	ruleNames	 循环规则名称
	**/
	public void setRuleNames(String  ruleNames){
		 this.ruleNames=ruleNames;
 	}

	/**
	  * 获取循环规则名称的值
	 * @return 返回循环规则名称的值
	**/
	public String getRuleNames(){
		 return ruleNames;
 	}

	/**
	  * 设置排班设置ID的值
	 * @param 	setId	 排班设置ID
	**/
	public void setSetId(Long  setId){
		 this.setId=setId;
 	}

	/**
	  * 获取排班设置ID的值
	 * @return 返回排班设置ID的值
	**/
	public Long getSetId(){
		 return setId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{etime,stime,ruleVals,ruleNames,setId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"etime","stime","ruleVals","ruleNames","setId"};
	}

}
