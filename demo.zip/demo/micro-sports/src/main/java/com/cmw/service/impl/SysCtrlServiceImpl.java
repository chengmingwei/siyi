package com.cmw.service.impl;


import com.cmw.constant.GlobalConstant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.AttachmentDaoInter;
import com.cmw.dao.ClassGoDao;
import com.cmw.dao.TempPlanDao;
import com.cmw.entity.AttachmentEntity;
import com.cmw.service.inter.AttachmentService;
import com.cmw.service.inter.SysCtrlService;
import com.cmw.util.StringHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 系统控制面板   Service实现类
 * @author 程明卫
 * @date 2019-11-12 21:20:30
 */
@Description(remark="附件表业务实现类",createDate="2019-04-10 22:18:30",author="程明卫")
@Slf4j
@Service("sysCtrlService")
public class SysCtrlServiceImpl implements SysCtrlService {
	@Autowired
	private AmqpTemplate amqpTemplate;

	@Autowired
	TempPlanDao tempPlanDao;

	@Override
	public void rebulidClassGo(String planIds) {
		if(StringUtils.isEmpty(planIds)){
			List<Map<String,Object>> listPlanIds = tempPlanDao.getNoClassGoPlanIds();
			StringBuilder sbPlanIds = new StringBuilder();
			listPlanIds.forEach(map -> {
				Object id = map.get("id");
				sbPlanIds.append(id).append(",");
			});
			planIds = StringHandler.RemoveStr(sbPlanIds);
		}
		Map<String,Object> msg = new HashMap<>();
		msg.put("planIds", planIds);
		//2.发送消息
		this.amqpTemplate.convertAndSend(GlobalConstant.REBULIDCLASSGO_TASK_EXCHANGE,GlobalConstant.REBULIDCLASSGO_TASK_KEY,msg);
	}

	@Override
	public void synchroUhours2Enroll(Long studentId, Long courseId) {
		Map<String,Object> msg = new HashMap<>();
		if(null != studentId && courseId != null){
			msg.put("studentId", studentId);
			msg.put("courseId", courseId);
		}else{
			if(null != studentId) msg.put("studentId", studentId);
			if(null != courseId) msg.put("courseId", courseId);
			msg.put("makeErrData", 1);
		}

		//2.发送消息
		this.amqpTemplate.convertAndSend(GlobalConstant.SYNCHROUHOURS_TASK_EXCHANGE,GlobalConstant.SYNCHROUHOURS_TASK_KEY,msg);
	}
}
