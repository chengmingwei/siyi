package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.ExchangeGoEntity;


/**
 * 学员转派  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 13:51:12
 */
@Description(remark="学员转派DAO Mapper接口",createDate="2019-04-10 13:51:12",author="程明卫")
@Mapper
public interface ExchangeGoDao extends GenericDaoInter<ExchangeGoEntity, Long>{

}
