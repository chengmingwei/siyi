package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;

import java.util.Date;


/**
 * 交易流水
 * @author 程明卫
 * @date 2019-04-10 14:08:45
 */
@Description(remark="交易流水实体",createDate="2019-04-10 14:08:45",author="程明卫")
@Entity
@Table(name="GL_TransWater")
@SuppressWarnings("serial")
public class TransWaterEntity extends IdEntity {
	
	
	 @Description(remark="备注")
	 @Column(name="remark" ,length=200 )
	 private String remark;

	 @Description(remark="IP")
	 @Column(name="ip" ,length=20 )
	 private String ip;

	 @Description(remark="支付来源")
	 @Column(name="psource" ,nullable=false )
	 private Integer psource = 1;

	 @Description(remark="订单状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus;

	 @Description(remark="支付人")
	 @Column(name="payer" ,nullable=false )
	 private Long payer;

	 @Description(remark="交易日期")
	 @Column(name="transDate" ,nullable=false )
	 private Date transDate;

	 @Description(remark="报名ID")
	 @Column(name="enrollId" ,nullable=false )
	 private Long enrollId;


	public TransWaterEntity() {

	}

	
	/**
	  * 设置备注的值
	 * @param 	remark	 备注
	**/
	public void setRemark(String  remark){
		 this.remark=remark;
 	}

	/**
	  * 获取备注的值
	 * @return 返回备注的值
	**/
	public String getRemark(){
		 return remark;
 	}

	/**
	  * 设置IP的值
	 * @param 	ip	 IP
	**/
	public void setIp(String  ip){
		 this.ip=ip;
 	}

	/**
	  * 获取IP的值
	 * @return 返回IP的值
	**/
	public String getIp(){
		 return ip;
 	}

	/**
	  * 设置支付来源的值
	 * @param 	psource	 支付来源
	**/
	public void setPsource(Integer  psource){
		 this.psource=psource;
 	}

	/**
	  * 获取支付来源的值
	 * @return 返回支付来源的值
	**/
	public Integer getPsource(){
		 return psource;
 	}

	/**
	  * 设置订单状态的值
	 * @param 	xstatus	 订单状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取订单状态的值
	 * @return 返回订单状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置支付人的值
	 * @param 	payer	 支付人
	**/
	public void setPayer(Long  payer){
		 this.payer=payer;
 	}

	/**
	  * 获取支付人的值
	 * @return 返回支付人的值
	**/
	public Long getPayer(){
		 return payer;
 	}

	/**
	  * 设置交易日期的值
	 * @param 	transDate	 交易日期
	**/
	public void setTransDate(Date transDate){
		 this.transDate=transDate;
 	}

	/**
	  * 获取交易日期的值
	 * @return 返回交易日期的值
	**/
	public Date getTransDate(){
		 return transDate;
 	}

	/**
	  * 设置报名ID的值
	 * @param 	enrollId	 报名ID
	**/
	public void setEnrollId(Long  enrollId){
		 this.enrollId=enrollId;
 	}

	/**
	  * 获取报名ID的值
	 * @return 返回报名ID的值
	**/
	public Long getEnrollId(){
		 return enrollId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{remark,ip,psource,xstatus,payer,transDate,enrollId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"remark","ip","psource","xstatus","payer","transDate","enrollId"};
	}

}
