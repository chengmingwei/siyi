package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.PosterEntity;
import org.springframework.stereotype.Component;


/**
 * 学生海报  Mapper接口
 * @author 程明卫
 * @date 2019-07-10 20:19:51
 */
@Description(remark="学生海报DAO Mapper接口",createDate="2019-07-10 20:19:51",author="程明卫")
@Component
@Mapper
public interface PosterDao extends GenericDaoInter<PosterEntity, Long>{
    /**
     * 根据学生ID获取其最新海报ID
     * @param studentId 学生ID
     * @return
     */
    Long getMaxIdByStudentId(Long studentId);
}
