package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 教学计划
 * @author 程明卫
 * @date 2019-04-10 14:01:31
 */
@Description(remark="教学计划实体",createDate="2019-04-10 14:01:31",author="程明卫")
@Entity
@Table(name="GL_CoursePlan")
@SuppressWarnings("serial")
public class CoursePlanEntity extends IdBaseEntity {
	
	
	 @Description(remark="视频")
	 @Column(name="vedioPath" ,length=150 )
	 private String vedioPath;

	 @Description(remark="图片")
	 @Column(name="imgPath" ,length=150 )
	 private String imgPath;

	 @Description(remark="描述")
	 @Column(name="describes" ,length=500 )
	 private String describes;

	 @Description(remark="标题")
	 @Column(name="title" ,nullable=false ,length=100 )
	 private String title;

	 @Description(remark="课程ID")
	 @Column(name="courseId" ,nullable=false )
	 private Long courseId;

	@Description(remark="业务类型")
	@Column(name="formType" ,nullable=false )
	private Integer formType = 0;

	@Description(remark="业务ID")
	@Column(name="formId" ,nullable=false )
	private Long formId = -1L;


	public CoursePlanEntity() {

	}

	public Integer getFormType() {
		return formType;
	}

	public void setFormType(Integer formType) {
		this.formType = formType;
	}

	public Long getFormId() {
		return formId;
	}

	public void setFormId(Long formId) {
		this.formId = formId;
	}

	/**
	  * 设置视频的值
	 * @param 	vedioPath	 视频
	**/
	public void setVedioPath(String  vedioPath){
		 this.vedioPath=vedioPath;
 	}

	/**
	  * 获取视频的值
	 * @return 返回视频的值
	**/
	public String getVedioPath(){
		 return vedioPath;
 	}

	/**
	  * 设置图片的值
	 * @param 	imgPath	 图片
	**/
	public void setImgPath(String  imgPath){
		 this.imgPath=imgPath;
 	}

	/**
	  * 获取图片的值
	 * @return 返回图片的值
	**/
	public String getImgPath(){
		 return imgPath;
 	}

	/**
	  * 设置描述的值
	 * @param 	describes	 描述
	**/
	public void setDescribes(String  describes){
		 this.describes=describes;
 	}

	/**
	  * 获取描述的值
	 * @return 返回描述的值
	**/
	public String getDescribes(){
		 return describes;
 	}

	/**
	  * 设置标题的值
	 * @param 	title	 标题
	**/
	public void setTitle(String  title){
		 this.title=title;
 	}

	/**
	  * 获取标题的值
	 * @return 返回标题的值
	**/
	public String getTitle(){
		 return title;
 	}

	/**
	  * 设置课程ID的值
	 * @param 	courseId	 课程ID
	**/
	public void setCourseId(Long  courseId){
		 this.courseId=courseId;
 	}

	/**
	  * 获取课程ID的值
	 * @return 返回课程ID的值
	**/
	public Long getCourseId(){
		 return courseId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{vedioPath,imgPath,describes,title,courseId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"vedioPath","imgPath","describes","title","courseId"};
	}

}
