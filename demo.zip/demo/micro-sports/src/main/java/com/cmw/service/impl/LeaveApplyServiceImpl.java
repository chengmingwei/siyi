package com.cmw.service.impl;


import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.LeaveApplyDao;
import com.cmw.entity.ClassEntity;
import com.cmw.entity.ClassGoEntity;
import com.cmw.entity.LeaveApplyEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.ClassGoService;
import com.cmw.service.inter.ClassService;
import com.cmw.service.inter.LeaveApplyService;
import com.cmw.util.BeanUtil;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 请假表  Service实现类
 * @author 程明卫
 * @date 2019-04-20 13:26:16
 */
@Description(remark="请假表业务实现类",createDate="2019-04-20 13:26:16",author="程明卫")
@Service("leaveApplyService")
public class LeaveApplyServiceImpl extends AbsService<LeaveApplyEntity, Long> implements  LeaveApplyService {
	@Autowired
	private LeaveApplyDao leaveApplyDao;

	@Autowired
	private ClassGoService classGoService;

	@Autowired
	private ClassService classService;

	@Override
	public GenericDaoInter<LeaveApplyEntity, Long> getDao() {
		return leaveApplyDao;
	}
	
	@Override
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		LeaveApplyEntity entity = null;
		try {
			entity = BeanUtil.copyValue(LeaveApplyEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		if(null == entity.getId()){
			//entity.setStudentId(userInfo.getInempId());
			setAuditTeacher(entity);
			UserUtil.setCreateInfo(userInfo, entity);
			insert(entity);
		}else{
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);
		}

		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}

	private void setAuditTeacher(LeaveApplyEntity entity){
		Long classGoId = entity.getCgoId();
		ClassGoEntity classGoEntity = classGoService.get(classGoId);
		if(null == classGoEntity){
			throw new ServiceException("请假时，必须指定要请的是哪一次的上课!");
		}
		Date goTime = classGoEntity.getGoTime();
		Date downTime = classGoEntity.getDownTime();
		ClassEntity classEntity = classService.get(classGoEntity.getClassId());
		Long master = classEntity.getMaster();
		Long coach = classEntity.getCoach();
		entity.setTeacherId(master);
		entity.setCoach(coach);
		entity.setStartTime(goTime);
		entity.setEndTime(downTime);
	}

	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(LeaveApplyEntity entity) {
		Long cgoId = entity.getCgoId();
		Map<String,Object> pars = new HashMap<>();
		pars.put("cgoId",cgoId);
		LeaveApplyEntity old_entity = getByPars(pars);
		ClassGoEntity classGoEntity = classGoService.get(cgoId);
		Date goTime = classGoEntity.getGoTime();
		Date downTime = classGoEntity.getDownTime();
		Date today = new Date();
		if(null != downTime && today.getTime() >= downTime.getTime()){
			throw new ServiceException("当前已经过了上课时间，不允许请假！");
		}
		if(null != goTime && today.getTime() >= goTime.getTime()){
			throw new ServiceException("当前已经是上课时间，不允许请假！");
		}
		if(null != old_entity){
			throw new ServiceException("当前课次已经有一笔请假申请记录！");
		}
		if(StringUtils.isEmpty(entity.getReason()) && entity.getReason().length() > 200){
			throw new ServiceException("请假原因长度不能超过200!");	}
	}

	@Override
	@Transactional
	public void audit(Map<String, Object> pars) {
		SHashMap pars_SH = new SHashMap(pars);

		Integer cupHours = pars_SH.getvalAsInt("cupHours");

		UserModel userInfo = (UserModel)pars.get(SysContant.USER_INFO);
		LeaveApplyEntity leaveApplyEntity = updateXstatus(pars, userInfo);
		Integer xstatus = leaveApplyEntity.getXstatus();
		if(xstatus.intValue() != LeaveApplyEntity.XSTATUS_1){
			return;
		}
		Long cgoId = leaveApplyEntity.getCgoId();
		if(null == cgoId) return;
		ClassGoEntity classGoEntity = classGoService.get(cgoId);
		if(null == classGoEntity){
			log.error(String.format("找不到ID=%d的请假申请单的上课记录!",leaveApplyEntity.getId()));
			return;
		}
		classGoEntity.setXstatus(BussContant.CLASSGO_XSTATUS_4);

		if(StringHandler.isValidObj(cupHours) && (1 == cupHours || 2 == cupHours)){
			classGoEntity.setCupHours(cupHours);
		}

		UserUtil.setModifyInfo(userInfo, classGoEntity);
		classGoService.update(classGoEntity);

		classGoService.updateUhours(userInfo,classGoEntity);
	}

	private LeaveApplyEntity updateXstatus(Map<String, Object> pars, UserModel userInfo) {
		Integer xstatus = Integer.parseInt(pars.get("xstatus").toString());
		Long id = Long.parseLong(pars.get("id").toString());
		String remark = (String)pars.get("remark");
		LeaveApplyEntity leaveApplyEntity = get(id);

		UserUtil.setModifyInfo(userInfo, leaveApplyEntity);
		leaveApplyEntity.setXstatus(xstatus);
		leaveApplyEntity.setRemark(remark);
		update(leaveApplyEntity);
		return leaveApplyEntity;
	}


	@Override
	public List<Map<String, Object>> getLeaveApplyByPars(Map<String, Object> params) {
		return leaveApplyDao.getLeaveApplyByPars(params);
	}
}
