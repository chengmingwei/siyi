package com.cmw.controller.web;

import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.entity.CommentTagEntity;
import com.cmw.service.inter.CommentTagService;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Description(remark = "评论标签Controller", createDate = "2019-08-13 17:12:13", author = "肖家添")
@Api(value = "评论标签微服务", description = "#CONTROLLER# 2019-08-13 17:12:13 肖家添")
@RestController
@RequestMapping("/commentTag")
public class CommentTagController {

    @Resource
    private CommentTagService commentTagService;
    
    /**
     * 用户的评论标签
     * @Author 肖家添
     * @Date 2019/8/13 17:14
     */
    @ApiOperation("获取用户的评论标签API")
    @PostMapping("/getCommentTagForUser")
    public JSONObject getCommentTagForUser(
            @RequestParam(required = false) Integer dataCount,
            @RequestParam(required = false) Object randOrderBy
    ){
        Map<String, Object> params = new HashMap<>();

        params.put("dataCount", dataCount);
        params.put("randOrderBy", randOrderBy);

        List<CommentTagEntity> commentTagEntityList = commentTagService.getCommentTagForUser(params);

        return PageHandler.getJson(commentTagEntityList);
    }
    
    /**
     * 新增/编辑 标签API
     * @Author 肖家添
     * @Date 2019/8/14 12:29
     */
    @ApiOperation("新增/编辑 标签API")
    @PostMapping("/handlerData")
    public JSONObject handlerData(@RequestParam Map<String, Object> params){
        commentTagService.doComplexBusss(params);

        return PageHandler.getSuccessJson();

    }

    /**
     * 上架/下架/删除
     * @Author 肖家添
     * @Date 2019/8/14 11:25
     */
    @ApiOperation("上架/下架/删除")
    @PostMapping("/isEnabled")
    public JSONObject isEnabled(HttpServletRequest request){
        String[] ids = request.getParameterValues("id");
        String isEnabled = request.getParameter("isenabled");

        if(StringHandler.isValidObj(ids) && StringHandler.isValidStr(isEnabled)){
            String beachParam = "";
            for (String id : ids) {
                beachParam += id + ",";
            }

            if(beachParam.length() > 0){
                beachParam = beachParam.substring(0, beachParam.length() - 1);
            }

            commentTagService.enabledByIds(beachParam, Integer.parseInt(isEnabled));

            return PageHandler.getSuccessJson();
        }else{
            return PageHandler.getFailureJson("缺少参数");
        }
    }
}
