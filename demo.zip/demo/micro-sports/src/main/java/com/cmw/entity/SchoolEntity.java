package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 学校信息
 * @author 程明卫
 * @date 2019-04-10 13:57:41
 */
@Description(remark="学校信息实体",createDate="2019-04-10 13:57:41",author="程明卫")
@Entity
@Table(name="GL_School")
@SuppressWarnings("serial")
public class SchoolEntity extends IdBaseEntity {
	
	
	 @Description(remark="校区图片附件ID")
	 @Column(name="attachId" )
	 private Long attachId;

	 @Description(remark="学校介绍")
	 @Column(name="intro" ,length=500 )
	 private String intro;

	 @Description(remark="联系电话")
	 @Column(name="tel" ,length=20 )
	 private String tel;

	 @Description(remark="联系人")
	 @Column(name="contacts" ,length=20 )
	 private String contacts;

	 @Description(remark="坐标")
	 @Column(name="coordinate" ,length=20 )
	 private String coordinate;

	 @Description(remark="校区图片")
	 @Column(name="imgPath" ,length=150 )
	 private String imgPath;

	 @Description(remark="详细地址")
	 @Column(name="address" ,length=150 )
	 private String address;

	 @Description(remark="区")
	 @Column(name="areaId" )
	 private Long areaId;

	 @Description(remark="市")
	 @Column(name="cityId" )
	 private Long cityId;

	 @Description(remark="省")
	 @Column(name="provinceId" )
	 private Long provinceId;

	 @Description(remark="名称")
	 @Column(name="sname" ,nullable=false ,length=100 )
	 private String sname;

	 @Description(remark="校区编号")
	 @Column(name="code" ,nullable=false ,length=30 )
	 private String code;


	public SchoolEntity() {

	}

	
	/**
	  * 设置校区图片附件ID的值
	 * @param 	attachId	 校区图片附件ID
	**/
	public void setAttachId(Long  attachId){
		 this.attachId=attachId;
 	}

	/**
	  * 获取校区图片附件ID的值
	 * @return 返回校区图片附件ID的值
	**/
	public Long getAttachId(){
		 return attachId;
 	}

	/**
	  * 设置学校介绍的值
	 * @param 	intro	 学校介绍
	**/
	public void setIntro(String  intro){
		 this.intro=intro;
 	}

	/**
	  * 获取学校介绍的值
	 * @return 返回学校介绍的值
	**/
	public String getIntro(){
		 return intro;
 	}

	/**
	  * 设置联系电话的值
	 * @param 	tel	 联系电话
	**/
	public void setTel(String  tel){
		 this.tel=tel;
 	}

	/**
	  * 获取联系电话的值
	 * @return 返回联系电话的值
	**/
	public String getTel(){
		 return tel;
 	}

	/**
	  * 设置联系人的值
	 * @param 	contacts	 联系人
	**/
	public void setContacts(String  contacts){
		 this.contacts=contacts;
 	}

	/**
	  * 获取联系人的值
	 * @return 返回联系人的值
	**/
	public String getContacts(){
		 return contacts;
 	}

	/**
	  * 设置坐标的值
	 * @param 	coordinate	 坐标
	**/
	public void setCoordinate(String  coordinate){
		 this.coordinate=coordinate;
 	}

	/**
	  * 获取坐标的值
	 * @return 返回坐标的值
	**/
	public String getCoordinate(){
		 return coordinate;
 	}

	/**
	  * 设置校区图片的值
	 * @param 	imgPath	 校区图片
	**/
	public void setImgPath(String  imgPath){
		 this.imgPath=imgPath;
 	}

	/**
	  * 获取校区图片的值
	 * @return 返回校区图片的值
	**/
	public String getImgPath(){
		 return imgPath;
 	}

	/**
	  * 设置详细地址的值
	 * @param 	address	 详细地址
	**/
	public void setAddress(String  address){
		 this.address=address;
 	}

	/**
	  * 获取详细地址的值
	 * @return 返回详细地址的值
	**/
	public String getAddress(){
		 return address;
 	}

	/**
	  * 设置区的值
	 * @param 	areaId	 区
	**/
	public void setAreaId(Long  areaId){
		 this.areaId=areaId;
 	}

	/**
	  * 获取区的值
	 * @return 返回区的值
	**/
	public Long getAreaId(){
		 return areaId;
 	}

	/**
	  * 设置市的值
	 * @param 	cityId	 市
	**/
	public void setCityId(Long  cityId){
		 this.cityId=cityId;
 	}

	/**
	  * 获取市的值
	 * @return 返回市的值
	**/
	public Long getCityId(){
		 return cityId;
 	}

	/**
	  * 设置省的值
	 * @param 	provinceId	 省
	**/
	public void setProvinceId(Long  provinceId){
		 this.provinceId=provinceId;
 	}

	/**
	  * 获取省的值
	 * @return 返回省的值
	**/
	public Long getProvinceId(){
		 return provinceId;
 	}

	/**
	  * 设置名称的值
	 * @param 	sname	 名称
	**/
	public void setSname(String  sname){
		 this.sname=sname;
 	}

	/**
	  * 获取名称的值
	 * @return 返回名称的值
	**/
	public String getSname(){
		 return sname;
 	}

	/**
	  * 设置校区编号的值
	 * @param 	code	 校区编号
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取校区编号的值
	 * @return 返回校区编号的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{attachId,intro,tel,contacts,coordinate,imgPath,address,areaId,cityId,provinceId,sname,code};
	}

	@Override
	public String[] getFields() {
		return new String[]{"attachId","intro","tel","contacts","coordinate","imgPath","address","areaId","cityId","provinceId","sname","code"};
	}

}
