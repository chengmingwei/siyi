package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.EnrollEntity;


/**
 * 学生报名  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 14:07:54
 */
@Description(remark="学生报名DAO Mapper接口",createDate="2019-04-10 14:07:54",author="程明卫")
@Mapper
public interface EnrollDao extends GenericDaoInter<EnrollEntity, Long>{

    /**
     * 获取课程报名记录
     * @Author 肖家添
     * @Date 2019/7/11 21:31
     */
    List<Map<String, Object>> getEnrollByParams(Map<String, Object> params);

    /**
     * 统计没有用完课时订单数量
     * @Author 肖家添
     * @Date 2019/7/12 18:33
     */
    Integer findNoFinishEnrollCount(Long studentId);

}
