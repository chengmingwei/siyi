package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.OrderEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * 订单表  Service接口
 * @author 程明卫
 * @date 2019-05-07 21:22:03
 */
@Description(remark="订单表业务接口",createDate="2019-05-07 21:22:03",author="程明卫")
public interface OrderService extends IService<OrderEntity, Long> {

    /**
     * 获取订单列表
     * @Author 肖家添
     * @Date 2019/6/13 17:46
     */
    List<Map<String, Object>> getOrderList(Map<String, Object> params);

    /**
     * 获取订单课程
     * @Author 肖家添
     * @Date 2019/6/14 15:44
     */
    List<Map<String, Object>> getOrderCourse(Long orderId);

    /**
     * 数据导出
     * @Author 肖家添
     * @Date 2019/9/9 11:27
     */
    void exportData(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM);

    /**
     * 获取订单列表 -> 根据课程Id和学生Id分组
     * @Author 肖家添
     * @Date 2019/9/9 11:22
     */
    List<Map<String, Object>> getOrderListGroupByCourseAndStu(Map<String, Object> params);
    
    /**
     * 订单报表_数据导出
     * @Author 肖家添
     * @Date 2019/9/19 9:53
     */
    void getOrderListGroupByCourseAndStu_exportData(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM);

}
