package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.util.BeanUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cmw.entity.SchoolEntity;
import com.cmw.service.inter.SchoolService;


/**
 * 学校信息  ACTION类
 *
 * @author 程明卫
 * @date 2019-04-10 13:57:41
 */
@Description(remark = "学校信息ACTION", createDate = "2019-04-10 13:57:41", author = "程明卫")
@Api(value = "学校信息微服务", description = "#CONTROLLER# 2019-04-10 13:57:41 程明卫")
@RestController
@RequestMapping({"/school"})
public class SchoolController {
    @Resource(name = "schoolService")
    private SchoolService schoolService;


    /**
     * 跳转列表页面
     *
     * @param sname 学校名称
     * @return
     */
    @ApiOperation("学校信息列表API")
    @PostMapping(value = "/list")
    public JSONObject list(@RequestParam(value = "sname", required = false) String sname) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("sname", sname);
        PageResult<List<Map<String,Object>>> pageResult = schoolService.getPageByPars(params,null,null);
        List list = pageResult.getList();
        return PageHandler.getJson(list);
    }

    /**
     * 跳转详细页面
     *
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取学校信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("学校信息ID") @PathVariable("id") Long id) {
        if (!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        SchoolEntity obj = schoolService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * 保存数据
     *
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存学校信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestBody Map<String, Object> params) throws Exception {
        Map<String, Object> dataResult = (Map<String, Object>) schoolService.doComplexBusss(new SHashMap(params));
        return PageHandler.getJson(dataResult);
    }

    /**
     * 分布式事务测试
     *
     * @param params 分布式事务测试
     * @return
     */
    @ApiOperation("分布式事务测试")
    @PostMapping(value = "/trans")
    public JSONObject trans(@RequestParam Map<String, Object> params) throws Exception {
        schoolService.test_trans(new SHashMap<String,Object>(params));
        return PageHandler.getSuccessJson();
    }

    /**
     * 分布式事务测试
     *
     * @param params 分布式事务测试
     * @return
     */
    @ApiOperation("分布式事务测试")
    @PostMapping(value = "/feign/trans")
    public JSONObject feign_trans(@RequestParam Map<String, Object> params) throws Exception {
        schoolService.test_trans2(new SHashMap<String,Object>(params));
        return PageHandler.getSuccessJson();
    }

    /**
     * 移除数据
     *
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除学校信息")
    @DeleteMapping(value = "/{id}")
    public JSONObject delete(@ApiParam("学校ID") @PathVariable("id") Long id) throws Exception {
        schoolService.enabled(id, -1);
        return PageHandler.getSuccessJson();
    }

    /**
     * 获取学校下拉框
     * @Author 肖家添
     * @Date 2019/7/15 16:51
     */
    @ApiOperation("获取学校下拉框")
    @PostMapping("/getSchoolSelect")
    public JSONObject getSchoolSelect(@RequestParam Map<String, Object> params){
        return PageHandler.getJson(schoolService.getSchoolBySelect(params));
    }

}
