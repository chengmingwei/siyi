package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 成长档案表
 * @author 程明卫
 * @date 2019-04-20 13:52:04
 */
@Description(remark="成长档案表实体",createDate="2019-04-20 13:52:04",author="程明卫")
@Entity
@Table(name="GL_GrowUp")
@SuppressWarnings("serial")
public class GrowUpEntity extends IdBaseEntity {
	
	
	 @Description(remark="创建人类型")
	 @Column(name="creatorType" ,nullable=false )
	 private Byte creatorType = 1;

	 @Description(remark="视频")
	 @Column(name="vedioPath" ,length=150 )
	 private String vedioPath;

	 @Description(remark="图片")
	 @Column(name="imgPath" ,length=150 )
	 private String imgPath;

	 @Description(remark="描述")
	 @Column(name="describes" ,length=500 )
	 private String describes;

	 @Description(remark="学生ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;

	@Description(remark="上课记录ID")
	@Column(name="ccId" ,nullable=false )
	private Long ccId;

	public GrowUpEntity() {

	}

	public Long getCcId() {
		return ccId;
	}

	public void setCcId(Long ccId) {
		this.ccId = ccId;
	}

	/**
	  * 设置创建人类型的值
	 * @param 	creatorType	 创建人类型
	**/
	public void setCreatorType(Byte  creatorType){
		 this.creatorType=creatorType;
 	}

	/**
	  * 获取创建人类型的值
	 * @return 返回创建人类型的值
	**/
	public Byte getCreatorType(){
		 return creatorType;
 	}

	/**
	  * 设置视频的值
	 * @param 	vedioPath	 视频
	**/
	public void setVedioPath(String  vedioPath){
		 this.vedioPath=vedioPath;
 	}

	/**
	  * 获取视频的值
	 * @return 返回视频的值
	**/
	public String getVedioPath(){
		 return vedioPath;
 	}

	/**
	  * 设置图片的值
	 * @param 	imgPath	 图片
	**/
	public void setImgPath(String  imgPath){
		 this.imgPath=imgPath;
 	}

	/**
	  * 获取图片的值
	 * @return 返回图片的值
	**/
	public String getImgPath(){
		 return imgPath;
 	}

	/**
	  * 设置描述的值
	 * @param 	describes	 描述
	**/
	public void setDescribes(String  describes){
		 this.describes=describes;
 	}

	/**
	  * 获取描述的值
	 * @return 返回描述的值
	**/
	public String getDescribes(){
		 return describes;
 	}

	/**
	  * 设置学生ID的值
	 * @param 	studentId	 学生ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取学生ID的值
	 * @return 返回学生ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{creatorType,vedioPath,imgPath,describes,studentId,ccId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"creatorType","vedioPath","imgPath","describes","studentId","ccId"};
	}

}
