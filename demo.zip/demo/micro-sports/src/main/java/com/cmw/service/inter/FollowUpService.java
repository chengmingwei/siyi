package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.FollowUpEntity;


/**
 * 学员跟进记录  Service接口
 * @author 程明卫
 * @date 2019-04-10 13:41:05
 */
@Description(remark="学员跟进记录业务接口",createDate="2019-04-10 13:41:05",author="程明卫")
public interface FollowUpService extends IService<FollowUpEntity, Long> {
}
