package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.SchoolEntity;
import org.springframework.stereotype.Component;


/**
 * 学校信息  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 13:57:41
 */
@Description(remark="学校信息DAO Mapper接口",createDate="2019-04-10 13:57:41",author="程明卫")
@Component
@Mapper
public interface SchoolDao extends GenericDaoInter<SchoolEntity, Long>{
    
    /**
     * 获取Ant Design
     * @Author 肖家添
     * @Date 2019/7/15 16:36
     */
    List<Map<String, Object>> getSchoolBySelect(Map<String, Object> params);

}
