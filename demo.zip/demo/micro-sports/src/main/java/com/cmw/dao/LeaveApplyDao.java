package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.LeaveApplyEntity;
import org.springframework.stereotype.Component;


/**
 * 请假表  Mapper接口
 * @author 程明卫
 * @date 2019-04-20 13:26:16
 */
@Description(remark="请假表DAO Mapper接口",createDate="2019-04-20 13:26:16",author="程明卫")
@Component
@Mapper
public interface LeaveApplyDao extends GenericDaoInter<LeaveApplyEntity, Long>{
    
    /**
     * 获取请假记录
     * @Author 肖家添
     * @Date 2019/7/17 16:00
     */
    List<Map<String, Object>> getLeaveApplyByPars(Map<String, Object> params);

}
