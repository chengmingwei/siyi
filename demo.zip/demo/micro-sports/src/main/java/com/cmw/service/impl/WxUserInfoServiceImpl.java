package com.cmw.service.impl;


import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.WxUserInfoDao;
import com.cmw.entity.WxUserInfoEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.WxUserInfoService;
import com.cmw.util.BeanUtil;
import com.cmw.util.SHashMap;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * 公众号用户信息  Service实现类
 * @author 程明卫
 * @date 2019-08-24 17:10:59
 */
@Description(remark="公众号用户信息业务实现类",createDate="2019-08-24 17:10:59",author="程明卫")
@Service("wxUserInfoService")
public class WxUserInfoServiceImpl extends AbsService<WxUserInfoEntity, Long> implements  WxUserInfoService {
	@Autowired
	private WxUserInfoDao wxUserInfoDao;
	@Override
	public GenericDaoInter<WxUserInfoEntity, Long> getDao() {
		return wxUserInfoDao;
	}
	
	@Override
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		WxUserInfoEntity entity = null;
		try {
			entity = BeanUtil.copyValue(WxUserInfoEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}

		validInfo(entity);
		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		if(null == entity.getId()){
			
			entity.setCreateTime(new Date());
			insert(entity);
		}else{
			entity.setModifyTime(new Date());
			update(entity);
		}

		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		return dataResult;
	}



	/**
	 * 验证字段信息
	 * @param entity
	 */
	private void validInfo(WxUserInfoEntity entity) {
		
			if(StringUtils.isEmpty(entity.getRemark()) && entity.getRemark().length() > 200){
			throw new ServiceException("备注长度不能超过200!");
			}


		if(null == entity.getCreateTime()){
			throw new ServiceException("创建时间不能为空!");
		}


			if(StringUtils.isEmpty(entity.getHeadimgurl()) && entity.getHeadimgurl().length() > 200){
			throw new ServiceException("用户头像长度不能超过200!");
			}

		if(null == entity.getSex()){
			throw new ServiceException("性别不能为空!");
		}


			if(StringUtils.isEmpty(entity.getNickname()) && entity.getNickname().length() > 75){
			throw new ServiceException("用户的昵称长度不能超过75!");
			}


			if(StringUtils.isEmpty(entity.getUnionid()) && entity.getUnionid().length() > 100){
			throw new ServiceException("通用ID长度不能超过100!");
			}

		if(StringUtils.isEmpty(entity.getOpenid())){
			throw new ServiceException("公众号openid不能为空!");
		}

			if(StringUtils.isEmpty(entity.getOpenid()) && entity.getOpenid().length() > 100){
			throw new ServiceException("公众号openid长度不能超过100!");
			}

		if(StringUtils.isEmpty(entity.getSubscribe())){
			throw new ServiceException("是否订阅该公众号不能为空!");
		}

			if(StringUtils.isEmpty(entity.getSubscribe()) && entity.getSubscribe().length() > 50){
			throw new ServiceException("是否订阅该公众号长度不能超过50!");
			}

		if(null == entity.getMemberId()){
			throw new ServiceException("会员ID不能为空!");
		}


	}
}
