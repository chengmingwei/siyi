package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 选/转班表
 * @author 程明卫
 * @date 2019-04-20 12:06:21
 */
@Description(remark="选/转班表实体",createDate="2019-04-20 12:06:21",author="程明卫")
@Entity
@Table(name="GL_ClassChoose")
@SuppressWarnings("serial")
public class ClassChooseEntity extends IdBaseEntity {
	
	
	 @Description(remark="状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="原班级ID")
	 @Column(name="oldClassId" )
	 private Long oldClassId;

	 @Description(remark="班级ID")
	 @Column(name="classId" ,nullable=false )
	 private Long classId;

	 @Description(remark="学员ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;

	public ClassChooseEntity() {

	}

	
	/**
	  * 设置状态的值
	 * @param 	xstatus	 状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取状态的值
	 * @return 返回状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置原班级ID的值
	 * @param 	oldClassId	 原班级ID
	**/
	public void setOldClassId(Long  oldClassId){
		 this.oldClassId=oldClassId;
 	}

	/**
	  * 获取原班级ID的值
	 * @return 返回原班级ID的值
	**/
	public Long getOldClassId(){
		 return oldClassId;
 	}

	/**
	  * 设置班级ID的值
	 * @param 	classId	 班级ID
	**/
	public void setClassId(Long  classId){
		 this.classId=classId;
 	}

	/**
	  * 获取班级ID的值
	 * @return 返回班级ID的值
	**/
	public Long getClassId(){
		 return classId;
 	}

	/**
	  * 设置学员ID的值
	 * @param 	studentId	 学员ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取学员ID的值
	 * @return 返回学员ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{xstatus,oldClassId,classId,studentId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"xstatus","oldClassId","classId","studentId"};
	}

}
