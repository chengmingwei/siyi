package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.StudentEntity;
import com.cmw.util.SHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * 学员信息  Service接口
 * @author 程明卫
 * @date 2019-04-10 11:33:10
 */
@Description(remark="学员信息业务接口",createDate="2019-04-10 11:33:10",author="程明卫")
public interface StudentService extends IService<StudentEntity, Long> {

    /**
     * 更新学生数据没有生成 PTP_Member的记录。（）
     * @return
     */
    Integer updateErrData();

    List<Map<String, Object>> getListMapByClassId(Map<String, Object> params);

    /**
     * 导入Excel保存学生
     * @param params
     * @return
     */
    Map<String, Object> saveStudentByImport(SHashMap<String, Object> params);

    /**
     * 导出数据
     * @Author 肖家添
     * @Date 2019/6/26 19:04
     */
    void exportData(HttpServletRequest request, HttpServletResponse response, List<Map<String, Object>> dataList_LM);

    StudentEntity getBySource(SHashMap<String, Object> pars);
}
