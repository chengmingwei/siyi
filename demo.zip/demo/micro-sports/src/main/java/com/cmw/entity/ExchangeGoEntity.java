package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 学员转派
 * @author 程明卫
 * @date 2019-04-10 13:51:12
 */
@Description(remark="学员转派实体",createDate="2019-04-10 13:51:12",author="程明卫")
@Entity
@Table(name="GL_ExchangeGo")
@SuppressWarnings("serial")
public class ExchangeGoEntity extends IdBaseEntity {
	
	
	 @Description(remark="接收人ID")
	 @Column(name="receiverId" )
	 private Long receiverId;

	 @Description(remark="学员ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;

	 @Description(remark="批次编号")
	 @Column(name="bachCode" ,nullable=false )
	 private String bachCode;


	public ExchangeGoEntity() {

	}

	
	/**
	  * 设置接收人ID的值
	 * @param 	receiverId	 接收人ID
	**/
	public void setReceiverId(Long  receiverId){
		 this.receiverId=receiverId;
 	}

	/**
	  * 获取接收人ID的值
	 * @return 返回接收人ID的值
	**/
	public Long getReceiverId(){
		 return receiverId;
 	}

	/**
	  * 设置学员ID的值
	 * @param 	studentId	 学员ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取学员ID的值
	 * @return 返回学员ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}

	/**
	  * 设置批次编号的值
	 * @param 	bachCode	 批次编号
	**/
	public void setBachCode(String  bachCode){
		 this.bachCode=bachCode;
 	}

	/**
	  * 获取批次编号的值
	 * @return 返回批次编号的值
	**/
	public String getBachCode(){
		 return bachCode;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{receiverId,studentId,bachCode};
	}

	@Override
	public String[] getFields() {
		return new String[]{"receiverId","studentId","bachCode"};
	}

}
