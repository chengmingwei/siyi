package com.cmw.dao;


import com.cmw.annotation.HoursAnnotation;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.StudentEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * 数据报表  Mapper接口
 * @author 程明卫
 * @date 2019-10-16 18:12:58
 */
@Description(remark="数据报表DAO Mapper接口",createDate="2019-10-16 18:12:58",author="程明卫")
@Component
@Mapper
public interface DataReportDaoInter extends GenericDaoInter<StudentEntity, Long>{
    /**
     * 学生详细信息报表
     * @param params
     * @return
     */
    List<Map<String,Object>> getStudentDetailReport(Map<String,Object> params);

    /**
     * 学员剩余课时报表
     * @param params
     * @return
     */
    List<Map<String,Object>> getSurplusHoursReport(Map<String,Object> params);

    /**
     * 学员上课统计报表
     * @param params
     * @return
     */
    List<Map<String,Object>> getGoClassReport(Map<String,Object> params);

    /**
     * 学员上课课时（按课时）报表
     * @param params
     * @return
     */
    List<Map<String,Object>> getGoClassHoursReport(Map<String,Object> params);

    /**
     * 老师上课统计报表
     * @param params
     * @return
     */
    List<Map<String,Object>> getGoClassByTeacherReport(Map<String,Object> params);
}
