package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.TempPlanEntity;

import java.util.List;
import java.util.Map;


/**
 * 课次排班表  Service接口
 * @author 程明卫
 * @date 2019-04-20 18:25:05
 */
@Description(remark="课次排班表业务接口",createDate="2019-04-20 18:25:05",author="程明卫")
public interface TempPlanService extends IService<TempPlanEntity, Long> {

    /**
     * 获取要删除的已生成的排课课次
     * @param pars
     * @return
     */
    String getDellIds(Map<String, Object> pars);

    List<Map<String, Object>> getListMapByClassId(Long classId);

    Long getFinshCount(Map<String, Object> pars);

    /**
     * 获取课次详情
     * @Author 肖家添
     * @Date 2019/5/17 10:56
     */
    List<Map<String, Object>> getTempPlanDetail(Long tempPlanId);

    List<Map<String, Object>> getListMapByTeacherId(Map<String, Object> params);

    /**
     * 获取课程表中的课程
     * @Author 肖家添
     * @Date 2019/6/4 18:20
     */
    List<Map<String, Object>> getTempPlanByClassScheduleCard(Map<String, Object> params);
}
