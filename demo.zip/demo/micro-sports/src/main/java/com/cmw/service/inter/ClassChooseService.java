package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.ClassChooseEntity;
import com.cmw.util.SHashMap;

import java.util.List;
import java.util.Map;


/**
 * 选/转班表  Service接口
 * @author 程明卫
 * @date 2019-04-20 12:06:21
 */
@Description(remark="选/转班表业务接口",createDate="2019-04-20 12:06:21",author="程明卫")
public interface ClassChooseService extends IService<ClassChooseEntity, Long> {
    List<Map<String, Object>> getStudents(Map<String, Object> pars);

    /**
     * 导入学生数据保存选班数据
     * @param params
     * @return
     */
    Map<String,Object> saveClassChooseByImport(SHashMap<String, Object> params);
}
