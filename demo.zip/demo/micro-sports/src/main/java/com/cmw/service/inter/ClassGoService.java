package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.ClassGoEntity;
import com.cmw.model.back.UserModel;

import java.util.List;
import java.util.Map;


/**
 * 上课记录表  Service接口
 * @author 程明卫
 * @date 2019-04-20 13:08:06
 */
@Description(remark="上课记录表业务接口",createDate="2019-04-20 13:08:06",author="程明卫")
public interface ClassGoService extends IService<ClassGoEntity, Long> {
    /**
     *
     * update time: 2019-11-10, Mr.Cmw
     *
     * 更新已消耗课时
     * @param userModel
     * @param classGoEntity
     */
     void updateUhours(UserModel userModel, ClassGoEntity classGoEntity);
    /**
     * 教练端（上课记录）根据班级ID找上课记录
     * @param classId   班级ID
     * @return
     */
    List<Map<String,Object>> getListByClassId(Long classId);

    Integer getFinishCount(Map<String, Object> pars);

    List<Map<String, Object>> getListByPlanId(Long planId);


    /**
     * 获取已消耗的上课数
     * @param pars
     * @return
     */
    Integer getDoCount(Map<String, Object> pars);

    List<Map<String, Object>> getListByXstatus(Map<String, Object> pars);

    List<Map<String, Object>> getLeavesByPlanId(Map<String, Object> pars);

    /**
     * 获取上课记录
     * @Author 肖家添
     * @Date 2019/7/17 11:43
     */
    List<Map<String, Object>> getClassGoByParams(Map<String, Object> params);

    /**
     * 家长端 ==> 学生课程
     * @Author 肖家添
     * @Date 2019/7/18 17:54
     */
    List<Map<String, Object>> getClassGoByStudent(Map<String, Object> params);

    /**
     * 重置时间
     * @Author 肖家添
     * @Date 2019/7/19 10:04
     */
    void resetTimeToTempPlan();

    /**
     * 学生点名前的检查
     * @param rollType
     * @param classGoIds
     * @param  cupHours
     * @Author cmw
     * @Date 2020/03/14 21:59
     * @return
     */
    Map<String, Object> checkRoll(Integer rollType, String classGoIds,Integer  cupHours);
}
