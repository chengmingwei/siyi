package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.entity.CoursePlanEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.CoursePlanService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;


/**
 * 教学计划  ACTION类
 * @author 程明卫
 * @date 2019-04-10 14:01:31
 */
@Description(remark="教学计划ACTION",createDate="2019-04-10 14:01:31",author="程明卫")
@Api(value = "教学计划微服务", description = "#CONTROLLER# 2019-04-10 14:01:31 程明卫")
@RestController
@RequestMapping({"/courseplan"})
public class CoursePlanController {
	@Resource(name="coursePlanService")
	private CoursePlanService coursePlanService;

    /**
     * 根据课程ID获取课程计划信息
     * @param courseId 课程ID
     * @return
     */
    @ApiOperation("根据ID获取教学计划信息")
    @PostMapping(value = "/{courseId}")
    public JSONObject get(@ApiParam("课程ID") @PathVariable("courseId") Long courseId){
        if(!StringHandler.isValidObj(courseId)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        Map<String, Object> pars = new HashMap<>();
        pars.put("courseId", courseId);
        CoursePlanEntity obj = coursePlanService.getByPars(pars);
        JSONObject jsonObject = PageHandler.getJson(obj);
        return   jsonObject;
    }

    /**
     * 根据课程ID获取课程计划信息
     * @param formType 业务类型
     * @param formId 业务ID
     * @return
     */
    @ApiOperation("根据业务类型和业务ID获取教学计划信息")
    @PostMapping(value = "/{formType}/{formId}")
    public JSONObject getByFormType(@ApiParam("业务类型") @PathVariable("formType") Long formType,
                                    @ApiParam("业务ID") @PathVariable("formId") Long formId){
        Map<String, Object> pars = new HashMap<>();
        pars.put("formType", formType);
        pars.put("formId", formId);
        CoursePlanEntity obj = coursePlanService.getByPars(pars);
        JSONObject jsonObject = PageHandler.getJson(obj);
        return   jsonObject;
    }

    //classSetId
    /**
     * 根据课程ID获取课程计划信息
     * @param id 教学计划ID
     * @return
     */
    @ApiOperation("根据ID获取教学计划信息")
    @PostMapping(value = "/id/{id}")
    public JSONObject getById(@ApiParam("教学计划ID") @PathVariable("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        CoursePlanEntity obj = coursePlanService.get(id);
        JSONObject jsonObject = PageHandler.getJson(obj);
        return   jsonObject;
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存教学计划信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params){
        try{
            UserModel userInfo = LoginInterceptor.getLoginUser();
            SHashMap<String,Object> pars = new SHashMap(params);
            pars.put(SysContant.USER_INFO, userInfo);
            Map<String, Object> dataResult = (Map<String, Object>)coursePlanService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody  Map<String,String> param){
        String formTypeStr = param.get("formType");
        if(StringUtils.isEmpty(formTypeStr)){//如果没有传入 formType 参数，则默认为课程新增时保存的课程计划数据
            param.put("formType", "0");
        }
        return save(param);
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除课程信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("课程ID") @PathVariable("id")  Long id) throws Exception{
        coursePlanService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }
}
