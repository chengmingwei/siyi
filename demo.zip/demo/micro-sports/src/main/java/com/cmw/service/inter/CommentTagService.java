package com.cmw.service.inter;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.CommentTagEntity;

import java.util.List;
import java.util.Map;

/**
 * 评论标签业务接口
 * @Author 肖家添
 * @Date 2019/8/13 17:07
 */
@Description(remark="评论标签业务接口",createDate="2019-08-13 17:07",author="肖家添")
public interface CommentTagService extends IService<CommentTagEntity, Long> {

    /**
     * 用户的评论标签
     * @Author 肖家添
     * @Date 2019/8/13 17:16
     */
    List<CommentTagEntity> getCommentTagForUser(Map<String, Object> params);

}