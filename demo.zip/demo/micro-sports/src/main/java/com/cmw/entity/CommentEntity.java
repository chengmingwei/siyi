package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 评论表
 * @author 程明卫
 * @date 2019-04-20 13:35:01
 */
@Description(remark="评论表实体",createDate="2019-04-20 13:35:01",author="程明卫")
@Entity
@Table(name="GL_Comment")
@SuppressWarnings("serial")
public class CommentEntity extends IdEntity {
	/**
	 * 1:学生对老师评价
	 */
	public static final int CTYPE_1 = 1;
	/**
	 * 2:老师对学生评价
	 */
	public static final int CTYPE_2 = 2;

	@Description(remark="被评论对象")
	@Column(name="toMan",length=100 )
	private String toMan;

	@Description(remark="被评论对象ID")
	@Column(name="toManId")
	private Long toManId;

	 @Description(remark="可用标识")
	 @Column(name="isenabled" ,nullable=false )
	 private Byte isenabled = 1;

	 @Description(remark="评论时间")
	 @Column(name="createTime" ,nullable=false )
	 private Date  createTime;

	 @Description(remark="内容")
	 @Column(name="content" ,nullable=false ,length=250 )
	 private String content;

	 @Description(remark="得分")
	 @Column(name="stars" ,nullable=false )
	 private Integer stars = 0;

	@Description(remark="课次ID")
	@Column(name="classGoId")
	private Long classGoId;

	 @Description(remark="评论人")
	 @Column(name="cperson" ,nullable=false )
	 private Long cperson;

	 @Description(remark=" 评论人类型")
	 @Column(name="ctype" ,nullable=false )
	 private Integer ctype;


	public CommentEntity() {

	}

	public Long getToManId() {
		return toManId;
	}

	public void setToManId(Long toManId) {
		this.toManId = toManId;
	}

	public String getToMan() {
		return toMan;
	}

	public void setToMan(String toMan) {
		this.toMan = toMan;
	}

	public Long getClassGoId() {
		return classGoId;
	}

	public void setClassGoId(Long classGoId) {
		this.classGoId = classGoId;
	}

	/**
	  * 设置可用标识的值
	 * @param 	isenabled	 可用标识
	**/
	public void setIsenabled(Byte  isenabled){
		 this.isenabled=isenabled;
 	}

	/**
	  * 获取可用标识的值
	 * @return 返回可用标识的值
	**/
	public Byte getIsenabled(){
		 return isenabled;
 	}

	/**
	  * 设置评论时间的值
	 * @param 	 createTime	 评论时间
	**/
	public void setCreateTime(Date   createTime){
		 this.createTime= createTime;
 	}

	/**
	  * 获取评论时间的值
	 * @return 返回评论时间的值
	**/
	public Date getCreateTime(){
		 return  createTime;
 	}

	/**
	  * 设置内容的值
	 * @param 	 content	 内容
	**/
	public void setContent(String   content){
		 this.content= content;
 	}

	/**
	  * 获取内容的值
	 * @return 返回内容的值
	**/
	public String getContent(){
		 return  content;
 	}

	/**
	  * 设置得分的值
	 * @param 	stars	 得分
	**/
	public void setStars(Integer  stars){
		 this.stars=stars;
 	}

	/**
	  * 获取得分的值
	 * @return 返回得分的值
	**/
	public Integer getStars(){
		 return stars;
 	}

	/**
	  * 设置评论人的值
	 * @param 	cperson	 评论人
	**/
	public void setCperson(Long  cperson){
		 this.cperson=cperson;
 	}

	/**
	  * 获取评论人的值
	 * @return 返回评论人的值
	**/
	public Long getCperson(){
		 return cperson;
 	}

	/**
	  * 设置 评论人类型的值
	 * @param 	ctype	  评论人类型
	**/
	public void setCtype(Integer  ctype){
		 this.ctype=ctype;
 	}

	/**
	  * 获取 评论人类型的值
	 * @return 返回 评论人类型的值
	**/
	public Integer getCtype(){
		 return ctype;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{isenabled, createTime, content,stars,cperson,ctype};
	}

	@Override
	public String[] getFields() {
		return new String[]{"isenabled"," createTime","content","stars","cperson","ctype"};
	}

}
