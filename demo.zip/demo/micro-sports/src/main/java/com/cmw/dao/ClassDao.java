package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.ClassEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;


/**
 * 班级  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 14:02:43
 */
@Description(remark="班级DAO Mapper接口",createDate="2019-04-10 14:02:43",author="程明卫")
@Mapper
public interface ClassDao extends GenericDaoInter<ClassEntity, Long>{

    List<Map<String, Object>> getListByPars(Map<String, Object> params);
}
