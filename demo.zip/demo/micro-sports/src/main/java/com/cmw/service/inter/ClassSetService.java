package com.cmw.service.inter;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.service.IService;
import com.cmw.entity.ClassSetEntity;


/**
 * 排班设置表  Service接口
 * @author 程明卫
 * @date 2019-04-20 18:21:37
 */
@Description(remark="排班设置表业务接口",createDate="2019-04-20 18:21:37",author="程明卫")
public interface ClassSetService extends IService<ClassSetEntity, Long> {
}
