package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;


/**
 * 订单表
 * @author 程明卫
 * @date 2019-05-07 21:22:03
 */
@Description(remark="订单表实体",createDate="2019-05-07 21:22:03",author="程明卫")
@Entity
@Table(name="GL_Order")
@SuppressWarnings("serial")
public class OrderEntity extends IdBaseEntity {
	
	
	 @Description(remark="付款方式")
	 @Column(name="payType" ,nullable=false )
	 private Integer payType = 0;

	 @Description(remark="审批状态")
	 @Column(name="axstatus" ,nullable=false )
	 private Integer axstatus = 0;

	 @Description(remark="订单支付时间")
	 @Column(name="payDate" )
	 private Date payDate;

	 @Description(remark="订单类型")
	 @Column(name="otype" ,nullable=false )
	 private Integer otype = 0;

	 @Description(remark="订单状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="实际价格")
	 @Column(name="payPrice" ,nullable=false ,scale=2)
	 private BigDecimal payPrice  = new BigDecimal("0.00");

	 @Description(remark="订单总价")
	 @Column(name="totalPrice" ,nullable=false ,scale=2)
	 private BigDecimal totalPrice = new BigDecimal("0.00");

	 @Description(remark="业务单ID")
	 @Column(name="formId" ,nullable=false )
	 private Long formId;

	 @Description(remark="业务类型")
	 @Column(name="formType" ,nullable=false )
	 private Integer formType;

	 @Description(remark="订单编号")
	 @Column(name="code" ,nullable=false ,length=50 )
	 private String code = "000000";


	public OrderEntity() {

	}

	
	/**
	  * 设置付款方式的值
	 * @param 	payType	 付款方式
	**/
	public void setPayType(Integer  payType){
		 this.payType=payType;
 	}

	/**
	  * 获取付款方式的值
	 * @return 返回付款方式的值
	**/
	public Integer getPayType(){
		 return payType;
 	}

	/**
	  * 设置审批状态的值
	 * @param 	axstatus	 审批状态
	**/
	public void setAxstatus(Integer  axstatus){
		 this.axstatus=axstatus;
 	}

	/**
	  * 获取审批状态的值
	 * @return 返回审批状态的值
	**/
	public Integer getAxstatus(){
		 return axstatus;
 	}

	/**
	  * 设置订单支付时间的值
	 * @param 	payDate	 订单支付时间
	**/
	public void setPayDate(Date  payDate){
		 this.payDate=payDate;
 	}

	/**
	  * 获取订单支付时间的值
	 * @return 返回订单支付时间的值
	**/
	public Date getPayDate(){
		 return payDate;
 	}

	/**
	  * 设置订单类型的值
	 * @param 	otype	 订单类型
	**/
	public void setOtype(Integer  otype){
		 this.otype=otype;
 	}

	/**
	  * 获取订单类型的值
	 * @return 返回订单类型的值
	**/
	public Integer getOtype(){
		 return otype;
 	}

	/**
	  * 设置订单状态的值
	 * @param 	xstatus	 订单状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取订单状态的值
	 * @return 返回订单状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置实际价格的值
	 * @param 	payPrice	 实际价格
	**/
	public void setPayPrice(BigDecimal  payPrice){
		 this.payPrice=payPrice;
 	}

	/**
	  * 获取实际价格的值
	 * @return 返回实际价格的值
	**/
	public BigDecimal getPayPrice(){
		 return payPrice;
 	}

	/**
	  * 设置订单总价的值
	 * @param 	totalPrice	 订单总价
	**/
	public void setTotalPrice(BigDecimal  totalPrice){
		 this.totalPrice=totalPrice;
 	}

	/**
	  * 获取订单总价的值
	 * @return 返回订单总价的值
	**/
	public BigDecimal getTotalPrice(){
		 return totalPrice;
 	}

	/**
	  * 设置业务单ID的值
	 * @param 	formId	 业务单ID
	**/
	public void setFormId(Long  formId){
		 this.formId=formId;
 	}

	/**
	  * 获取业务单ID的值
	 * @return 返回业务单ID的值
	**/
	public Long getFormId(){
		 return formId;
 	}

	/**
	  * 设置业务类型的值
	 * @param 	formType	 业务类型
	**/
	public void setFormType(Integer  formType){
		 this.formType=formType;
 	}

	/**
	  * 获取业务类型的值
	 * @return 返回业务类型的值
	**/
	public Integer getFormType(){
		 return formType;
 	}

	/**
	  * 设置订单编号的值
	 * @param 	code	 订单编号
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取订单编号的值
	 * @return 返回订单编号的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{payType,axstatus,payDate,otype,xstatus,payPrice,totalPrice,formId,formType,code};
	}

	@Override
	public String[] getFields() {
		return new String[]{"payType","axstatus","payDate","otype","xstatus","payPrice","totalPrice","formId","formType","code"};
	}

	/**
	 * 	业务类型 [1:报名订单]
	 */
	public static int FORMTYPE_1 = 1;
}
