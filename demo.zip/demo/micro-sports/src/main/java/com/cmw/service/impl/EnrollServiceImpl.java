package com.cmw.service.impl;



import com.alibaba.fastjson.JSONObject;
import com.cmw.client.UserClient;
import com.cmw.constant.GlobalConstant;
import com.cmw.constant.SmsTemplateConstant;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.annotation.UserCache;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.core.vo.PageResult;
import com.cmw.dao.EnrollDao;
import com.cmw.entity.*;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.*;
import com.cmw.util.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.cmw.entity.EnrollEntity.AXSTATUS_1;


/**
 * 学生报名  Service实现类
 * @author 程明卫
 * @date 2019-04-10 14:07:54
 */
@Slf4j
@Description(remark="学生报名业务实现类",createDate="2019-04-10 14:07:54",author="程明卫")
@Service("enrollService")
public class EnrollServiceImpl extends AbsService<EnrollEntity, Long> implements  EnrollService {

	@Resource
	private EnrollDao enrollDao;

	@Resource(name="studentService")
	private StudentService studentService;

	@Autowired
	private TeacherService teacherService;

	@Autowired
	private OrderService orderService;

	@Autowired
	private AmqpTemplate amqpTemplate;

	@Resource(name="posterService")
	private PosterService posterService;

	@Autowired
	private UserClient userClient;

	@Autowired
	private ClassService classService;

	@Autowired
	private CourseService courseService;


	@Resource(name="studentDetailService")
	private StudentDetailService studentDetailService;

	@Override
	public GenericDaoInter<EnrollEntity, Long> getDao() {
		return enrollDao;
	}


	@Override
	@UserCache(cmns={"empName"}, returnType = UserCache.ReturnDataType.PAGE_RESULT)
	public PageResult<List<Map<String, Object>>> getPageByPars(Map<String, Object> map, Integer currPage, Integer pageSize) throws ServiceException {
		return super.getPageByPars(map, currPage, pageSize);
	}

	@Override
	@UserCache(cmns={"creator","auditUser"}, aliasCmns = {"trackerMan","auditUser"})
	public List<Map<String, Object>> getListMap(Map<String, Object> map) throws ServiceException {
		return super.getListMap(map);
	}

	/**
	 * 保存学生信息
	 *
	 * @param params
	 * @return
	 */
	private Map<String, Object> saveStudentInfo(SHashMap<String,Object> params){
		Integer source = BussContant.STUDENT_SOURCE_4;
		Long sourceId = params.getvalAsLng("sourceId");
		params.put("source", source);
		if(null == sourceId) throw new ServiceException("参数：sourceId 不能为空!");
		SHashMap<String,Object> pars = new SHashMap<>();
		pars.put("source", source);
		pars.put("sourceId", sourceId);
		pars.put("phone", params.getvalAsStr("phone"));
		StudentEntity studentEntity = studentService.getBySource(pars);
		if(null != studentEntity){
			String phone = studentEntity.getPhone();
			String sname = params.getvalAsStr("sname");
			throw new ServiceException(String.format("手机号为：%s的学生%s已经成功报名了，请不要重复报名!", phone,sname));
		}
		UserModel userModel = getCreator(sourceId);
		params.put(SysContant.USER_INFO, userModel);
		Map<String, Object> dataResult = (Map<String, Object>)studentService.doComplexBusss(params);
		return dataResult;
	}

	private UserModel getCreator(Long sourceId) {
		StudentEntity studentEntity;
		PosterEntity posterEntity = posterService.get(sourceId);
		Long studentId = posterEntity.getStudentId();
		studentEntity = studentService.get(studentId);
		Long creator = studentEntity.getCreator();
		JSONObject jsonObject = userClient.getUserById(creator);
		jsonObject = jsonObject.getJSONObject("datas");
		Long userId = jsonObject.getLong("userId");
		String userName = jsonObject.getString("userName");
		Long indeptId = jsonObject.getLong("indeptId");
		Long incompId = jsonObject.getLong("incompId");
		Long inempId = jsonObject.getLong("inempId");
		//4.用户名密码都正确
		UserModel userModel = new UserModel(userId,userName,indeptId,incompId, inempId, 0);
		return userModel;
	}

	@Override
	@Transactional(rollbackFor = {ServiceException.class, Exception.class})
	public Object doComplexBusssByPoster(Map pars) throws ServiceException {
		SHashMap<String,Object> params = new SHashMap<>(pars);
		Map<String, Object> dataResult = saveStudentInfo(params);
		Long studentId = (Long)dataResult.get("id");
		params.put("studentId", studentId);
		params.put("axstatus", AXSTATUS_1);
		Map<String,Object> dataMap = saveEnrollByImport(params);
		String cookieName = (String)dataResult.get("cookieName");
		String token = (String)dataResult.get(cookieName);
		Integer maxAge = (Integer)dataResult.get("maxAge");
		dataMap.put(cookieName, token);
		dataMap.put("maxAge", maxAge);
		dataMap.put("sid", studentId);
		return dataMap;
	}

	@Override
	public Map<String, Object> getDiffInfo(Long studentId,Long oldClsId, Long classId) {
		Map<String,Object> pars = new HashMap<>();
		pars.put("ids", oldClsId+","+classId);
		List<ClassEntity> classList = classService.getList(pars);
		ClassEntity oldClassObj = getClass(classList, oldClsId);
		ClassEntity newClassObj = getClass(classList, classId);
		Long newCourseId = newClassObj.getCourseId();
		String oldClassName = oldClassObj.getCname();
		String className = newClassObj.getCname();
		Long courseId = oldClassObj.getCourseId();
		pars.clear();

		Map<String,Object> dataMap = new HashMap<>();
		dataMap.put("errCode", 1);
		pars.put("studentId",studentId);
		pars.put("courseId",courseId);
		pars.put("source","changeCourse");

		List<EnrollEntity> enrollList = enrollDao.getList(pars);
		if(null == enrollList || enrollList.size() == 0){ //该学员还未报名转班报错提示
			dataMap.put("errCode", -1);
			return dataMap;
		}

		Integer ghours = 0;
		Integer zhours = 0;
		Integer thours = 0;
		EnrollEntity lastEnrollObj = enrollList.get(enrollList.size() - 1);
		Long enrollId = lastEnrollObj.getId();
		BigDecimal oldPrice = lastEnrollObj.getPrice();
		for(EnrollEntity enrollEntity : enrollList){
			Integer _hours = enrollEntity.getHours();
			Integer _ghours = enrollEntity.getGhours();
			Integer _uhours = enrollEntity.getUhours();
			Integer _stockHours = enrollEntity.getStockUhours();
            Integer old_thours = enrollEntity.getThours();
			if(null == _hours) _hours = 0;
			if(null == _ghours) _ghours = 0;
			if(null == _uhours) _uhours = 0;
            if(null == old_thours) old_thours = 0;
			if(null == _stockHours) _stockHours = 0;
			Integer _thours = (_hours+_ghours) - (_uhours + old_thours + _stockHours);
			if(_thours <= 0) continue;

			Integer _zhours = 0;
			if(_hours > _uhours){
				_zhours = (_hours+_ghours) - _uhours - old_thours - _stockHours;
			}
			if(_ghours.intValue() > 0){
				if(_zhours.intValue() > 0 && (_zhours.intValue() > _ghours.intValue())){
					_zhours -= _ghours;
				}else{
					if(_zhours.intValue() >0 && _zhours.intValue() <= _ghours.intValue()){
						_zhours = 0;
						_ghours = _zhours;
					}
				}
			}

			ghours += _ghours;
			zhours += _zhours;
			thours += _thours;
		}

		CourseEntity courseEntity = courseService.get(newCourseId);
		BigDecimal price = courseEntity.getPrice();
		BigDecimal diffPrice = getDiffPrice(zhours, oldPrice, price);


		dataMap.put("oldClassName", oldClassName);
		dataMap.put("className", className);
		dataMap.put("courseId", newCourseId);
		dataMap.put("studentId", studentId);
		dataMap.put("enrollId", enrollId);
		dataMap.put("hours", zhours);
		dataMap.put("ghours", ghours);
		dataMap.put("thours",thours);
		dataMap.put("price", price);
		dataMap.put("totalPrice", diffPrice);
		dataMap.put("payPrice", diffPrice);
		dataMap.put("cchooseId", newClassObj.getId());
		return dataMap;
	}

	@Override
	public void initRollTimeDatas() {
		Map<String,Object> params = new HashMap<>();
		params.put("remarkSign","原ID为");
		List<EnrollEntity> list = enrollDao.getList(params);
		if(null == list || list.size() == 0){
			return;
		}
		list.forEach(enrollEntity -> initRollTimeData(enrollEntity));
	}

	private void initRollTimeData(EnrollEntity enrollEntity){
		Date createTime = enrollEntity.getCreateTime();
		Long studentId = enrollEntity.getStudentId();
		Long enrollId = enrollEntity.getId();
		String remark = enrollEntity.getRemark();
		log.info("enrollId:{}, studentId:{}, createTime:{}, remark:{}", enrollId, studentId, createTime,remark);
		Map<String,Object> params = new HashMap<>();
		params.put("studentId",studentId);
		params.put("rollEnrollId",enrollId);
		List<EnrollEntity> list = enrollDao.getList(params);
		if(null == list || list.size() == 0) return;

		SHashMap<String,Object> dataMap = parseIdAndHours(remark);
		String enrollIds = dataMap.getvalAsStr("enrollIds");
		Integer totalZhours = dataMap.getvalAsInt("totalZhours");
		for(EnrollEntity enrollObj : list){
			Integer thours = enrollObj.getThours();
			if(null == thours || thours == 0) continue;
			if(totalZhours.intValue() <= thours.intValue()){
				enrollObj.setRollTime(createTime);
				enrollDao.update(enrollObj);
				break;
			}else{
				Integer result = totalZhours - thours;
				boolean isChange = false;
				if(result > 0){
					isChange = true;
					totalZhours = result;
				}else{
					if(totalZhours > 0){
						isChange = true;
						totalZhours = 0;
					}
				}
				if(isChange){
					enrollObj.setRollTime(createTime);
					enrollDao.update(enrollObj);
				}
				if(totalZhours.intValue() == 0) break;
			}
		}
	}

	private SHashMap<String,Object> parseIdAndHours(String str){
		//String str = "原ID为：2334 的报名单剩余43课时，通过转课转入当前新报名单下";
		int offset = str.indexOf("：");
		int last = str.indexOf(" 的报名");
		String enrollIds = str.substring(offset+1, last);
		offset = str.indexOf("剩余")+2;
		last = str.indexOf("课时");
		String zhoursStr = str.substring(offset, last);
		System.out.println(enrollIds+ " ,zhoursStr="+zhoursStr);
		SHashMap<String,Object> dataMap = new SHashMap<>();
		dataMap.put("enrollIds", enrollIds);
		dataMap.put("totalZhours", Integer.parseInt(zhoursStr));
		return dataMap;
	}

	private BigDecimal getDiffPrice(Integer zhours, BigDecimal oldPirce, BigDecimal price){
		BigDecimal diffPrice = new BigDecimal("0");
		if(oldPirce.doubleValue() >= price.doubleValue()){//如果原单价大于新课程单价，差价为0
			return  diffPrice;
		}else{
			double zprice = BigDecimalHandler.sub(price, oldPirce);
			zprice = zprice * zhours;
			diffPrice = BigDecimalHandler.roundToBigDecimal(zprice, 2);
		}
		return diffPrice;
	}

	private ClassEntity getClass(List<ClassEntity> classList, Long classId){
		ClassEntity entity = null;
		for(ClassEntity classEntity : classList){
			Long id = classEntity.getId();
			if(id.equals(classId)){
				entity = classEntity;
				break;
			}
		}
		return  entity;
	}


	@Override
	@Transactional(rollbackFor = {ServiceException.class, Exception.class})
	public Object doComplexBusss(SHashMap<String, Object> params) throws ServiceException {
		return saveEnrollByImport(params);
	}

	@Override
	public Map<String,Object> saveEnrollByImport(SHashMap<String, Object> params) throws ServiceException{
		EnrollEntity entity = null;
		try {
			entity = BeanUtil.copyValue(EnrollEntity.class, params.getMap());
		} catch (UtilException e) {
			e.printStackTrace();
			throw new ServiceException(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		}
		validInfo(entity);
		setTotalPrice(entity);

		//-- newest insert, time as 2019-06-19 16:43, Mr.Shaw start
		/*
		BigDecimal payPrice = entity.getPayPrice();

		if(!StringHandler.isValidObj(payPrice) || payPrice.intValue() == 0){
			BigDecimal totalPrice = entity.getTotalPrice();
			entity.setPayPrice(totalPrice);

			params.put("payPrice", totalPrice);
		}
		*/

		//-- newest insert, time as 2019-07-11 21:46, Mr.Shaw start
		checkSelectedCourseIsHasEnroll(params);

		//-- newest insert, time as 2019-10-30 14:58, Mr.Shaw start
		/*
		if(null != payPrice && payPrice.intValue() > 0){
			//-- 支付金额大于0, 审批通过
			entity.setAxstatus(BussContant.ENROLL_AXSTATUS_1);
		}
		*/
		//-- Mr.Shaw end

		//1.获取用户
		UserModel userInfo = (UserModel)params.getvalAsObj(SysContant.USER_INFO);
		Long orderId = null;
		if(null == entity.getId()){
			Integer diffPrice = params.getvalAsInt("diffPrice");
			if(null != diffPrice && diffPrice.intValue() != 0){  //转其它课程班级 (教练端 转班 功能 2019-08-06 19：17 cmw)
				setDataWhenDiffPrice(params,entity, userInfo);
			}

			UserUtil.setCreateInfo(userInfo, entity);
			//setOtypeToEnroll(entity);
			insert(entity);
			setCode(entity);
			params.put("formType", OrderEntity.FORMTYPE_1);
			params.put("sourceFormObj", entity);
			OrderEntity orderEntity = (OrderEntity) orderService.doComplexBusss(params);
			orderId = orderEntity.getId();
			//log.info("报名成功，发送短消息...");
//			sendMsg(entity, orderEntity, SmsTemplateConstant.ORDER_AUDIT_CODE, userInfo);
			Integer xstatus = entity.getXstatus();
			log.info("xstatus.intValue()="+xstatus.intValue());
			if(xstatus.intValue() == BussContant.ENROLL_XSTATUS_1){//支付成功(线下支付直接支付成功 )
				updateStudentXstatus(entity, userInfo);
			}else{
				sendMsg(entity, orderEntity, SmsTemplateConstant.ORDER_UNPAY_CODE, userInfo);
			}
		}else{
			UserUtil.setModifyInfo(userInfo, entity);
			update(entity);
		}

		Map<String,Object> dataResult = new HashMap<String, Object>();
		dataResult.put("id", entity.getId());
		dataResult.put("orderId", orderId);
		return dataResult;
	}

	@Override
	public DataTable getDataTableByPars(Map<String, Object> map, Integer offset, Integer pageSize) throws ServiceException {
		return super.getDataTableByPars(map, offset, pageSize);
	}

	private void setOtypeToEnroll(EnrollEntity enrollEntity){
		Map<String,Object> pars = new HashMap<>();
		pars.put("studentId", enrollEntity.getStudentId());
		StudentDetailEntity studentDetailEntity = studentDetailService.getByPars(pars);
		Long _enrollId = studentDetailEntity.getEnrollId();
		Integer otype = BussContant.ENROLL_OTYPE_0;
		if(null != _enrollId){ //如果之前已报名过，则 studnetDetail 表有原报名记录
			otype = BussContant.ENROLL_OTYPE_1;  //续签
		}
		enrollEntity.setOtype(otype);
	}

	/**
	 * 报名成功后，将学员更新为正式学员
	 * @param enrollEntity
	 * @param userModel
	 */
	private void updateStudentXstatus(EnrollEntity enrollEntity, UserModel userModel){

		Long studentId = enrollEntity.getStudentId();
		Map<String,Object> pars = new HashMap<>();
		pars.put("studentId", studentId);
		StudentDetailEntity studentDetailEntity = studentDetailService.getByPars(pars);
		StudentEntity studentObj = studentService.get(studentId);
	//	if(studentObj.getXstatus().intValue() >= BussContant.STUDENT_XSTATUS_4) return;
		UserUtil.setModifyInfo(userModel, studentObj);
		studentObj.setXstatus(BussContant.STUDENT_XSTATUS_5);
		studentService.update(studentObj);

		UserUtil.setModifyInfo(userModel, studentDetailEntity);
		studentDetailEntity.setRemark("报名");
		studentDetailEntity.setEnrollId(enrollEntity.getId());
		studentDetailService.update(studentDetailEntity);
	}


	private void setDataWhenDiffPrice(SHashMap<String, Object> params, EnrollEntity entity, UserModel userInfo) {
        Long enrollId = params.getvalAsLng("enrollId");
        Integer thours = params.getvalAsInt("thours");
        Map<String,Object> dataMap =  updateThours(userInfo, enrollId, thours);
		Date endDate = (Date)dataMap.get("endDate");
		String enrollIds = (String)dataMap.get("enrollIds");
		Byte diffPrice = entity.getDiffPrice();
		if(diffPrice.intValue() == 1){ //不补差价时，价格等于0
			entity.setPayPrice(new BigDecimal("0"));
			params.put("payPrice", entity.getPayPrice());
		}
		params.put("payType", BussContant.ORDER_PAYTYPE_1);
        StringBuilder sbRemark = new StringBuilder();
        sbRemark.append("原ID为："+enrollIds+" 的报名单剩余"+thours+"课时，通过转课转入当前新报名单下");
		entity.setPayDate(new Date());
		entity.setStartDate(new Date());
		entity.setEndDate(endDate);
		entity.setThours(0);
	    entity.setAxstatus(BussContant.ENROLL_AXSTATUS_1);
        entity.setXstatus(BussContant.ENROLL_XSTATUS_1);
        entity.setOtype(BussContant.ENROLL_OTYPE_2);
        entity.setRemark(sbRemark.toString());
	}

	/**
	 * 更新转出课时（如果有多个相同课程时，要遍历更新）
	 * @param userInfo
	 * @param enrollId
	 * @param thours
	 * @return
	 */
	private Map<String,Object> updateThours(UserModel userInfo, Long enrollId, Integer thours) {
		EnrollEntity old_enrollObj = get(enrollId);
		Date endDate = old_enrollObj.getEndDate();
		Integer hours = old_enrollObj.getHours();
		Integer ghours = old_enrollObj.getGhours();
		Integer uhours = old_enrollObj.getUhours();
		Integer old_thours = old_enrollObj.getThours();
		Integer old_shours = old_enrollObj.getStockUhours();
		if(null == old_thours) old_thours = 0;
		if(null == old_shours) old_shours = 0;
		Map<String,Object> dataMap = new HashMap<>();
		dataMap.put("endDate", endDate);
		Integer zhours = (hours + ghours) - uhours - old_thours - old_shours;
		if(thours.intValue() <= zhours.intValue()){
			updateThours(userInfo, old_enrollObj, thours);
			dataMap.put("enrollIds",enrollId.toString());
			return  dataMap;
		}
		Long courseId = old_enrollObj.getCourseId();
		Long studentId = old_enrollObj.getStudentId();
		Map<String,Object> pars = new HashMap<>();
		pars.put("courseId", courseId);
		pars.put("studentId", studentId);
		pars.put("btype", "changeCourse");
		StringBuilder sbEnrollIds = new StringBuilder();
		List<EnrollEntity> enrollList = getList(pars);
		for(EnrollEntity enrollObj : enrollList){
			Integer _hours = enrollObj.getHours();
			Integer _ghours = enrollObj.getGhours();
			Integer _uhours = enrollObj.getUhours();
			Integer curr_thours = enrollObj.getThours();
			Integer _shours = enrollObj.getStockUhours();
			if(null == curr_thours) curr_thours = 0;
			if(null == _shours) _shours = 0;

			Date _endDate = enrollObj.getEndDate();
			if(null != _endDate) endDate = _endDate;
			Integer _zhours = (_hours + _ghours) - _uhours - curr_thours - _shours;
			if(_zhours <= 0) continue;
			Integer result = thours - _zhours;
			Integer _thours = 0;
			if(result >= 0){
				_thours = _zhours;
				thours = result;
			}else {
				if (thours > 0) {
					_thours = thours;
					thours = 0;
				}
			}
			if(_thours.intValue() == 0) break;
			sbEnrollIds.append(enrollObj.getId()).append(",");
			updateThours(userInfo, enrollObj, _thours);
		}
		String enrollIds = StringHandler.RemoveStr(sbEnrollIds);

		if(StringHandler.isValidStr(enrollIds)){
			dataMap.put("enrollIds", enrollIds);
		}
		return dataMap;
	}

	private void updateThours(UserModel userInfo, EnrollEntity enrollObj, Integer _thours) {
		enrollObj.setThours(_thours);
		enrollObj.setRollTime(new Date());
		UserUtil.setModifyInfo(userInfo, enrollObj);
		log.info("rollTime --> enrollId:{}, thours:{}, rollTime:{}", enrollObj.getId(), enrollObj.getThours(), DateUtil.getDateStr());
		update(enrollObj);
	}

	@Override
	public void doComplexBusss(Map<String, Object> params) throws ServiceException {
		super.doComplexBusss(params);
	}

	private void setTotalPrice(EnrollEntity enrollEntity){
		BigDecimal totalPrice = enrollEntity.getPayPrice();
		if(null != totalPrice && totalPrice.doubleValue() > 0){ //当实际价格大于0时，直接不需要审批。小于0时，何总要批
			enrollEntity.setAxstatus(BussContant.ENROLL_AXSTATUS_1);
			return;
		}
		BigDecimal price = enrollEntity.getPrice();
		Integer hours = enrollEntity.getHours();
		totalPrice = BigDecimalHandler.get(BigDecimalHandler.round(price.doubleValue() * hours,2));
		enrollEntity.setTotalPrice(totalPrice);
	}


	/**
	 * 设置编号
	 * @param entity
	 */
	private void setCode(EnrollEntity entity) {
		String code = CodeRule.getCodeById("E",entity.getId());
		entity.setCode(code);
		enrollDao.updateCode(code, entity.getId());
	}

	private void validInfo(EnrollEntity entity) {
		if(null == entity.getCourseId()){
			throw new ServiceException("参数： courseId 课程ID不能为空！");
		}
		if(null == entity.getPrice() || entity.getPrice().doubleValue() < 0){
			throw new ServiceException("参数： price 课程单价不能为空且必须大于或等于de0！");
		}
//		if(null == entity.getHours() || entity.getHours().intValue() <= 0){
//			throw new ServiceException("参数： hours 购买课时不能为空且必须大于0！");
//		}
//		if(null == entity.getStartDate()){
//			throw new ServiceException("参数： startDate 课时开始日期不能为空！");
//		}
//		if(null == entity.getEndDate()){
//			throw new ServiceException("参数： endDate 课时截止日期不能为空！");
//		}

		//-- new insert, time as 2019-06-18 14:06, Mr.Shaw
		BigDecimal payPrice = entity.getPayPrice();

		if(StringHandler.isValidObj(payPrice) && payPrice.intValue() < 0)
			throw new ServiceException("参数： payPrice 必须大于等于0！");

		//-- ==> new insert, time as 2019-07-16 11:03, Mr.Shaw
		//-- 验证赠送课时是否大于购买课时的20%，采用四舍五入计算
		Integer hours = entity.getHours();
		if(null == hours) hours = 0;
		Integer giveHours = entity.getGhours();
		if(hours.intValue() > 0){
			BigDecimal maxGiveHours = new BigDecimal(hours).multiply(new BigDecimal(0.20)).setScale(0, RoundingMode.HALF_UP);
			BigDecimal giveHours_BD = new BigDecimal(giveHours);

			if(giveHours_BD.intValue() > maxGiveHours.intValue()){
				throw new ServiceException(String.format("赠送课时不能大于购买课时的百分之二十(Max:%s)", maxGiveHours.intValue()));
			}
		}

	}

	/**
	 * 报名审批
	 * @param pars
	 *
	pars.put(SysContant.USER_INFO, userInfo);
	pars.put("enrollId", enrollId);
	pars.put("axstatus", axstatus);
	pars.put("remark", remark);
	 */
	@Override
	public void audit(SHashMap<String, Object> pars) {
		UserModel userInfo = (UserModel)pars.getvalAsObj(SysContant.USER_INFO);
		Long orderId = pars.getvalAsLng("orderId");
		Integer axstatus = pars.getvalAsInt("axstatus");
		String remark = pars.getvalAsStr("remark");
		if(StringUtils.isEmpty(remark)){
			remark = String.format("用户：%s审批后将状态改为：%d", userInfo.getUserName(), axstatus);
		}
		OrderEntity orderEntity = orderService.get(orderId);
		UserUtil.setModifyInfo(userInfo, orderEntity);
		orderEntity.setAxstatus(axstatus);
		orderEntity.setRemark(remark);
		orderService.update(orderEntity);

		Long formId = orderEntity.getFormId();
		EnrollEntity enrollEntity = get(formId);
		UserUtil.setModifyInfo(userInfo, enrollEntity);
		enrollEntity.setAxstatus(axstatus);
		enrollEntity.setAuditUser(userInfo.getId());
		enrollEntity.setAuditTime(new Date());
		enrollEntity.setContent(remark);
		update(enrollEntity);

		sendMsg(enrollEntity, orderEntity, SmsTemplateConstant.ORDER_UNPAY_CODE, userInfo);
	}

	private void sendMsg(EnrollEntity enrollEntity, OrderEntity orderEntity, String tempCode, UserModel userModel){
		if(enrollEntity.getAxstatus().intValue() != BussContant.ENROLL_AXSTATUS_1){
			log.info("编号为："+orderEntity.getCode()+"的订单状态 axstatus="+orderEntity.getAxstatus()+"时，暂不需要发送短信和站内消息！");
			return;
		}
		Map<String,Object> msg = new HashMap<>();

		String teacherName = teacherService.getTeacheByUserId(userModel.getId());

		msg.put("teacherName", teacherName);

		Long studentId = enrollEntity.getStudentId();

		StudentEntity studentEntity = studentService.get(studentId);

		Long memberId = studentEntity.getMemberId();
		String phone = studentEntity.getPhone();

		msg.put("code", orderEntity.getCode());
		msg.put("totalPrice", orderEntity.getPayPrice());
		msg.put("rtype", BussContant.MSG_RTYPE_2);
		msg.put("memberId", memberId);
		msg.put("sender",userModel.getUserName());
		msg.put("phone",phone);
		msg.put("mtypes", BussContant.MSG_MTYPE_1+","+BussContant.MSG_MTYPE_2);
		msg.put("tempCode", tempCode);
		log.info("sendMsg... code = "+ enrollEntity.getCode()+" , tempCode = "+tempCode);

		//2.发送消息
		this.amqpTemplate.convertAndSend(GlobalConstant.AMQP_EXCHANGE_COMMON_KEY,GlobalConstant.AMQP_ROUTINGKEY_COMMON_KEY,msg);
	}
	
	/**
	 * 检查选中的课程是否已经报名
	 * @Author 肖家添
	 * @Date 2019/7/11 21:28
	 */
	private void checkSelectedCourseIsHasEnroll(SHashMap<String, Object> params_SH) throws ServiceException{

		String isChecking = params_SH.getvalAsStr("isCheckHasEnrollByCourse");
		Boolean isCheckHasEnrollByCourse_YES = params_SH.getvalAsBln("isCheckHasEnrollByCourse_YES");

		//-- 过滤已经过完的课时
		params_SH.put("filterUseUpCourse", true);

		if(!StringHandler.isValidStr(isChecking) || (isCheckHasEnrollByCourse_YES != null && isCheckHasEnrollByCourse_YES)){
			return;
		}

		List<Map<String, Object>> findEnrollResult = enrollDao.getEnrollByParams(params_SH.getMap());

		if(findEnrollResult != null && findEnrollResult.size() > 0){
			throw new ServiceException(String.format("此学生已经报名此课程，确定继续添加吗？"));
		}
	}

	@Override
	public List<Map<String, Object>> getEnrollByParams(Map<String, Object> params) {
		return enrollDao.getEnrollByParams(params);
	}

	@Override
	public Integer findNoFinishEnrollCount(Long studentId) {
		return enrollDao.findNoFinishEnrollCount(studentId);
	}
}
