package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.vo.PageResult;
import com.cmw.service.inter.DataReportService;
import com.cmw.util.DateUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


/**
 * 数据报表  ACTION类
 *
 * @author 程明卫
 * @date 2019-10-16 22:05:43
 */
@Description(remark = "数据报表ACTION", createDate = "2019-10-16 22:05:43", author = "程明卫")
@Api(value = "数据报表微服务", description = "#CONTROLLER# 2019-10-16 22:05:43 程明卫")
@RestController
@RequestMapping({"/data-report"})
public class DataReportController extends BaseAction {

    @Resource(name = "dataReportService")
    private DataReportService dataReportService;

    private void setEndDate(Map<String, Object> params){
        setEndDate("endDate", params);
    }

    /**
     * 学生详细信息报表分页查询
     */
    @ApiOperation("学生详细信息报表列表API")
    @PostMapping("month-list")
    public JSONObject getMonthList( @RequestBody Map<String, Object> params) {
        Integer listType = (Integer)params.get("listType");
        Integer endMonth = 0;
        if(null != listType && listType.intValue() == 1){ //获取整年的月份数
            endMonth = 12;
        }else{ //获取当前月份及之后的月份数
            endMonth = DateUtil.getMonth(new Date());
        }
        List<String> monthList = getMonthList(endMonth);
        return PageHandler.getJson(monthList);
    }

    private List<String> getMonthList(Integer endMonth){
        int[] ymd = DateUtil.getYMD(new Date());
        int year = ymd[0];
        List<String> monthList = new ArrayList<>(endMonth);
        do{
            String monthStr = null;
            if(endMonth < 10){
                monthStr = "0"+endMonth;
            } else{
                monthStr = ""+endMonth;
            }
            String ymonthDate = year + "-" + monthStr;
            monthList.add(ymonthDate);
            endMonth--;
        }while (endMonth.intValue() > 0);
        return monthList;
    }


    private void setEndDate(String endDateName,Map<String, Object> params){
        if(null == params || params.size() == 0) return;
        String endDate = (String)params.get(endDateName);
        if(StringUtils.isEmpty(endDate)) return;
        endDate = DateUtil.addDays(endDate, 1);
        params.put(endDateName, endDate);
    }

    /**
     * 学生详细信息报表分页查询
     */
    @ApiOperation("学生详细信息报表列表API")
    @PostMapping("student-detail")
    public JSONObject getStudentDetailReport(
            @RequestParam(name = "_current", defaultValue = "1") Integer currentPage,
            @RequestParam(name = "_pageSize", defaultValue = "10") Integer pageSize,
            @RequestBody Map<String, Object> params
    ) {
        PageResult<List<Map<String, Object>>> result = dataReportService.getStudentDetailReport(params, currentPage, pageSize);

        return PageHandler.getJson(result);
    }

    /**
     * 学员剩余课时报表分页查询
     */
    @ApiOperation("学员剩余课时报表列表API")
    @PostMapping("surplus-hours")
    public JSONObject getSurplusHoursReport(
            @RequestParam(name = "_current", defaultValue = "1") Integer currentPage,
            @RequestParam(name = "_pageSize", defaultValue = "10") Integer pageSize,
            @RequestBody Map<String, Object> params
    ) {
        setEndDate(params);
        PageResult<List<Map<String, Object>>> result = dataReportService.getSurplusHoursReport(params, currentPage, pageSize);
        return PageHandler.getJson(result);
    }

    /**
     * 学员上课统计报表分页查询
     */
    @ApiOperation("学员上课统计报表列表API")
    @PostMapping("go-class")
    public JSONObject getGoClassReport(
            @RequestParam(name = "_current", defaultValue = "1") Integer currentPage,
            @RequestParam(name = "_pageSize", defaultValue = "10") Integer pageSize,
            @RequestBody Map<String, Object> params
    ) {
        setEndDate(params);
        PageResult<List<Map<String, Object>>> result = dataReportService.getGoClassReport(params, currentPage, pageSize);
        return PageHandler.getJson(result);
    }

    /**
     * 学员上课课时（按课时）报表分页查询
     */
    @ApiOperation("学员上课课时（按课时）报表列表API")
    @PostMapping("go-class-hours")
    public JSONObject getGoClassHoursReport(
            @RequestParam(name = "_current", defaultValue = "1") Integer currentPage,
            @RequestParam(name = "_pageSize", defaultValue = "10") Integer pageSize,
            @RequestBody Map<String, Object> params
    ) {
        SHashMap<String, Object> pars = setPars(params);
        PageResult<List<Map<String, Object>>> result = dataReportService.getGoClassHoursReport(pars.getMap(), currentPage, pageSize);

        return PageHandler.getJson(result);
    }

    private SHashMap<String, Object> setPars(@RequestBody Map<String, Object> params) {
        setEndDate(params);
        SHashMap<String, Object> pars = new SHashMap<>(params);
        String currentMonth = pars.getvalAsStr("currentMonth");
        if (StringUtils.isEmpty(currentMonth)) {//当前月份未空时，默认当前月份
            currentMonth = DateUtil.dateFormatToStr(DateUtil.DATE_YYYYMM_FORMAT, new Date());
            pars.put("currentMonth", currentMonth);
        }
        String currentDate = currentMonth + "-01";
        String prevMonth = DateUtil.minusMonthToDateStr(currentDate, 1);
        pars.put("prevMonth", prevMonth);
        return pars;
    }

    /**
     * 老师上课统计报表分页查询
     */
    @ApiOperation("老师上课统计报表列表API")
    @PostMapping("go-class-teacher")
    public JSONObject getGoClassByTeacherReport(
            @RequestParam(name = "_current", required = false) Integer currentPage,
            @RequestParam(name = "_pageSize", required = false) Integer pageSize,
            @RequestBody Map<String, Object> params
    ) {
        setEndDate(params);
        PageResult<List<Map<String, Object>>> result = dataReportService.getGoClassByTeacherReport(params, currentPage, pageSize);

        return PageHandler.getJson(result);
    }

    /**
     * 数据导出
     * bizType -> [10001: 学生详细信息报表列表, 10002: 学生剩余课时报表, 10003: 学生上课统计局报表, 10004: 学生上课课时报表, 10005: 老师上课统计报表]
     * @Author 肖家添
     * @Date 2019/6/19 12:41
     */
    @ApiOperation("数据导出")
    @PostMapping("/exportData")
    public void exportData(
            HttpServletRequest request,
            HttpServletResponse response,
            @RequestParam(name = "_current", required = false) Integer currentPage,
            @RequestParam(name = "_pageSize", required = false) Integer pageSize,
            @RequestParam Map<String, Object> params,
            @RequestParam(required = false, defaultValue = "10001") Integer bizType
    ) {
        if(null != bizType && bizType.intValue() == 10004){ //学生上课课时报表,参数要重新处理
            SHashMap<String, Object> pars = setPars(params);
            params = pars.getMap();
        }
        setEndDate(params);
        dataReportService.exportData(request, response, bizType, params, currentPage, pageSize);
    }
}
