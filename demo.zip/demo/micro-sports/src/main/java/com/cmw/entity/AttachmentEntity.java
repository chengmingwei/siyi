package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 附件表
 * @author 程明卫
 * @date 2019-04-10 22:18:30
 */
@Description(remark="附件表实体",createDate="2019-04-10 22:18:30",author="程明卫")
@Entity
@Table(name="ts_Attachment")
@SuppressWarnings("serial")
public class AttachmentEntity extends IdBaseEntity {
	
	
	 @Description(remark="排序")
	 @Column(name="orderNo" ,nullable=false )
	 private Integer orderNo=0;

	 @Description(remark="是否置顶")
	 @Column(name="isTop" ,nullable=false )
	 private Integer isTop = 1;

	 @Description(remark="文件大小")
	 @Column(name="fileSize" )
	 private Long fileSize;

	 @Description(remark="文件路径")
	 @Column(name="filePath" ,nullable=false ,length=255 )
	 private String filePath;

	 @Description(remark="原文件名称")
	 @Column(name="fileName" ,nullable=false ,length=255 )
	 private String fileName;

	 @Description(remark="附件类型")
	 @Column(name="atype" ,nullable=false )
	 private Integer atype = -1;

	 @Description(remark="业务单ID")
	 @Column(name="formId" ,nullable=false ,length=50 )
	 private String formId = "-1";

	 @Description(remark="业务类型")
	 @Column(name="formType" ,nullable=false )
	 private Integer formType = -1;

	 @Description(remark="系统Id")
	 @Column(name="sysId" ,nullable=false )
	 private Long sysId = -1L;


	public AttachmentEntity() {

	}

	
	/**
	  * 设置排序的值
	 * @param 	orderNo	 排序
	**/
	public void setOrderNo(Integer  orderNo){
		 this.orderNo=orderNo;
 	}

	/**
	  * 获取排序的值
	 * @return 返回排序的值
	**/
	public Integer getOrderNo(){
		 return orderNo;
 	}

	/**
	  * 设置是否置顶的值
	 * @param 	isTop	 是否置顶
	**/
	public void setIsTop(Integer  isTop){
		 this.isTop=isTop;
 	}

	/**
	  * 获取是否置顶的值
	 * @return 返回是否置顶的值
	**/
	public Integer getIsTop(){
		 return isTop;
 	}

	/**
	  * 设置文件大小的值
	 * @param 	fileSize	 文件大小
	**/
	public void setFileSize(Long  fileSize){
		 this.fileSize=fileSize;
 	}

	/**
	  * 获取文件大小的值
	 * @return 返回文件大小的值
	**/
	public Long getFileSize(){
		 return fileSize;
 	}

	/**
	  * 设置文件路径的值
	 * @param 	filePath	 文件路径
	**/
	public void setFilePath(String  filePath){
		 this.filePath=filePath;
 	}

	/**
	  * 获取文件路径的值
	 * @return 返回文件路径的值
	**/
	public String getFilePath(){
		 return filePath;
 	}

	/**
	  * 设置原文件名称的值
	 * @param 	fileName	 原文件名称
	**/
	public void setFileName(String  fileName){
		 this.fileName=fileName;
 	}

	/**
	  * 获取原文件名称的值
	 * @return 返回原文件名称的值
	**/
	public String getFileName(){
		 return fileName;
 	}

	/**
	  * 设置附件类型的值
	 * @param 	atype	 附件类型
	**/
	public void setAtype(Integer  atype){
		 this.atype=atype;
 	}

	/**
	  * 获取附件类型的值
	 * @return 返回附件类型的值
	**/
	public Integer getAtype(){
		 return atype;
 	}

	/**
	  * 设置业务单ID的值
	 * @param 	formId	 业务单ID
	**/
	public void setFormId(String  formId){
		 this.formId=formId;
 	}

	/**
	  * 获取业务单ID的值
	 * @return 返回业务单ID的值
	**/
	public String getFormId(){
		 return formId;
 	}

	/**
	  * 设置业务类型的值
	 * @param 	formType	 业务类型
	**/
	public void setFormType(Integer  formType){
		 this.formType=formType;
 	}

	/**
	  * 获取业务类型的值
	 * @return 返回业务类型的值
	**/
	public Integer getFormType(){
		 return formType;
 	}

	/**
	  * 设置系统Id的值
	 * @param 	sysId	 系统Id
	**/
	public void setSysId(Long  sysId){
		 this.sysId=sysId;
 	}

	/**
	  * 获取系统Id的值
	 * @return 返回系统Id的值
	**/
	public Long getSysId(){
		 return sysId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{orderNo,isTop,fileSize,filePath,fileName,atype,formId,formType,sysId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"orderNo","isTop","fileSize","filePath","fileName","atype","formId","formType","sysId"};
	}

}
