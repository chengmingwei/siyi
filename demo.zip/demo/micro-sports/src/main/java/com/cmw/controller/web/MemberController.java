package com.cmw.controller.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmw.client.UploadClient;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.entity.MemberEntity;
import com.cmw.model.back.UserModel;
import com.cmw.model.global.ResultModel;
import com.cmw.model.global.ResultUtil;
import com.cmw.service.inter.MemberService;
import com.cmw.util.BeanUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 会员信息  ACTION类
 * @author 程明卫
 * @date 2019-04-10 22:07:38
 */
@Description(remark="会员信息ACTION",createDate="2019-04-10 22:07:38",author="程明卫")
@Api(value = "会员信息微服务", description = "#CONTROLLER# 2019-04-10 22:07:38 程明卫")
@RestController
@RequestMapping({"/member"})
@Slf4j
public class MemberController{

	@Resource(name="memberService")
	private MemberService memberService;

	@Autowired
	UploadClient uploadClient;

    /**
     * 通过 openid 会员用户验证 /member/login
     * @param openid
     * @return
     */
    @GetMapping("/loginbyopenid")
    public ResultModel<UserModel> login(@RequestParam(value = "openid", required = false) String openid,
                                        @RequestParam(value = "memberId", required = false) Long memberId){
        UserModel userModel = memberService.login(openid, memberId);
        if(null == userModel){
            return ResultUtil.getFailure("用户帐户不存在！");
        }else{
            return ResultUtil.getSuccess(userModel);
        }
    }

    /**
     *
     * 会员用户验证 /member/login
     * @param
     * @param password
     * @return
     */
    @GetMapping("login")
    public JSONArray login(
            @RequestParam("username")String username,
            @RequestParam("password")String password,
            @RequestParam("ltype")Integer ltype,
            @RequestParam("ipAddr")String ipAddr,
            @RequestParam("isource") Integer isource,
            @RequestParam(value = "openid", required = false) String openid){
        JSONArray jsonArray = memberService.login(username, password,
                ltype, ipAddr, isource, openid);
        if (jsonArray == null || jsonArray.isEmpty()){
            return null;
        }
        return jsonArray;
    }

	 /**
     * 跳转主页面
     * @return
     */
     @ApiOperation("会员信息首页API")
    @GetMapping(value = "/home")
    public JSONObject home(Map<String, Object> params) throws Exception{
       List<MemberEntity> list = memberService.getListAll();
       return PageHandler.getJson(list);
    }

    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取会员信息")
    @GetMapping(value = "/info")
    public JSONObject info(@ApiParam("会员信息ID") @RequestParam Long id){
      	if(StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        MemberEntity obj = memberService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存会员信息")
    @PostMapping(value = "/save")
    public JSONObject save(Map<String, Object> params) throws Exception{
        MemberEntity entity = BeanUtil.copyValue(MemberEntity.class, params);
        memberService.insert(entity);
        return PageHandler.getSuccessJson();
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除会员信息")
    @DeleteMapping(value = "/remove")
    public JSONObject remove(@ApiParam("会员ID") @RequestParam Long id) throws Exception{
        memberService.delete(id);
        return PageHandler.getSuccessJson();
    }

    /**
     * OSS文件迁移
     * @Author 肖家添
     * @Date 2019/7/10 17:22
     */
    @PostMapping("/ossFileTransfer")
    public void ossFileTransfer(){
        uploadClient.ossFileTransfer();
    }

    /**
     * 修改会员密码
     * @Author 肖家添
     * @Date 2019/7/15 15:16
     */
    @PostMapping("/editPassword")
    public JSONObject editPassword(@RequestParam Map<String, Object> params){
        try{
            memberService.editPassword(params);

            return PageHandler.getSuccessJson();
        }catch (Exception ex){
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }
}
