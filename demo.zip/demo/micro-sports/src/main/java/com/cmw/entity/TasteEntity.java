package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import java.util.Date;


/**
 * 学员体验记录
 * @author 程明卫
 * @date 2019-04-10 13:48:24
 */
@Description(remark="学员体验记录实体",createDate="2019-04-10 13:48:24",author="程明卫")
@Entity
@Table(name="GL_Taste")
@SuppressWarnings("serial")
public class TasteEntity extends IdBaseEntity {
	
	
	 @Description(remark="是否已体验")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus;

	 @Description(remark="体验日期")
	 @Column(name="ndate" )
	 private Date ndate;

	 @Description(remark="体验班级")
	 @Column(name="classId" )
	 private Long classId;

	 @Description(remark="体验校区")
	 @Column(name="schoolId" )
	 private Long schoolId;

	 @Description(remark="学员ID")
	 @Column(name="studentId" ,nullable=false )
	 private Long studentId;

	@Description(remark="来源")
	@Column(name="source" ,nullable=false )
	private Byte source = 0;

	@Description(remark="来源ID")
	@Column(name="sourceId" )
	private Long sourceId;

	@Description(remark="课程ID")
	@Column(name="courseId")
	private Long courseId;

	public TasteEntity() {

	}

	public Byte getSource() {
		return source;
	}

	public void setSource(Byte source) {
		this.source = source;
	}

	public Long getSourceId() {
		return sourceId;
	}

	public void setSourceId(Long sourceId) {
		this.sourceId = sourceId;
	}

	public Long getCourseId() {
		return courseId;
	}

	public void setCourseId(Long courseId) {
		this.courseId = courseId;
	}

	/**
	  * 设置是否已体验的值
	 * @param 	xstatus	 是否已体验
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取是否已体验的值
	 * @return 返回是否已体验的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置体验日期的值
	 * @param 	ndate	 体验日期
	**/
	public void setNdate(Date  ndate){
		 this.ndate=ndate;
 	}

	/**
	  * 获取体验日期的值
	 * @return 返回体验日期的值
	**/
	public Date getNdate(){
		 return ndate;
 	}

	/**
	  * 设置体验班级的值
	 * @param 	classId	 体验班级
	**/
	public void setClassId(Long  classId){
		 this.classId=classId;
 	}

	/**
	  * 获取体验班级的值
	 * @return 返回体验班级的值
	**/
	public Long getClassId(){
		 return classId;
 	}

	/**
	  * 设置体验校区的值
	 * @param 	schoolId	 体验校区
	**/
	public void setSchoolId(Long  schoolId){
		 this.schoolId=schoolId;
 	}

	/**
	  * 获取体验校区的值
	 * @return 返回体验校区的值
	**/
	public Long getSchoolId(){
		 return schoolId;
 	}

	/**
	  * 设置学员ID的值
	 * @param 	studentId	 学员ID
	**/
	public void setStudentId(Long  studentId){
		 this.studentId=studentId;
 	}

	/**
	  * 获取学员ID的值
	 * @return 返回学员ID的值
	**/
	public Long getStudentId(){
		 return studentId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{xstatus,ndate,classId,schoolId,studentId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"xstatus","ndate","classId","schoolId","studentId"};
	}

}
