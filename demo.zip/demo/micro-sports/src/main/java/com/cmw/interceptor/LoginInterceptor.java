package com.cmw.interceptor;

import com.cmw.constant.GlobalConstant;
import com.cmw.constant.SysParamConstant;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.cache.RedisService;
import com.cmw.model.back.SystemModel;
import com.cmw.model.back.UserModel;
import com.cmw.props.JwtProperties;
import com.cmw.util.CookieUtils;
import com.cmw.util.GenPass;
import com.cmw.util.JwtUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author: 98050
 * @Time: 2018-10-25 18:17
 * @Feature: 登录拦截器
 */
@Slf4j
@Component
public class LoginInterceptor extends HandlerInterceptorAdapter {

    private JwtProperties jwtProperties;

    @Value("${web.uri.excludes}")
    private String excluedesUri;

    private static String[] excluedesUriList;

    @Autowired
    private RedisService redisService;

//    @Autowired
//    RedisTemplate redisTemplate;

    public static final String USER_UUID_KEY = "USERINFO_UUID_KEY";


    /**
     * 定义一个线程域，存放登录用户
     */
    private static final ThreadLocal<Map<String,Object>> t1 = new InheritableThreadLocal<>();

    public LoginInterceptor(JwtProperties jwtProperties) {
        this.jwtProperties = jwtProperties;
    }

    /**
     *      * 在业务处理器处理请求之前被调用
     *      * 如果返回false
     *      *      则从当前的拦截器往回执行所有拦截器的afterCompletion(),再退出拦截器链
     *      * 如果返回true
     *      *      执行下一个拦截器，直到所有拦截器都执行完毕
     *      *      再执行被拦截的Controller
     *      *      然后进入拦截器链
     *      *      从最后一个拦截器往回执行所有的postHandle()
     * @param request
     * @param response
     * @param handler
     * @return
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String uri = request.getRequestURI();
        parseSystemToken(request, response);
        if(!StringUtils.isEmpty(uri) && uri.indexOf("/feign") != -1){ //在URI 上加 /feign 指明给Feign 客户端调用，此时就会验证权限
            return doFeignAuth(request, response); //验证Feigin 客户端调用权限
        }
        String token = null;
        if(isExclude(uri)){
            token = getToken(request, response);
            if(!StringUtils.isEmpty(token)){
                try{
                    parseToken(token);
                }catch (Exception ex){
                    //不做任何处理
                }
            }
            return true;
        }
        if(StringUtils.isEmpty(token))   token = getToken(request, response);

        if (StringUtils.isBlank(token)){
            //2.未登录，返回401
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            return false;
        }
        //3.有token，查询用户信息
        try{
            parseToken(token);
            return true;
        }catch (Exception e){
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            return false;
        }
    }

    private boolean doFeignAuth(HttpServletRequest request, HttpServletResponse response) throws IOException {
        boolean isAllow = true;
        String uri = request.getRequestURI();
        if(!StringUtils.isEmpty(uri) && uri.indexOf("/feign") != -1){
            String feignKey = request.getParameter("feignKey");
            if(StringUtils.isEmpty(feignKey)){
                response.setStatus(HttpStatus.UNAUTHORIZED.value());
                log.error("参数：feignKey 不能为空！");
                return false;
            }
            if(!GlobalConstant.FEIGN_REQUEST_KEY.equals(feignKey)){
                response.setStatus(HttpStatus.UNAUTHORIZED.value());
                log.error("参数：feignKey 不正确！");
                return false;
            }
        }
        return isAllow;
    }

    private String getToken(HttpServletRequest request, HttpServletResponse response, String tokenName) {
        //1.查询token
        String token = CookieUtils.getCookieValue(request,tokenName);
        if(StringUtils.isEmpty(token)){
            token = request.getHeader(tokenName);
            CookieUtils.setCookie(request,response, tokenName, token);
        }
        return token;
    }

    private String getToken(HttpServletRequest request, HttpServletResponse response) {
        String cookieName = jwtProperties.getCookieName();
        return getToken(request, response, cookieName);
    }

    private void parseSystemToken(HttpServletRequest request, HttpServletResponse response){
        String systemToken = getToken(request, response, "TXR_SYS_CODE");
        if(StringUtils.isEmpty(systemToken)) return;
        String systemCode = GenPass.Decrypt(systemToken);
        if(StringUtils.isEmpty(systemCode)) return;
        String redisKey = String.format(SysParamConstant.SYSTEM_KEY,systemCode);
        SystemModel systemModel = redisService.get(redisKey);
        setLocalVals("systemModel", systemModel);
    }

    private void setLocalVals(String localKey, Object data) {
        Map<String,Object> localMap = t1.get();
        if(null == localMap || localMap.size() == 0) localMap = new ConcurrentHashMap<>();
        localMap.put(localKey, data);
        t1.set(localMap);
    }

    private void parseToken(String token) throws Exception {
        //4.解析成功，说明已经登录
        UserModel userInfo = JwtUtils.getInfoFromToken(token,jwtProperties.getPublicKey());
        //5.放入线程域
        setLocalVals("userInfoModel", userInfo);
    }

    /**
     * 验证当前URI是否要排除
     * @param uri 要验证的URI
     * @return  [true:排除,false:不排除]
     */
    private boolean isExclude(String uri){
        if(StringUtils.isEmpty(uri)) return true;
        if(StringUtils.isEmpty(excluedesUri)) return true;
        if(null == excluedesUriList || excluedesUriList.length == 0){
            synchronized (excluedesUri){
                excluedesUriList = excluedesUri.split(",");
            }
        }
        boolean flag = false;
        for(String excluedesUri : excluedesUriList){
            if(excluedesUri.indexOf(uri) != -1) return true;
        }
        return flag;
    }

    /**
     * 在业务处理器处理请求执行完成后，生成视图之前执行的动作
     * 可在modelAndView中加入数据，比如当前时间
     * @param request
     * @param response
     * @param handler
     * @param modelAndView
     * @throws Exception
     */
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        super.postHandle(request, response, handler, modelAndView);
    }

    /**
     * 在DispatcherServlet完全处理完请求后被调用,可用于清理资源等
     * 当有拦截器抛出异常时,会从当前拦截器往回执行所有的拦截器的afterCompletion()
     * @param request
     * @param response
     * @param handler
     * @param ex
     * @throws Exception
     */
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
       t1.remove();
    }

    public static UserModel getLoginUser(){
        Map<String,Object> localMap = t1.get();
        if(null == localMap || localMap.isEmpty()) return null;
        return (UserModel)localMap.get("userInfoModel");
    }

    public static UserModel getLoginMember(){
        UserModel userModel = getLoginUser();
        if(null != userModel){
            userModel.setIndeptId(SysContant.MEMBER_DEFAULT_DEPTID);
            userModel.setIncompId(SysContant.MEMBER_DEFAULT_EMPID);
            userModel.setInempId(SysContant.MEMBER_DEFAULT_EMPID);
            userModel.setUtype(BussContant.USER_UTYPE_MEMBER);
        }
        return userModel;
    }

    public static SystemModel getSystem(){
        Map<String,Object> localMap = t1.get();
        if(null == localMap || localMap.isEmpty()) return null;
        return (SystemModel)localMap.get("systemModel");
    }

}
