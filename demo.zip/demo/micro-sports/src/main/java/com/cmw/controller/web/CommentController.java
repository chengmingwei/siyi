package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.CommentEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.CommentService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 评论表  Conntroller类
 *
 * @author 程明卫
 * @date 2019-04-20 13:37:36
 */
@Description(remark = "评论表Conntroller", createDate = "2019-04-20 13:37:36", author = "程明卫")
@Api(value = "评论表微服务", description = "#CONTROLLER# 2019-04-20 13:37:36 程明卫")
@RestController
@RequestMapping({"/comment"})
public class CommentController {
    @Resource(name = "commentService")
    private CommentService commentService;


    /**
     * 跳转列表页面
     *
     * @param params [
     *               ctype:{1:学生对老师评价,2:老师对学生评价},
     *               tag:{
     *               1 - 2 星 tag = stars_one,
     *               2 - 4 星 tag = stars_two,
     *               5 星	 tag = stars_three
     *               }]
     * @return
     */
    @ApiOperation("评论表列表API")
    @PostMapping(value = "/wx/list")
    public JSONObject wx_list(@RequestParam Map<String, Object> params) {
        String ctypeStr = (String) params.get("ctype");
        String cpersonStr = (String) params.get("cperson");
        if (StringUtils.isEmpty(ctypeStr)) {
            return PageHandler.getFailureJson("参数：ctype 不能为空!");
        }
        Integer ctype = Integer.parseInt(ctypeStr);

        if (ctype.intValue() == CommentEntity.CTYPE_2) {
            UserModel userModel = LoginInterceptor.getLoginUser();

            if (!StringUtils.isEmpty(cpersonStr)) {
                params.put("cperson", Long.parseLong(cpersonStr));
            } else {
                params.put("userId", userModel.getId());
            }
        } else {
            UserModel userModel = LoginInterceptor.getLoginMember();
            if (!StringUtils.isEmpty(cpersonStr)) {
                params.put("cperson", Long.parseLong(cpersonStr));
            } else {
                params.put("memberId", userModel.getId());
            }
        }
        List<Map<String, Object>> list = commentService.getListMap(params);
        return PageHandler.getJson(list);
    }

    /**
     * 评论列表
     *
     * ctype = 1 ==> 获取`学生`对`老师`的评价(登录人为教师)
     * ctype = 2 ==> 获取`老师`对`学生`的评价(登录人为学生)
     *
     * @Author 肖家添
     * @Date 2019/7/4 4:29 PM
     */
    @ApiOperation("评论表列表API")
    @PostMapping(value = "/wx/list_newest")
    public JSONObject wx_list_newest(@RequestParam Map<String, Object> params) {

        SHashMap params_SH = new SHashMap(params);

        String ctype = params_SH.getvalAsStr("ctype");
        String toManId = params_SH.getvalAsStr("toManId");

        if (StringUtils.isEmpty(ctype)) {
            return PageHandler.getFailureJson("参数：ctype 不能为空!");

        }else if((CommentEntity.CTYPE_1 + "").equals(ctype) && (CommentEntity.CTYPE_2 + "").equals(ctype)){
            return PageHandler.getFailureJson("参数：ctype 非法!");

        }else if(StringUtils.isEmpty(toManId)){
            return PageHandler.getFailureJson("参数：toManId 不能为空!");
        }

        List<Map<String, Object>> list = commentService.getCommentByPars(params);

        return PageHandler.getJson(list);
    }

    /**
     * 分页查询
     * 返回状态码：
     * 404 : 没有查询到任何数据
     *
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     */
    @ApiOperation("分页查询评论表信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String, Object> params) {
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String, Object>>> result = commentService.getPageByPars(params, page, pageSize);
        if (result == null) {
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }


    /**
     * 跳转详细页面
     *
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取评论表信息")
    @PostMapping(value = "/{id}")
    public JSONObject get(@ApiParam("评论表ID") @PathVariable("id") Long id) {
        if (!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        CommentEntity obj = commentService.get(id);
        JSONObject jsonObject = PageHandler.getJson(obj);
        return jsonObject;
    }


    /**
     * 保存数据
     *
     * @param params 要保存的数据 [
     *               toManId:被评论对象的ID，classGoId:课次ID,
     *               ctype:评论人类型{1:学生对老师评价,2:老师对学生评价},
     *               stars:得分,content:内容]
     * @return
     */
    @ApiOperation("保存评论表信息")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, String> params) {
        try {
            SHashMap pars = new SHashMap(params);
            UserModel userInfo = null;

            String ctype_Str = params.get("ctype");
            int ctype = Integer.parseInt(ctype_Str);
            if (ctype == CommentEntity.CTYPE_2) {
                userInfo = LoginInterceptor.getLoginUser();
            } else {
                userInfo = LoginInterceptor.getLoginMember();
            }
            pars.put(SysContant.USER_INFO, userInfo);

            Map<String, Object> dataResult = (Map<String, Object>) commentService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        } catch (ServiceException ex) {
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }

    }

    @PostMapping(value = "sys/save")
    public JSONObject sys_save(@RequestBody Map<String, String> param) {
        return save(param);
    }

    /**
     * 移除数据
     *
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除评论表信息")
    @DeleteMapping(value = "{id}")
    public JSONObject delete(@ApiParam("#DESCRIPTIONID") @PathVariable("id") Long id) throws Exception {
        commentService.enabled(id, -1);
        return PageHandler.getSuccessJson();
    }

    /**
     * 获取评论
     * @Author 肖家添
     * @Date 2019/6/20 14:13
     */
    @ApiOperation("获取评论")
    @PostMapping(value = "/getCommentByPars")
    public JSONObject getCommentByPars(@RequestParam Map<String, Object> params) {
        return PageHandler.getJson(commentService.getPageByPars(params, null, null));
    }

}
