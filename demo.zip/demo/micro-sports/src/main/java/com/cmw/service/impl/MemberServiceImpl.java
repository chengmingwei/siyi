package com.cmw.service.impl;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.GlobalConstant;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import com.cmw.dao.MemberDao;
import com.cmw.entity.MemberEntity;
import com.cmw.entity.StudentEntity;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.MemberService;
import com.cmw.service.inter.StudentService;
import com.cmw.util.*;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 会员信息  Service实现类
 * @author 程明卫
 * @date 2019-04-10 22:07:38
 */
@Description(remark="会员信息业务实现类",createDate="2019-04-10 22:07:38",author="程明卫")
@Service("memberService")
public class MemberServiceImpl extends AbsService<MemberEntity, Long> implements  MemberService {
	@Autowired
	private MemberDao memberDao;
	@Autowired
	private StringRedisTemplate stringRedisTemplate;

	@Autowired
	private StudentService studentService;

	@Override
	public GenericDaoInter<MemberEntity, Long> getDao() {
		return memberDao;
	}


	@Override
	@Transactional
	public UserModel login(String openid, Long memberId) throws ServiceException {
		Map<String,Object> params = new HashMap<String,Object>();
		if(null != memberId){
			params.put("memberId", memberId);
		}else{
			params.put("openid", openid);
		}
		MemberEntity member = getByPars(params);

		//2.校验用户名
		if (member == null){
			log.error("用户名不存在！");
			return null;
		}

		String _openid = member.getOpenid();
		if((StringUtils.isEmpty(_openid) || _openid.equals("null"))
				&& (!StringUtils.isEmpty(openid) && null != memberId) && null != member){
			member.setOpenid(openid);
			member.setModifytime(new Date());
			this.update(member);
		}

		return getUserModel(member);
	}



	@Override
	@Transactional
	public JSONArray login(String username, String password, Integer ltype,
						   String ipAddr, Integer isource, String openid) throws ServiceException {
		Map<String,Object> params = new HashMap<String,Object>();
		String enc_username = GenPass.Encrypt(username);
		if(ltype.intValue() == BussContant.LOGIN_TYPE_2){
			params.put("phone",enc_username);
		}else{
			params.put("account", enc_username);
		}

		List<MemberEntity> memberList = getList(params);

		//2.校验用户名
		if (memberList == null || memberList.isEmpty()){
			log.error("用户名不存在！");
			return null;
		}
		JSONArray jsonArr = null;
		if(memberList.size() > 1){
			jsonArr = getUserInfos(memberList);
		}else{
			MemberEntity member = memberList.get(0);
			jsonArr = new JSONArray();
			jsonArr.add(getUserInfo(member));
			if(isAdminAccount(member, password)){
				return jsonArr;
			}

		}

		if(ltype.intValue() == BussContant.LOGIN_TYPE_2){
			String code = this.stringRedisTemplate.opsForValue().get(GlobalConstant.REDIS_KEY_MEMBER_VALID_CODE + username);
			if(StringUtils.isEmpty(code)){
				throw new ServiceException("短信验证码已过期，请重新发送！");
			}
			if(!code.equals(password)){
				log.error("短信验错误！");
				throw new ServiceException("短信验错误！");
			}
			log.info("login.user.valid.code is success");
		}else{
			//3. 校验密码
			boolean result = eqPwd(username , password, memberList);
			if (!result){
				log.error("密码错误！");
				throw new ServiceException("密码错误！");
				//return null;
			}
			log.info("login.user.valid.password is success");
		}
		if(!StringUtils.isEmpty(openid)) setOpenid(memberList, openid);
		return jsonArr;
	}

	private void setOpenid(List<MemberEntity> members, String openid){
		for(MemberEntity member : members){
			String db_openid = member.getOpenid();
			if(StringUtils.isEmpty(db_openid)){
				member.setOpenid(openid);
				this.update(member);
			}
		}
	}

	/**
	 * 密码比较
	 * @param username
	 * @param password
	 * @param members
	 * @return
	 */
	private boolean eqPwd(String username, String password, List<MemberEntity> members){
		boolean result = false;
		for(MemberEntity member : members){
			result = CodecUtils.passwordConfirm(username + password,member.getPwd());
			if(result) break;
		}
		return result;
	}

	private boolean isAdminAccount(MemberEntity memberEntity,String password){
		Byte cardnoPass = memberEntity.getCardnoPass();
		String pwd = memberEntity.getPwd();
		String cardno = memberEntity.getCardno();
		log.info("isAdminAccount.db.pwd="+pwd+", cardnoPass="+cardnoPass+", password="+password );
		if(null != cardnoPass && cardnoPass.intValue() == 2 && StringHandler.isValidStr(cardno)){ //超级帐户
			if(password.equals(cardno)){
				return true;
			}
		}
		return false;
	}

	private JSONArray getUserInfos(List<MemberEntity> members){
		JSONArray jsonArray = new JSONArray();
		Map<String,Object> pars = new HashMap<>();
		for(MemberEntity member : members){
			pars.put("memberId", member.getId());
			StudentEntity studentEntity = studentService.getByPars(pars);
			Long studentId = studentEntity.getId();

			JSONObject json = new JSONObject();
			json.put("id", member.getId());
			json.put("userName",member.getAccount());
			json.put("sname",studentEntity.getSname());
			json.put("inempId",studentId);
			json.put("indeptId",SysContant.MEMBER_DEFAULT_DEPTID);
			json.put("incompId", SysContant.MEMBER_DEFAULT_DEPTID);
			json.put("utype", BussContant.USER_UTYPE_MEMBER);
			jsonArray.add(json);
		}
		return  jsonArray;
	}

	private JSONObject getUserInfo(MemberEntity member){
		return FastJsonUtil.convertObjToJsonObj(getUserModel(member));
	}

	private UserModel getUserModel(MemberEntity member) {
		Map<String, Object> pars = new HashMap<>();
		pars.put("memberId", member.getId());
		StudentEntity studentEntity = studentService.getByPars(pars);
		Long studentId = studentEntity.getId();

		//4.用户名密码都正确
		UserModel userModel = new UserModel(
				member.getId(), member.getAccount(), SysContant.MEMBER_DEFAULT_DEPTID,
				SysContant.MEMBER_DEFAULT_DEPTID, studentId, BussContant.USER_UTYPE_MEMBER
		);
		return userModel;
	}

	/**
	 * 修改密码
	 * @Author 肖家添
	 * @Date 2019/7/15 14:29
	 */
	@Override
	@Transactional
	public void editPassword(Map<String, Object> params) {
		SHashMap<String, Object> params_SH = new SHashMap<>(params);

		String account = params_SH.getvalAsStr("account");
		String oldPassword = params_SH.getvalAsStr("oldPassword");
		String newestPassword = params_SH.getvalAsStr("newestPassword");

		if(!StringHandler.isValidStr(account)){
			throw new ServiceException("用户名不能为空");
		}else if(!StringHandler.isValidStr(oldPassword)){
			throw new ServiceException("原密码不能为空");
		}else if(!StringHandler.isValidStr(newestPassword)){
			throw new ServiceException("新密码不能为空");
		}else{
			Map<String, Object> queryMap = new HashMap<>();

			String enc_account = GenPass.Encrypt(account);
			queryMap.put("account", enc_account);

			MemberEntity member = memberDao.getByPars(queryMap);

			if(!StringHandler.isValidObj(member) || !StringHandler.isValidObj(member.getId())){
				throw new ServiceException(String.format("用户名%s未找到相关会员", account));
			}
			String find_Phone = member.getPhone().trim();
			String enc_find_phone = GenPass.Decrypt(find_Phone);

			boolean isSuccess = CodecUtils.passwordConfirm(enc_find_phone + oldPassword, member.getPwd());
			if(!isSuccess){
				throw new ServiceException("原密码不正确");
			}

			isSuccess = CodecUtils.passwordConfirm(enc_find_phone + newestPassword, member.getPwd());

			if(isSuccess){
				throw new ServiceException("新密码不能和旧密码相同");
			}

			String encodePassword = CodecUtils.passwordBcryptEncode(enc_find_phone, newestPassword);
			member.setPwd(encodePassword);

			memberDao.update(member);
		}
	}
}
