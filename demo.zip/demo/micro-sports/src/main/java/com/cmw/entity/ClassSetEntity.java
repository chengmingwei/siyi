package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 排班设置表
 * @author 程明卫
 * @date 2019-04-20 18:21:37
 */
@Description(remark="排班设置表实体",createDate="2019-04-20 18:21:37",author="程明卫")
@Entity
@Table(name="GL_ClassSet")
@SuppressWarnings("serial")
public class ClassSetEntity extends IdBaseEntity {
	
	
	 @Description(remark="下课时间")
	 @Column(name="etime" ,nullable=false )
	 private String etime;

	 @Description(remark="上课时间")
	 @Column(name="stime" ,nullable=false )
	 private String stime;

	 @Description(remark="循环规则值")
	 @Column(name="ruleVals" ,nullable=false ,length=100 )
	 private String ruleVals = "0";

	 @Description(remark="循环规则名称")
	 @Column(name="ruleNames" ,nullable=false ,length=100 )
	 private String ruleNames;

	 @Description(remark="循环规则")
	 @Column(name="rtype" )
	 private Integer rtype = 0;

	 @Description(remark="开始日期")
	 @Column(name="startDate" )
	 private Date startDate;

	 @Description(remark="排课类型")
	 @Column(name="ptype" ,nullable=false )
	 private Integer ptype;

	 @Description(remark="班级ID")
	 @Column(name="classId" ,nullable=false )
	 private Long classId;


	public ClassSetEntity() {

	}

	
	/**
	  * 设置下课时间的值
	 * @param 	etime	 下课时间
	**/
	public void setEtime(String  etime){
		 this.etime=etime;
 	}

	/**
	  * 获取下课时间的值
	 * @return 返回下课时间的值
	**/
	public String getEtime(){
		 return etime;
 	}

	/**
	  * 设置上课时间的值
	 * @param 	stime	 上课时间
	**/
	public void setStime(String  stime){
		 this.stime=stime;
 	}

	/**
	  * 获取上课时间的值
	 * @return 返回上课时间的值
	**/
	public String getStime(){
		 return stime;
 	}

	/**
	  * 设置循环规则值的值
	 * @param 	ruleVals	 循环规则值
	**/
	public void setRuleVals(String  ruleVals){
		 this.ruleVals=ruleVals;
 	}

	/**
	  * 获取循环规则值的值
	 * @return 返回循环规则值的值
	**/
	public String getRuleVals(){
		 return ruleVals;
 	}

	/**
	  * 设置循环规则名称的值
	 * @param 	ruleNames	 循环规则名称
	**/
	public void setRuleNames(String  ruleNames){
		 this.ruleNames=ruleNames;
 	}

	/**
	  * 获取循环规则名称的值
	 * @return 返回循环规则名称的值
	**/
	public String getRuleNames(){
		 return ruleNames;
 	}

	/**
	  * 设置循环规则的值
	 * @param 	rtype	 循环规则
	**/
	public void setRtype(Integer  rtype){
		 this.rtype=rtype;
 	}

	/**
	  * 获取循环规则的值
	 * @return 返回循环规则的值
	**/
	public Integer getRtype(){
		 return rtype;
 	}

	/**
	  * 设置开始日期的值
	 * @param 	startDate	 开始日期
	**/
	public void setStartDate(Date  startDate){
		 this.startDate=startDate;
 	}

	/**
	  * 获取开始日期的值
	 * @return 返回开始日期的值
	**/
	public Date getStartDate(){
		 return startDate;
 	}

	/**
	  * 设置排课类型的值
	 * @param 	ptype	 排课类型
	**/
	public void setPtype(Integer  ptype){
		 this.ptype=ptype;
 	}

	/**
	  * 获取排课类型的值
	 * @return 返回排课类型的值
	**/
	public Integer getPtype(){
		 return ptype;
 	}

	/**
	  * 设置班级ID的值
	 * @param 	classId	 班级ID
	**/
	public void setClassId(Long  classId){
		 this.classId=classId;
 	}

	/**
	  * 获取班级ID的值
	 * @return 返回班级ID的值
	**/
	public Long getClassId(){
		 return classId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{etime,stime,ruleVals,ruleNames,rtype,startDate,ptype,classId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"etime","stime","ruleVals","ruleNames","rtype","startDate","ptype","classId"};
	}

}
