package com.cmw.service.impl;



import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.core.ssm.service.AbsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.cmw.entity.StudentDetailEntity;
import com.cmw.dao.StudentDetailDao;
import com.cmw.service.inter.StudentDetailService;


/**
 * 学员详细信息  Service实现类
 * @author 程明卫
 * @date 2019-04-10 11:39:22
 */
@Description(remark="学员详细信息业务实现类",createDate="2019-04-10 11:39:22",author="程明卫")
@Service("studentDetailService")
public class StudentDetailServiceImpl extends AbsService<StudentDetailEntity, Long> implements  StudentDetailService {
	@Autowired
	private StudentDetailDao studentDetailDao;
	@Override
	public GenericDaoInter<StudentDetailEntity, Long> getDao() {
		return studentDetailDao;
	}

}
