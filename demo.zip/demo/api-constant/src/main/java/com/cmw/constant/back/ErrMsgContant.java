package com.cmw.constant.back;

/**
 * 错误消息常量
 * @author chengmingwei
 * @date 2019-03-27 15:22
 */
public class ErrMsgContant {
    /**
     * 参数ID为空
     */
    public static final String ID_IS_NULL = "参数id为空!";
}
