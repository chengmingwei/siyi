package com.cmw.constant;

/**
 * 短信模板常量
 * @author chengmingwei
 * @date 2019-04-12 16:27
 */
public class SmsTemplateConstant {
    /**
     * 短信登录验证码：T_0001
     */
    public static final String LOGIN_VALID_CODE = "T_0001";
    /**
     * 订单待支付消息模板：T_0002 [校长确认订单后发送给家长支付订单的消息]
     */
    public static final String ORDER_UNPAY_CODE = "T_0002";

    /**
     * 订单待审批消息模板：T_0003  [班主任报名后发送给校长确认的订单消息]
     */
    public static final String ORDER_AUDIT_CODE = "T_0003";

    /**
     * 订单支付成功消息模板：T_0004  [家长支付订单成功后，通知班主任的消息]
     */
    public static final String ORDER_PAYSUCCESS_CODE = "T_0004";

    /**
     * 学生点名(到课)消息模板：T_0005  [学生点名(到课)之后，通知家长的消息]
     */
    public static final String STUDENT_ROLLCALL_CLASS_CODE = "T_0005";

    /**
     * 上课通知消息模板:T_0006 [上课前一天,通知教务的消息]
     */
    public static final String CLASS_NOTICE_TEACHER_CODE = "T_0006";

    /**
     * 上课通知消息模板:T_0007 [上课前一天,通知学生的消息]
     */
    public static final String CLASS_NOTICE_STUDENT_CODE = "T_0007";

    /**
     * 上课通知消息模板:T_0008 [上课前3小时,通知学生的消息]
     */
    public static final String CLASSGO_BEFORE_NOTIFY_CODE = "T_0008";

    /**
     * 机构帐号申请验证码：T_0009
     */
    public static final String APPLY_ACCOUNT_VALID_CODE = "T_0009";
    /**
     * 机构帐号审核通过模板：T_0010
     */
    public static final String APPLY_ACCOUNT_AUDIT_OK = "T_0010";
    /**
     * 机构帐号审核未通过模板：T_0011
     */
    public static final String APPLY_ACCOUNT_AUDIT_NO = "T_0011";
}
