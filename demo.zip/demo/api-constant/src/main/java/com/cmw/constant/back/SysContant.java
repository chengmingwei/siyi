package com.cmw.constant.back;

/**
 * 后台系统系统级常量
 * @Author chengmingwei
 * @Date 2019-03-26 22:49
 */
public class SysContant {
    /**
     * 默认编号
     */
    public static final String DEFAULT_CODE = "00000000";
    /**
     * 定时器开关控制 （true:打开，false:关闭） [cmw : 2020.05.17 12:38]
     */
    public static final boolean  TIMER_FLAG = true;

    /**
     * 可用标识：[删除：-1]
     */
    public static final byte ISENABLED_DEL_1 = -1;

    /**
     * 可用标识：[禁用：0]
     */
    public static final byte ISENABLED_0 = 0;
    /**
     * 可用标识：[启用：0]
     */
    public static final byte ISENABLED_1 = 1;

    /**
     * 当前用户的KEY
     */
    public static final String USER_INFO = "USER_INFO";

    /**
     * 默认后台用户密码
     */
    public static final String DEFAULT_PWD = "88888888";
    /**
     * 创建记录时，记录会员的假部门ID默认值：-7777l
     */
    public static final Long MEMBER_DEFAULT_DEPTID = -7777l;
    /**
     * 创建记录时，记录会员的假公司机构ID默认值：-7777l
     */
    public static final Long MEMBER_DEFAULT_ORGID = -7777l;
    /**
     * 创建记录时，记录会员的假员工ID默认值：-7777l
     */
    public static final Long MEMBER_DEFAULT_EMPID = -7777l;


    /**
     * 创建管理员时，记录创建人ID默认值：-8888l
     */
    public static final Long ADMIN_DEFAULT_CREATE = -8888l;
    /**
     * 创建管理员时，记录部门ID默认值：-8888l
     */
    public static final Long ADMIN_DEFAULT_DEPTID = -8888l;
    /**
     * 创建管理员时，记录公司机构ID默认值：-8888l
     */
    public static final Long ADMIN_DEFAULT_ORGID = -8888l;
    /**
     * 创建管理员时，记录员工ID默认值：-8888l
     */
    public static final Long ADMIN_DEFAULT_EMPID = -8888l;

    /**
     * 创建管理员时，记录创建人ID默认值：-8888l
     */
    public static final Long SYSTEM_DEFAULT_CREATE = -9999l;
    /**
     * 创建管理员时，记录部门ID默认值：-8888l
     */
    public static final Long SYSTEM_DEFAULT_DEPTID = -9999l;
    /**
     * 创建管理员时，记录公司机构ID默认值：-8888l
     */
    public static final Long SYSTEM_DEFAULT_ORGID = -9999l;
    /**
     * 创建管理员时，记录员工ID默认值：-8888l
     */
    public static final Long SYSTEM_DEFAULT_EMPID = -9999l;


}
