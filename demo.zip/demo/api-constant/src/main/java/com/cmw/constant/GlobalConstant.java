package com.cmw.constant;

/**
 * 通知常量
 * @Author chengmingwei
 * @Date 2019-03-23 21:02
 */
public class GlobalConstant {
    public static final String SYS_ERR_MSG = "系统错误,请稍后再试!";

    /**
     * 负载均衡[Feign]专用Action的请求KEY值, 注意：此KEY不允许暴露放到外面, 否则会出现安全漏洞！
     */
    public static final String FEIGN_REQUEST_KEY = "76ed8c7dc828470c86993c66f062ef5f_hscloud$2020";


    /**============= JWT UserModel KEY CODE START ================**/
    /**
     * KEY -> [id:用户ID]
     */
    public static final String JWT_KEY_USER_ID = "id";
    /**
     * KEY -> [userName:用户名]
     */
    public static final String JWT_KEY_USER_USERNAME = "userName";
    /**
     * KEY -> [indeptId:部门ID]
     */
    public static final String JWT_KEY_USER_INDEPTID = "indeptId";
    /**
     * KEY -> [incompId:公司ID]
     */
    public static final String JWT_KEY_USER_INCOMPID = "incompId";
    /**
     * KEY -> [inempId:员工ID]
     */
    public static final String JWT_KEY_USER_INEMPID = "inempId";
    /**
     * KEY -> [utype:用户类型]
     */
    public static final String JWT_KEY_USER_UTYPE = "utype";
    /**============= JWT UserModel KEY CODE END ================**/

    /**============= Redis KEY CODE START ================**/

    /**
     * Redis KEY -> [user_code_phone:短信验证码KEY]
     */
    public static final String REDIS_KEY_VALID_CODE = "user_code_phone";
    /**
     * Redis KEY -> [member_code_phone:短信验证码KEY]
     */
    public static final String REDIS_KEY_MEMBER_VALID_CODE = "member_code_phone";

    /**
     * Redis KEY -> [user_code_phone_expire:短信验证码过期时间KEY]
     */
    public static final String REDIS_KEY_VALID_CODE_EXPIRE = "user_code_phone_expire";

    /**
     * Redis KEY -> [user_code_phone_ip:发验证码的客户端IPKEY]
     */
    public static final String REDIS_KEY_VALID_CODE_IP_EXPIRE = "user_code_phone_ip";

    /**============= Redis KEY CODE END ================**/

    /**============= AMQP KEY CODE START ================**/
    /**
     * Amqp KEY -> [sports.common.queue:通用消息Queue KEY]
     */
    public static final String AMQP_QUEUE_COMMON_KEY = "sports.common.queue";
    /**
     * Amqp KEY -> [sports.common.exchange:通用消息exchange KEY]
     */
    public static final String AMQP_EXCHANGE_COMMON_KEY = "sports.common.exchange";
    /**
     * Amqp KEY -> [common.msg.key:通用消息routingkey KEY]
     */
    public static final String AMQP_ROUTINGKEY_COMMON_KEY = "common.msg.key";

    //-- newest insert, time : 2019-07-03, Begin
    /**
     * Amqp KEY -> [sports.common.queue:通用消息Queue KEY]
     */
    public static final String SCHEDULE_TASK_QUEUE_COMMON_KEY = "schedule.task.common.queue";
    /**
     * Amqp KEY -> [schedule.task.common.exchange:通用消息exchange KEY]
     */
    public static final String SCHEDULE_TASK_COMMON_EXCHANGE = "schedule.task.common.exchange";
    /**
     * Amqp KEY -> [schedule.task.common.key:通用消息routingkey KEY]
     */
    public static final String SCHEDULE_TASK_COMMON_KEY = "schedule.task.common.key";
    //-- newest insert, time : 2019-07-03, END

    //-- newest insert, time : 2019-08-31 16:54, Begin
    /**
     * Amqp KEY -> [sports.common.queue:微信消息Queue KEY]
     */
    public static final String WXMSG_TASK_QUEUE_COMMON_KEY = "wxmsg.task.common.queue";
    /**
     * Amqp KEY -> [schedule.task.common.exchange:通用消息exchange KEY]
     */
    public static final String WXMSG_TASK_COMMON_EXCHANGE = "wxmsg.task.common.exchange";
    /**
     * Amqp KEY -> [schedule.task.common.key:通用消息routingkey KEY]
     */
    public static final String WXMSG_TASK_COMMON_KEY = "wxmsg.task.common.key";
    //-- newest insert, time : 2019-08-31 16:54, END


    //-- newest insert, time : 2019-11-06 17:25, Begin
    /**
     * Amqp KEY -> [synchrouhours.task.queue:课时更新Queue KEY]
     */
    public static final String SYNCHROUHOURS_TASK_QUEUE = "synchrouhours.task.queue";
    /**
     * Amqp KEY -> [synchrouhours.task.exchange:课时更新exchange KEY]
     */
    public static final String SYNCHROUHOURS_TASK_EXCHANGE = "synchrouhours.task.exchange";
    /**
     * Amqp KEY -> [synchrouhours.task.key:课时更新routingkey KEY]
     */
    public static final String SYNCHROUHOURS_TASK_KEY = "synchrouhours.task.key";
    //-- newest insert, time : 2019-11-06 17:25, END

    //-- newest insert, time : 2019-11-12 21:05, Begin
    /**
     * Amqp KEY -> [synchrouhours.task.queue:课时更新Queue KEY]
     */
    public static final String REBULIDCLASSGO_TASK_QUEUE = "rebulidClassGo.task.queue";
    /**
     * Amqp KEY -> [synchrouhours.task.exchange:课时更新exchange KEY]
     */
    public static final String REBULIDCLASSGO_TASK_EXCHANGE = "rebulidClassGo.task.exchange";
    /**
     * Amqp KEY -> [synchrouhours.task.key:课时更新routingkey KEY]
     */
    public static final String REBULIDCLASSGO_TASK_KEY = "rebulidClassGo.task.key";
    //-- newest insert, time : 2019-11-12 21:05, END


    //-- newest insert, time : 2020-03-18, Begin
    /**
     * Amqp Queue KEY -> [task.queue.problem.data.key:异常数据消息 Queue KEY]
     */
    public static final String TASK_QUEUE_PROBLEM_DATA_KEY = "task.queue.problem.data.key";
    /**
     * Amqp exchange -> [task.problem.data.exchange:异常数据消息 exchange KEY]
     */
    public static final String TASK_PROBLEM_DATA_EXCHANGE = "task.problem.data.exchange";
    /**
     * Amqp KEY -> [task.problem.data.key:异常数据消息 routingkey KEY]
     */
    public static final String TASK_PROBLEM_DATA_KEY = "task.problem.data.key";
    //-- newest insert, time : 2020-03-18, END

    //-- cmw insert, time : 2020-09-24 00:40, Begin
    /**
     * Amqp Queue KEY -> [task.queue.order_item.school_update.key:创建订单添加校区消息 Queue KEY]
     */
    public static final String TASK_QUEUE_ORDER_ITEM_SCHOOL_UPDATE_QUEUE = "task.queue.order_item.school_update.queue";
    /**
     * Amqp exchange -> [task.order_item.school_update.exchange:创建订单添加校区消息 exchange KEY]
     */
    public static final String TASK_ORDER_ITEM_SCHOOL_UPDATE_EXCHANGE = "task.order_item.school_update.exchange";
    /**
     * Amqp KEY -> [task.order_item.school_update.key:创建订单添加校区消息 routingkey KEY]
     */
    public static final String TASK_ORDER_ITEM_SCHOOL_UPDATE_KEY = "task.order_item.school_update.key";
    //-- cmw insert, time : 2020-09-24 00:40,  END
    /**============= AMQP KEY CODE END ================**/

    //-- cmw insert, time : 2020-10-11 20:20, Begin
    /**
     * Amqp Queue KEY -> [task.school.order_item_update.queue:添加校区更新订单项关联消息 Queue KEY]
     */
    public static final String TASK_SCHOOL_ORDER_ITEM_UPDATE_QUEUE = "task.school.order_item_update.queue";
    /**
     * Amqp exchange -> [task.school.order_item_update.exchange:添加校区更新订单项关联消息 exchange KEY]
     */
    public static final String TASK_SCHOOL_ORDER_ITEM_UPDATE_EXCHANGE = "task.school.order_item_update.exchange";
    /**
     * Amqp KEY -> [task.school.order_item_update.key:添加校区更新订单项关联消息 routingkey KEY]
     */
    public static final String TASK_SCHOOL_ORDER_ITEM_UPDATE_KEY = "task.school.order_item_update.key";
    //-- cmw insert, time : 2020-10-11 20:20,  END
    /**============= AMQP KEY CODE END ================**/

}
