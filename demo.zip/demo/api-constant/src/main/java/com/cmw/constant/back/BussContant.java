package com.cmw.constant.back;

/**
 * 后台系统业务级常量
 * @Author chengmingwei
 * @Date 2019-03-26 22:49
 */
public class BussContant {
    /**
     *  登录方式[1:帐号登录]
     */
    public static final int LOGIN_TYPE_1 = 1;
    /**
     *  登录方式[2:手机号登录]
     */
    public static final int LOGIN_TYPE_2 = 2;
    /**
     *  小程序教练端openid登录[3:openid登录]
     */
    public static final int LOGIN_TYPE_3 = 3;
    /**
     *  小程序家长端openid登录[4:家长openid登录]
     */
    public static final int LOGIN_TYPE_4 = 4;

    /**============= micro-sports 微服务常量 CODE REGION START ===============**/
    /**----------2.1.1.18.GL_CoursePlan (教学计划表)  常量 CODE START -----------**/
    /**
     *  业务类型  [0 : 课程教学计划]
     */
    public static final int COURSEPLAN_FORMTYPE_0 = 0;
    /**
     *  业务类型  [1 : 排课教学计划]
     */
    public static final int COURSEPLAN_FORMTYPE_1 = 1;
    /**
     *  业务类型   [2 : 课次教学计划]
     */
    public static final int COURSEPLAN_FORMTYPE_2 = 2;
    /**----------2.1.1.18.GL_CoursePlan (教学计划表) 常量 CODE END -----------**/

    /**----------2.1.1.21.GL_TempPlan (课次排班表)  常量 CODE START -----------**/
    /**
     *  课次类型  [1 : 正常课次]
     */
    public static final int TEMPPLAN_CTYPE_1 = 1;
    /**
     *  课次类型   [2 : 临时课次]
     */
    public static final int TEMPPLAN_CTYPE_2 = 2;
    /**
     *
     *  课次类型  [ 3: 循环课次]
     */
    public static final int TEMPPLAN_CTYPE_3 = 3;

    /**
     *
     *  课次排班状态   [ 0: 未到开课时间]
     */
    public static final int TEMPPLAN_XSTATUS_0 = 0;
    /**
     *  课次排班状态   [1 : 已开课]
     */
    public static final int TEMPPLAN_XSTATUS_1 = 1;
    /**
     *  课次排班状态   [2 : 下课]
     */
    public static final int TEMPPLAN_XSTATUS_2 = 2;

    /**---------- 2.1.1.12.GL_Taste (学生体验记录表)  常量 CODE START -----------**/
    /**
     *
     *  来源   [ 0: 销售自挖]
     */
    public static final int TASTE_SOURCE_0 = 0;
    /**
     *  来源   [1 : 家长海报分享引流]
     */
    public static final int TASTE_SOURCE_1 = 1;
    /** ---------- 2.1.1.12.GL_Taste (学生体验记录表)  常量 CODE END -----------**/

    /**---------- 2.1.1.30.GL_Order (订单表)  常量 CODE START -----------**/
    /**
     *  付款方式   [ 0:未知 ]
     */
    public static final int ORDER_PAYTYPE_0 = 0;
    /**
     *  付款方式   [1 : 线下付]
     */
    public static final int ORDER_PAYTYPE_1 = 1;
    /**
     *  付款方式   [2 : 微信]
     */
    public static final int ORDER_PAYTYPE_2 = 2;
    /**
     *  付款方式   [3 : 支付宝]
     */
    public static final int ORDER_PAYTYPE_3 = 3;
    /**---------- 2.1.1.30.GL_Order (订单表)  常量 CODE END -----------**/

    /**---------- 2.1.1.27.GL_Enroll (学生报名表)  常量 CODE START -----------**/

    /**
     *  订单类型   [ 0:新签 ]
     */
    public static final int ENROLL_OTYPE_0 = 0;
    /**
     *  订单类型   [1 : 续签]
     */
    public static final int ENROLL_OTYPE_1 = 1;
    /**
     *  订单类型   [2 : 转课续签]
     */
    public static final int ENROLL_OTYPE_2 = 2;

    /**
     *  购买方式   [ 按课时购买:1 ]
     */
    public static final int ENROLL_BTYPE_1 = 1;
    /**
     *  购买方式   [ 按套餐购买:2 ]
     */
    public static final int ENROLL_BTYPE_2 = 2;

    /**
     *  审批状态   [ 0:待审批 ]
     */
    public static final int ENROLL_AXSTATUS_0 = 0;
    /**
     *  审批状态   [1 : 审批通过]
     */
    public static final int ENROLL_AXSTATUS_1 = 1;
    /**
     *  审批状态   [ 2:不通过 ]
     */
    public static final int ENROLL_AXSTATUS_2 = 2;


    /**
     *  订单状态   [-1:作废]
     */
    public static final int ENROLL_XSTATUS_D1 = -1;
    /**
     *  订单状态   [ 0:待支付 ]
     */
    public static final int ENROLL_XSTATUS_0 = 0;
    /**
     *  订单状态   [1 : 支付成功]
     */
    public static final int ENROLL_XSTATUS_1 = 1;
    /**
     *  订单状态   [ 2:支付失败 ]
     */
    public static final int ENROLL_XSTATUS_2 = 2;
    /**
     *  订单状态   [ 3:已退费 ]
     */
    public static final int ENROLL_XSTATUS_3 = 3;
    /**
     *  订单状态   [ 4:已超时 ]
     */
    public static final int ENROLL_XSTATUS_4 = 4;
    /**
     *  订单状态   [ 5:支付处理中 ]
     */
    public static final int ENROLL_XSTATUS_5 = 5;
    /**---------- 2.1.1.27.GL_Enroll (学生报名表)  常量 CODE END -----------**/

    /**---------- 2.1.1.9. GL_Student (学员信息表)  常量 CODE START -----------**/
    /**
     *  学员状态 状态 [ 未跟进:0 ]
     */
    public static final int STUDENT_XSTATUS_0 = 0;
    /**
     *  学员状态 状态 [ 跟进中:1 ]
     */
    public static final int STUDENT_XSTATUS_1 = 1;
    /**
     *  学员状态 状态 [ 预约体验:2 ]
     */
    public static final int STUDENT_XSTATUS_2 = 2;
    /**
     *  学员状态 状态 [ 已体验:3 ]
     */
    public static final int STUDENT_XSTATUS_3 = 3;
    /**
     *  学员状态 状态 [ 正式学员:4 ]
     */
    public static final int STUDENT_XSTATUS_4 = 4;
    /**
     *  学员状态 状态 [ 历史学员:5 ]
     */
    public static final int STUDENT_XSTATUS_5 = 5;

    /**
     *  学生来源 [ 地推: 1]
     */
    public static final int STUDENT_SOURCE_1 = 1;
    /**
     *  学生来源 [ 转介绍: 2]
     */
    public static final int STUDENT_SOURCE_2 = 2;
    /**
     *  学生来源 [ 官网: 3]
     */
    public static final int STUDENT_SOURCE_3 = 3;
    /**
     *  学生来源 [ 微信: 4]
     */
    public static final int STUDENT_SOURCE_4 = 4;
    /**
     *  学生来源 [ 电话邀约: 5]
     */
    public static final int STUDENT_SOURCE_5 = 5;
    /**
     *  学生来源 [ 门店到访: 6]
     */
    public static final int STUDENT_SOURCE_6 = 6;
    /**
     *  学生来源 [ 其他合作渠道: 7]
     */
    public static final int STUDENT_SOURCE_7 = 7;
    /**
     *  学生来源 [ 其他相关渠道: 8]
     */
    public static final int STUDENT_SOURCE_8 = 8;

    /**---------- 2.1.1.9. GL_Student (学员信息表)  常量 CODE END -----------**/

    /**---------- 2.1.1.23.GL_ClassGo (上课记录表)  常量 CODE START -----------**/
    /**
     *
     *  上课记录 状态 [未到上课时间 : 0]
     */
    public static final int CLASSGO_XSTATUS_0 = 0;
    /**
     *  上课记录 状态 [正常 : 1]
     */
    public static final int CLASSGO_XSTATUS_1 = 1;
    /**
     *  上课记录 状态 [迟到 : 2]
     */
    public static final int CLASSGO_XSTATUS_2 = 2;
    /**
     *  上课记录 状态 [旷课 : 3]
     */
    public static final int CLASSGO_XSTATUS_3 = 3;
    /**
     *  上课记录 状态 [请假 : 4]
     */
    public static final int CLASSGO_XSTATUS_4 = 4;
    /**---------- 2.1.1.23.GL_ClassGo (上课记录表)  常量 CODE END -----------**/

    /**---------- 2.1.1.22.GL_ClassChoose (选/转班表)  常量 CODE START -----------**/
    /**
     *  选/转班 状态 [ 正常:0 ]
     */
    public static final int CLASSCHOOSE_XSTATUS_0 = 0;
    /**
     *  选/转班 状态 [ 已转班: 1]
     */
    public static final int CLASSCHOOSE_XSTATUS_1 = 1;
    /**
     *  选/转班 状态 [ 已结班: 2]
     */
    public static final int CLASSCHOOSE_XSTATUS_2 = 2;
    /**
     *  选/转班 状态 [ 已退出: 3]
     */
    public static final int CLASSCHOOSE_XSTATUS_3 = 3;
    /**---------- 2.1.1.22.GL_ClassChoose (选/转班表)  常量 CODE END -----------**/

    /**---------- ClassSetEntity 排班设置表 常量 CODE START -----------**/
    /**
     *  排课类型 [循环排课 : 1]
     */
    public static final int CLASSSET_PTYPE_1 = 1;
    /**
     *  排课类型 [课次排课 : 2]
     */
    public static final int CLASSSET_PTYPE_2 = 2;

    /**
     *  循环规则 [无 : 0]
     */
    public static final int CLASSSET_RTYPE_0 = 0;

    /**
     *  循环规则 [每天 : 1]
     */
    public static final int CLASSSET_RTYPE_1 = 1;
    /**
     *  循环规则 [每周 : 2]
     */
    public static final int CLASSSET_RTYPE_2 = 2;


    /**
     * 周一名称
     */
    public static final String WEEK_NAME_ONE = "周一";
    /**
     * 周二名称
     */
    public static final String WEEK_NAME_TWO = "周二";
    /**
     * 周三名称
     */
    public static final String WEEK_NAME_THREE = "周三";
    /**
     * 周四名称
     */
    public static final String WEEK_NAME_FOUR = "周四";
    /**
     * 周五名称
     */
    public static final String WEEK_NAME_FIVE = "周五";
    /**
     * 周六名称
     */
    public static final String WEEK_NAME_SIX = "周六";
    /**
     * 周日名称
     */
    public static final String WEEK_NAME_SEVEN = "周日";

    /**
     * 1:周一
     */
    public static final int WEEK_VAL_ONE = 1;
    /**
     * 2：周二
     */
    public static final int WEEK_VAL_TWO = 2;
    /**
     * 3：周三
     */
    public static final int  WEEK_VAL_THREE = 3;
    /**
     * 4：周四
     */
    public static final int  WEEK_VAL_FOUR = 4;
    /**
     * 5：周五
     */
    public static final int  WEEK_VAL_FIVE = 5;
    /**
     * 6：周六
     */
    public static final int  WEEK_VAL_SIX = 6;
    /**
     * 7：周日
     */
    public static final int  WEEK_VAL_SEVEN = 7;
    /**---------- TeacherEntity 排班设置表 常量 CODE END -----------**/

    /**---------- TeacherEntity 老师表 常量 CODE START -----------**/
    /**
     *  教师角色类型 [班主任 : 1]
     */
    public static final byte TEACHER_TTYPE_1 = 1;
    /**
     *  教师角色类型 [教练 : 2]
     */
    public static final byte TEACHER_TTYPE_2 = 2;
    /**
     *  教师角色类型 [校长 : 3]
     */
    public static final byte TEACHER_TTYPE_3 = 3;

    /**---------- TeacherEntity 老师表 常量 CODE END -----------**/


    /**============= micro-sports 微服务常量 CODE REGION END ===============**/


    /**============= micro-sysbase 微服务常量 CODE REGION START ===============**/

    /**---------- OperationLog 用户表 常量 CODE START -----------**/
    /**
     *  操作功能 [LOGIN : 登录]
     */
    public static final String OPERATIONLOG_FUN_LOGIN = "登录";
    /**
     *  操作功能 [EXIT : 登出]
     */
    public static final String OPERATIONLOG_FUN_EXIT = "登出";

    /**
     *  设备类型 [PC : 1]
     */
    public static final int OPERATIONLOG_ISOURCE_1 = 1;
    /**
     *  设备类型 [微信小程序 : 1]
     */
    public static final int OPERATIONLOG_ISOURCE_2 = 2;
    /**
     *  设备类型 [Android : 3]
     */
    public static final int OPERATIONLOG_ISOURCE_3 = 3;
    /**
     *  设备类型 [IOS : 4]
     */
    public static final int OPERATIONLOG_ISOURCE_4 = 4;
    /**---------- OperationLog 用户表 常量 CODE END -----------**/

    /**---------- RoleEntity 用户表 常量 CODE START -----------**/
    /**
     * 角色编号 [机构管理员:R202010100000002]
     */
    public static final String ROLE_CODE_2 = "R202010100000002";
    /**---------- RoleEntity 用户表 常量 CODE END -----------**/


    /**---------- UserEntity 用户表 常量 CODE START -----------**/
    /**
     *  用户类型 [-1:前端会员学生用户]
     */
    public static final int USER_UTYPE_MEMBER = -1;
    /**
     *  用户类型 [1:普通用户]
     */
    public static final int USER_UTYPE_1 = 1;
    /**
     * 用户类型 [2:区域管理员或校长]
     */
    public static final int USER_UTYPE_2 = 2;
    /**
     * 用户类型 [3:超级管理员]
     */
    public static final int USER_UTYPE_3 = 3;
    /**
     * 用户类型 [4:教练]
     */
    public static final int USER_UTYPE_4 = 4;
    /**
     * 用户类型 [5:班主任或销售]
     */
    public static final int USER_UTYPE_5 = 5;
    /**
     * 用户类型 [6:区域管理员]
     */
    public static final int USER_UTYPE_6 = 6;
    /**
     * 用户类型 [7:财务]
     */
    public static final int USER_UTYPE_7 = 7;

    /**
     *  数据访问级别 [5:本公司数据]
     */
    public static final int USER_DATA_LEVEL_5 = 5;
    /**---------- UserEntity 用户表 常量 CODE END -----------**/

    /**---------- CompanyEntity 公司表 常量 CODE START -----------**/
    /**
     *  隶属关系 [0:总公司]
     */
    public static final int COMPANY_AFFILIATION_0 = 0;
    /**
     *  隶属关系 [1:分公司]
     */
    public static final int COMPANY_AFFILIATION_1 = 1;
    /**
     *  公司性质 [0:自有公司]
     */
    public static final int COMPANY_NTYPE_0 = 0;
    /**
     *  公司性质 [1:机构客户]
     */
    public static final int COMPANY_NTYPE_1 = 1;
    /**
     *  公司性质 [2:代理商]
     */
    public static final int COMPANY_NTYPE_2 = 2;

    /**
     *  上级单位类型 [0:无上张斌]
     */
    public static final int COMPANY_POTYPE_0 = 0;
    /**
     *  上级单位类型 [1:公司]
     */
    public static final int COMPANY_POTYPE_1 = 1;
    /**
     *  上级单位类型 [2:部门]
     */
    public static final int COMPANY_POTYPE_2 = 2;

    /**---------- CompanyEntity 公司表 常量 CODE END -----------**/


    /**---------- MsgEntity 消息表 常量 CODE START -----------**/

    /**
     *  消息状态 [0:处理中]
     */
    public static final int MSG_XSTATUS_0 = 0;
    /**
     * 消息状态 [1:成功]
     */
    public static final int MSG_XSTATUS_1 = 1;
    /**
     * 消息状态 [2:失败]
     */
    public static final int MSG_XSTATUS_2 = 2;

    /**
     *  阅读状态 [0:未读]
     */
    public static final int MSG_RSTATUS_0 = 0;
    /**
     * 阅读状态 [1:已读]
     */
    public static final int MSG_RSTATUS_1 = 1;

    /**
     *  消息类型 [1:站内消息]
     */
    public static final int MSG_MTYPE_1 = 1;
    /**
     * 消息类型 [2:短消息]
     */
    public static final int MSG_MTYPE_2 = 2;
    /**
     * 消息类型 [3:邮件消息]
     */
    public static final int MSG_MTYPE_3 = 3;
    /**
     * 消息类型 [4:其它消息]
     */
    public static final int MSG_MTYPE_4 = 4;

    /**
     * 消息接收人类型 [1:老师或系统用户] --> Ts_User 表 userId
     */
    public static final int MSG_RTYPE_1 = 1;
    /**
     * 消息接收人类型 [2:学生家长] --> GL_Member 表 memberId
     */
    public static final int MSG_RTYPE_2 = 2;

    /**
     * 消息业务类型 [1:学生上课提前通知] --> GL_ClassGo 表 Id
     */
    public static final int MSG_FORM_TYPE_1 = 1;

    /**
     * 消息业务编号 [2:老师上课提前通知] --> GL_TempPlan 表 Id
     */
    public static final int MSG_FORM_TYPE_2 = 2;

    /**
     * 消息业务编号 [3:学生提前X小时通知] --> GL_ClassGo 表 Id
     */
    public static final int MSG_FORM_TYPE_3 = 3;


    /**---------- MsgEntity 消息表 常量 CODE END -----------**/

    /**---------- 2.1.1.49.ts_ProdDiscount (Saas产品折扣表) 常量 CODE START -----------**/
    /**
     * 优惠方式 [1:按折扣]
     */
    public static final byte PRODDISCOUNT_PREWAY_1 = 1;
    /**
     * 优惠方式 [2:按现金]
     */
    public static final byte PRODDISCOUNT_PREWAY_2 = 2;

    /**---------- 2.1.1.49.ts_ProdDiscount (Saas产品折扣表) 常量 CODE END -----------**/



    /**---------- 2.1.1.50.Ts_OrgCustomer (机构客户信息表) 常量 CODE START -----------**/
    /**
     * 是否试用状态 [1:是]
     */
    public static final byte ORGCUSTOMER_TRYFLAG_1 = 1;

    /**
     * 是否试用状态 [2:否]
     */
    public static final byte ORGCUSTOMER_TRYFLAG_2 = 2;

    /**
     * 审批状态 [0:待审批]
     */
    public static final int ORGCUSTOMER_XSTATUS_0 = 0;
    /**
     * 审批状态 [1:审批通过]
     */
    public static final int ORGCUSTOMER_XSTATUS_1 = 1;

    /**
     * 审批状态 [2:审批不通过]
     */
    public static final int ORGCUSTOMER_XSTATUS_2 = 2;

    /**
     * 跟进状态 [1:待跟进]
     */
    public static final int ORGCUSTOMER_FSTATUS_1 = 1;

    /**
     * 跟进状态 [2:已跟进]
     */
    public static final int ORGCUSTOMER_FSTATUS_2 = 2;
    /**
     * 跟进状态 [3:已跟进]
     */
    public static final int ORGCUSTOMER_FSTATUS_3 = 3;

    /**---------- 2.1.1.50.Ts_OrgCustomer (机构客户信息表) 常量 CODE END -----------**/

    /**---------- 2.1.1.52.ts_CustOrder (订单表)常量 CODE START -----------**/
    /**
     * 业务类型 [1:标准产品购买]
     */
    public static final int CUSTORDER_BUSSTYPE_1 = 1;
    /**
     * 业务类型 [2:校区点位购买]
     */
    public static final int CUSTORDER_BUSSTYPE_2 = 2;

    /**
     * 付款方式 [0:未知]
     */
    public static final int CUSTORDER_PAYTYPE_0 = 0;
    /**
     * 付款方式 [1:线下付]
     */
    public static final int CUSTORDER_PAYTYPE_1 = 1;
    /**
     * 付款方式 [2:微信]
     */
    public static final int CUSTORDER_PAYTYPE_2 = 2;
    /**
     * 付款方式 [3:支付宝]
     */
    public static final int CUSTORDER_PAYTYPE_3 = 3;
    /**
     * 付款方式 [4:第三方快捷支付]
     */
    public static final int CUSTORDER_PAYTYPE_4 = 4;
    /**
     * 付款方式 [5:对公支付]
     */
    public static final int CUSTORDER_PAYTYPE_5 = 5;

    /**
     * 审批状态 [0:待审批]
     */
    public static final int CUSTORDER_AXSTATUS_0 = 0;
    /**
     * 审批状态 [1:审批通过]
     */
    public static final int CUSTORDER_AXSTATUS_1 = 1;
    /**
     * 审批状态 [2:不通过]
     */
    public static final int CUSTORDER_AXSTATUS_2 = 2;

    /**
     * 订单状态 [-1:]
     */
    public static final int CUSTORDER_XSTATUS_F1 = -1;
    /**
     * 订单状态 [0:]
     */
    public static final int CUSTORDER_XSTATUS_0 = 0;
    /**
     * 订单状态 [1:]
     */
    public static final int CUSTORDER_XSTATUS_1 = 1;
    /**
     * 订单状态 [2:]
     */
    public static final int CUSTORDER_XSTATUS_2 = 2;
    /**
     * 订单状态 [3:]
     */
    public static final int CUSTORDER_XSTATUS_3 = 3;
    /**
     * 订单状态 [4:]
     */
    public static final int CUSTORDER_XSTATUS_4 = 4;
    /**
     * 订单状态 [5:]
     */
    public static final int CUSTORDER_XSTATUS_5 = 5;
    /**
     * 订单状态 [6:]
     */
    public static final int CUSTORDER_XSTATUS_6 = 6;

    /**
     * 订单类型 [0:新签]
     */
    public static final int CUSTORDER_OTYPE_0 = 0;
    /**
     * 订单类型 [1:续签]
     */
    public static final int CUSTORDER_OTYPE_1 = 1;

    /**
     * 设备来源 [0:未知]
     */
    public static final int CUSTORDER_PSOURCE_0 = 0;
    /**
     * 设备来源 [1:微信小程序]
     */
    public static final int CUSTORDER_PSOURCE_1 = 1;
    /**
     * 设备来源 [2:PC]
     */
    public static final int CUSTORDER_PSOURCE_2 = 2;
    /**
     * 设备来源 [3:手机APP]
     */
    public static final int CUSTORDER_PSOURCE_3 = 3;
    /**---------- 2.1.1.52.ts_CustOrder (订单表)常量 CODE END -----------**/

    /**============= micor-sysbase 微服务常量 CODE REGION END ===============**/

    /**============= micro-schedule & micro-msg 微服务常量  [cmw:2020-03-18 11:16] CODE REGION START ===============**/
    /**
     * 异常数据类型：剩余课时不相同比对 [cmw:2020-03-18 11:16]
     */
    public static final int ACTION_TYPE_1 = 1;

    /**============= micro-schedule & micro-msg 微服务常量  [cmw:2020-03-18 11:16] CODE REGION END ===============**/
}
