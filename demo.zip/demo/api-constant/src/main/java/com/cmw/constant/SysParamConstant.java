package com.cmw.constant;

/**
 * @ClassName SysParamConstant
 * @Description: 系统参数常量
 * @Author cheng
 * @Date 2019/10/23
 * @Version V1.0
 **/
public class SysParamConstant {
    /**
     * 系统参数Redis Key 前缀
     */
    public  static final String REDIS_PREFIX = "SysParam_";
    /**
     * 微信及短信消息发送开关
     *  CMW ADD Time: 2019-10-09 13:30
     */
    public static final String SEND_SMS$WX_FLAG = "SEND_SMS$WX_FLAG";
    /**
     * 微信及短信消息发送开关 [1:打开消息发送,0或null 关闭消息发送]
     *  CMW ADD Time: 2019-10-09 13:30
     */
    public static final String SEND_SMS$WX_FLAG_DEFAULT_VAL = "1";

    /**
     * 上课提前多长时间通知
     *  CMW ADD Time: 2019-10-09 23:14
     */
    public static final String TIME_CLASSGO_NOTIFY = "TIME_CLASSGO_NOTIFY";
    /**
     * 上课默认提前3小时通知
     */
    public static final String TIME_CLASSGO_NOTIFY_DEFAULT_VAL = "3";

    /**
     * 微信小程序家长端是否强制微信认证
     */
    public static final String RECODE_PARENT_MUST_AUTH = "PARENT_MUST_AUTH";

    /**
     * 微信小程序家长端是否强制微信认证 [1:登录后不用进行微信认证;null或0则强制微信认证]
     */
    public static final String RECODE_PARENT_MUST_AUTH_VAL_1 = "1";

    /**
     * 微信小程序家长端是否强制微信认证 [null或0 ： 则强制微信认证]
     */
    public static final String RECODE_PARENT_MUST_AUTH_VAL_0 = "0";

    /**
     * 排课时是否删除全部未上课记录 KEY
     */
    public static final String CLASSSET_CLASSGO_TYPEDEL = "CLASSSET_CLASSGO_TYPEDEL";

    /**
     * 排课时是否删除全部未上课记录 VAL [0或null 则删除当前时间以后的所有未上课的记录]
     */
    public static final String CLASSSET_CLASSGO_TYPEDEL_VAL_0 = "0";
    /**
     * 排课时是否删除全部未上课记录 VAL [1:删除所有未上课的记录]
     */
    public static final String CLASSSET_CLASSGO_TYPEDEL_VAL_1 = "1";

    /**
     * 排课时是否删除全部未上课记录 VAL [2:删除所有已上或未上课的记录]
     */
    public static final String CLASSSET_CLASSGO_TYPEDEL_VAL_2 = "2";


    /**
     * 正常点名限制 KEY
     * 点名限制[1:没有到上课时间，老师点名限制为不能点,2:上课开始时间之前多久可以点名,3:不限制(随时都可以点名)]
     */
    public static final String ROLL_CALL_RESTRICTION = "ROLL_CALL_RESTRICTION";


    /**
     * 正常点名限制 [1:没有到上课时间,老师点名限制为不能点]
     */
    public static final String ROLL_CALL_RESTRICTION_VAL_1 = "1";

    /**
     * 正常点名限制 [2:上课开始时间之前多久可以点名]
     */
    public static final String ROLL_CALL_RESTRICTION_VAL_2 = "2";


    /**
     * 正常点名限制 [3:不限制(随时都可以点名)]
     */
    public static final String ROLL_CALL_RESTRICTION_VAL_3 = "3";


    /**
     * 上课提前点名的有效时间 KEY
     * 在正常上课时间前多长时间内可以点名，对应【正常点名限制：ROLL_CALL_RESTRICTION的值：2】
     */
    public static final String ROLL_BEFORE_TIME = "ROLL_BEFORE_TIME";

    /**
     * 上课提前点名的有效时间默认可提前30分钟点名
     * 在正常上课时间前多长时间内可以点名，对应【正常点名限制：ROLL_CALL_RESTRICTION的值：2】
     */
    public static final String ROLL_BEFORE_TIME_VAL = "0:30";


    /**
     * 过期点名限制 KEY
     * 过期点名[1:当天以内可以点名,2:到期上课时间多少天内可以点名,3:不限制]
     */
    public static final String ROOLL_CALL_EXPIRE = "ROOLL_CALL_EXPIRE";


    /**
     * 过期点名限制 [1:当天以内可以点名]
     */
    public static final String ROOLL_CALL_EXPIRE_VAL_1 = "1";

    /**
     * 过期点名限制 [2:到期上课时间多少天内可以点名]
     */
    public static final String ROOLL_CALL_EXPIRE_VAL_2 = "2";


    /**
     * 过期点名限制 [3:不限制]
     */
    public static final String ROOLL_CALL_EXPIRE_VAL_3 = "3";

    /**
     * 过期点名的有效天数
     * 当上课时间到期时间结束后多少天内可以点名，对应【过期点名限制：ROOLL_CALL_EXPIRE的值：2】
     */
    public static final String ROLL_EXPIRE_TIME = "ROLL_EXPIRE_TIME";

    /**
     * 过期点名的有效天数默认到期日期3天内还可以点名
     * 当上课时间到期时间结束后多少天内可以点名，对应【过期点名限制：ROOLL_CALL_EXPIRE的值：2】
     */
    public static final String ROLL_EXPIRE_TIME_VAL = "3";


    /**
     * 帮校云Saas官网地址
     * 当机构客户试用申请通过后，会将帮校云Saas官网地址发给客户手机上，方便其登录体验
     */
    public static final String HOME_WEBSITE = "HOME_WEBSITE";

    /**
     *  帮校云Saas官网地址 ，默认值：https://www.vip-xy.com
     当机构客户试用申请通过后，会将帮校云Saas官网地址发给客户手机上，方便其登录体验
     */
    public static final String HOME_WEBSITE_VAL = "https://www.vip-xy.com";

    /**
     * 试用帐号体验天数
     * 试用申请通过后。默认帮校云平台，试用帐号体验天数
     */
    public static final String ACCOUNT_TRY_DAYS = "ACCOUNT_TRY_DAYS";

    /**
     * 试用帐号体验天数， 默认：7天
     * 试用申请通过后。默认帮校云平台，试用帐号体验天数
     */
    public static final String ACCOUNT_TRY_DAYS_VAL = "7";



    /**
     *  产品续费时，购买单个校区的价格。
     */
    public static final String ONE_SCHOOL_PRICE = "ONE_SCHOOL_PRICE";

    /**
     * 产品续费时，购买单个校区的价格， 默认：500元
     *
     */
    public static final String ONE_SCHOOL_PRICE_VAL = "500";

    /**
     * 需要拦截的加权限的Mybatis map 方法
     * 如果 redis中KEY以 MAP 开头，则以HashMap 的方法存储
     */
    public static final String MAP_RIGHT_METHODS = "MAP:RIGHT_METHODS:%s";
    /**
     * 不需要拦截的加权限的Mybatis map 方法
     * 如果 redis中KEY以 MAP 开头，则以HashMap 的方法存储
     */
    public static final String MAP_NOT_RIGHT_METHODS = "MAP:NOT_RIGHT_METHODS:%s";

    /**
     * 系统记录缓存KEY
     */
    public static final String SYSTEM_KEY = "SYSTEM:%s";

    /**
     * Saas产品记录缓存KEY
     */
    public static final String SAASPRODUCT_KEY = "SAASPRODUCT:%s";

    /**
     * 基础数据记录缓存KEY
     */
    public static final String GVLIST_KEY = "GVLIST:%s";

    /**
     * 返回系统参数recode 引用键
     * @param recode
     * @return
     */
    public static final String getKey(String recode){
        return REDIS_PREFIX+recode;
    }
}
