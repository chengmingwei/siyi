package com.cmw.util;

import com.cmw.constant.GlobalConstant;
import com.cmw.model.back.UserModel;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.joda.time.DateTime;

import java.security.PrivateKey;
import java.security.PublicKey;

/**
 *
 * @author: chengmingwei
 * @create: 2019-03-27 21:42
 **/
public class JwtUtils {
    /**
     * 私钥加密token
     *
     * @param userInfo      载荷中的数据
     * @param privateKey    私钥
     * @param expireMinutes 过期时间，单位秒
     * @return
     * @throws Exception
     */
    public static String generateToken(UserModel userInfo, PrivateKey privateKey, int expireMinutes) throws Exception {
        return Jwts.builder()
                .claim(GlobalConstant.JWT_KEY_USER_ID, userInfo.getId())
                .claim(GlobalConstant.JWT_KEY_USER_USERNAME, userInfo.getUserName())
                .claim(GlobalConstant.JWT_KEY_USER_INCOMPID, userInfo.getIncompId())
                .claim(GlobalConstant.JWT_KEY_USER_INDEPTID, userInfo.getIndeptId())
                .claim(GlobalConstant.JWT_KEY_USER_INEMPID, userInfo.getInempId())
                .claim(GlobalConstant.JWT_KEY_USER_UTYPE, userInfo.getUtype())
                .setExpiration(DateTime.now().plusDays(expireMinutes).toDate())
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .compact();
    }

    /**
     * 私钥加密token
     *
     * @param userInfo      载荷中的数据
     * @param privateKey    私钥字节数组
     * @param expireMinutes 过期时间，单位秒
     * @return
     * @throws Exception
     */
    public static String generateToken(UserModel userInfo, byte[] privateKey, int expireMinutes) throws Exception {
        PrivateKey privateKeyObj = RsaUtils.getPrivateKey(privateKey);
        return generateToken(userInfo, privateKeyObj, expireMinutes);
    }

    /**
     * 公钥解析token
     *
     * @param token     用户请求中的token
     * @param publicKey 公钥
     * @return
     * @throws Exception
     */
    private static Jws<Claims> parserToken(String token, PublicKey publicKey) {
        return Jwts.parser().setSigningKey(publicKey).parseClaimsJws(token);
    }

    /**
     * 公钥解析token
     *
     * @param token     用户请求中的token
     * @param publicKey 公钥字节数组
     * @return
     * @throws Exception
     */
    private static Jws<Claims> parserToken(String token, byte[] publicKey) throws Exception {
        PublicKey publicKeyObj = RsaUtils.getPublicKey(publicKey);
        return parserToken(token, publicKeyObj);
    }

    /**
     * 获取token中的用户信息
     *
     * @param token     用户请求中的令牌
     * @param publicKey 公钥
     * @return 用户信息
     * @throws Exception
     */
    public static UserModel getInfoFromToken(String token, PublicKey publicKey) throws Exception {
        Jws<Claims> claimsJws = parserToken(token, publicKey);
        Claims body = claimsJws.getBody();
        return new UserModel(
                ObjectUtils.toLong(body.get(GlobalConstant.JWT_KEY_USER_ID)),
                ObjectUtils.toString(body.get(GlobalConstant.JWT_KEY_USER_USERNAME)),
                ObjectUtils.toLong(body.get(GlobalConstant.JWT_KEY_USER_INDEPTID)),
                ObjectUtils.toLong(body.get(GlobalConstant.JWT_KEY_USER_INCOMPID)),
                ObjectUtils.toLong(body.get(GlobalConstant.JWT_KEY_USER_INEMPID)),
                ObjectUtils.toInt(body.get(GlobalConstant.JWT_KEY_USER_UTYPE))
        );
    }

    /**
     * 获取token中的用户信息
     *
     * @param token     用户请求中的令牌
     * @param publicKey 公钥
     * @return 用户信息
     * @throws Exception
     */
    public static UserModel getInfoFromToken(String token, byte[] publicKey) throws Exception {
        PublicKey publicKeyObj = RsaUtils.getPublicKey(publicKey);
        return getInfoFromToken(token, publicKeyObj);
    }
}