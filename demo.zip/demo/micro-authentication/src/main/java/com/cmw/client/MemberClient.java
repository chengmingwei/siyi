package com.cmw.client;

import com.alibaba.fastjson.JSONArray;
import com.cmw.model.back.UserModel;
import com.cmw.model.global.ResultModel;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 *
 * @Author: chengmingwei
 * @Time: 2019-04-30 08:14
 * @Feature: 会员feignclient
 */
@FeignClient(value = "micro-sports")
public interface MemberClient {
    /**
     * 获取老师详细页面
     * @param id 记录ID
     * @return
     */
    @GetMapping(value = "/teacher/info")
    ResultModel<Map<String, Object>> getTeacherInfo(@RequestParam("id") Long id);

    /**
     * 获取学生详细页面
     * @param id 记录ID
     * @return
     */
    @GetMapping(value = "/student/info")
    ResultModel<Map<String, Object>> getStudentInfo(@RequestParam("id") Long id);

    /**
     * 通过 openid 会员用户验证 /member/login
     *
     * @param openid
     * @return
     */
    @GetMapping("/member/loginbyopenid")
    ResultModel<UserModel> login(@RequestParam("openid") String openid, @RequestParam(value="memberId", required = false) Long memberId);

    /**
     * 会员登录验证
     * @param username  用户名
     * @param password  密码
     * @param ltype  登录方式
     * @param ipAddr    IP
     * @param isource   设备类型 See BussConstant.OPERATION_ISOURCE
     * @param openid
     * @return  返回用户Model对象
     */
    @GetMapping("/member/login")
    JSONArray login(@RequestParam("username") String username,
                    @RequestParam("password") String password,
                    @RequestParam("ltype") Integer ltype,
                    @RequestParam("ipAddr") String ipAddr,
                    @RequestParam("isource") Integer isource,
                    @RequestParam("openid") String openid);
}
