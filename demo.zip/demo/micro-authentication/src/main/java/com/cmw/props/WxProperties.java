package com.cmw.props;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * @Author: chengmingwei
 * @Time: 2019-05-10 14:33
 * @Feature: 微信配置参数
 *
 */
@Configuration
@RefreshScope
@Data
public class WxProperties {
    /**
     * 小程序 appid
     */
    @Value("${wx.appid}")
    private String appId;

    /**
     * mchid    商户号
     */
    @Value("${wx.mchid}")
    private String mchId;

    /**
     * AppSecret(小程序密钥)
     */
    @Value("${wx.sercet.key}")
    private String sercetKey;

    /**
     * API密钥(支付相关)
     */
    @Value("${wx.sercet.api}")
    private String sercetApi;

    /**
     * APIv3密钥(支付相关)
     */
    @Value("${wx.sercet.apiv3}")
    private String getSercetApiv3;

    /**
     * 获取openId的URL
     */
    @Value("${wx.url.openidUrl}")
    private String openidUrl;


}
