package com.cmw.client;

import com.alibaba.fastjson.JSONArray;
import com.cmw.model.back.UserModel;
import com.cmw.model.global.ResultModel;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 *
 * @Author: chengmingwei
 * @Time: 2019-08-27 10:50
 * @Feature: 消息feignclient
 */
@FeignClient(value = "micro-msg")
public interface MsgClient {
    /**
     * 用户类型：[1：家长]
     */
    public final static Integer UTYPE_MEMBER = 1;
    /**
     * 用户类型：[2：用户]
     */
    public final static Integer UTYPE_USER = 2;

    /**
     * 获取登录用户是否关注公众号
     * @param utype 用户类型 [1:家长学生,2:老师]
     * @param memberId  当 utype=1 -> gl_member表ID , 2 -> ts_user 表 userId
     * @return  返回Integer [0:未关注,1：已关注]
     */
    @GetMapping(value = "/subscribe")
    Integer subscribe(@RequestParam("utype") Integer utype,
                           @RequestParam("memberId") Long memberId);

    /**
     * 将登录后的用户与已关注的微信用户信息进行绑定
     * @param unionid 联合唯一ID
     * @param utype 用户类型 [1:家长学生,2:老师]
     * @param memberId  当 utype=1 -> gl_member表ID , 2 -> ts_user 表 userId
     * @return
     */
    @GetMapping(value = "/bind")
    ResultModel<Map<String, String>> bind(@RequestParam("unionid") String unionid, @RequestParam("utype") Integer utype,
                                          @RequestParam("memberId") Long memberId);
  }
