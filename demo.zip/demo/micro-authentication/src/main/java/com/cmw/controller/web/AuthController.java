package com.cmw.controller.web;

import com.cmw.client.MemberClient;
import com.cmw.client.MsgClient;
import com.cmw.client.UserClient;
import com.cmw.constant.SysParamConstant;
import com.cmw.constant.back.BussContant;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.model.back.UserModel;
import com.cmw.model.global.ResultModel;
import com.cmw.model.global.ResultUtil;
import com.cmw.props.JwtProperties;
import com.cmw.service.inter.AuthService;
import com.cmw.util.CookieUtils;
import com.cmw.util.JwtUtils;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @Author: 98050
 * @Time: 2018-10-23 22:43
 * @Feature: 登录授权
 */
@Slf4j
@RestController
//@EnableConfigurationProperties(JwtProperties.class)
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private JwtProperties properties;

    @Autowired
    private MemberClient memberClient;



    /**
     * openid登录授权
     * @param ltype  登录方式{3:教练端openid登录,4:家长端openid登录}
     * @param code  微信用来换取openid的code{必填}
     * @param encryptedData     微信加密数据
     * @param request
     * @param response
     * @return
     */
    @PostMapping("/login")
    public ResultModel<Map<String, Object>> authenticationByMember(
            @RequestParam(value = "ltype",defaultValue = BussContant.LOGIN_TYPE_4+"", required = false) Integer ltype,
            @RequestParam(value="code", required = false) String code, @RequestParam(value="memberId", required = false) Long memberId,
            @RequestParam(value="encryptedData", required = false) String encryptedData,
            @RequestParam(value="iv", required = false) String iv,
            HttpServletRequest request,
            HttpServletResponse response){
        log.info("ltype="+ltype+", code="+code+", encryptedData="+encryptedData+",memberId="+memberId+", iv="+iv);
        String ipAddr = PageHandler.getIpAddr(request);
        Integer isource = null;
        if(!StringHandler.isValidIntegerNull(isource)){
            isource = BussContant.OPERATIONLOG_ISOURCE_2;
        }
        try{
            if(!StringHandler.isValidStr(code) &&
                    !StringHandler.isValidObj(memberId)){
                return ResultUtil.getFailure("参数: code 和 memberId 两者必须有一个要传入参数!");
            }

            //1.登录校验
            Map<String,Object> dataMap = this.authService.authenticationByCode(ltype,code, memberId,encryptedData,iv);
            if (null == dataMap || dataMap.size() == 0){
                return ResultUtil.getFailure("通过code换取openid失败");
            }
            String token = (String)dataMap.get("token");

            //2.将token写入cookie，并指定httpOnly为true，防止通过js获取和修改
            String cookieName = properties.getCookieName();
            Integer cookieMaxage = properties.getCookieMaxAge();
            CookieUtils.setCookie(request,response,cookieName,token,cookieMaxage,true);
            if(!StringUtils.isEmpty(token)){
                dataMap.remove("token");
                dataMap.put(cookieName, token);
                dataMap.put("maxAge", cookieMaxage);
            }
            return ResultUtil.getSuccess(dataMap);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return ResultUtil.getFailure(ex.getMessage());
        }

    }




    /**
     * 登录授权
     * @param username  用户名或手机号{必填}
     * @param password  密码或短信验证码{必填}
     * @param vcode     图形验证码{选填，预留字段}
     * @param request
     * @param response
     * @return
     */
    @PostMapping("/member/accredit")
    public ResponseEntity<Map<String, Object>> authenticationByMember(
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            @RequestParam(name="vcode",required = false) String vcode,
            @RequestParam(name="openid",required = false) String openid,
            @RequestParam(name="ltype", required = false) Integer ltype,  //  newest add code, time : 2019-07-11 11:50, is login type
            HttpServletRequest request,
            HttpServletResponse response
    ){
        if(!StringHandler.isValidObj(ltype) || (BussContant.LOGIN_TYPE_1 != ltype && BussContant.LOGIN_TYPE_2 != ltype)){
            ltype = BussContant.LOGIN_TYPE_2;
        }

        String ipAddr = PageHandler.getIpAddr(request);
        Integer isource = null;
        if(!StringHandler.isValidIntegerNull(isource)){
            isource = BussContant.OPERATIONLOG_ISOURCE_2;
        }

        //1.登录校验
        Map<String,Object> dataMap = this.authService.authenticationByMember(username,password, ltype, ipAddr, isource, openid);
        if(null == dataMap || dataMap.isEmpty()){ //找不到用户信息
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
        Boolean isMore = (Boolean)dataMap.get("isMore");
        if(null == isMore || !isMore){
            String token = (String)dataMap.get("token");
            if (StringUtils.isBlank(token)){
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            }
            //2.将token写入cookie，并指定httpOnly为true，防止通过js获取和修改
            String cookieName = properties.getCookieName();
            Integer cookieMaxage = properties.getCookieMaxAge();
            CookieUtils.setCookie(request,response,cookieName,token,cookieMaxage,true);

            if(!StringUtils.isEmpty(token)){
                dataMap.remove("token");
                dataMap.put(cookieName, token);
                dataMap.put("maxAge", cookieMaxage);
            }
        }
        return ResponseEntity.ok(dataMap);
    }



    /**
     * 系统后台登录授权
//     * @param  ltype    登录方式{选填，默认为：1}[1:帐号登录,2:手机号登录]
//     * @param username  用户名或手机号{必填}
//     * @param password  密码或短信验证码{必填}
//     * @param vcode     图形验证码{选填，预留字段}
//     * @param isource   设备类型 {选填，默认为：1}[1:PC,2:微信小程序,3:Android,4:IOS]
//     * @param request
//     * @param response
     * @return
     */
    @PostMapping("sys/accredit")
    public ResponseEntity<Map<String, Object>> sys_authentication(@RequestBody  Map<String,String> param,HttpServletRequest request,
                                                                  HttpServletResponse response){
        String username = param.get("username");
        String password = param.get("password");
        String ltypeStr = param.get("ltype");
        Integer ltype = null;
        if(StringHandler.isValidStr(ltypeStr)) ltype = Integer.parseInt(ltypeStr);
        return (ResponseEntity<Map<String, Object>>) authentication(ltype, username, password, null, null, request, response);
    }

    /**
     * 登录授权
     * @param  ltype    登录方式{选填，默认为：1}[1:帐号登录,2:手机号登录]
     * @param username  用户名或手机号{必填}
     * @param password  密码或短信验证码{必填}
     * @param vcode     图形验证码{选填，预留字段}
     * @param isource   设备类型 {选填，默认为：1}[1:PC,2:微信小程序,3:Android,4:IOS]
     * @param request
     * @param response
     * @return
     */
    @PostMapping("accredit")
    public ResponseEntity<Map<String, Object>> authentication(
            @RequestParam(name = "ltype",required = false) Integer ltype,
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            @RequestParam(name="vcode",required = false) String vcode,
            @RequestParam(name="isource",required = false) Integer isource,
            HttpServletRequest request,
            HttpServletResponse response
    ){
        try{
            if(!StringHandler.isValidIntegerNull(ltype)){
                ltype = BussContant.LOGIN_TYPE_1;
            }
            String ipAddr = PageHandler.getIpAddr(request);
            if(!StringHandler.isValidIntegerNull(isource)){
                isource = BussContant.OPERATIONLOG_ISOURCE_1;
            }
            //1.登录校验
            Map<String,Object> dataMap = this.authService.authentication(username,password, ltype, ipAddr, isource, null);
            String token = (String)dataMap.get("token");
            if (StringUtils.isBlank(token)){
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            }
            List<String[]> uroles = (List<String[]>)dataMap.get("uroles");
            Integer subscribe = (Integer) dataMap.get("subscribe");
            //2.将token写入cookie，并指定httpOnly为true，防止通过js获取和修改
            String cookieName = properties.getCookieName();
            Integer cookieMaxage = properties.getCookieMaxAge();
            CookieUtils.setCookie(request,response,cookieName,token,cookieMaxage,true);
            Map<String, Object> tokenMap = new HashMap<String, Object>();
            tokenMap.put(cookieName, token);
            tokenMap.put("uroles", uroles);
            tokenMap.put("maxAge", cookieMaxage);
            tokenMap.put("subscribe", subscribe);
            tokenMap.put("userRoles_Original", dataMap.get("userRoles_Original"));

            return ResponseEntity.ok(tokenMap);
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }


    /**
     *
     * 当选择完角色后，调用此方法重新获取Tokcen 并替换前端 localStorage 中的 tocken
     * @param
     * @return
     */
    @PostMapping("setutype")
    public ResponseEntity<Map<String,Object>> setutype(HttpServletRequest request,
                                                         HttpServletResponse response,
                                                         @RequestParam(value = "utype",required = false) Integer utype){
        try{
            String token = CookieUtils.getCookieValue(request,"TXR_USER_TOKEN");
            if(StringUtils.isEmpty(token)){
                token = request.getHeader("TXR_USER_TOKEN");
            }
            //1.从token中解析token信息
            UserModel userInfo = JwtUtils.getInfoFromToken(token,this.properties.getPublicKey());
            if(null != utype && utype.intValue() > 0){
                userInfo.setUtype(utype);
            }
            //2.解析成功要重新刷新token
            token = JwtUtils.generateToken(userInfo,this.properties.getPrivateKey(),this.properties.getExpire());
            Integer cookieMaxage = this.properties.getCookieMaxAge();
            //4.解析成功返回用户信息
            Map<String,Object> dataMap = new HashMap<>();
            dataMap.put(this.properties.getCookieName(),token);
            dataMap.put("maxAge", cookieMaxage);
            return ResponseEntity.ok(dataMap);
        }catch (Exception e){
            e.printStackTrace();
        }
        //5.出现异常,相应401
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    /**
     * 用户验证
     *
     * @param
     * @return
     */
    @PostMapping("verify")
    public ResponseEntity<Map<String,Object>> verifyUser(HttpServletRequest request,
                                                HttpServletResponse response,
                                                         @RequestParam(value = "utype",required = false) Integer utype){
        try{
            String token = CookieUtils.getCookieValue(request,"TXR_USER_TOKEN");
            if(StringUtils.isEmpty(token)){
                token = request.getHeader("TXR_USER_TOKEN");
              //  System.out.println("2token="+token);
            }
            log.info("token="+token);
            if(StringUtils.isEmpty(token)){
                log.info("token 为空，返回 401 ！");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }
            //1.从token中解析token信息
            UserModel userInfo = JwtUtils.getInfoFromToken(token,this.properties.getPublicKey());
            if(null != utype && utype.intValue() > 0){
                userInfo.setUtype(utype);
            }
            //2.解析成功要重新刷新token
            token = JwtUtils.generateToken(userInfo,this.properties.getPrivateKey(),this.properties.getExpire());
            //3.更新Cookie中的token
            CookieUtils.setCookie(request,response,this.properties.getCookieName(),token,this.properties.getCookieMaxAge());
            Integer cookieMaxage = this.properties.getCookieMaxAge();
            //4.解析成功返回用户信息
            Map<String,Object> dataMap = getVerfyUserInfo(userInfo);
            dataMap.put(this.properties.getCookieName(),token);
            dataMap.put("maxAge", cookieMaxage);
            return ResponseEntity.ok(dataMap);
        }catch (Exception e){
            e.printStackTrace();
        }
        //5.出现异常,相应401
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    /**
     *
     * @param userInfo
     * @return
     */
    private Map<String,Object> getVerfyUserInfo(UserModel userInfo){
        Integer utype = userInfo.getUtype();
       // BussContant.USER_UTYPE_MEMBER
        Long inempId = userInfo.getInempId();
        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("id", userInfo.getId());
        dataMap.put("inempId", userInfo.getInempId());
        dataMap.put("indeptId", userInfo.getIndeptId());
        dataMap.put("utype", userInfo.getUtype());
        dataMap.put("incompId", userInfo.getIncompId());
        dataMap.put("utype", utype);
        dataMap.put("userName", userInfo.getUserName());
        ResultModel<Map<String,Object>> appendInfoModel = null;
        switch (utype){
            case BussContant.USER_UTYPE_MEMBER:{
                appendInfoModel = memberClient.getStudentInfo(inempId);
                break;
            }case BussContant.USER_UTYPE_2:
            case BussContant.USER_UTYPE_4:
            case BussContant.USER_UTYPE_5:{
                appendInfoModel = memberClient.getTeacherInfo(inempId);
                break;
            }
        }

        if(null != appendInfoModel && (true == appendInfoModel.getSuccess())){
            Map<String,Object> map = appendInfoModel.getDatas();
            if(null == map || map.size() == 0) return  dataMap;
            String imgPath = (String) map.get("imgPath");
            String name = (String)map.get("name");
            Integer sex = (Integer)map.get("sex");
            String phone = (String)map.get("phone");
            dataMap.put("imgPath", imgPath);
            dataMap.put("name", name);
            dataMap.put("sex", sex);
            dataMap.put("phone", phone);
        }

        return dataMap;
    }

}
