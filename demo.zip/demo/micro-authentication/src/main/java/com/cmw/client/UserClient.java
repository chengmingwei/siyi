package com.cmw.client;

import com.cmw.model.back.UserModel;
import com.cmw.model.global.ResultModel;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 *
 * @Author: chengmingwei
 * @Time: 2019-03-27 23:28
 * @Feature: 用户feignclient
 */
@FeignClient(value = "micro-sysbase")
public interface UserClient {

    /**
     * 通过 openid 会员用户验证 /member/login
     *
     * @param openid
     * @return
     */
    @GetMapping("/user/loginbyopenid")
    ResultModel<UserModel> login(@RequestParam("openid") String openid, @RequestParam(value="userId", required = false) Long userId);

    /**
     * 用户登录验证
     * @param username  用户名
     * @param password  密码
     * @param ltype  登录方式
     * @param ipAddr    IP
     * @param isource   设备类型 See BussConstant.OPERATION_ISOURCE
     * @param openid
     * @return  返回用户Model对象
     */
    @GetMapping("/user/login")
    Map<String,Object> login(@RequestParam("username") String username,
                             @RequestParam("password") String password,
                             @RequestParam("ltype") Integer ltype,
                             @RequestParam("ipAddr") String ipAddr,
                             @RequestParam("isource") Integer isource,
                             @RequestParam("openid") String openid);


    /**
     * 加载系统参数到缓存中
     * @Param recode ==> 引用键
     * @Author 程明卫
     * @Date 2019/10/31 09:35
     */
    @GetMapping("/sysparams/load-by-recode")
    void loadSysparamsToRedis(@RequestParam(value = "recode", required = true) String recode);
}
