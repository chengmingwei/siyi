package com.cmw.service.inter;

import java.util.Map;

/**
 * @Author: 98050
 * @Time: 2018-10-23 22:46
 *
 * @Feature:
 */
public interface AuthService {
    /**
     * 会员授权
     * @param username 用户名
     * @param password  密码
     * @param ltype  登录方式
     * @param ipAddr    IP地址
     * @param isource   设备类型
     * @param openid   微信openid
     * @return
     */
    Map<String,Object>  authenticationByMember(String username, String password,
                                  Integer ltype, String ipAddr, Integer isource, String openid);

    /**
     * 用户授权
     * @param username 用户名
     * @param password  密码
     * @param ltype  登录方式
     * @param ipAddr    IP地址
     * @param isource   设备类型
     * @param openid   微信openid
     * @return
     */
    Map<String,Object> authentication(String username, String password,
                          Integer ltype, String ipAddr, Integer isource, String openid);

    /**
     * 根据open id 来登录
     * @param ltype
     * @param code
     * @param memberId 会员ID
     * @param encryptedData
     * @param  iv
     * @return
     */
    Map<String,Object> authenticationByCode(Integer ltype, String code, Long memberId, String encryptedData, String iv);
}
