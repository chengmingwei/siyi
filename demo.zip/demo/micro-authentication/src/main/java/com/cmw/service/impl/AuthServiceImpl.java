package com.cmw.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmw.client.MemberClient;
import com.cmw.client.MsgClient;
import com.cmw.client.UserClient;
import com.cmw.constant.SysParamConstant;
import com.cmw.constant.back.BussContant;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.base.exception.UtilException;
import com.cmw.model.back.UserModel;
import com.cmw.model.global.ResultModel;
import com.cmw.props.JwtProperties;
import com.cmw.props.WxProperties;
import com.cmw.service.inter.AuthService;
import com.cmw.util.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.*;
import java.security.spec.InvalidParameterSpecException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户JWT认证Service
 * @Author: chengmingwei
 * @Time: 2019-03-27 23:37
 * @Feature:
 *
 */
@Slf4j
@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserClient userClient;

    @Autowired
    private MemberClient memberClient;


    @Autowired
    private MsgClient msgClient;

    @Autowired
    private JwtProperties properties;

    @Autowired
    private WxProperties wxProperties;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;


    /**
     * 从Redis 中获取登录后是否需要用户微信授权
     * @return
     */
    private String getSysparamsByCache(String recode, String defaultVal) {
        String key = SysParamConstant.getKey(recode);
        String val = stringRedisTemplate.opsForValue().get(key);
        if(StringUtils.isEmpty(val)){
            userClient.loadSysparamsToRedis(recode);
            val = stringRedisTemplate.opsForValue().get(key);
        }
        if(StringUtils.isEmpty(val)){
            val = defaultVal;
        }
        return val;
    }

    @Override
    public Map<String,Object> authenticationByCode(Integer ltype, String code, Long memberId,String encryptedData, String iv) {
        String openid = null;
        String unionId = null;
        Map<String,Object> dataMap = new HashMap<>();
        ResultModel<UserModel> resultModel = null;
        if(StringHandler.isValidStr(code)){
            dataMap = getOpenId(code);
            if("0".equals(dataMap.get("status"))){
                String msg = (String)dataMap.get("msg");
                throw new ServiceException(msg);
            }
            openid = (String)dataMap.get("openid");
            String session_key = (String)dataMap.get("session_key");
            if(StringHandler.isValidStr(encryptedData)){
                JSONObject userInfo = getUserInfo(encryptedData,session_key, iv);
                unionId = userInfo.getString("unionId");
            }
            log.info("openid=",openid,",memberId=",memberId);
            switch (ltype.intValue()){
                case BussContant.LOGIN_TYPE_3:{ //教练端未实现
                    resultModel = userClient.login(openid, memberId);
                    break;
                } case BussContant.LOGIN_TYPE_4:{//家长端
                    resultModel = memberClient.login(openid, memberId);
                    break;
                }
            }
            dataMap.clear();
            dataMap.put("openid", openid);

            if(resultModel == null || (null != resultModel && !resultModel.getSuccess()) || resultModel.getDatas() == null){
                dataMap.put("openid", openid);
                dataMap.put("code", "0");
                dataMap.put("errMsg","您还没有绑定登录帐号!");
                return dataMap;
            }
        }else{
            switch (ltype.intValue()){
                case BussContant.LOGIN_TYPE_3:{ //教练端未实现
                    resultModel = userClient.login(openid, memberId);
                    break;
                } case BussContant.LOGIN_TYPE_4:{//家长端
                    resultModel = memberClient.login(openid, memberId);
                    break;
                }
            }
        }


        UserModel user = resultModel.getDatas();
        //3.查询结果不为空，则生成token
        String token = null;
        try {
            token = JwtUtils.generateToken(user,
                    properties.getPrivateKey(), properties.getExpire());
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(!StringUtils.isEmpty(unionId)){
            Integer utype = (null != ltype && ltype.intValue() == BussContant.LOGIN_TYPE_3) ? MsgClient.UTYPE_USER : MsgClient.UTYPE_MEMBER;
            ResultModel<Map<String,String>> resultBindMod = msgClient.bind(unionId, utype, user.getId());
            boolean success = resultBindMod.getSuccess();
            Map<String,String> resultMap = resultBindMod.getDatas();
            if(!success || (null == resultMap || resultMap.isEmpty())){
                String errMsg = resultBindMod.getMsg();
                if(StringUtils.isEmpty(errMsg)) errMsg = "请先关注公众号";
                dataMap.put("code", "-1");
                dataMap.put("errMsg",errMsg);
                return dataMap;
            }

            String subscribe = resultMap.get("subscribe");
            dataMap.put("subscribe", subscribe);
        }
        dataMap.put("code", "1");
        dataMap.put("token", token);
        dataMap.put("uid", user.getInempId());
        dataMap.put("memberId", user.getId());
        return dataMap;
    }


    /**
     * 用户授权
     * @param username
     * @param password
     * @param openid   微信openid
     * @return
     */
    @Override
    public Map<String,Object> authenticationByMember(String username, String password,
                                         Integer ltype, String ipAddr, Integer isource, String openid) {

        try{
            //1.调用微服务查询用户信息
            JSONArray userArr = this.memberClient.login(username,password,ltype, ipAddr, isource, openid);
            //2.查询结果为空，则直接返回null
            if (userArr == null || userArr.isEmpty()){
                return null;
            }
            Map<String,Object> dataMap = new HashMap<>();
            Boolean isMore = false; // 是否有多个学生
            if(userArr.size() > 1){
                isMore = true;
                dataMap.put("students", userArr);
            }else{
                JSONObject userJson = userArr.getJSONObject(0);
                UserModel user = FastJsonUtil.convertJsonToObj(userJson.toJSONString(), UserModel.class);
                //3.查询结果不为空，则生成token
                String token = JwtUtils.generateToken(user,
                        properties.getPrivateKey(), properties.getExpire());
                Long memberId = user.getId();
                Integer subscribe = msgClient.subscribe(MsgClient.UTYPE_MEMBER, memberId);

                dataMap.put("openid", openid);
                dataMap.put("token", token);
                dataMap.put("uid", user.getInempId());
                dataMap.put("memberId", user.getId());
                dataMap.put("subscribe", subscribe);
            }
            dataMap.put("isMore", isMore);
            String user_auth = getSysparamsByCache(SysParamConstant.RECODE_PARENT_MUST_AUTH ,SysParamConstant.RECODE_PARENT_MUST_AUTH_VAL_0);
            dataMap.put("userAuth", user_auth);
            return dataMap;

        }catch (Exception e){
            e.printStackTrace();
            throw new ServiceException("用户名或密码不正确!");
        }
    }

    /**
     * 用户授权
     * @param username
     * @param password
     * @param openid   微信openid
     * @return
     */
    @Override
    public  Map<String,Object> authentication(String username, String password,
                                 Integer ltype, String ipAddr, Integer isource, String openid) {
        try{
            //1.调用微服务查询用户信息
            Map<String,Object> dataMap = this.userClient.login(username,password,ltype, ipAddr, isource, openid);
            UserModel user = convertMap2User(dataMap);

            List<Map<String,String>>  uroles = (List<Map<String,String>> )dataMap.get("uroles");

            //2.查询结果为空，则直接返回null
            if (user == null){
                return null;
            }
            //3.查询结果不为空，则生成token
            String token = JwtUtils.generateToken(user,
                    properties.getPrivateKey(), properties.getExpire());

            Object userRoles_Original = dataMap.get("userRoles_Original");
            Long memberId = user.getId();
            Integer subscribe = msgClient.subscribe(MsgClient.UTYPE_USER, memberId);

            dataMap.clear();
            dataMap.put("subscribe", subscribe);
            dataMap.put("token", token);
            dataMap.put("uroles", uroles);
            dataMap.put("userRoles_Original", userRoles_Original);

            return dataMap;
        }catch (Exception e){
            e.printStackTrace();
            throw new ServiceException("用户名或密码不正确!");
        }
    }


    /**
     * 获取信息
     */
    public JSONObject getUserInfo(String encryptedData, String sessionkey, String iv){

        try {

            // 被加密的数据
            byte[] dataByte = Base64.decode2(encryptedData);
            // 加密秘钥
            byte[] keyByte = Base64.decode2(sessionkey);
            // 偏移量
            byte[] ivByte = Base64.decode2(iv);
            // 如果密钥不足16位，那么就补足.  这个if 中的内容很重要
            int base = 16;
            if (keyByte.length % base != 0) {
                int groups = keyByte.length / base + (keyByte.length % base != 0 ? 1 : 0);
                byte[] temp = new byte[groups * base];
                Arrays.fill(temp, (byte) 0);
                System.arraycopy(keyByte, 0, temp, 0, keyByte.length);
                keyByte = temp;
            }
            // 初始化
            Security.addProvider(new BouncyCastleProvider());
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding","BC");
            SecretKeySpec spec = new SecretKeySpec(keyByte, "AES");
            AlgorithmParameters parameters = AlgorithmParameters.getInstance("AES");
            parameters.init(new IvParameterSpec(ivByte));
            cipher.init(Cipher.DECRYPT_MODE, spec, parameters);// 初始化
            byte[] resultByte = cipher.doFinal(dataByte);
            if (null != resultByte && resultByte.length > 0) {
                String result = new String(resultByte, "UTF-8");
                return JSONObject.parseObject(result);
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidParameterSpecException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        }
        return null;
    }


    private UserModel convertMap2User(Map<String,Object> dataMap) throws UtilException {
        Map<String,Object> userMap = (Map<String,Object>)dataMap.get("userModel");
        UserModel userModel = BeanUtil.copyValue(UserModel.class, userMap);
        return userModel;
    }


    /**
     * 获取openId
     * @param code
     */
    public Map<String, Object> getOpenId(String code){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = "1";
        String msg = "ok";
        String wx_openidUrl = wxProperties.getOpenidUrl();
        log.info("wx_openidUrl="+wx_openidUrl);
        try {
            if(StringUtils.isEmpty(code)){
                status = "0";//失败状态
                msg = "code为空";
            }else {
                String appId = wxProperties.getAppId();
                String sercetKey = wxProperties.getSercetKey();

//                if(loginType == BussContant.LOGIN_TYPE_4){
//                    /**
//                     * 注：此处账号信息应放到配置文件
//                     * @Author 肖家添
//                     * @Date 2019/5/15 22:34
//                     **/
//                    //-- 家长端
//
//                    appId = "wx045c2f878a36c15c";
//                    sercetKey = "56fe1dad22b3a535ef22760bd6bc9667";
//                }

                String requestUrl = wx_openidUrl.replace("APPID", appId).
                        replace("SECRET", sercetKey).replace("JSCODE", code);
                log.info(requestUrl);
                // 发起GET请求获取凭证
                String jsonStr = HttpUtil.get(requestUrl);
                log.info(jsonStr);
                JSONObject jsonObject = FastJsonUtil.convertStrToJSONObj(jsonStr);
                if (jsonObject != null) {
                    Integer errcode = jsonObject.getInteger("errcode");
                    if(null != errcode && errcode.intValue() == 40029){
                        String errmsg = jsonObject.getString("errmsg");
                        log.info("errcode = "+errcode+", errmsg="+errmsg);
                        status = "0";
                        msg = "code无效";
                    }else{
                        map.put("openid", jsonObject.getString("openid"));
                        map.put("session_key", jsonObject.getString("session_key"));
                    }

                }else {
                    status = "0";
                    msg = "code无效";
                }
            }
            map.put("status", status);
            map.put("msg", msg);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(),e);
        }
        return map;
    }

}
