package com.cmw.core.vo;

import java.util.List;

/**
 * 分页VO
 * @date 2019-02-13 19:09
 * @param <T>
 */
//@Data
public class PageResult<T> {
    //分页参数信息
    private Pagination pagination;
    private List<T> list;// 当前页数据

    public PageResult() {
    }

    public PageResult(Pagination pagination, List<T> list) {
        this.pagination = pagination;
        this.list = list;
    }


    public Pagination getPagination() {
        return pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }
}
