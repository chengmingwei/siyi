package com.cmw.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/*import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder; */

public class CompressPicTools {

    public static final long minLength = 200 * 1024;        // 低于200KB的文件不做压缩处理

    /**
     * 此方法用于压缩图片，保持原有的高宽
     * @param inputDir 输入图文件夹路径
     * @param outputDir 输出图文件夹路径
     * @param inputFileName 输入图文件名
     * @param outputFileName  输出图文件名
     * @return 返回需要的文件名
     */
    public static String compressPic(String inputDir, String outputDir, String inputFileName, String outputFileName) {
        try {
            // 获取源文件，如果源文件小于200KB，不做压缩处理
            File file = new File(inputDir + inputFileName);
            if(file.exists()){
                if(minLength > file.length()) {
                    return inputFileName;
                }

                Image img = ImageIO.read(file);
                int newWidth = img.getWidth(null);
                int newHeight = img.getHeight(null);
                BufferedImage tag = new BufferedImage((int) newWidth, (int) newHeight, BufferedImage.TYPE_INT_RGB);
                tag.getGraphics().drawImage(
                        img.getScaledInstance(newWidth, newHeight,
                                Image.SCALE_SMOOTH), 0, 0, null);
                /*FileOutputStream out = new FileOutputStream(outputDir + outputFileName);
                JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
                encoder.encode(tag);
                out.close();*/
                String dstName = outputDir + outputFileName;
                String formatName = dstName.substring(dstName.lastIndexOf(".") + 1);
                ImageIO.write(tag, /*"GIF"*/ formatName /* format desired */ , new File(dstName) /* target */ );

                // 压缩完成后，删除源文件
                file.delete();
            }else{
                return "压缩文件不存在";
            }

        } catch (IOException ex) {
            System.out.println(ex);
            ex.printStackTrace();
            return inputFileName;
        }
        return outputFileName;
    }

    public static void main(String[] args) {
        String inputDir = "/Users/chengmingwei/Downloads/pic/";//输入文件路径
        String outputDir = "/Users/chengmingwei/Downloads/pic/";//输出文件路径
        String inputFileName = "t1.jpg";//输入文件名
        String outputFileName = "t2.jpg";//输出文件名
        String fileName = compressPic(inputDir, outputDir, inputFileName, outputFileName);
        System.out.println(fileName);
        //System.exit(0);
    }
}


