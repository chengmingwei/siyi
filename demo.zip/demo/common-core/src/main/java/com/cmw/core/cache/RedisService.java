package com.cmw.core.cache;

import com.cmw.model.back.RightModel;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * @ClassName RedisService
 * @Description: Redis 操作类
 * @Author cheng
 * @Date 2020/8/27 14:50
 * @Version V1.0
 **/

public abstract class RedisService {
    private RedisTemplate redisTemplate;
    /**
     * 加载指定的用户信息到缓存当中
     * @param userIdList 要加载的用户ID列表
     */
    public abstract void loadUserList(List<String> userIdList);

    public void setRedisTemplate(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public RedisTemplate getRedisTemplate(){
        return redisTemplate;
    }

    public boolean hasKey(String key){
        try{
            return getRedisTemplate().hasKey(key);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public void removeKey(String key){
        try{
            getRedisTemplate().delete(key);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public void removeKeys(List<String> keys){
        try{
            getRedisTemplate().delete(keys);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 往 Redis 中添加 Map 数据
     * @param key   redis key
     * @param map   HashMap 对象
     * @param <T>
     */
    public <T> void setMap(String key, Map<String,T> map){
        try{
            getRedisTemplate().opsForHash().putAll(key, map);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 将指定的 键值添加到 Map 中
     * @param redisKey  Redis Key
     * @param key   Map key
     * @param val   Map值
     */
    public void addVal2Map(String redisKey, String key, Object val){
        try{
            getRedisTemplate().opsForHash().put(redisKey, key ,val);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 从 redis 中获取 Map 对象
     * @param key   redis key
     * @param <T>
     * @return  返回 HashMap 对象
     */
    public <T> T getMap(String key){
        try{
            return (T)getRedisTemplate().opsForHash().entries(key);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }

    public <T> T getMapVal(String redisKey, String mapKey){
        try{
            // 检测 是否 存在该键
            boolean isKey = getRedisTemplate().opsForHash().hasKey(redisKey, mapKey);
            if(!isKey) return null;
            return (T)getRedisTemplate().opsForHash().get(redisKey, mapKey);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }


    public boolean hasMapKey(String redisKey, String mapKey){
        try {
            HashOperations hashOperations = getRedisTemplate().opsForHash();
            boolean isKey = hashOperations.hasKey(redisKey, mapKey);
            return isKey;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public void removeMapKeys(String redisKey, String mapKey){
        try{
            HashOperations hashOperations = getRedisTemplate().opsForHash();
            boolean isKey = hashOperations.hasKey(redisKey, mapKey);
            if(!isKey) return;
            hashOperations.delete(redisKey, mapKey);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 设置无序集合 set (无序，不重复)
     * @param key   键
     * @param setObjs Set 对象
     */
    public void setSet(String key,Set<T> setObjs){
        try{
            getRedisTemplate().opsForSet().add(key, setObjs);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 从 redis 中获取 Set 对象
     * @param key   Redis key
     * @param <T>
     * @return  返回 Set 对象
     */
    public  <T> T getSet(String key){
        try {
            return (T)getRedisTemplate().opsForSet().members(key);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * 设置有序集合 set
     * @param key   键
     * @param setObjs Set 对象
     */
    public <T> void setZSet(String key, Set<T> setObjs){
       if(null == setObjs || setObjs.size() == 0){
           return;
       }
       try{
           ZSetOperations<String, Object> zSetOperations = getRedisTemplate().opsForZSet();
           long num = 0;
            for(T t : setObjs){
                zSetOperations.add(key, t, num++);
            }
       }catch (Exception ex){
           ex.printStackTrace();
       }
    }

    /**
     * 从 redis 中获取 有序Set 对象
     * @param key   Redis key
     * @param <T>
     * @return  返回 ZSet 对象
     */
    public  <T> T getZSet(String key){
        try{
            ZSetOperations<String, Object> zSetOperations = getRedisTemplate().opsForZSet();
            long size = zSetOperations.size(key);
            return (T)zSetOperations.rangeByScore(key, 0, size-1);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }


    public long getListSize(String key){
        try{
            Long size =  getRedisTemplate().opsForList().size(key);
            return null == size ? 0 : size;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return 0L;
    }

    /**
     * 从右边插入List 数据
     * @param key   redis Key
     * @param list  要插入的List对象
     */
    public <T> void setList2Right(String key, List<T> list){
        try{
            getRedisTemplate().opsForList().rightPushAll(key, list);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 从左边插入List 数据
     * @param key   redis Key
     * @param list  要插入的List对象
     */
    public <T> void setList2Left(String key, List<T> list){
        try{
            getRedisTemplate().opsForList().leftPushAll(key, list);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * * 从左边将元素插入List 中
     * @param key   redis key
     * @param val   要插入到List中的元素
     */
    public void addVal2ListAtLeft(String key, Object val){
        try{
            getRedisTemplate().opsForList().leftPush(key,val);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * * 从右边将元素插入List 中
     * @param key   redis key
     * @param val   要插入到List中的元素
     */
    public void addVal2ListAtRight(String key, Object val){
        try{
            getRedisTemplate().opsForList().rightPush(key,val);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 根据 key 从 redis 中获取 List 对象
     * @param key   redisKey
     * @param <T> 返回泛型List 对象
     * @return
     */
    public <T> T getList(String key){
        try{
            ListOperations<String,Object> listOperations = getRedisTemplate().opsForList();
            Long size = listOperations.size(key);
            if(null == size || size.equals(0)) return null;
            return (T)listOperations.range(key, 0, size-1);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * 设置指定的值到 redis 当中
     * @param key   redis 键
     * @param val   存储的值 （泛型值）
     * @param <T>
     */
    public <T> void set(String key, T val){
        try{
            getRedisTemplate().opsForValue().set(key, val);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 设置指定的值到 redis 当中,同时设定过期时间
     * @param key   redis 键
     * @param val   存储的值 （泛型值）
     * @param expireTime 过期时间
     * @param timeUnit 时间单位
     */
    public void set(String key, T val, long expireTime, TimeUnit timeUnit){
        try{
            getRedisTemplate().opsForValue().set(key,val,expireTime, timeUnit);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 设置指定的值到 redis 当中KEY同时设定过期时间
     * @param key   redis 键
     * @param expireTime 过期时间
     * @param timeUnit 时间单位
     */
    public void expire(String key,long expireTime,TimeUnit timeUnit){
        try{
            getRedisTemplate().expire(key, expireTime, timeUnit);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 设置指定的值到 redis 当中,同时设定过期时间
     * @param key   redis 键
     * @param val   存储的值 （泛型值）
     * @param expireTime 过期时间
     * @param timeUnit 时间单位
     */
    public void set(String key, String val, long expireTime, TimeUnit timeUnit){
        try{
            getRedisTemplate().opsForValue().set(key,val,expireTime, timeUnit);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 根据指定的key 从 redis 中获取值
     * @param key
     * @param <T>
     * @return
     */
    public <T> T get(String key){
        try{
            Object val = getRedisTemplate().opsForValue().get(key);
            return (T)val;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }

    public Object getObj(String key){
        try{
            Object val = getRedisTemplate().opsForValue().get(key);
            return val;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }

    public String getStr(String key){
        try{
           Object val = getRedisTemplate().opsForValue().get(key);
           return (null == val) ? null : (String)val;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }

    public Integer getInt(String key){
        try{
            Object val = getRedisTemplate().opsForValue().get(key);
            return (null == val) ? null : (Integer) val;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }

    public Double getDouble(String key){
        try{
            Object val = getRedisTemplate().opsForValue().get(key);
            return (null == val) ? null : (Double) val;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }

    public Float getFloat(String key){
        try{
            Object val = getRedisTemplate().opsForValue().get(key);
            return (null == val) ? null : (Float) val;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }


}
