package com.cmw.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * @Author: 98050
 * @Time: 2018-10-23 10:49
 * @Feature: 密码加密
 */
public class CodecUtils {

    /**
     * 密码加密
     * @param username 用户名
     * @param password 明文密码
     * @return
     */
    public static String passwordBcryptEncode(String username,String password){
        return new BCryptPasswordEncoder().encode(username + password);
    }

    /**
     * 比较密码是否正确
     * @param rawPassword   原始加盐的密码KEY
     * @param encodePassword    加密后密码
     * @return 返回Boolean [true:密码正确, false:密码不正确]
     */
    public static Boolean passwordConfirm(String rawPassword,String encodePassword){
        return new BCryptPasswordEncoder().matches(rawPassword,encodePassword);
    }

    public static void main(String[] args){
        String username = "18529427464";
        String passWord = "88888888";
        String encodePassword = CodecUtils.passwordBcryptEncode(username,passWord);
        System.out.println(encodePassword);
    }
}
