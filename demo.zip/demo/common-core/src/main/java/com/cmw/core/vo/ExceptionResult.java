package com.cmw.core.vo;

import com.cmw.core.base.exception.ServiceException;
import lombok.Data;

/**
 * 异常返回结果
 * @Date 2019-02-11
 */
@Data
public class ExceptionResult {
    private int status;
    private String message;
    private Long timestamp;

    public ExceptionResult(ServiceException ex){
        this.status = ex.getCode();
        this.message = ex.getMsg();
        this.timestamp = System.currentTimeMillis();
    }
}
