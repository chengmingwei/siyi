package com.cmw.util;

import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.entity.BaseEntity;
import com.cmw.model.back.UserModel;
import org.springframework.util.StringUtils;

import java.util.Date;

/**
 * 创建记录时的用户信息工具类
 */
public class UserUtil {

    /**
     * 根据当前用户获取数据过滤权限SQL (只到机构ID级别，不会到本人数据级别)
     * @param tabAsName  表别名 "A.creator =" 如A
     * @param user  当前用户
     * @return  返回权限过滤SQL
     */
    public static String getOrgRightSql(String tabAsName, UserModel user){
        Integer utype = user.getUtype();
        if(null != utype && utype.intValue() == BussContant
                .USER_UTYPE_3) return "";  //超级管理员
        if(!StringUtils.isEmpty(tabAsName)) tabAsName = String.format("%s.",tabAsName);
        Long deptId = user.getIndeptId();
        Long incompId = user.getIncompId();
        StringBuilder sbWhere = new StringBuilder();
        if(null == utype){
            sbWhere.append(String.format(" and %sorgid = '%d'",tabAsName,-111111));
        }else{
            sbWhere.append(String.format(" and %sorgid = '%d'",tabAsName,incompId));
        }
        return sbWhere.toString();
    }

    /**
     * 根据当前用户获取数据过滤SQL
     * @param tabAsName  表别名 "A.creator =" 如A
     * @param user  当前用户
     * @return  返回权限过滤SQL
     */
    public static String getRightSql(String tabAsName, UserModel user){
        Integer utype = user.getUtype();
        if(null != utype && utype.intValue() == BussContant
                .USER_UTYPE_3) return "";  //超级管理员
        Long deptId = user.getIndeptId();
        Long incompId = user.getIncompId();
        StringBuilder sbWhere = new StringBuilder();
        if(!StringUtils.isEmpty(tabAsName)) tabAsName = String.format("%s.",tabAsName);
        if(null == utype){
            sbWhere.append(String.format(" and %sorgid = '%d'",tabAsName,-111111));
        }else{
            switch (utype){
                case BussContant.USER_UTYPE_1:{ //本人数据
                    sbWhere.append(String.format(" and %screator='%d'",tabAsName, user.getId()));
                    break;
                } case BussContant.USER_UTYPE_2:
                case BussContant.USER_UTYPE_6:{ //机构系统管理员
                    sbWhere.append(String.format(" and %sorgid = '%d'",tabAsName,incompId));
                    break;
                }case BussContant.USER_UTYPE_4:{ //教练
                    sbWhere.append(String.format(" and %coach = '%d'",user.getId()));
                    break;
                }case BussContant.USER_UTYPE_5:{ //班主任或销售
                    sbWhere.append(String.format(" and %screator='%d'",tabAsName, user.getId()));
                    break;
                }
            }
        }
        return sbWhere.toString();
    }


    /**
     * 创建系统管理员时的create Info值
     * @param entity    要赋值创建人信息的记录
     */
    public static void setCreateInfoBySysAdmin(BaseEntity entity){
        entity.setCreateTime(new Date());
        entity.setCreator(SysContant.ADMIN_DEFAULT_CREATE);
        entity.setDeptId(SysContant.ADMIN_DEFAULT_DEPTID);
        entity.setOrgid(SysContant.ADMIN_DEFAULT_ORGID);
    }

    /**
     * 由系统创建的记录的create Info值
     * @param entity    要赋值创建人信息的记录
     */
    public static void setCreateInfoBySystem(BaseEntity entity){
        entity.setCreateTime(new Date());
        entity.setCreator(SysContant.SYSTEM_DEFAULT_CREATE);
        entity.setDeptId(SysContant.SYSTEM_DEFAULT_DEPTID);
        entity.setOrgid(SysContant.SYSTEM_DEFAULT_ORGID);
    }

    /**
     * 为记录赋值创建人信息
     * @param user  用户信息
     * @param entity    要赋值创建人信息的记录
     */
    public static void setCreateInfo(UserModel user, BaseEntity entity){
        entity.setCreateTime(new Date());
        entity.setCreator(user.getId());
        entity.setDeptId(user.getIndeptId());
        entity.setOrgid(user.getIncompId());
    }


    public static void setModifyInfo(UserModel user, BaseEntity entity){
        entity.setModifier(user.getId());
        entity.setModifytime(new Date());
    }

    public static void setModifyInfoBySysAdmin(BaseEntity entity){
        entity.setModifier(SysContant.ADMIN_DEFAULT_CREATE);
        entity.setModifytime(new Date());
    }

    public static void setModifyInfoBySystem(BaseEntity entity){
        entity.setModifier(SysContant.SYSTEM_DEFAULT_CREATE);
        entity.setModifytime(new Date());
    }

}
