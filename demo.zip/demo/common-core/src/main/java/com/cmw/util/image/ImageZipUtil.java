package com.cmw.util.image;


import com.cmw.core.kit.file.FileUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

@Slf4j
public class ImageZipUtil {

    public static void main(String[] args) {
        //zipWidthHeightImageFile(new File("/Users/chengmingwei/Downloads/pic/1.jpg"),new File("/Users/chengmingwei/Downloads/pic/2.jpg"),425,638,0.7f);

        //zipImageFile(new File("/Users/chengmingwei/Downloads/pic/1.jpg"),new File("/Users/chengmingwei/Downloads/pic/3.jpg"),425,638,0.7f);
//        zipImageFile(new File("/Users/chengmingwei/Downloads/pic/T1.jpg"),new File("/Users/chengmingwei/Downloads/pic/T2.jpg"),425,638,0.7f);

        zipImageFile(new File("C:/cmw/documents/test/1.png"),new File("C:/cmw/documents/test/1_small.png"),300,300,1f);

        System.out.println("ok");
    }


    public static File zipImageFile(MultipartFile oldFile, String tmpDir, int width, int height, float quality){
        InputStream ins = null;
        try {
             if(!FileUtil.exist(tmpDir)){
                 FileUtil.creatDictory(tmpDir);
             }

             String fileFileName = oldFile.getOriginalFilename();
            int index = fileFileName.lastIndexOf('.');
            String now = UUID.randomUUID().toString().replace("-", "");
            String newFileName = null;
            String zipFileName = null;
            // 判断上传文件名是否有扩展名
            String endPrefix = (index != -1) ? fileFileName.substring(index) : "";
            newFileName = now + endPrefix;
            zipFileName = now+"_small"+endPrefix;
            String newFilePath = tmpDir+newFileName;
            String zipFilePath = tmpDir+zipFileName;
            File nfile = new File(newFilePath);
            ins = oldFile.getInputStream();
            FileUtils.copyInputStreamToFile(ins, nfile);
            File zipFile = new File(zipFilePath);
            zipImageFile(nfile, zipFile, width, height, quality);
            nfile.delete();
            return zipFile;
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(null != ins){
                try {
                    ins.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }


    /**
     * 根据设置的宽高等比例压缩图片文件<br> 先保存原文件，再压缩、上传
     * @param oldFile  要进行压缩的文件
     * @param newFile  新文件
     * @param width  宽度 //设置宽度时（高度传入0，等比例缩放）
     * @param height 高度 //设置高度时（宽度传入0，等比例缩放）
     * @param quality 质量
     * @return 返回压缩后的文件的全路径
     */
    public static String zipImageFile(File oldFile,File newFile, int width, int height,float quality) {
        if (oldFile == null) {
            return null;
        }
        try {
            /** 对服务器上的临时文件进行处理 */
            Image srcFile = ImageIO.read(oldFile);
            int w = srcFile.getWidth(null);
            int h = srcFile.getHeight(null);
            double bili;
            if(width>0){
                bili=width/(double)w;
                height = (int) (h*bili);
            }else{
                if(height>0){
                    bili=height/(double)h;
                    width = (int) (w*bili);
                }
            }

            String srcImgPath = newFile.getAbsoluteFile().toString();
            log.info(srcImgPath);
            String subfix = "jpg";
            subfix = srcImgPath.substring(srcImgPath.lastIndexOf(".")+1,srcImgPath.length());

            BufferedImage buffImg = null;
            if(subfix.equals("png")){
                buffImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            }else{
                buffImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            }

            Graphics2D graphics = buffImg.createGraphics();
            graphics.setBackground(new Color(255,255,255));
            graphics.setColor(new Color(255,255,255));
            graphics.fillRect(0, 0, width, height);
            graphics.drawImage(srcFile.getScaledInstance(width, height, Image.SCALE_SMOOTH), 0, 0, null);

            ImageIO.write(buffImg, subfix, new File(srcImgPath));


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return newFile.getAbsolutePath();
    }

    /**
     * 按设置的宽度高度压缩图片文件<br> 先保存原文件，再压缩、上传
     * @param oldFile  要进行压缩的文件全路径
     * @param newFile  新文件
     * @param width  宽度
     * @param height 高度
     * @param quality 质量
     * @return 返回压缩后的文件的全路径
     */
    public static String zipWidthHeightImageFile(File oldFile,File newFile, int width, int height,float quality) {
        if (oldFile == null) {
            return null;
        }
        String newImage = null;
        try {
            /** 对服务器上的临时文件进行处理 */
            Image srcFile = ImageIO.read(oldFile);

            String srcImgPath = newFile.getAbsoluteFile().toString();
            System.out.println(srcImgPath);
            String subfix = "jpg";
            subfix = srcImgPath.substring(srcImgPath.lastIndexOf(".")+1,srcImgPath.length());

            BufferedImage buffImg = null;
            if(subfix.equals("png")){
                buffImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            }else{
                buffImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            }

            Graphics2D graphics = buffImg.createGraphics();
            graphics.setBackground(new Color(255,255,255));
            graphics.setColor(new Color(255,255,255));
            graphics.fillRect(0, 0, width, height);
            graphics.drawImage(srcFile.getScaledInstance(width, height, Image.SCALE_SMOOTH), 0, 0, null);

            ImageIO.write(buffImg, subfix, new File(srcImgPath));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return newImage;
    }
}