package com.cmw.core.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 分页信息
 * @author  chengmingwei
 * @date 2019-04-14 24:11
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Pagination {
    private Long total = 0L;// 总条数
    private Integer current = 0;// 当前页
    private Integer pageSize = 0;//每页大小

}
