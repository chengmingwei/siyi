package com.cmw.core.advice;

import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.ExceptionResult;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * 栏截Controller层异常
 * @Date 2019-02-11 16:43
 */
@ControllerAdvice
public class CommonExceptionHandler {

    @ExceptionHandler(ServiceException.class)
    public ResponseEntity<ExceptionResult> handleException(ServiceException e){
        return ResponseEntity.status(e.getCode())
                .body(new ExceptionResult(e));
    }
}
