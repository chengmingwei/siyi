package com.cmw.core.cache;

/**
 * 本地缓存接口
 * @author chengmingwei
 * @date 2020-10-15 20:55
 */
public interface LocalCacheService{
   <T> void set(String key, T val);

   <T> T get(String key);
}