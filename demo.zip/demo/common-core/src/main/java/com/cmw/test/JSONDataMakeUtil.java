package com.cmw.test;

import com.alibaba.fastjson.JSONObject;
import com.cmw.core.kit.file.FileUtil;

public class JSONDataMakeUtil {
    static final String PATH = "/Volumes/2/cmw/workspaces/idea_dev/Sports-Sass/common-core/src/main/java/com/cmw/test/data.txt";
    public static void main(String[] args){
        String content = FileUtil.readFileToStr(PATH, "UTF-8");
        String[] dataArr = content.split("\n");
        JSONObject jsonObject = new JSONObject();
        for(String row : dataArr){
            String[] kv = row.split(":");
            if(null == kv || kv.length < 2) continue;
            String k = kv[0];
            String v = kv[1];
            jsonObject.put(k, v);
        }
        System.out.println(jsonObject.toJSONString());

    }
}
