package com.cmw.util;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.Security;

public class GenPass {

	private static final String Algorithm = "DES"; // 定义 加密算法,可用 // DES,DESede,Blowfish

	private static final String DES_KEY = "2017100119841221";

	// src为被加密的数据缓冲区（源）
	public static byte[] encryptMode(byte[] keybyte, byte[] src) {
		try {
			// 生成密钥
			SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);
			// 加密
			Cipher c1 = Cipher.getInstance(Algorithm);
			c1.init(Cipher.ENCRYPT_MODE, deskey);
			return c1.doFinal(src);
		} catch (java.security.NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		} catch (javax.crypto.NoSuchPaddingException e2) {
			e2.printStackTrace();
		} catch (Exception e3) {
			e3.printStackTrace();
		}
		return null;
	}

	// keybyte为加密密钥，长度为24字节
	// src为加密后的缓冲区
	public static byte[] decryptMode(byte[] keybyte, byte[] src) {
		try {
			// 生成密钥
			SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);
			// 解密
			Cipher c1 = Cipher.getInstance(Algorithm);
			c1.init(Cipher.DECRYPT_MODE, deskey);
			return c1.doFinal(src);
		} catch (java.security.NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		} catch (javax.crypto.NoSuchPaddingException e2) {
			e2.printStackTrace();
		} catch (Exception e3) {
			e3.printStackTrace();
		}
		return null;
	}

	// 转换成十六进制字符串
	public static String byte2hex(byte[] b) {
		String hs = "";
		String stmp = "";
		for (int n = 0; n < b.length; n++) {
			stmp = (Integer.toHexString(b[n] & 0XFF));
			if (stmp.length() == 1)
				hs = hs + "0" + stmp;
			else
				hs = hs + stmp;
			if (n < b.length - 1)
				hs = hs + "";
		}
		return hs.toUpperCase();
	}

	// 16 进制 转 2 进制
	public static byte[] hex2byte(String hex) throws IllegalArgumentException {
		if (hex.length() % 2 != 0) {
			throw new IllegalArgumentException();
		}
		char[] arr = hex.toCharArray();
		byte[] b = new byte[hex.length() / 2];
		for (int i = 0, j = 0, l = hex.length(); i < l; i++, j++) {
			String swap = "" + arr[i++] + arr[i];
			int byteint = Integer.parseInt(swap, 16) & 0xFF;
			b[j] = new Integer(byteint).byteValue();
		}
		return b;
	}

	// 加密
	@SuppressWarnings("restriction")
	public static String Encrypt(String str, byte[] key) {
		Security.addProvider(new com.sun.crypto.provider.SunJCE());
		byte[] encrypt = encryptMode(key, str.getBytes());
		return byte2hex(encrypt);
	}
	
	// 加密
	@SuppressWarnings("restriction")
	public static String Encrypt(String str) {
		byte[] key = hex2byte(DES_KEY);
		Security.addProvider(new com.sun.crypto.provider.SunJCE());
		byte[] encrypt = encryptMode(key, str.getBytes());
		return byte2hex(encrypt);
	}

	// 加密
	@SuppressWarnings("restriction")
	public static byte[] EncryptRetByte(byte[] src, byte[] key) {
		Security.addProvider(new com.sun.crypto.provider.SunJCE());
		byte[] encrypt = encryptMode(key, src);
		return encrypt;
	}

	// 解密
	public static String Decrypt(String str, byte[] key) {
		try {
			Security.addProvider(new com.sun.crypto.provider.SunJCE());
			byte[] decrypt = decryptMode(key, hex2byte(str));
			return new String(decrypt);
		} catch (Exception e) {
			return "";
		}
	}

	// 解密
	public static String Decrypt(String str) {
		try {
			byte[] key = hex2byte(DES_KEY);
			Security.addProvider(new com.sun.crypto.provider.SunJCE());
			byte[] decrypt = decryptMode(key, hex2byte(str));
			return new String(decrypt);
		} catch (Exception e) {
			return "";
		}
	}
	
	public static void main(String arg[]) {
//		System.out.println(Encrypt("13922111489", hex2byte(DES_KEY)));
//		System.out.println(Encrypt("ibank3", hex2byte(SysConstant.DES_KEY)));
		//System.out.println(Encrypt("18064179050", hex2byte(Constants.KEY)));
		//3BFC28ACB23E258B6698F79A949E201A
		//71D0C215DF5ACB7913D5BFA98A52DD15
		//String str1 = "18813482004";
		//String str2 = "45FF13A1D5AFD452";
//		System.out.println(Encrypt(str1, hex2byte(SysConstant.DES_KEY)));
//		System.out.println(Decrypt("2C27C5A6BBCB87EEEF1884738B479DD9", hex2byte(DES_KEY)));
		System.out.println(Encrypt("SYS_10000"));
//		
//		System.out.println("==============================");
//		System.out.println(GenerateLinkUtils.md5("cmw123456"));
	}
}