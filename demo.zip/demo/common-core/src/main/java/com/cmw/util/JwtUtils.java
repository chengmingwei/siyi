package com.cmw.util;

import com.cmw.constant.GlobalConstant;
import com.cmw.model.back.UserModel;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.*;

/**
 *
 * @author: chengmingwei
 * @create: 2019-03-27 21:42
 **/
@Component
public class JwtUtils {

    static IdWorker idWorker = new IdWorker();
    /**
     * 用户认证Redis前缀
     */
    static final String USER_PREFIX = "AUTH_TOKEN:";
    /**
     * 私钥加密token
     *
     * @param userInfo      载荷中的数据
     * @param privateKey    私钥
     * @param expireMinutes 过期时间，单位秒
     * @return
     * @throws Exception
     */
    public static String generateToken(UserModel userInfo, PrivateKey privateKey, int expireMinutes) throws Exception {
        String token = Jwts.builder()
                .claim(GlobalConstant.JWT_KEY_USER_ID, userInfo.getId())
                .claim(GlobalConstant.JWT_KEY_USER_USERNAME, userInfo.getUserName())
                .claim(GlobalConstant.JWT_KEY_USER_INCOMPID, userInfo.getIncompId())
                .claim(GlobalConstant.JWT_KEY_USER_INDEPTID, userInfo.getIndeptId())
                .claim(GlobalConstant.JWT_KEY_USER_INEMPID, userInfo.getInempId())
                .claim(GlobalConstant.JWT_KEY_USER_UTYPE, userInfo.getUtype())
                .setExpiration(DateTime.now().plusDays(expireMinutes).toDate())
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .compact();
        return makeSaltToToken(token);
    }

    /**
     * 私钥加密token
     *
     * @param userInfo      载荷中的数据
     * @param privateKey    私钥字节数组
     * @param expireMinutes 过期时间，单位秒
     * @return
     * @throws Exception
     */
    public static String generateToken(UserModel userInfo, byte[] privateKey, int expireMinutes) throws Exception {
        PrivateKey privateKeyObj = RsaUtils.getPrivateKey(privateKey);
        return generateToken(userInfo, privateKeyObj, expireMinutes);
    }

    public static String makeSaltToToken(String token){
       if(1==1) return token;
       //后期再优化 token 续期问题
        String saltToken = null;
        long seqId = idWorker.nextId();
        StringBuilder sb = new StringBuilder();
        String saltStr = GenPass.Encrypt(seqId+"");
        saltToken = String.format("%s$$%s", token, saltStr);
        return saltToken;
    }



    public static void main(String[] args){
        String token = "eyJhbGciOiJSUzI1NiJ9.eyJpZCI6MSwidXNlck5hbWUiOiJjaGVuZ21pbmd3ZWkiLCJ1dHlwZSI6MywiZXhwIjoxNTg2NDMzODA2fQ.uUuSyBk9sS5XvUNp2Zpt7TI78P1MNGMnnGjjP2kSWEsodSmsHFjD-gSgxjJmHQPcWJsNXZm3qWD2D7jy8NQbme7t3NJf25OC7j4CCW_910rJbvTuHDHEkmKbnOP0mhjuzPndq7rL5OVMZ0hi_-6GJrJoXjfAa8TxFsEFzY-wWUQ";
        String seqId = "202005141805543674096";
        makeSaltToToken(token);
    }

    private static Integer[] getIndexArr(int len) {
        Integer[] indexArr = new Integer[len];
        for(int i=0; i<len; i++){
            indexArr[i] = i;
        }
        List<Integer> indexList = Arrays.asList(indexArr);
        Collections.shuffle(indexList);
        return (Integer[]) indexList.toArray();
    }

    /**
     * 公钥解析token
     *
     * @param token     用户请求中的token
     * @param publicKey 公钥
     * @return
     * @throws Exception
     */
    private static Jws<Claims> parserToken(String token, PublicKey publicKey) {
        return Jwts.parser().setSigningKey(publicKey).parseClaimsJws(token);
    }

    /**
     * 公钥解析token
     *
     * @param token     用户请求中的token
     * @param publicKey 公钥字节数组
     * @return
     * @throws Exception
     */
    private static Jws<Claims> parserToken(String token, byte[] publicKey) throws Exception {
        PublicKey publicKeyObj = RsaUtils.getPublicKey(publicKey);
        return parserToken(token, publicKeyObj);
    }

    /**
     * 获取token中的用户信息
     *
     * @param token     用户请求中的令牌
     * @param publicKey 公钥
     * @return 用户信息
     * @throws Exception
     */
    public static UserModel getInfoFromToken(String token, PublicKey publicKey) throws Exception {
        Jws<Claims> claimsJws = parserToken(token, publicKey);
        Claims body = claimsJws.getBody();
        return new UserModel(
                ObjectUtils.toLong(body.get(GlobalConstant.JWT_KEY_USER_ID)),
                ObjectUtils.toString(body.get(GlobalConstant.JWT_KEY_USER_USERNAME)),
                ObjectUtils.toLong(body.get(GlobalConstant.JWT_KEY_USER_INDEPTID)),
                ObjectUtils.toLong(body.get(GlobalConstant.JWT_KEY_USER_INCOMPID)),
                ObjectUtils.toLong(body.get(GlobalConstant.JWT_KEY_USER_INEMPID)),
                ObjectUtils.toInt(body.get(GlobalConstant.JWT_KEY_USER_UTYPE))
        );
    }

    /**
     * 获取token中的用户信息
     *
     * @param token     用户请求中的令牌
     * @param publicKey 公钥
     * @return 用户信息
     * @throws Exception
     */
    public static UserModel getInfoFromToken(String token, byte[] publicKey) throws Exception {
        PublicKey publicKeyObj = RsaUtils.getPublicKey(publicKey);
        return getInfoFromToken(token, publicKeyObj);
    }
}