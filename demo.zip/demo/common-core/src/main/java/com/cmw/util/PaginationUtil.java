package com.cmw.util;

import com.cmw.core.vo.PageResult;
import com.cmw.core.vo.Pagination;

import java.util.List;
import java.util.Map;

/**
 * 分页工具类
 * @Author 肖家添
 * @Date 2019/9/2 23:42
 */
public class PaginationUtil {

    //-- 查询总行数标识
    private static String queryTotalTip = "_queryTotal";

    /**
     * 设置分页参数
     * @Author 肖家添
     * @Date 2019/9/2 23:42
     */
    public static void setPagingParams(
            Map<String, Object> params,
            Integer currPage,
            Integer pageSize
    ){
        if(pageSize == null || currPage == null) return;

        currPage--;
        if (currPage < 0) {
            currPage = 0;
        }

        Integer offset = 0;
        if (null != currPage && currPage.intValue() > 0) {
            offset = (currPage * pageSize);
        }

        params.put("offset", offset);
        params.put("pageSize", pageSize);
    }

    /**
     * 设置查询总行数的标识
     * @Author 肖家添
     * @Date 2019/9/3 0:01
     */
    public static void setQueryTotalParam(Map<String, Object> params){
        params.put(queryTotalTip, true);
    }

    /**
     * 从ListMap中取出total
     * @Author 肖家添
     * @Date 2019/9/2 23:45
     */
    public static Long getTotalByListMap(List<Map<String, Object>> queryResult){
        try{
            if(StringHandler.isValidObj(queryResult) && queryResult.size() > 0){
                Map<String, Object> totalCountData = queryResult.get(0);

                String key = "total";
                if(totalCountData.containsKey(key)){
                    Object totalObj = totalCountData.get("total");

                    if(StringHandler.isValidObj(totalObj)){
                        return Long.parseLong(totalObj.toString());
                    }
                }
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }

        return 0L;
    }

    /**
     * 获取分页结果
     * @Author 肖家添
     * @Date 2019/9/2 23:59
     */
    public static PageResult getResult(
            List<Map<String, Object>> dataResult,
            List<Map<String, Object>> totalResult,
            Integer currPage,
            Integer pageSize
    ){
        Long total = PaginationUtil.getTotalByListMap(totalResult);

        Pagination pagination = new Pagination(total, currPage, pageSize);

        PageResult<List<Map<String, Object>>> result = new PageResult(pagination, dataResult);

        return result;
    }

}
