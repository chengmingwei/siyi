package com.cmw.model.global;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 结果集工具类
 * @author chengmingwei
 * @date 2019-05-10 13:43
 */
public class ResultUtil {
    @JsonIgnore
    public static ResultModel getSuccess(){
        ResultModel resultModel = new ResultModel();
        return resultModel;
    }

    @JsonIgnore
    public static ResultModel getSuccess(String msg){
        ResultModel resultModel = new ResultModel();
        resultModel.setMsg(msg);
        return resultModel;
    }

    @JsonIgnore
    public static <T> ResultModel getSuccess(T datas){
        ResultModel resultModel = new ResultModel();
        resultModel.setDatas(datas);
        return resultModel;
    }

    @JsonIgnore
    public static <T> ResultModel getSuccess(T datas, int code){
        ResultModel resultModel = new ResultModel();
        resultModel.setDatas(datas);
        resultModel.setCode(code);
        return resultModel;
    }

    @JsonIgnore
    public static <T> ResultModel getSuccess(T datas, String msg){
        ResultModel resultModel = new ResultModel();
        resultModel.setDatas(datas);
        resultModel.setMsg(msg);
        return resultModel;
    }

    @JsonIgnore
    public static <T> ResultModel getSuccess(T datas, String msg, int code){
        ResultModel resultModel = new ResultModel();
        resultModel.setDatas(datas);
        resultModel.setMsg(msg);
        resultModel.setCode(code);
        return resultModel;
    }

    @JsonIgnore
    public static <T> ResultModel getFailure(String msg, int code){
        ResultModel resultModel = new ResultModel();
        resultModel.setMsg(msg);
        resultModel.setCode(code);
        return resultModel;
    }

    @JsonIgnore
    public static ResultModel getFailure(String msg){
        ResultModel resultModel = new ResultModel();
        resultModel.setMsg(msg);
        resultModel.setSuccess(false);
        resultModel.setCode(ResultModel.CODE_FAILURE);
        return resultModel;
    }

}
