package com.cmw.model.back;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @ClassName SaasProdModel
 * @Description: Saas产品信息模型
 * @Author cmw
 * @Date 2020/9/22 00：00
 * @Version V1.0
 **/
public class SaasProdModel implements Serializable {
    //产品ID
    private Long id;
    //产品编号
    private String code;
    //产品名称
    private String pname;
    //产品价格
    private BigDecimal price;
    //校区数量
    private Integer schoolCount;
    //手续费率
    private Float freeRate;
    //品牌自定义
    private Byte brandFlag = 0;
    //付款限制
    private Byte payLimit = 0;
    //降级产品
    private Long dprodId;
    //限免截止时间
    private Date nopayTime;
    //单个校区购买价格
    private BigDecimal schoolPrice;

    public SaasProdModel() {
    }

    public BigDecimal getSchoolPrice() {
        return schoolPrice;
    }

    public void setSchoolPrice(BigDecimal schoolPrice) {
        this.schoolPrice = schoolPrice;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getSchoolCount() {
        return schoolCount;
    }

    public void setSchoolCount(Integer schoolCount) {
        this.schoolCount = schoolCount;
    }

    public Float getFreeRate() {
        return freeRate;
    }

    public void setFreeRate(Float freeRate) {
        this.freeRate = freeRate;
    }

    public Byte getBrandFlag() {
        return brandFlag;
    }

    public void setBrandFlag(Byte brandFlag) {
        this.brandFlag = brandFlag;
    }

    public Byte getPayLimit() {
        return payLimit;
    }

    public void setPayLimit(Byte payLimit) {
        this.payLimit = payLimit;
    }

    public Long getDprodId() {
        return dprodId;
    }

    public void setDprodId(Long dprodId) {
        this.dprodId = dprodId;
    }

    public Date getNopayTime() {
        return nopayTime;
    }

    public void setNopayTime(Date nopayTime) {
        this.nopayTime = nopayTime;
    }
}
