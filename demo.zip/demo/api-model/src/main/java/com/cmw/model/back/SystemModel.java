package com.cmw.model.back;

import java.io.Serializable;

/**
 * @ClassName SystemModel
 * @Description: 系统模型对象
 * @Author cmw
 * @Date 2020/9/21 23：56
 * @Version V1.0
 **/
public class SystemModel  implements Serializable {
    //系统ID
    private Long systemId;
    //系统名称
    private String name;

    public SystemModel(Long systemId, String name) {
        this.systemId = systemId;
        this.name = name;
    }

    public SystemModel() {
    }

    /**
     * 获取 系统ID
     * @return  返回系统ID
     */
    public Long getSystemId() {
        return systemId;
    }

    /**
     * 设置 系统ID
     * @param systemId  系统ID
     */
    public void setSystemId(Long systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 系统名称
     * @return  返回系统名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置 系统名称
     * @param name  系统名称
     */
    public void setName(String name) {
        this.name = name;
    }
}
