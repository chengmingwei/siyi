package com.cmw.model.back;

import java.io.Serializable;

/**
 * 后台系统用户信息Model
 * @Author chengmingwei
 * @date 2019-03-27 17:20
 */
public class UserModel implements Serializable {
    /**
     * 用户ID
     */
    private Long id;
    /**
     * 账号
     */
    private String userName;
    /**
     * 部门ID
     */
    private Long indeptId;
    /**
     * 公司ID
     */
    private Long incompId;
    /**
     * 员工ID
     */
    private Long inempId;
    /**
     * 用户类型
     */
    private Integer utype;


    public UserModel() {
        super();
    }

    public UserModel(Long id, String userName, Long indeptId, Long incompId, Long inempId, Integer utype) {
        this.id = id;
        this.userName = userName;
        this.indeptId = indeptId;
        this.incompId = incompId;
        this.inempId = inempId;
        this.utype = utype;
    }

    /**
     * 设置用户ID
     * @param id 用户ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 设置账号
     * @param userName 账号
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * 设置部门ID
     * @param indeptId 部门ID
     */
    public void setIndeptId(Long indeptId) {
        this.indeptId = indeptId;
    }

    /**
     * 设置公司ID
     * @param incompId 公司ID
     */
    public void setIncompId(Long incompId) {
        this.incompId = incompId;
    }

    /**
     * 设置员工ID
     * @param inempId 员工ID
     */
    public void setInempId(Long inempId) {
        this.inempId = inempId;
    }

    /**
     * 设置用户类型
     * @param utype   用户类型
     */
    public void setUtype(Integer utype) {
        this.utype = utype;
    }


    /**
     * 获取用户ID
     * @return 返回用户ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 获取账号
     * @return 返回账号
     */
    public String getUserName() {
        return userName;
    }

    /**
     * 获取部门ID
     * @return 返回部门ID
     */
    public Long getIndeptId() {
        return indeptId;
    }

    /**
     * 获取公司ID
     * @return 返回公司ID
     */
    public Long getIncompId() {
        return incompId;
    }

    /**
     * 获取员工ID
     * @return 返回员工ID
     */
    public Long getInempId() {
        return inempId;
    }

    /**
     * 获取用户类型
     * @return 返回用户类型
     */
    public Integer getUtype() {
        return utype;
    }


}
