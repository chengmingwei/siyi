package com.cmw.model.back;

import java.io.Serializable;

/**
 * @ClassName RightModel
 * @Description: 权限数据模型类
 * @Author chengmingwei
 * @Date 2020/9/8 16:59
 * @Version V1.0
 **/
public class RightModel implements Serializable {
    private String sourceTag;

    private String tabAlisName;

    private boolean flag = true;

    private boolean isOrgRight = false; //是否只到本机构级别数据权限

    public RightModel() {
    }

    public RightModel(String sourceTag, String tabAlisName, boolean flag) {
        this.sourceTag = sourceTag;
        this.tabAlisName = tabAlisName;
        this.flag = flag;
    }

    public RightModel(String sourceTag, String tabAlisName, boolean flag, boolean isOrgRight) {
        this.sourceTag = sourceTag;
        this.tabAlisName = tabAlisName;
        this.flag = flag;
        this.isOrgRight = isOrgRight;
    }

    public String getSourceTag() {
        return sourceTag;
    }

    public void setSourceTag(String sourceTag) {
        this.sourceTag = sourceTag;
    }

    public String getTabAlisName() {
        return tabAlisName;
    }

    public void setTabAlisName(String tabAlisName) {
        this.tabAlisName = tabAlisName;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public boolean isOrgRight() {
        return isOrgRight;
    }

    public void setOrgRight(boolean orgRight) {
        isOrgRight = orgRight;
    }
}