package com.cmw.model.global;

import java.io.Serializable;

/**
 * Controller 层 结果数据模型
 * @author chengmingwei
 * @date 2019-05-10 13:07
 * @param <T>
 */
public class ResultModel<T> implements Serializable {
    String msg = "ok";
    int code = CODE_SUCCESS;
    boolean success = true;
    T datas;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean getSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public T getDatas() {
        return datas;
    }

    public void setDatas(T datas) {
        this.datas = datas;
    }

    /**
     * 消息码 [1：成功]
     */
    public static final int CODE_SUCCESS = 1;

    /**
     * 消息码 [0：失败]
     */
    public static final int CODE_FAILURE = 0;
}
