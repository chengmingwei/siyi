package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.RoleEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.RoleService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 角色  ACTION类
 * @author 程明卫
 * @date 2019-04-02 00:14:57
 */
@Description(remark="角色ACTION",createDate="2019-04-02 00:14:57",author="程明卫")
@Api(value = "角色微服务", description = "#CONTROLLER# 2019-04-02 00:14:57 程明卫")
@RestController
@RequestMapping({"/role"})
public class RoleController{
	@Resource(name="roleService")
	private RoleService roleService;
	
	 /**
     * 跳转主页面
     * @return
     */
     @ApiOperation("角色首页API")
    @GetMapping(value = "/home")
    public JSONObject home(Map<String, Object> params) throws Exception{
       List<RoleEntity> list = roleService.getListAll();
       return PageHandler.getJson(list);
    }

    /**
     * 跳转列表页面
     * @return
     */
    @ApiOperation("分页查询用户信息列表API")
    @PostMapping("list")
    public JSONObject list(@RequestBody Map<String,Object> params){
        Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
       // params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = roleService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
    }
    /**
     * 根据部门名称获取
     * @param request
     * @param response
     * @return
     */
    @ApiOperation("根据角色名称获取")
    @RequestMapping(value = "/getByName")
    public JSONObject getByCode(HttpServletRequest request, HttpServletResponse response){
        String name = request.getParameter("name");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("name",name);
        List<RoleEntity> list = new ArrayList<RoleEntity>();
        if (StringHandler.isValidStr(name)){
            list  =roleService.getList(map);
        }else {
            list = roleService.getListAll();
        }

        return PageHandler.getJson(list);
    }
    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取角色")
    @PostMapping(value = "/{id}")
    public JSONObject info(@ApiParam("角色ID") @PathVariable("id") Long id){
        if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        RoleEntity obj = roleService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存角色")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestBody  Map<String, String> params) throws Exception{
        try{
            Map<String, Object> dataResult = (Map<String, Object>)roleService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除角色")
    @DeleteMapping(value = "/{id}")
    public JSONObject delete(@ApiParam("角色ID") @PathVariable("id")  Long id) throws Exception{
        roleService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }

    /**
     * 菜单权限 ==> 获取角色列表
     * @Author 肖家添
     * @Date 2019/5/12 14:11
     */
    @ApiOperation("菜单权限获取角色列表")
    @PostMapping(value = "/getRoleForRightMenu")
    public JSONObject getRoleForRightMenu(){
        return PageHandler.getJson(roleService.getRoleForRightMenu());
    }

    /**
     * 获取角色
     * @Author 肖家添
     * @Date 2019/6/10 15:08
     */
    @ApiOperation("获取角色")
    @PostMapping(value = "/getRoleByParams")
    public JSONObject getRoleByParams(@RequestParam Map<String, Object> params){

        String appendSql = " limit 1 ";
        params.put("appendSQL", appendSql);

        return PageHandler.getJson(roleService.getListMap(params));
    }
}
