package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.MsgTemplateEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;


/**
 * 消息模板表  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 23:14:25
 */
@Description(remark="消息模板表DAO Mapper接口",createDate="2019-04-10 23:14:25",author="程明卫")
@Component
@Mapper
public interface MsgTemplateDao extends GenericDaoInter<MsgTemplateEntity, Long>{

}
