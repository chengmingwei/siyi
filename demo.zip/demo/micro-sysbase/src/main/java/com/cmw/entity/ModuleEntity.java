package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 模块表
 * @author 程明卫
 * @date 2019-03-27 15:12:47
 */
@Description(remark="模块表实体",createDate="2019-03-27 15:12:47",author="程明卫")
@Entity
@Table(name="ts_Module")
@SuppressWarnings("serial")
public class ModuleEntity extends IdBaseEntity {
	
	
	 @Description(remark="菜单ID")
	 @Column(name="menuId" ,nullable=false )
	 private Long menuId;

	 @Description(remark="按钮样式")
	 @Column(name="iconCls" ,length=30 )
	 private String iconCls;

	 @Description(remark="按钮名称")
	 @Column(name="name" ,nullable=false ,length=30 )
	 private String name;

	 @Description(remark="按钮编号")
	 @Column(name="code" ,nullable=false ,length=20 )
	 private String code;


	public ModuleEntity() {

	}

	
	/**
	  * 设置菜单ID的值
	 * @param 	menuId	 菜单ID
	**/
	public void setMenuId(Long  menuId){
		 this.menuId=menuId;
 	}

	/**
	  * 获取菜单ID的值
	 * @return 返回菜单ID的值
	**/
	public Long getMenuId(){
		 return menuId;
 	}

	/**
	  * 设置按钮样式的值
	 * @param 	iconCls	 按钮样式
	**/
	public void setIconCls(String  iconCls){
		 this.iconCls=iconCls;
 	}

	/**
	  * 获取按钮样式的值
	 * @return 返回按钮样式的值
	**/
	public String getIconCls(){
		 return iconCls;
 	}

	/**
	  * 设置按钮名称的值
	 * @param 	name	 按钮名称
	**/
	public void setName(String  name){
		 this.name=name;
 	}

	/**
	  * 获取按钮名称的值
	 * @return 返回按钮名称的值
	**/
	public String getName(){
		 return name;
 	}

	/**
	  * 设置按钮编号的值
	 * @param 	code	 按钮编号
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取按钮编号的值
	 * @return 返回按钮编号的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{menuId,iconCls,name,code};
	}

	@Override
	public String[] getFields() {
		return new String[]{"menuId","iconCls","name","code"};
	}

}
