package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.MenuEntity;


/**
 * 菜单表  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 15:02:39
 */
@Description(remark="菜单表DAO Mapper接口",createDate="2019-03-27 15:02:39",author="程明卫")
@Mapper
public interface MenuDao extends GenericDaoInter<MenuEntity, Long>{

    /**
     * 获取系统菜单
     * @Author 肖家添
     * @Date 2019/5/10 11:44
     */
    List<MenuEntity> getSystemMenu(Map<String, Object> params);

    /**
     * 获取没有权限记录的上级节点
     * @Author 肖家添
     * @Date 2019/5/12 20:39
     */
    List<Map<String, Object>> getNotHasRightForParentNode(Long roleId);

}
