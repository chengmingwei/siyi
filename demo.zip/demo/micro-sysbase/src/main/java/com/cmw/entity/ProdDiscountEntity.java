package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * Saas产品折扣表
 * @author 程明卫
 * @date 2020-06-07 15:01:53
 */
@Description(remark="Saas产品折扣表实体",createDate="2020-06-07 15:01:53",author="程明卫")
@Entity
@Table(name="ts_ProdDiscount")
@SuppressWarnings("serial")
public class ProdDiscountEntity extends IdBaseEntity {

	@Description(remark="产品ID")
	@Column(name="productId" ,nullable=false ,length=20 )
	private Long productId;

	@Description(remark="折扣编号")
	@Column(name="code" ,nullable=false ,length=20 )
	private String code;

	 @Description(remark="失效日期")
	 @Column(name="expireDate" )
	 private Date expireDate;

	 @Description(remark="生效日期")
	 @Column(name="effectiveDate" )
	 private Date effectiveDate;

	 @Description(remark="折扣率")
	 @Column(name="rate" ,nullable=false ,scale=2)
	 private Float rate = 0f;

	 @Description(remark="时长值")
	 @Column(name="durationVal" ,nullable=false )
	 private Integer durationVal = 1;

	 @Description(remark="比较方式")
	 @Column(name="eqType" ,nullable=false )
	 private Integer eqType = 1;

	 @Description(remark="打折方式")
	 @Column(name="disType" ,nullable=false )
	 private Integer disType = 0;

	 @Description(remark="优惠方式")
	 @Column(name="preWay" ,nullable=false )
	 private Byte preWay;

	 @Description(remark="折扣名称")
	 @Column(name="dname" ,nullable=false ,length=50 )
	 private String dname;



	public ProdDiscountEntity() {

	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	/**
	  * 设置失效日期的值
	 * @param 	expireDate	 失效日期
	**/
	public void setExpireDate(Date  expireDate){
		 this.expireDate=expireDate;
 	}

	/**
	  * 获取失效日期的值
	 * @return 返回失效日期的值
	**/
	public Date getExpireDate(){
		 return expireDate;
 	}

	/**
	  * 设置生效日期的值
	 * @param 	effectiveDate	 生效日期
	**/
	public void setEffectiveDate(Date  effectiveDate){
		 this.effectiveDate=effectiveDate;
 	}

	/**
	  * 获取生效日期的值
	 * @return 返回生效日期的值
	**/
	public Date getEffectiveDate(){
		 return effectiveDate;
 	}

	/**
	  * 设置折扣率的值
	 * @param 	rate	 折扣率
	**/
	public void setRate(Float  rate){
		 this.rate=rate;
 	}

	/**
	  * 获取折扣率的值
	 * @return 返回折扣率的值
	**/
	public Float getRate(){
		 return rate;
 	}

	/**
	  * 设置时长值的值
	 * @param 	durationVal	 时长值
	**/
	public void setDurationVal(Integer  durationVal){
		 this.durationVal=durationVal;
 	}

	/**
	  * 获取时长值的值
	 * @return 返回时长值的值
	**/
	public Integer getDurationVal(){
		 return durationVal;
 	}

	/**
	  * 设置比较方式的值
	 * @param 	eqType	 比较方式
	**/
	public void setEqType(Integer  eqType){
		 this.eqType=eqType;
 	}

	/**
	  * 获取比较方式的值
	 * @return 返回比较方式的值
	**/
	public Integer getEqType(){
		 return eqType;
 	}

	/**
	  * 设置打折方式的值
	 * @param 	disType	 打折方式
	**/
	public void setDisType(Integer  disType){
		 this.disType=disType;
 	}

	/**
	  * 获取打折方式的值
	 * @return 返回打折方式的值
	**/
	public Integer getDisType(){
		 return disType;
 	}

	/**
	  * 设置优惠方式的值
	 * @param 	preWay	 优惠方式
	**/
	public void setPreWay(Byte  preWay){
		 this.preWay=preWay;
 	}

	/**
	  * 获取优惠方式的值
	 * @return 返回优惠方式的值
	**/
	public Byte getPreWay(){
		 return preWay;
 	}

	/**
	  * 设置折扣名称的值
	 * @param 	dname	 折扣名称
	**/
	public void setDname(String  dname){
		 this.dname=dname;
 	}

	/**
	  * 获取折扣名称的值
	 * @return 返回折扣名称的值
	**/
	public String getDname(){
		 return dname;
 	}

	/**
	  * 设置产品ID的值
	 * @param 	code	 产品ID
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取产品ID的值
	 * @return 返回产品ID的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{expireDate,effectiveDate,rate,durationVal,eqType,disType,preWay,dname,code,productId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"expireDate","effectiveDate","rate","durationVal","eqType","disType","preWay","dname","code","productId"};
	}

}
