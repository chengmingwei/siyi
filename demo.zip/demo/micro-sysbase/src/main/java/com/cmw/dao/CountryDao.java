package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.CountryEntity;


/**
 * 国家表  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 13:57:47
 */
@Description(remark="国家表DAO Mapper接口",createDate="2019-03-27 13:57:47",author="程明卫")
@Mapper
public interface CountryDao extends GenericDaoInter<CountryEntity, Long>{

}
