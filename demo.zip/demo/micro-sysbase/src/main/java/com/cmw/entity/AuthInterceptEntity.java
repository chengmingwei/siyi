package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;

import com.cmw.core.base.entity.IdBaseEntity;


/**
 * AuthIntercept
 * @author 程明卫
 * @date 2020-09-16 10:09:32
 */
@Description(remark="AuthIntercept实体",createDate="2020-09-16 10:09:32",author="程明卫")
@Entity
@Table(name="ts_AuthIntercept")
@SuppressWarnings("serial")
public class AuthInterceptEntity extends IdBaseEntity {
	
	
	 @Description(remark="是否本机构数据")
	 @Column(name="orgRight" ,nullable=false )
	 private Byte orgRight = 0;

	 @Description(remark="可用开关")
	 @Column(name="flag" ,nullable=false )
	 private Byte flag = 1;

	 @Description(remark="表别名")
	 @Column(name="tabAlisName" ,length=50 )
	 private String tabAlisName;

	 @Description(remark="替换插槽")
	 @Column(name="slotCode" ,length=100 )
	 private String slotCode;

	 @Description(remark="方法名")
	 @Column(name="methodName" ,nullable=false ,length=100 )
	 private String methodName;

	 @Description(remark="拦截类型")
	 @Column(name="itype" ,nullable=false )
	 private Integer itype;

	 @Description(remark="微服务名称")
	 @Column(name="microName" ,nullable=false ,length=50 )
	 private String microName;


	public AuthInterceptEntity() {

	}

	
	/**
	  * 设置是否本机构数据的值
	 * @param 	orgRight	 是否本机构数据
	**/
	public void setOrgRight(Byte  orgRight){
		 this.orgRight=orgRight;
 	}

	/**
	  * 获取是否本机构数据的值
	 * @return 返回是否本机构数据的值
	**/
	public Byte getOrgRight(){
		 return orgRight;
 	}

	/**
	  * 设置可用开关的值
	 * @param 	flag	 可用开关
	**/
	public void setFlag(Byte  flag){
		 this.flag=flag;
 	}

	/**
	  * 获取可用开关的值
	 * @return 返回可用开关的值
	**/
	public Byte getFlag(){
		 return flag;
 	}

	/**
	  * 设置表别名的值
	 * @param 	tabAlisName	 表别名
	**/
	public void setTabAlisName(String  tabAlisName){
		 this.tabAlisName=tabAlisName;
 	}

	/**
	  * 获取表别名的值
	 * @return 返回表别名的值
	**/
	public String getTabAlisName(){
		 return tabAlisName;
 	}

	/**
	  * 设置替换插槽的值
	 * @param 	slotCode	 替换插槽
	**/
	public void setSlotCode(String  slotCode){
		 this.slotCode=slotCode;
 	}

	/**
	  * 获取替换插槽的值
	 * @return 返回替换插槽的值
	**/
	public String getSlotCode(){
		 return slotCode;
 	}

	/**
	  * 设置方法名的值
	 * @param 	methodName	 方法名
	**/
	public void setMethodName(String  methodName){
		 this.methodName=methodName;
 	}

	/**
	  * 获取方法名的值
	 * @return 返回方法名的值
	**/
	public String getMethodName(){
		 return methodName;
 	}

	/**
	  * 设置拦截类型的值
	 * @param 	itype	 拦截类型
	**/
	public void setItype(Integer  itype){
		 this.itype=itype;
 	}

	/**
	  * 获取拦截类型的值
	 * @return 返回拦截类型的值
	**/
	public Integer getItype(){
		 return itype;
 	}

	/**
	  * 设置微服务名称的值
	 * @param 	microName	 微服务名称
	**/
	public void setMicroName(String  microName){
		 this.microName=microName;
 	}

	/**
	  * 获取微服务名称的值
	 * @return 返回微服务名称的值
	**/
	public String getMicroName(){
		 return microName;
 	}

	/**
	  * 设置ID的值
	 * @param 	id	 ID
	**/
	public void setId(Long  id){
		 this.id=id;
 	}

	/**
	  * 获取ID的值
	 * @return 返回ID的值
	**/
	public Long getId(){
		 return id;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{orgRight,flag,tabAlisName,slotCode,methodName,itype,microName,id};
	}

	@Override
	public String[] getFields() {
		return new String[]{"orgRight","flag","tabAlisName","slotCode","methodName","itype","microName","id"};
	}

}
