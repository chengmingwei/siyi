package com.cmw.interceptor;

import com.cmw.core.base.annotation.CryptoAnnotation;

import com.cmw.core.base.crypto.CryptoAspect;
import com.cmw.core.base.crypto.CryptoFactory;
import com.cmw.core.base.crypto.IStrategyCrypto;
import com.cmw.core.cache.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.util.StringUtil;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.aop.aspectj.MethodInvocationProceedingJoinPoint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Arrays;


/**
 * @ClassName ServiceAspect
 * @Description: Service 业务拦截
 * @Author chengmingwei
 * @Date 2020/8/27 09:44
 * @Version V1.0
 **/
@Slf4j
@Component
@Aspect
public class ServiceAspect {

    CryptoAspect cryptoAspect = new CryptoAspect();

    @Autowired
    RedisService redisService;

    @Around("execution(* com.cmw.service..*.*(..))")
    public Object arroundInvoke(ProceedingJoinPoint point) throws Throwable {
        log.info("【*** Service-Before ***】执行参数："
                + Arrays.toString(point.getArgs()));
        cryptoAspect.setRedisService(redisService);
        Method targetMethod = cryptoAspect.getTargetMethod(point);
        Object[] args = point.getArgs();
        Object obj = null;
        if(null != targetMethod){   //基于加密解密注解
            obj = cryptoAspect.parseMethodDatas(targetMethod, point);
           return  (null == obj) ? obj = point.proceed(args) : obj;
        }else{
            obj = point.proceed(args); // 进行具体业务调用
        }
        log.info("【*** Service-After ***】返回结果：" + obj);
        return obj;
    }

}
