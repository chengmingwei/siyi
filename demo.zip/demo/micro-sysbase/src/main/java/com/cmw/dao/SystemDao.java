package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.SystemEntity;


/**
 * 系统  Mapper接口
 * @author 程明卫
 * @date 2020-06-07 14:47:24
 */
@Description(remark="系统DAO Mapper接口",createDate="2020-06-07 14:47:24",author="程明卫")
@Mapper
public interface SystemDao extends GenericDaoInter<SystemEntity, Long>{

}
