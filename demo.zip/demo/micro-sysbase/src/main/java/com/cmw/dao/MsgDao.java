package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.MsgEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.Map;


/**
 * 消息表  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 23:17:10
 */
@Description(remark="消息表DAO Mapper接口",createDate="2019-04-10 23:17:10",author="程明卫")
@Mapper
public interface MsgDao extends GenericDaoInter<MsgEntity, Long>{

    /**
     * 将当前用户或指定消息记录ID的所有消息更新为已读
     * @param pars
     */
   void updateToReaded(Map<String, Object> pars);

    /**
     * 获取未读消息记录数
     * @param pars
     */
    Integer getUnReadTotals(Map<String, Object> pars);
}
