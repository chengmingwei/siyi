package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import java.util.Date;


/**
 * 员工信息
 * @author 程明卫
 * @date 2019-04-02 00:12:31
 */
@Description(remark="员工信息实体",createDate="2019-04-02 00:12:31",author="程明卫")
@Entity
@Table(name="ts_Employee")
@SuppressWarnings("serial")
public class EmployeeEntity extends IdBaseEntity {
	
	
	 @Description(remark="员工编号")
	 @Column(name="code" ,nullable=false ,length=20 )
	 private String code;

	 @Description(remark="姓名")
	 @Column(name="name" ,nullable=false ,length=30 )
	 private String name;

	 @Description(remark="手机号")
	 @Column(name="phone" ,nullable=false ,length=20 )
	 private String phone;

	 @Description(remark="Email")
	 @Column(name="email" ,length=30 )
	 private String email;

	@Description(remark="性别")
	@Column(name="sex" ,nullable=false )
	private Byte sex = 0;

	 @Description(remark="生日")
	 @Column(name="birthday" )
	 private Date birthday;

	 @Description(remark="入职日期")
	 @Column(name="indate" )
	 private Date indate;

	 @Description(remark="职位")
	 @Column(name="postId" )
	 private Long postId;

	 @Description(remark="所属部门")
	 @Column(name="indeptId" )
	 private Long indeptId;

	 @Description(remark="所属公司")
	 @Column(name="incompId" )
	 private Long incompId;

	 @Description(remark="状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus;


	public EmployeeEntity() {

	}

	/**
	 * 设置性别的值
	 * @param 	sex	 性别
	 **/
	public void setSex(Byte  sex){
		this.sex=sex;
	}

	/**
	 * 获取性别的值
	 * @return 返回性别的值
	 **/
	public Byte getSex(){
		return sex;
	}
	
	/**
	  * 设置员工编号的值
	 * @param 	code	 员工编号
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取员工编号的值
	 * @return 返回员工编号的值
	**/
	public String getCode(){
		 return code;
 	}

	/**
	  * 设置姓名的值
	 * @param 	name	 姓名
	**/
	public void setName(String  name){
		 this.name=name;
 	}

	/**
	  * 获取姓名的值
	 * @return 返回姓名的值
	**/
	public String getName(){
		 return name;
 	}

	/**
	  * 设置手机号的值
	 * @param 	phone	 手机号
	**/
	public void setPhone(String  phone){
		 this.phone=phone;
 	}

	/**
	  * 获取手机号的值
	 * @return 返回手机号的值
	**/
	public String getPhone(){
		 return phone;
 	}

	/**
	  * 设置Email的值
	 * @param 	email	 Email
	**/
	public void setEmail(String  email){
		 this.email=email;
 	}

	/**
	  * 获取Email的值
	 * @return 返回Email的值
	**/
	public String getEmail(){
		 return email;
 	}

	/**
	  * 设置生日的值
	 * @param 	birthday	 生日
	**/
	public void setBirthday(Date  birthday){
		 this.birthday=birthday;
 	}

	/**
	  * 获取生日的值
	 * @return 返回生日的值
	**/
	public Date getBirthday(){
		 return birthday;
 	}

	/**
	  * 设置入职日期的值
	 * @param 	indate	 入职日期
	**/
	public void setIndate(Date  indate){
		 this.indate=indate;
 	}

	/**
	  * 获取入职日期的值
	 * @return 返回入职日期的值
	**/
	public Date getIndate(){
		 return indate;
 	}

	/**
	  * 设置职位的值
	 * @param 	postId	 职位
	**/
	public void setPostId(Long  postId){
		 this.postId=postId;
 	}

	/**
	  * 获取职位的值
	 * @return 返回职位的值
	**/
	public Long getPostId(){
		 return postId;
 	}

	/**
	  * 设置所属部门的值
	 * @param 	indeptId	 所属部门
	**/
	public void setIndeptId(Long  indeptId){
		 this.indeptId=indeptId;
 	}

	/**
	  * 获取所属部门的值
	 * @return 返回所属部门的值
	**/
	public Long getIndeptId(){
		 return indeptId;
 	}

	/**
	  * 设置所属公司的值
	 * @param 	incompId	 所属公司
	**/
	public void setIncompId(Long  incompId){
		 this.incompId=incompId;
 	}

	/**
	  * 获取所属公司的值
	 * @return 返回所属公司的值
	**/
	public Long getIncompId(){
		 return incompId;
 	}

	/**
	  * 设置状态的值
	 * @param 	xstatus	 状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取状态的值
	 * @return 返回状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}



	@Override
	public Object[] getDatas() {
		return null;
	}

	@Override
	public String[] getFields() {
		return null;
	}

}
