package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 卡片菜单表
 * @author 程明卫
 * @date 2019-03-27 15:01:18
 */
@Description(remark="卡片菜单表实体",createDate="2019-03-27 15:01:18",author="程明卫")
@Entity
@Table(name="ts_Accordion")
@SuppressWarnings("serial")
public class AccordionEntity extends IdBaseEntity {
	
	
	 @Description(remark="排列顺序")
	 @Column(name="orderNo" ,nullable=false )
	 private Integer orderNo = 1;

	 @Description(remark="数据URL")
	 @Column(name="url" ,length=200 )
	 private String url;

	 @Description(remark="加载类型")
	 @Column(name="type" ,nullable=false )
	 private Integer type = 0;

	 @Description(remark="图标样式")
	 @Column(name="iconCls" ,length=50 )
	 private String iconCls;

	 @Description(remark="名称")
	 @Column(name="name" ,nullable=false ,length=50 )
	 private String name;

	 @Description(remark="卡片编码")
	 @Column(name="code" ,nullable=false ,length=20 )
	 private String code;


	public AccordionEntity() {

	}

	
	/**
	  * 设置排列顺序的值
	 * @param 	orderNo	 排列顺序
	**/
	public void setOrderNo(Integer  orderNo){
		 this.orderNo=orderNo;
 	}

	/**
	  * 获取排列顺序的值
	 * @return 返回排列顺序的值
	**/
	public Integer getOrderNo(){
		 return orderNo;
 	}

	/**
	  * 设置数据URL的值
	 * @param 	url	 数据URL
	**/
	public void setUrl(String  url){
		 this.url=url;
 	}

	/**
	  * 获取数据URL的值
	 * @return 返回数据URL的值
	**/
	public String getUrl(){
		 return url;
 	}

	/**
	  * 设置加载类型的值
	 * @param 	type	 加载类型
	**/
	public void setType(Integer  type){
		 this.type=type;
 	}

	/**
	  * 获取加载类型的值
	 * @return 返回加载类型的值
	**/
	public Integer getType(){
		 return type;
 	}

	/**
	  * 设置图标样式的值
	 * @param 	iconCls	 图标样式
	**/
	public void setIconCls(String  iconCls){
		 this.iconCls=iconCls;
 	}

	/**
	  * 获取图标样式的值
	 * @return 返回图标样式的值
	**/
	public String getIconCls(){
		 return iconCls;
 	}

	/**
	  * 设置名称的值
	 * @param 	name	 名称
	**/
	public void setName(String  name){
		 this.name=name;
 	}

	/**
	  * 获取名称的值
	 * @return 返回名称的值
	**/
	public String getName(){
		 return name;
 	}

	/**
	  * 设置卡片编码的值
	 * @param 	code	 卡片编码
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取卡片编码的值
	 * @return 返回卡片编码的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{orderNo,url,type,iconCls,name,code};
	}

	@Override
	public String[] getFields() {
		return new String[]{"orderNo","url","type","iconCls","name","code"};
	}

}
