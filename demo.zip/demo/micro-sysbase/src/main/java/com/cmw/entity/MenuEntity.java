package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import java.util.ArrayList;
import java.util.List;


/**
 * 菜单表
 *
 * @author 程明卫
 * @date 2019-03-27 15:02:39
 */
@Description(remark = "菜单表实体", createDate = "2019-03-27 15:02:39", author = "程明卫")
@Entity
@Table(name = "ts_Menu")
@SuppressWarnings("serial")
public class MenuEntity extends IdBaseEntity {


    @Description(remark = "排列顺序")
    @Column(name = "orderNo", nullable = false)
    private Integer orderNo = 1;

    @Description(remark = "叶子")
    @Column(name = "leaf", length = 4)
    private String leaf;

    @Description(remark = "TabId")
    @Column(name = "tabId", length = 50)
    private String tabId;

    @Description(remark = "附加参数")
    @Column(name = "params", length = 200)
    private String params;

    @Description(remark = "url")
    @Column(name = "jsArray", nullable = false, length = 200)
    private String jsArray;

    @Description(remark = "UI加载方式")
    @Column(name = "loadType", nullable = false)
    private Integer loadType = 1;

    @Description(remark = "菜单大图标")
    @Column(name = "biconCls", length = 200)
    private String biconCls;

    @Description(remark = "菜单样式")
    @Column(name = "iconCls", length = 50)
    private String iconCls;

    @Description(remark = "父菜单类型")
    @Column(name = "type", nullable = false)
    private Integer type = 2;

    @Description(remark = "菜单名称")
    @Column(name = "name", nullable = false, length = 50)
    private String name;

    @Description(remark = "菜单编码")
    @Column(name = "code", nullable = false, length = 20)
    private String code;

    @Description(remark = "父菜单ID")
    @Column(name = "pid", nullable = false)
    private Long pid;

    @Description(remark = "卡片ID")
    @Column(name = "accordionId", nullable = false)
    private Long accordionId = -1L;

    @Description(remark = "菜单ID")
    @Column(name = "menuID", nullable = false)
    private Long menuID;

    @Description(remark = "子菜单")
    @Transient
    private List<MenuEntity>  childrenMenu = new ArrayList<>();

    @Description(remark="修改人")
    private UserEntity modifierUser = new UserEntity();

    public MenuEntity() {

    }


    /**
     * 设置排列顺序的值
     *
     * @param orderNo 排列顺序
     **/
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * 获取排列顺序的值
     *
     * @return 返回排列顺序的值
     **/
    public Integer getOrderNo() {
        return orderNo;
    }

    /**
     * 设置叶子的值
     *
     * @param leaf 叶子
     **/
    public void setLeaf(String leaf) {
        this.leaf = leaf;
    }

    /**
     * 获取叶子的值
     *
     * @return 返回叶子的值
     **/
    public String getLeaf() {
        return leaf;
    }

    /**
     * 设置TabId的值
     *
     * @param tabId TabId
     **/
    public void setTabId(String tabId) {
        this.tabId = tabId;
    }

    /**
     * 获取TabId的值
     *
     * @return 返回TabId的值
     **/
    public String getTabId() {
        return tabId;
    }

    /**
     * 设置附加参数的值
     *
     * @param params 附加参数
     **/
    public void setParams(String params) {
        this.params = params;
    }

    /**
     * 获取附加参数的值
     *
     * @return 返回附加参数的值
     **/
    public String getParams() {
        return params;
    }

    /**
     * 设置url的值
     *
     * @param jsArray url
     **/
    public void setJsArray(String jsArray) {
        this.jsArray = jsArray;
    }

    /**
     * 获取url的值
     *
     * @return 返回url的值
     **/
    public String getJsArray() {
        return jsArray;
    }

    /**
     * 设置UI加载方式的值
     *
     * @param loadType UI加载方式
     **/
    public void setLoadType(Integer loadType) {
        this.loadType = loadType;
    }

    /**
     * 获取UI加载方式的值
     *
     * @return 返回UI加载方式的值
     **/
    public Integer getLoadType() {
        return loadType;
    }

    /**
     * 设置菜单大图标的值
     *
     * @param biconCls 菜单大图标
     **/
    public void setBiconCls(String biconCls) {
        this.biconCls = biconCls;
    }

    /**
     * 获取菜单大图标的值
     *
     * @return 返回菜单大图标的值
     **/
    public String getBiconCls() {
        return biconCls;
    }

    /**
     * 设置菜单样式的值
     *
     * @param iconCls 菜单样式
     **/
    public void setIconCls(String iconCls) {
        this.iconCls = iconCls;
    }

    /**
     * 获取菜单样式的值
     *
     * @return 返回菜单样式的值
     **/
    public String getIconCls() {
        return iconCls;
    }

    /**
     * 设置父菜单类型的值
     *
     * @param type 父菜单类型
     **/
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 获取父菜单类型的值
     *
     * @return 返回父菜单类型的值
     **/
    public Integer getType() {
        return type;
    }

    /**
     * 设置菜单名称的值
     *
     * @param name 菜单名称
     **/
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取菜单名称的值
     *
     * @return 返回菜单名称的值
     **/
    public String getName() {
        return name;
    }

    /**
     * 设置菜单编码的值
     *
     * @param code 菜单编码
     **/
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 获取菜单编码的值
     *
     * @return 返回菜单编码的值
     **/
    public String getCode() {
        return code;
    }

    /**
     * 设置父菜单ID的值
     *
     * @param pid 父菜单ID
     **/
    public void setPid(Long pid) {
        this.pid = pid;
    }

    /**
     * 获取父菜单ID的值
     *
     * @return 返回父菜单ID的值
     **/
    public Long getPid() {
        return pid;
    }

    /**
     * 设置卡片ID的值
     *
     * @param accordionId 卡片ID
     **/
    public void setAccordionId(Long accordionId) {
        this.accordionId = accordionId;
    }

    /**
     * 获取卡片ID的值
     *
     * @return 返回卡片ID的值
     **/
    public Long getAccordionId() {
        return accordionId;
    }

    /**
     * 菜单Id
     *
     * @Author 肖家添
     * @Date 2019/5/10 0:22
     **/
    public Long getMenuID() {
        return menuID;
    }

    /**
     * 菜单Id
     *
     * @Author 肖家添
     * @Date 2019/5/10 0:22
     **/
    public void setMenuID(Long menuID) {
        this.menuID = menuID;
    }

    /**
     * 子菜单
     * @Author 肖家添
     * @Date 2019/5/10 12:03
     */
    public List<MenuEntity> getChildrenMenu() {
        return childrenMenu;
    }

    /**
     * 子菜单
     * @Author 肖家添
     * @Date 2019/5/10 12:03
     */
    public void setChildrenMenu(List<MenuEntity> childrenMenu) {
        this.childrenMenu = childrenMenu;
    }

    /**
     *  修改人
     * @Author 肖家添
     * @Date 2019/5/14 10:44
     */
    public UserEntity getModifierUser() {
        return modifierUser;
    }

    /**
     * 修改人
     * @Author 肖家添
     * @Date 2019/5/14 10:44
     */
    public void setModifierUser(UserEntity modifierUser) {
        this.modifierUser = modifierUser;
    }

    @Override
    public Object[] getDatas() {
        return new Object[]{orderNo, leaf, tabId, params, jsArray, loadType, biconCls, iconCls, type, name, code, pid, accordionId, menuID, childrenMenu, modifierUser, getId()};
    }

    @Override
    public String[] getFields() {
        return new String[]{"orderNo", "leaf", "tabId", "params", "jsArray", "loadType", "biconCls", "iconCls",
                "type", "name", "code", "pid", "accordionId", "menuID", "menuID", "childrenMenu", "modifierUser", "id"};
    }

}
