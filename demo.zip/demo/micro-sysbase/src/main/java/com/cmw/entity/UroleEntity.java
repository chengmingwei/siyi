package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;


/**
 * 用户角色关联表
 * @author 程明卫
 * @date 2019-03-27 13:50:17
 */
@Description(remark="用户角色关联表实体",createDate="2019-03-27 13:50:17",author="程明卫")
@Entity
@Table(name="ts_Urole")
@SuppressWarnings("serial")
public class UroleEntity extends IdEntity {
	
	
	 @Description(remark="角色ID")
	 @Column(name="roleId" ,nullable=false )
	 private Long roleId;

	 @Description(remark="用户ID")
	 @Column(name="userId" ,nullable=false )
	 private Long userId;


	public UroleEntity() {

	}

	
	/**
	  * 设置角色ID的值
	 * @param 	roleId	 角色ID
	**/
	public void setRoleId(Long  roleId){
		 this.roleId=roleId;
 	}

	/**
	  * 获取角色ID的值
	 * @return 返回角色ID的值
	**/
	public Long getRoleId(){
		 return roleId;
 	}

	/**
	  * 设置用户ID的值
	 * @param 	userId	 用户ID
	**/
	public void setUserId(Long  userId){
		 this.userId=userId;
 	}

	/**
	  * 获取用户ID的值
	 * @return 返回用户ID的值
	**/
	public Long getUserId(){
		 return userId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{roleId,userId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"roleId","userId"};
	}

}
