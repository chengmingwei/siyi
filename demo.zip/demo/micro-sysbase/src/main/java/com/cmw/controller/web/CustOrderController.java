package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;


import com.cmw.entity.CustOrderEntity;
import com.cmw.service.inter.CustOrderService;


/**
 * 订单表  ACTION类
 * @author 程明卫
 * @date 2020-06-07 15:49:16
 */
@Description(remark="订单表ACTION",createDate="2020-06-07 15:49:16",author="程明卫")
@Api(value = "订单表微服务", description = "#CONTROLLER# 2020-06-07 15:49:16 程明卫")
@RestController
@RequestMapping({"/custorder"})
public class CustOrderController{
	@Resource(name="custOrderService")
	private CustOrderService custOrderService;
	

    /**
   	 * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     * @return
    */
    @ApiOperation("分页查订单表列表API")
    @PostMapping(value = "/list")
    public JSONObject list(@RequestBody Map<String,Object> params){
      	Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = getRightSql(userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = custOrderService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
        
    }

    private String getRightSql(UserModel userObj){
        Integer utype = userObj.getUtype();
        if(null != utype && utype.intValue() == BussContant
                .USER_UTYPE_3) return "";  //超级管理员
        return (utype.intValue() == BussContant.USER_UTYPE_2 || utype.intValue() == BussContant.USER_UTYPE_6 || utype.intValue() == BussContant.USER_UTYPE_4 || utype.intValue() == BussContant.USER_UTYPE_5)
        ? String.format(" and B.companyId = %d", userObj.getIncompId()) : String.format(" and A.creator = %d", userObj.getId()); //机构客户 或按个人过滤
    }

    
     /**
     * 根据自定义参数获取订单表
     * @param params {customerId:客户ID,prodId:产品ID}
     * @return
     */
 	@ApiOperation("根据自定义参数获取订单信息")
    @GetMapping
    public JSONObject get(@RequestParam Map<String, Object> params) throws Exception{
 	    params.put(SysContant.USER_INFO, LoginInterceptor.getLoginUser());
       Map<String,Object> dataResult = custOrderService.getDetailInfo(new SHashMap<String,Object>(params));
	   JSONObject jsonObject = PageHandler.getJson(dataResult);
	   return jsonObject;
    }
    

    /**
     * 根据ID获取订单表信息
  	 * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取订单表")
    @GetMapping(value = "/{id}")
    public JSONObject get(@ApiParam("订单表ID") @PathVariable("id") Long id){
      	if(StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        CustOrderEntity obj = custOrderService.get(id);
        return PageHandler.getJson(obj);
    }

	/**
     * 线下付款，更新订单状态
     * @param params 要保存的数据 【付款凭证截图,付款日期】
     * @return
     */
    @ApiOperation("线下付款更新订单状态")
    @PutMapping
    public JSONObject save(@RequestBody  Map<String, Object> params) throws Exception{
         try{
             params.put(SysContant.USER_INFO, LoginInterceptor.getLoginUser());
             custOrderService.doComplexBusss(params);
            return PageHandler.getSuccessJson();
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }
    
    /**
     * 保存数据（后台系统）
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存订单表")
    @PostMapping(value = "/save")
    public JSONObject sys_save(@RequestBody  Map<String, Object> params, HttpServletRequest request) throws Exception{
         try{
            params.put(SysContant.USER_INFO, LoginInterceptor.getLoginUser());
            String ip = PageHandler.getIpAddr(request);
            params.put("ip", ip);
            params.put("psource", BussContant.CUSTORDER_PSOURCE_2);
            Map<String, Object> dataResult = (Map<String, Object>)custOrderService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除订单表")
    @DeleteMapping(value = "/{id}")
    public JSONObject delete(@ApiParam("订单表ID") @PathVariable("id")  Long id) throws Exception{
        custOrderService.delete(id);
        return PageHandler.getSuccessJson();
    }
	
}
