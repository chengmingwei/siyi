package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.SysparamsEntity;
import org.springframework.stereotype.Component;


/**
 * 系统参数表  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 14:57:48
 */
@Description(remark="系统参数表DAO Mapper接口",createDate="2019-03-27 14:57:48",author="程明卫")
@Component
@Mapper
public interface SysparamsDao extends GenericDaoInter<SysparamsEntity, Long>{

}
