package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import java.math.BigDecimal;
import java.util.Date;


/**
 * Saas产品
 * @author 程明卫
 * @date 2020-06-07 14:57:22
 */
@Description(remark="Saas产品实体",createDate="2020-06-07 14:57:22",author="程明卫")
@Entity
@Table(name="ts_SaasProd")
@SuppressWarnings("serial")
public class SaasProdEntity extends IdBaseEntity {
	
	
	 @Description(remark="所属系统")
	 @Column(name="ownerSystemId" ,nullable=false )
	 private Long ownerSystemId;

	 @Description(remark="产品价格")
	 @Column(name="price" ,nullable=false ,scale=2)
	 private BigDecimal price = new BigDecimal("0.00");

	 @Description(remark="产品名称")
	 @Column(name="pname" ,nullable=false ,length=50 )
	 private String pname;

	 @Description(remark="产品编号")
	 @Column(name="code" ,nullable=false ,length=20 )
	 private String code;

	@Description(remark="校区数量")
	@Column(name="schoolCount" ,nullable=false)
	private Integer schoolCount = 2;

	@Description(remark="手续费率")
	@Column(name="freeRate" ,nullable=false)
	private Float freeRate = 0.6f;

	@Description(remark="品牌自定义")
	@Column(name="brandFlag" ,nullable=false)
	private Byte brandFlag = 0;

	@Description(remark="付款限制")
	@Column(name="payLimit" ,nullable=false)
	private Byte payLimit = 0;

	@Description(remark="降级产品")
	@Column(name="dprodId")
	private Long dprodId;

	@Description(remark="限免截止时间")
	@Column(name="nopayTime")
	private Date nopayTime;

	public SaasProdEntity() {

	}

	/**
	 * 获取校区数量的值
	 * @return 返回校区数量的值
	 **/
	public Integer getSchoolCount() {
		return schoolCount;
	}

	/**
	 * 设置校区数量的值
	 * @param	schoolCount	校区数量
	 **/
	public void setSchoolCount(Integer schoolCount) {
		this.schoolCount = schoolCount;
	}

	/**
	 * 获取手续费率的值
	 * @return 返回手续费率的值
	 **/
	public Float getFreeRate() {
		return freeRate;
	}

	/**
	 * 设置手续费率的值
	 * @param	freeRate	手续费率
	 **/
	public void setFreeRate(Float freeRate) {
		this.freeRate = freeRate;
	}

	/**
	 * 获取品牌自定义的值
	 * @return 返回品牌自定义的值
	 **/
	public Byte getBrandFlag() {
		return brandFlag;
	}

	/**
	 * 设置品牌自定义的值
	 * @param	brandFlag	品牌自定义
	 **/
	public void setBrandFlag(Byte brandFlag) {
		this.brandFlag = brandFlag;
	}

	/**
	 * 获取付款限制的值
	 * @return 返回付款限制的值
	 **/
	public Byte getPayLimit() {
		return payLimit;
	}

	/**
	 * 设置付款限制的值
	 * @param	payLimit	付款限制
	 **/
	public void setPayLimit(Byte payLimit) {
		this.payLimit = payLimit;
	}

	/**
	 * 获取降级产品的值
	 * @return 返回降级产品的值
	 **/
	public Long getDprodId() {
		return dprodId;
	}

	/**
	 * 设置降级产品的值
	 * @param	dprodId	降级产品
	 **/
	public void setDprodId(Long dprodId) {
		this.dprodId = dprodId;
	}

	/**
	 * 获取限免截止时间的值
	 * @return 返回限免截止时间的值
	 **/
	public Date getNopayTime() {
		return nopayTime;
	}

	/**
	 * 设置限免截止时间的值
	 * @param	nopayTime	限免截止时间
	 **/
	public void setNopayTime(Date nopayTime) {
		this.nopayTime = nopayTime;
	}

	/**
	  * 设置所属系统的值
	 * @param 	ownerSystemId	 所属系统
	**/
	public void setOwnerSystemId(Long  ownerSystemId){
		 this.ownerSystemId=ownerSystemId;
 	}

	/**
	  * 获取所属系统的值
	 * @return 返回所属系统的值
	**/
	public Long getOwnerSystemId(){
		 return ownerSystemId;
 	}

	/**
	  * 设置产品价格的值
	 * @param 	price	 产品价格
	**/
	public void setPrice(BigDecimal  price){
		 this.price=price;
 	}

	/**
	  * 获取产品价格的值
	 * @return 返回产品价格的值
	**/
	public BigDecimal getPrice(){
		 return price;
 	}

	/**
	  * 设置产品名称的值
	 * @param 	pname	 产品名称
	**/
	public void setPname(String  pname){
		 this.pname=pname;
 	}

	/**
	  * 获取产品名称的值
	 * @return 返回产品名称的值
	**/
	public String getPname(){
		 return pname;
 	}

	/**
	  * 设置产品编号的值
	 * @param 	code	 产品编号
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取产品编号的值
	 * @return 返回产品编号的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{ownerSystemId,price,pname,code,schoolCount,freeRate,brandFlag,payLimit,dprodId,nopayTime};
	}

	@Override
	public String[] getFields() {
		return new String[]{"ownerSystemId","price","pname","code","schoolCount","freeRate","brandFlag","payLimit","dprodId","nopayTime"};
	}

}
