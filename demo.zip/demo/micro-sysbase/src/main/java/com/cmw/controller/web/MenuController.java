package com.cmw.controller.web;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.entity.AccordionEntity;
import com.cmw.util.BeanUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.models.auth.In;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cmw.entity.MenuEntity;
import com.cmw.service.inter.MenuService;


/**
 * 菜单表  ACTION类
 *
 * @author 程明卫
 * @date 2019-03-27 15:02:39
 */
@Description(remark = "菜单表ACTION", createDate = "2019-03-27 15:02:39", author = "程明卫")
@Api(value = "菜单表微服务", description = "#CONTROLLER# 2019-03-27 15:02:39 程明卫")
@RestController
@RequestMapping({"/menu"})
public class MenuController {

    @Resource(name = "menuService")
    private MenuService menuService;

    /**
     * 获取系统菜单，动态展示用
     * @Author 肖家添
     * @Date 2019/5/10 11:46
     */
    @ApiOperation("获取系统菜单")
    @PostMapping("/getSystemMenu")
    public JSONObject getSystemMenu(@RequestParam Map<String, Object> params){
        try{
            JSONArray systemMenu = menuService.getSystemMenu(params);

            return PageHandler.getJson(systemMenu);
        }catch (Exception ex){
            ex.printStackTrace();

            return PageHandler.getFailureJson("系统异常");
        }
    }

    /**
     * 获取系统菜单列表
     * @Author 肖家添
     * @Date 2019/5/10 19:11
     */
    @ApiOperation("获取系统菜单列表")
    @PostMapping("/getMenuList")
    public JSONObject getMenuList(@RequestParam Map<String, Object> params){
        try{

            List<MenuEntity> menuList = menuService.getList(params);

            return PageHandler.getJson(menuList);
        }catch (Exception ex){
            ex.printStackTrace();

            return PageHandler.getFailureJson("系统异常");
        }
    }

    /**
     * 保存系统菜单
     * @Author 肖家添
     * @Date 2019/5/10 0:01
     **/
    @ApiOperation("保存系统菜单")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam Map<String, Object> params) {
        boolean success = true;
        String msg = "";

        try{
            MenuEntity entity = BeanUtil.copyValue(MenuEntity.class, params);

            if (StringHandler.isValidObj(entity)) {
                Integer orderNo = entity.getOrderNo();
                String jsArray = entity.getJsArray();
                Integer loadType = entity.getLoadType();
                String name = entity.getName();
                String code = entity.getCode();
                Long pid = entity.getPid();
                Long menuID = entity.getMenuID();

                Object[] mustFillArr = {orderNo, jsArray, loadType, name, code, pid, menuID};
                for (Object mustFill : mustFillArr) {
                    if (!StringHandler.isValidObj(mustFill)) {
                        success = false;
                        msg = "必填项不能为空";

                        break;
                    }
                }

                if (success) {
                    int rowCount = menuService.insert(entity);

                    if (rowCount > 0)
                        success = true;
                }
            }
        }catch (Exception ex){
            ex.printStackTrace();

            success = false;
            msg = "系统异常";
        }

        if (success)
            return PageHandler.getSuccessJson();
        else
            return PageHandler.getFailureJson(msg);

    }

    /**
     * 修改系统菜单
     * @Author 肖家添
     * @Date 2019/5/10 0:01
     **/
    @ApiOperation("修改系统菜单")
    @RequestMapping("/update")
    public JSONObject update(@RequestParam Map<String, Object> params){
        boolean success = true;
        String msg = "";

        try{
            MenuEntity entity = BeanUtil.copyValue(MenuEntity.class, params);

            Long id = entity.getId();
            Integer orderNo = entity.getOrderNo();
            String jsArray = entity.getJsArray();
            Integer loadType = entity.getLoadType();
            String name = entity.getName();
            String code = entity.getCode();
            Long pid = entity.getPid();
            Long menuID = entity.getMenuID();

            Object[] mustFillArr = {id, orderNo, jsArray, loadType, name, code, pid, menuID};
            for (Object mustFill : mustFillArr) {
                if(!StringHandler.isValidObj(mustFill)){
                    success = false;
                    msg = "必填项不能为空";

                    break;
                }
            }

            if(success)
                menuService.update(entity);

        }catch (Exception ex){
            ex.printStackTrace();

            success = false;
            msg = "系统异常";
        }

        if(success)
            return PageHandler.getSuccessJson();
        else
            return PageHandler.getFailureJson(msg);
    }

    @ApiOperation("上架/下架/删除")
    @PostMapping("/isEnabled")
    public JSONObject isEnabled(HttpServletRequest request){
        try{
            String[] ids = request.getParameterValues("id");
            String isEnabled = request.getParameter("isenabled");

            if(StringHandler.isValidObj(ids) && StringHandler.isValidStr(isEnabled)){
                String beachParam = "";
                for (String id : ids) {
                    beachParam += id + ",";
                }

                if(beachParam.length() > 0){
                    beachParam = beachParam.substring(0, beachParam.lastIndexOf(","));
                }

                menuService.enabledByIds(beachParam, Integer.parseInt(isEnabled));

                return PageHandler.getSuccessJson();
            }else{
                return PageHandler.getFailureJson("缺少参数");
            }
        }catch (Exception ex){
            return PageHandler.getFailureJson("系统异常");
        }
    }
}
