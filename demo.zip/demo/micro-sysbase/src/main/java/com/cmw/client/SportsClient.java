package com.cmw.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 *
 * @Author: chengmingwei
 * @Time: 2020-10-20 19:22
 * @Feature: micor-sports feignclient
 */
@FeignClient(value = "micro-sports")
public interface SportsClient {
    /**
     * 保存Post
     * @Param params ==> Post 数据Map
     * @Author cmw
     * @Date 2020/10/18 10:26
     */
    @PostMapping("/school/feign/trans")
    void saveSchool(@RequestParam Map<String, String> params, @RequestParam(value = "feignKey") String feignKey);
}
