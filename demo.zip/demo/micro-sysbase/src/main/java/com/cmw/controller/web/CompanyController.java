package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.CompanyEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.CompanyService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 公司表  ACTION类
 * @author 程明卫
 * @date 2019-03-27 14:44:03
 */
@Description(remark="公司表ACTION",createDate="2019-03-27 14:44:03",author="程明卫")
@Api(value = "公司表微服务", description = "#CONTROLLER# 2019-03-27 14:44:03 程明卫")
@RestController
@RequestMapping({"/company"})
public class CompanyController {
	@Resource(name="companyService")
	private CompanyService companyService;
	
	 /**
     * 跳转主页面
     * @return
     */
     @ApiOperation("公司表首页API")
    @GetMapping(value = "/home")
    public JSONObject home(Map<String, Object> params) throws Exception{
       List<CompanyEntity> list = companyService.getListAll();
       return PageHandler.getJson(list);
    }

    /**
     * 跳转列表页面
     * @param params
     * @return
     */
     @ApiOperation("分页查询公司表列表API")
     @PostMapping("list")
     public JSONObject list(@RequestBody Map<String,Object> params){
         Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
         Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
         params.remove("pageSize");
         params.remove("currentPage");
         UserModel userObj = LoginInterceptor.getLoginUser();
         String rightCondition = UserUtil.getRightSql("A", userObj);
//         params.put("rightCondition", rightCondition);
         PageResult<List<Map<String,Object>>> result = companyService.getPageByPars(params,page, pageSize);
         if(result == null){
             return PageHandler.getSuccessJson();
         }
         return PageHandler.getJson(result);
     }


    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取公司表")
    @PostMapping(value = "/{id}")
    public JSONObject info(@ApiParam("公司表ID") @PathVariable("id") Long id){
      	if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        CompanyEntity obj = companyService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存公司表")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestBody  Map<String, String> params) throws Exception{
        try{
            Map<String, Object> dataResult = (Map<String, Object>)companyService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除公司表")
    @DeleteMapping(value = "/{id}")
    public JSONObject delete(@ApiParam("会员ID") @PathVariable("id")  Long id) throws Exception{
        companyService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }

}
