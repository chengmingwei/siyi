package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;


/**
 * 消息表
 * @author 程明卫
 * @date 2019-04-10 23:17:10
 */
@Description(remark="消息表实体",createDate="2019-04-10 23:17:10",author="程明卫")
@Entity
@Table(name="ts_Msg")
@SuppressWarnings("serial")
public class MsgEntity extends IdBaseEntity {
	
	
	 @Description(remark="消息状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="阅读状态")
	 @Column(name="rstatus" ,nullable=false )
	 private Integer rstatus = 0;

	 @Description(remark="接收号码")
	 @Column(name="penum" ,nullable=false ,length=30 )
	 private String penum;

	 @Description(remark="发送时间")
	 @Column(name="sendTime" )
	 private Date sendTime;

	 @Description(remark="发送人")
	 @Column(name="sender" ,length=20 )
	 private String sender;

	 @Description(remark="消息类型")
	 @Column(name="mtype" ,nullable=false )
	 private Integer mtype;

	 @Description(remark="内容")
	 @Column(name="content" ,nullable=false ,length=225 )
	 private String content;

	 @Description(remark="标题")
	 @Column(name="title" ,length=100 )
	 private String title;

	 @Description(remark="消息模板ID")
	 @Column(name="templateId" )
	 private Long templateId;

	 @Description(remark="会员ID")
	 @Column(name="memberId" ,nullable=false )
	 private Long memberId;


	public MsgEntity() {

	}

	
	/**
	  * 设置消息状态的值
	 * @param 	xstatus	 消息状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取消息状态的值
	 * @return 返回消息状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置阅读状态的值
	 * @param 	rstatus	 阅读状态
	**/
	public void setRstatus(Integer  rstatus){
		 this.rstatus=rstatus;
 	}

	/**
	  * 获取阅读状态的值
	 * @return 返回阅读状态的值
	**/
	public Integer getRstatus(){
		 return rstatus;
 	}

	/**
	  * 设置接收号码的值
	 * @param 	penum	 接收号码
	**/
	public void setPenum(String  penum){
		 this.penum=penum;
 	}

	/**
	  * 获取接收号码的值
	 * @return 返回接收号码的值
	**/
	public String getPenum(){
		 return penum;
 	}

	/**
	  * 设置发送时间的值
	 * @param 	sendTime	 发送时间
	**/
	public void setSendTime(Date  sendTime){
		 this.sendTime=sendTime;
 	}

	/**
	  * 获取发送时间的值
	 * @return 返回发送时间的值
	**/
	public Date getSendTime(){
		 return sendTime;
 	}

	/**
	  * 设置发送人的值
	 * @param 	sender	 发送人
	**/
	public void setSender(String  sender){
		 this.sender=sender;
 	}

	/**
	  * 获取发送人的值
	 * @return 返回发送人的值
	**/
	public String getSender(){
		 return sender;
 	}

	/**
	  * 设置消息类型的值
	 * @param 	mtype	 消息类型
	**/
	public void setMtype(Integer  mtype){
		 this.mtype=mtype;
 	}

	/**
	  * 获取消息类型的值
	 * @return 返回消息类型的值
	**/
	public Integer getMtype(){
		 return mtype;
 	}

	/**
	  * 设置内容的值
	 * @param 	content	 内容
	**/
	public void setContent(String  content){
		 this.content=content;
 	}

	/**
	  * 获取内容的值
	 * @return 返回内容的值
	**/
	public String getContent(){
		 return content;
 	}

	/**
	  * 设置标题的值
	 * @param 	title	 标题
	**/
	public void setTitle(String  title){
		 this.title=title;
 	}

	/**
	  * 获取标题的值
	 * @return 返回标题的值
	**/
	public String getTitle(){
		 return title;
 	}

	/**
	  * 设置消息模板ID的值
	 * @param 	templateId	 消息模板ID
	**/
	public void setTemplateId(Long  templateId){
		 this.templateId=templateId;
 	}

	/**
	  * 获取消息模板ID的值
	 * @return 返回消息模板ID的值
	**/
	public Long getTemplateId(){
		 return templateId;
 	}

	/**
	  * 设置会员ID的值
	 * @param 	memberId	 会员ID
	**/
	public void setMemberId(Long  memberId){
		 this.memberId=memberId;
 	}

	/**
	  * 获取会员ID的值
	 * @return 返回会员ID的值
	**/
	public Long getMemberId(){
		 return memberId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{xstatus,rstatus,penum,sendTime,sender,mtype,content,title,templateId,memberId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"xstatus","rstatus","penum","sendTime","sender","mtype","content","title","templateId","memberId"};
	}

}
