package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import java.util.Date;


/**
 * 机构客户信息
 * @author 程明卫
 * @date 2020-06-07 15:44:37
 */
@Description(remark="机构客户信息实体",createDate="2020-06-07 15:44:37",author="程明卫")
@Entity
@Table(name="ts_OrgCustomer")
@SuppressWarnings("serial")
public class OrgCustomerEntity extends IdBaseEntity {

	@Description(remark="产品ID")
	@Column(name="productId" )
	private Long productId;

	@Description(remark="机构客户编号")
	@Column(name="code" ,nullable=false ,length=50 )
	private String code = "000000";

	 @Description(remark="跟进状态")
	 @Column(name="fstatus" ,nullable=false )
	 private Integer fstatus = 1;

	 @Description(remark="审批意见")
	 @Column(name="auditRemark" ,length=200 )
	 private String auditRemark;

	 @Description(remark="审批状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="是否试用状态")
	 @Column(name="tryFlag" ,nullable=false )
	 private Byte tryFlag = 1;

	 @Description(remark="公司ID")
	 @Column(name="companyId" )
	 private Long companyId;

	 @Description(remark="有效期")
	 @Column(name="endDate" )
	 private Date endDate;

	 @Description(remark="销售人员")
	 @Column(name="salerId" ,nullable=false )
	 private Long salerId;

	 @Description(remark="详细地址")
	 @Column(name="address" ,length=100 )
	 private String address;

	 @Description(remark="区")
	 @Column(name="areaId" )
	 private Long areaId;

	 @Description(remark="市")
	 @Column(name="cityId" )
	 private Long cityId;

	 @Description(remark="省")
	 @Column(name="provinceId" )
	 private Long provinceId;

	 @Description(remark="邮箱")
	 @Column(name="email" ,length=50 )
	 private String email;

	 @Description(remark="联系电话")
	 @Column(name="tel" ,length=50 )
	 private String tel;

	 @Description(remark="联系人")
	 @Column(name="contacts" ,length=50 )
	 private String contacts;

	 @Description(remark="机构名称")
	 @Column(name="oname" ,nullable=false ,length=100 )
	 private String oname;


	public OrgCustomerEntity() {

	}

	/**
	 * 获取产品ID的值
	 * @return 返回产品ID的值
	 **/
	public Long getProductId() {
		return productId;
	}

	/**
	 * 设置产品ID的值
	 * @param 	productId	 产品ID
	 **/
	public void setProductId(Long productId) {
		this.productId = productId;
	}

	/**
	 * 设置机构客户编号的值
	 * @param 	code	 机构客户编号
	 **/
	public void setCode(String  code){
		this.code=code;
	}

	/**
	 * 获取机构客户编号的值
	 * @return 返回机构客户编号的值
	 **/
	public String getCode(){
		return code;
	}
	
	/**
	  * 设置跟进状态的值
	 * @param 	fstatus	 跟进状态
	**/
	public void setFstatus(Integer  fstatus){
		 this.fstatus=fstatus;
 	}

	/**
	  * 获取跟进状态的值
	 * @return 返回跟进状态的值
	**/
	public Integer getFstatus(){
		 return fstatus;
 	}

	/**
	  * 设置审批意见的值
	 * @param 	auditRemark	 审批意见
	**/
	public void setAuditRemark(String  auditRemark){
		 this.auditRemark=auditRemark;
 	}

	/**
	  * 获取审批意见的值
	 * @return 返回审批意见的值
	**/
	public String getAuditRemark(){
		 return auditRemark;
 	}

	/**
	  * 设置审批状态的值
	 * @param 	xstatus	 审批状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取审批状态的值
	 * @return 返回审批状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置是否试用状态的值
	 * @param 	tryFlag	 是否试用状态
	**/
	public void setTryFlag(Byte  tryFlag){
		 this.tryFlag=tryFlag;
 	}

	/**
	  * 获取是否试用状态的值
	 * @return 返回是否试用状态的值
	**/
	public Byte getTryFlag(){
		 return tryFlag;
 	}

	/**
	  * 设置公司ID的值
	 * @param 	companyId	 公司ID
	**/
	public void setCompanyId(Long  companyId){
		 this.companyId=companyId;
 	}

	/**
	  * 获取公司ID的值
	 * @return 返回公司ID的值
	**/
	public Long getCompanyId(){
		 return companyId;
 	}

	/**
	  * 设置有效期的值
	 * @param 	endDate	 有效期
	**/
	public void setEndDate(Date  endDate){
		 this.endDate=endDate;
 	}

	/**
	  * 获取有效期的值
	 * @return 返回有效期的值
	**/
	public Date getEndDate(){
		 return endDate;
 	}

	/**
	  * 设置销售人员的值
	 * @param 	salerId	 销售人员
	**/
	public void setSalerId(Long  salerId){
		 this.salerId=salerId;
 	}

	/**
	  * 获取销售人员的值
	 * @return 返回销售人员的值
	**/
	public Long getSalerId(){
		 return salerId;
 	}

	/**
	  * 设置详细地址的值
	 * @param 	address	 详细地址
	**/
	public void setAddress(String  address){
		 this.address=address;
 	}

	/**
	  * 获取详细地址的值
	 * @return 返回详细地址的值
	**/
	public String getAddress(){
		 return address;
 	}

	/**
	  * 设置区的值
	 * @param 	areaId	 区
	**/
	public void setAreaId(Long  areaId){
		 this.areaId=areaId;
 	}

	/**
	  * 获取区的值
	 * @return 返回区的值
	**/
	public Long getAreaId(){
		 return areaId;
 	}

	/**
	  * 设置市的值
	 * @param 	cityId	 市
	**/
	public void setCityId(Long  cityId){
		 this.cityId=cityId;
 	}

	/**
	  * 获取市的值
	 * @return 返回市的值
	**/
	public Long getCityId(){
		 return cityId;
 	}

	/**
	  * 设置省的值
	 * @param 	provinceId	 省
	**/
	public void setProvinceId(Long  provinceId){
		 this.provinceId=provinceId;
 	}

	/**
	  * 获取省的值
	 * @return 返回省的值
	**/
	public Long getProvinceId(){
		 return provinceId;
 	}

	/**
	  * 设置邮箱的值
	 * @param 	email	 邮箱
	**/
	public void setEmail(String  email){
		 this.email=email;
 	}

	/**
	  * 获取邮箱的值
	 * @return 返回邮箱的值
	**/
	public String getEmail(){
		 return email;
 	}

	/**
	  * 设置联系电话的值
	 * @param 	tel	 联系电话
	**/
	public void setTel(String  tel){
		 this.tel=tel;
 	}

	/**
	  * 获取联系电话的值
	 * @return 返回联系电话的值
	**/
	public String getTel(){
		 return tel;
 	}

	/**
	  * 设置联系人的值
	 * @param 	contacts	 联系人
	**/
	public void setContacts(String  contacts){
		 this.contacts=contacts;
 	}

	/**
	  * 获取联系人的值
	 * @return 返回联系人的值
	**/
	public String getContacts(){
		 return contacts;
 	}

	/**
	  * 设置机构名称的值
	 * @param 	oname	 机构名称
	**/
	public void setOname(String  oname){
		 this.oname=oname;
 	}

	/**
	  * 获取机构名称的值
	 * @return 返回机构名称的值
	**/
	public String getOname(){
		 return oname;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{productId,fstatus,auditRemark,xstatus,tryFlag,companyId,endDate,salerId,address,areaId,cityId,provinceId,email,tel,contacts,oname};
	}

	@Override
	public String[] getFields() {
		return new String[]{"productId","fstatus","auditRemark","xstatus","tryFlag","companyId","endDate","salerId","address","areaId","cityId","provinceId","email","tel","contacts","oname"};
	}

}
