package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.constant.back.SysContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.cmw.entity.ProdDiscountEntity;
import com.cmw.service.inter.ProdDiscountService;


/**
 * Saas产品折扣表  ACTION类
 * @author 程明卫
 * @date 2020-06-07 15:01:53
 */
@Description(remark="Saas产品折扣表ACTION",createDate="2020-06-07 15:01:53",author="程明卫")
@Api(value = "Saas产品折扣表微服务", description = "#CONTROLLER# 2020-06-07 15:01:53 程明卫")
@RestController
@RequestMapping({"/proddiscount"})
public class ProdDiscountController{
	@Resource(name="prodDiscountService")
	private ProdDiscountService prodDiscountService;
	

    /**
   	 * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     * @return
    */
    @ApiOperation("分页查Saas产品折扣表列表API")
    @PostMapping(value = "/list")
    public JSONObject list(@RequestBody Map<String,Object> params){
      	Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = prodDiscountService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
        
    }
    
     /**
     * 根据自定义参数获取Saas产品折扣表
     * @param params
     * @return
     */
 	@ApiOperation("根据产品ID和购买时长获取打折后金额")
    @GetMapping
    public JSONObject get(@RequestParam Map<String, Object> params) throws Exception{
       Map<String,Object> dataResult = prodDiscountService.calculateRebate(new SHashMap<>(params));
	   JSONObject jsonObject = PageHandler.getJson(dataResult);
	   return jsonObject;
    }
    

    /**
     * 根据ID获取Saas产品折扣表信息
  	 * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取Saas产品折扣表")
    @GetMapping(value = "/{id}")
    public JSONObject get(@ApiParam("Saas产品折扣表ID") @PathVariable("id") Long id){
      	if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        ProdDiscountEntity obj = prodDiscountService.get(id);
        return PageHandler.getJson(obj);
    }

	/**
     * 保存数据（前端）
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存Saas产品折扣表")
    @PostMapping
    public JSONObject save(@RequestParam  Map<String, String> params) throws Exception{
         try{
            Map<String, Object> dataResult = (Map<String, Object>)prodDiscountService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }
    
    /**
     * 保存数据（后台系统）
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存Saas产品折扣表")
    @PostMapping(value = "/save")
    public JSONObject sys_save(@RequestBody  Map<String, String> params) throws Exception{
         try{
             SHashMap pars = new SHashMap(params);
             pars.put(SysContant.USER_INFO, LoginInterceptor.getLoginUser());
             Map<String, Object> dataResult = (Map<String, Object>)prodDiscountService.doComplexBusss(pars);
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除Saas产品折扣表")
    @DeleteMapping(value = "/{id}")
    public JSONObject delete(@ApiParam("Saas产品折扣表ID") @PathVariable("id")  Long id) throws Exception{
        prodDiscountService.delete(id);
        return PageHandler.getSuccessJson();
    }

    /**
     * 起用或禁用或删除产品
     * @param id 要删除的ID值
     * @param isenabled 数据标识 [-1:删除,0:禁用,1:启用]
     * @param params 自定义传入参数 如：备注 remark 可通过此参数进入传递
     * @return
     */
    @ApiOperation("根据ID删除Saas产品")
    @PutMapping(value = "/{id}/{isenabled}")
    public JSONObject enabled(@ApiParam("Saas产品ID") @PathVariable("id")  Long id,
                              @ApiParam("可用标识") @PathVariable("isenabled")  Integer isenabled,
                              @RequestBody  Map<String, String> params) throws Exception{
        String remark = params.get("remark");
        return enabledData(id+"", isenabled, remark);
    }

    /**
     * 批量起用或禁用或删除的多个产品
     * @param isenabled 数据标识 [-1:删除,0:禁用,1:启用]
     * @param params 自定义传入参数 如：ids,remark 可通过此参数进入传递
     * @return
     */
    @ApiOperation("批量根据ID删除Saas产品")
    @PutMapping(value = "/batch-enabled/{isenabled}")
    public JSONObject enabled(@ApiParam("可用标识") @PathVariable("isenabled")  Integer isenabled,
                              @RequestBody  Map<String, String> params) throws Exception{
        String ids = params.get("ids");
        String remark = params.get("remark");
        return enabledData(ids, isenabled, remark);
    }

    private JSONObject enabledData(String ids,Integer isenabled, String remark) {
        Map<String,Object> params = new HashMap<>();
        if(ids.indexOf(",") != -1){
            params.put("ids", ids);
        }else{
            params.put("id", ids);
        }

        params.put("remark", remark);
        params.put("modifier", LoginInterceptor.getLoginUser().getId());
        params.put("modifytime", new Date());
        prodDiscountService.enabledByPars(params, isenabled);
        return PageHandler.getSuccessJson();
    }
	
}
