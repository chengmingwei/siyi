package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.util.BeanUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

import com.cmw.entity.RestypeEntity;
import com.cmw.service.inter.RestypeService;


/**
 * 资源表  ACTION类
 * @author 程明卫
 * @date 2019-03-27 13:51:53
 */
@Description(remark="资源表ACTION",createDate="2019-03-27 13:51:53",author="程明卫")
@Api(value = "资源表微服务", description = "#CONTROLLER# 2019-03-27 13:51:53 程明卫")
@RestController
@RequestMapping({"/restype"})
public class RestypeController{
	@Resource(name="restypeService")
	private RestypeService restypeService;
	
	 /**
     * 跳转主页面
     * @return
     */
     @ApiOperation("资源表首页API")
    @GetMapping(value = "/home")
    public JSONObject home(Map<String, Object> params) throws Exception{
       List<RestypeEntity> list = restypeService.getListAll();
       return PageHandler.getJson(list);
    }

    /**
     * 跳转列表页面
     * @param request
     * @param response
     * @return
     */
     @ApiOperation("资源表列表API")
    @GetMapping(value = "/list")
    public JSONObject list(HttpServletRequest request, HttpServletResponse response){
        List<RestypeEntity> list = restypeService.getListAll();
        return PageHandler.getJson(list);
    }

    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取资源表")
    @GetMapping(value = "/info")
    public JSONObject info(@ApiParam("资源表ID") @RequestParam Long id){
      	if(StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        RestypeEntity obj = restypeService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存资源表")
    @PostMapping(value = "/save")
    public JSONObject save(Map<String, Object> params) throws Exception{
        RestypeEntity entity = BeanUtil.copyValue(RestypeEntity.class, params);
        restypeService.insert(entity);
        return PageHandler.getSuccessJson();
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除资源表")
    @DeleteMapping(value = "/remove")
    public JSONObject remove(@ApiParam("会员ID") @RequestParam Long id) throws Exception{
        restypeService.delete(id);
        return PageHandler.getSuccessJson();
    }
	
}
