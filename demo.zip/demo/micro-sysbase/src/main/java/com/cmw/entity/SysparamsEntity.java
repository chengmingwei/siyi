package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 系统参数表
 * @author 程明卫
 * @date 2019-03-27 14:57:48
 */
@Description(remark="系统参数表实体",createDate="2019-03-27 14:57:48",author="程明卫")
@Entity
@Table(name="ts_Sysparams")
@SuppressWarnings("serial")
public class SysparamsEntity extends IdBaseEntity {
	
	
	 @Description(remark="参数值")
	 @Column(name="val" ,nullable=false ,length=50 )
	 private String val;

	 @Description(remark="参数名称")
	 @Column(name="name" ,nullable=false ,length=50 )
	 private String name;

	 @Description(remark="业务引用键")
	 @Column(name="recode" ,nullable=false, length = 50)
	 private String recode;


	public SysparamsEntity() {

	}

	
	/**
	  * 设置参数值的值
	 * @param 	val	 参数值
	**/
	public void setVal(String  val){
		 this.val=val;
 	}

	/**
	  * 获取参数值的值
	 * @return 返回参数值的值
	**/
	public String getVal(){
		 return val;
 	}

	/**
	  * 设置参数名称的值
	 * @param 	name	 参数名称
	**/
	public void setName(String  name){
		 this.name=name;
 	}

	/**
	  * 获取参数名称的值
	 * @return 返回参数名称的值
	**/
	public String getName(){
		 return name;
 	}

	/**
	  * 设置业务引用键的值
	 * @param 	recode	 业务引用键
	**/
	public void setRecode(String  recode){
		 this.recode=recode;
 	}

	/**
	  * 获取业务引用键的值
	 * @return 返回业务引用键的值
	**/
	public String getRecode(){
		 return recode;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{val,name,recode};
	}

	@Override
	public String[] getFields() {
		return new String[]{"val","name","recode"};
	}

}
