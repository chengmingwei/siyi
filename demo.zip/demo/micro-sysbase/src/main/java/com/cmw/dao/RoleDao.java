package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.RoleEntity;


/**
 * 角色  Mapper接口
 * @author 程明卫
 * @date 2019-04-02 00:14:57
 */
@Description(remark="角色DAO Mapper接口",createDate="2019-04-02 00:14:57",author="程明卫")
@Mapper
public interface RoleDao extends GenericDaoInter<RoleEntity, Long>{

    /**
     * 菜单权限 ==> 获取菜单列表
     * @Author 肖家添
     * @Date 2019/5/12 14:12
     */
    List<Map<String, Object>> getRoleForRightMenu();

}
