package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.entity.PostEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.PostService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 职位表  ACTION类
 * @author 程明卫
 * @date 2019-03-27 14:54:51
 */
@Description(remark="职位表ACTION",createDate="2019-03-27 14:54:51",author="程明卫")
@Api(value = "职位表微服务", description = "#CONTROLLER# 2019-03-27 14:54:51 程明卫")
@RestController
@RequestMapping({"/post"})
public class PostController {
	@Resource(name="postService")
	private PostService postService;
	
	 /**
     * 跳转主页面
     * @return
     */
     @ApiOperation("职位表首页API")
    @GetMapping(value = "/home")
    public JSONObject home(Map<String, Object> params) throws Exception{
       List<PostEntity> list = postService.getListAll();
       return PageHandler.getJson(list);
    }

    /**
     * 跳转列表页面
     * @param params
     * @return
     */
     @ApiOperation("职位表列表API")
     @PostMapping("list")
     public JSONObject list(@RequestBody Map<String,Object> params){
         Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
         Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
         params.remove("pageSize");
         params.remove("currentPage");
         UserModel userObj = LoginInterceptor.getLoginUser();
         String rightCondition = UserUtil.getRightSql("A", userObj);
//         params.put("rightCondition", rightCondition);
         PageResult<List<Map<String,Object>>> result = postService.getPageByPars(params,page, pageSize);
         if(result == null){
             return PageHandler.getSuccessJson();
         }
         return PageHandler.getJson(result);
     }

    /**
     * 根据部门名称获取
     * @param request
     * @param response
     * @return
     */
    @ApiOperation("根据职位名称获取")
    @RequestMapping(value = "/getByName")
    public JSONObject getByCode(HttpServletRequest request, HttpServletResponse response){
        String name = request.getParameter("name");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("name",name);
        List<PostEntity> list = new ArrayList<PostEntity>();
        if (StringHandler.isValidStr(name)){
            list  =postService.getList(map);
        }else {
            list = postService.getListAll();
        }

        return PageHandler.getJson(list);
    }
    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取职位表")
    @PostMapping(value = "/{id}")
    public JSONObject info(@ApiParam("职位表ID") @PathVariable("id") Long id){
      	if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        PostEntity obj = postService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * /post/feign/trans
     * 分布式事务测试
     *
     * @param params 分布式事务测试
     * @return
     */
    @ApiOperation("分布式事务测试")
    @PostMapping(value = "/feign/trans")
    public JSONObject trans(@RequestParam Map<String, Object> params) throws Exception {
        //params.put("name","CEO");
        Map<String, Object> dataResult = (Map<String, Object>) postService.doComplexBusss(new SHashMap(params));
        return PageHandler.getJson(dataResult);
    }

    /**
     * 分布式事务测试
     *
     * @param params 分布式事务测试
     * @return
     */
    @ApiOperation("分布式事务测试")
    @PostMapping(value = "/trans")
    public JSONObject transToSchool(@RequestParam Map<String, Object> params) throws Exception {
        postService.test_trans(new SHashMap<String,Object>(params));
        return PageHandler.getSuccessJson();
    }


    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存职位表")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestBody  Map<String, String> params) throws Exception{
        try{
            Map<String, Object> dataResult = (Map<String, Object>)postService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除职位表")
    @DeleteMapping(value = "/{id}")
    public JSONObject remove(@ApiParam("职位ID") @PathVariable("id") Long id) throws Exception{
        postService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }
	
}
