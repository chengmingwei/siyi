package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 资源表
 * @author 程明卫
 * @date 2019-03-27 13:51:53
 */
@Description(remark="资源表实体",createDate="2019-03-27 13:51:53",author="程明卫")
@Entity
@Table(name="ts_Restype")
@SuppressWarnings("serial")
public class RestypeEntity extends IdBaseEntity {
	
	
	 @Description(remark="引用值")
	 @Column(name="recode" ,nullable=false )
	 private String recode;

	 @Description(remark="名称")
	 @Column(name="name" ,nullable=false )
	 private String name;


	public RestypeEntity() {

	}

	
	/**
	  * 设置引用值的值
	 * @param 	recode	 引用值
	**/
	public void setRecode( String  recode){
		 this.recode=recode;
 	}

	/**
	  * 获取引用值的值
	 * @return 返回引用值的值
	**/
	public String getRecode(){
		 return recode;
 	}

	/**
	  * 设置名称的值
	 * @param 	name	 名称
	**/
	public void setName( String  name){
		 this.name=name;
 	}

	/**
	  * 获取名称的值
	 * @return 返回名称的值
	**/
	public String getName(){
		 return name;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{recode,name};
	}

	@Override
	public String[] getFields() {
		return new String[]{"recode","name"};
	}

}
