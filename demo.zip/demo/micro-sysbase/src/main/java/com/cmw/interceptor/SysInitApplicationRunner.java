package com.cmw.interceptor;

import com.cmw.service.inter.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/**
 * SpringBoot 项目启动时初始化
 * @ClassName SysInitApplicationRunner
 * @Description: TODO
 * @Author cheng
 * @Date 2019/10/23
 * @Version V1.0
 **/
@Slf4j
@Component
@Order(value = 1)
public class SysInitApplicationRunner implements ApplicationRunner {

    @Autowired
    private SysparamsService sysparamsService;

    @Autowired
    private AuthInterceptService authInterceptService;

    @Autowired
    private SystemService systemService;

    @Autowired
    private SaasProdService saasProdService;

    @Autowired
    private GvlistService gvlistService;


    @Override
    public void run(ApplicationArguments args) throws Exception {
        try{
            //loadCache();
            loadCacheByParallel();
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private void loadCache(){
        long startTime = System.currentTimeMillis();
        log.info("开始加载系统参数到 redis ...");
        String result = sysparamsService.loadAllParsToCache();
        log.info(result);

        log.info("开始加载Sql数据权限参数到 redis ...");
        authInterceptService.loadDataToCache();

        log.info("开始加载系统数据到 redis ...");
        result = systemService.loadDataToCache();
        log.info(result);

        log.info("开始加载Saas产品数据到 redis ...");
        result = saasProdService.loadDataToCache();
        log.info(result);

        log.info("开始加载需要跳过用户Token校验URI记录数据到 redis ...");
        result = gvlistService.loadDataToCache();
        log.info(result);
        long endTime = System.currentTimeMillis();

        long resultTime = (endTime - startTime)/1000;
        log.info("加载初始化数据耗时：{}秒", resultTime);

    }

    private void loadCacheByParallel() throws ExecutionException, InterruptedException {
        long startTime = System.currentTimeMillis();
        CompletableFuture sysparamsFuture = CompletableFuture.runAsync(()->{
            log.info("开始加载系统参数到 redis ...");
            String result = sysparamsService.loadAllParsToCache();
            log.info(result);
        });
        CompletableFuture authInterceptFuture = CompletableFuture.runAsync(()->{
            log.info("开始加载Sql数据权限参数到 redis ...");
            authInterceptService.loadDataToCache();
        });
        CompletableFuture systemFuture = CompletableFuture.runAsync(()->{
            log.info("开始加载系统数据到 redis ...");
           String result = systemService.loadDataToCache();
            log.info(result);
        });

        CompletableFuture saasProdFuture = CompletableFuture.runAsync(()->{
            log.info("开始加载Saas产品数据到 redis ...");
            String result = saasProdService.loadDataToCache();
            log.info(result);
        });

        CompletableFuture gvlistFuture = CompletableFuture.runAsync(()->{
            log.info("开始加载需要跳过用户Token校验URI记录数据到 redis ...");
           String result = gvlistService.loadDataToCache();
            log.info(result);
        });

        CompletableFuture.allOf(sysparamsFuture,authInterceptFuture,systemFuture,saasProdFuture,gvlistFuture).get();
        long endTime = System.currentTimeMillis();
        long resultTime = (endTime - startTime)/1000;
        log.info("多线程并行加载初始化数据耗时：{}秒", resultTime);
    }
}
