package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.CustFollowUpEntity;


/**
 * 客户跟进记录  Mapper接口
 * @author 程明卫
 * @date 2020-06-07 15:47:49
 */
@Description(remark="客户跟进记录DAO Mapper接口",createDate="2020-06-07 15:47:49",author="程明卫")
@Mapper
public interface CustFollowUpDao extends GenericDaoInter<CustFollowUpEntity, Long>{

}
