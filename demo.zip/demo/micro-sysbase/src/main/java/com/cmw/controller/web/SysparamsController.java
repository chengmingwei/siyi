package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cmw.entity.SysparamsEntity;
import com.cmw.service.inter.SysparamsService;

import com.cmw.constant.back.ErrMsgContant;
import com.cmw.util.BeanUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;

/**
 * 系统参数表  ACTION类
 * @author 程明卫
 * @date 2019-03-27 14:57:48
 */
@Description(remark="系统参数表ACTION",createDate="2019-03-27 14:57:48",author="程明卫")
@Api(value = "系统参数表微服务", description = "#CONTROLLER# 2019-03-27 14:57:48 程明卫")
@Slf4j
@RestController
@RequestMapping({"/sysparams"})
public class SysparamsController {
	@Resource(name="sysparamsService")
	private SysparamsService sysparamsService;


    /**
     * /sysparams/load-by-recode
     * 根据引用健加载系统参数到redis中
     * @return
     */
    @ApiOperation("根据引用健加载系统参数到redis中")
    @GetMapping(value = "/load-by-recode")
    public void loadSysparamsByRecodeFromRemote(@RequestParam("recode")  String recode) throws Exception{
        Map<String,Object> pars = new HashMap<>();
        pars.put("recode",recode);
        SysparamsEntity sysparams = sysparamsService.getByPars(pars);
        if(sysparams == null){
            log.info("recode="+recode+"对应的参数值不存在，请检查是否有配置此参数或["+recode+"]值是否正确！");
        }else{
            log.info("["+recode+"]对应的参数值为："+sysparams.getVal());
        }
    }

	 /**
     * 跳转主页面
     * @return
     */
     @ApiOperation("系统参数表首页API")
    @GetMapping(value = "/home")
    public JSONObject home(Map<String, Object> params) throws Exception{
       List<SysparamsEntity> list = sysparamsService.getListAll();
       return PageHandler.getJson(list);
    }

    /**
     * 跳转列表页面
     * @param request
     * @param response
     * @return
     */
    @ApiOperation("系统参数表列表API")
    @GetMapping(value = "/list")
    public JSONObject list(HttpServletRequest request, HttpServletResponse response){
        List<SysparamsEntity> list = sysparamsService.getListAll();
        return PageHandler.getJson(list);
    }

    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取系统参数表")
    @GetMapping(value = "/info")
    public JSONObject info(@ApiParam("系统参数表ID") @RequestParam Long id){
      	if(StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        SysparamsEntity obj = sysparamsService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存系统参数表")
    @PostMapping(value = "/save")
    public JSONObject save(Map<String, Object> params) throws Exception{
        SysparamsEntity entity = BeanUtil.copyValue(SysparamsEntity.class, params);
        sysparamsService.insert(entity);
        return PageHandler.getSuccessJson();
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除系统参数表")
    @DeleteMapping(value = "/remove")
    public JSONObject remove(@ApiParam("会员ID") @RequestParam Long id) throws Exception{
        sysparamsService.delete(id);
        return PageHandler.getSuccessJson();
    }
	
}
