package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.entity.SmPgFunEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.SmPgFunService;
import com.cmw.util.BeanUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;


/**
 * 小程序模块表 ACTION类
 * @Author 肖家添
 * @Date 2019/5/13 15:42
 */
@Description(remark="小程序模块表业务接口",createDate="2019/5/13 15:42",author="肖家添")
@Api(value = "小程序模块表 ACTION类", description = "2019/5/13 15:42 肖家添")
@RestController
@RequestMapping({"/smPgFun"})
public class SmPgFunController extends BaseAction {

    @Resource(name = "smPgFunService")
    private SmPgFunService smPgFunService;

    /**
     * 获取模块数据
     * @Author 肖家添
     * @Date 2019/5/13 21:07
     **/
    @ApiOperation("获取模块数据")
    @PostMapping("/getSFList")
    public JSONObject getSFList(@RequestParam Map<String, Object> params){
        try{
            List sfList = smPgFunService.getList(params);

            return PageHandler.getJson(sfList);
        }catch (Exception ex){
            return fail(ex);
        }
    }

    /**
     * 获取工作台菜单
     * @Author 肖家添
     * @Date 2019/5/14 14:48
     */
    @ApiOperation("获取工作台菜单")
    @PostMapping("/getWorkbenchMenu")
    public JSONObject getWorkbenchMenu(@RequestParam Map<String, Object> params){
        try{
            UserModel loginUser = LoginInterceptor.getLoginUser();

            if(isNilObj(loginUser)){
                return fail("请先登录再进行操作");

            }else{
                Object utype = params.get("utype");
                Integer userType = null;
                if(null != utype){
                    userType = Integer.parseInt(utype.toString());
                    if(userType <= 0) userType = loginUser.getUtype();
                }else{
                    userType = loginUser.getUtype();
                }
                params.put("userType", userType);
                params.put("funGroup", 1);

                JSONObject returnJSON = success();

                returnJSON.put("coach", smPgFunService.getWorkbenchMenu(params));

                params.put("funGroup", 2);

                returnJSON.put("Sale", smPgFunService.getWorkbenchMenu(params));

                return returnJSON;
            }
        }catch (Exception ex){
            return fail(ex);
        }
    }

    /**
     * 保存模块数据
     * @Author 肖家添
     * @Date 2019/5/13 21:07
     **/
    @ApiOperation("操作数据")
    @PostMapping("/handleData")
    public JSONObject handleData(@RequestParam Map<String, Object> params){
        try{
            if(StringHandler.isValidObj(params)){
                Object handlerType = params.get("handlerType");

                if(isNilObj(handlerType)){
                    return fail("缺少参数");

                }else{
                    String handlerStr = handlerType.toString();

                    if(!"1".equals(handlerStr) && !"2".equals(handlerStr)){
                        return fail("参数非法");

                    }else{
                        SmPgFunEntity sf = BeanUtil.copyValue(SmPgFunEntity.class, params);

                        String code = sf.getCode();
                        String name = sf.getName();
                        Integer funGroup = sf.getFunGroup();
                        String action = sf.getAction();
                        Integer orderNo = sf.getOrderNo();

                        if(isNilStr(code)){
                            return fail("编号不能为空");

                        }else if(isNilStr(name)){
                            return fail("名称不能为空");

                        }else if(isNilObj(funGroup)){
                            return fail("所属功能组不能为空");

                        }else if(funGroup != 1 && funGroup != 2){
                            return fail("参数非法");

                        }else if(isNilObj(action)){
                            return fail("动作不能为空");

                        }else if(isNilObj(orderNo)){
                            return fail("排序不能为空");

                        }else{
                            if("1".equals(handlerStr)){
                                smPgFunService.insert(sf);
                            }else{
                                smPgFunService.update(sf);
                            }

                            return success();
                        }
                    }
                }
            }else{
                return fail("参数异常");
            }
        }catch (Exception ex){
            return fail(ex);
        }
    }

    @ApiOperation("上架/下架/删除")
    @PostMapping("/isEnabled")
    public JSONObject isEnabled(HttpServletRequest request){
        try{
            String[] ids = request.getParameterValues("id");
            String isEnabled = request.getParameter("isenabled");

            if(StringHandler.isValidObj(ids) && StringHandler.isValidStr(isEnabled)){
                String beachParam = "";
                for (String id : ids) {
                    beachParam += id + ",";
                }

                if(beachParam.length() > 0){
                    beachParam = beachParam.substring(0, beachParam.lastIndexOf(","));
                }

                smPgFunService.enabledByIds(beachParam, Integer.parseInt(isEnabled));

                return success();
            }else{
                return fail("缺少参数");
            }
        }catch (Exception ex){
            return fail(ex);
        }
    }
}
