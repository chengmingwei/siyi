package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;

import java.math.BigDecimal;
import java.util.Date;


/**
 * 订单项
 * @author 
 * @date 2020-06-07 15:50:03
 */
@Description(remark="订单项实体",createDate="2020-06-07 15:50:03",author="")
@Entity
@Table(name="ts_CustOrderItem")
@SuppressWarnings("serial")
public class CustOrderItemEntity extends IdEntity {

	/** --> 2020.09.22 0:42 CMW ADD Field START --*/
	@Description(remark="是否赠送商品")
	@Column(name="giveFlag" ,nullable=false )
	private Byte giveFlag = 0;

	@Description(remark="商品ID")
	@Column(name="goodId" ,nullable=false )
	private Long goodId;

	@Description(remark="优惠金额")
	@Column(name="disAmount" ,nullable=false ,scale=2)
	private BigDecimal disAmount = new BigDecimal("0.00");
	/** --> 2020.09.22 0:42 CMW ADD Field END --*/

	@Description(remark="实付金额")
	 @Column(name="payAmount" ,nullable=false ,scale=2)
	 private BigDecimal payAmount = new BigDecimal("0.00");

	 @Description(remark="应付金额")
	 @Column(name="totalAmount" ,nullable=false ,scale=2)
	 private BigDecimal totalAmount = new BigDecimal("0.00");

	 @Description(remark="商品数量")
	 @Column(name="goodCount" ,nullable=false )
	 private Integer goodCount = 1;

	 @Description(remark="商品单价")
	 @Column(name="price" ,nullable=false ,scale=2)
	 private BigDecimal price = new BigDecimal("0.00");

	 @Description(remark="商品名称")
	 @Column(name="goodName" ,nullable=false ,length=100 )
	 private String goodName;

	 @Description(remark="商品类型")
	 @Column(name="goodType" ,nullable=false )
	 private Integer goodType;

	 @Description(remark="订单ID")
	 @Column(name="orderId" ,nullable=false )
	 private Long orderId;


	public CustOrderItemEntity() {

	}

	public Byte getGiveFlag() {
		return giveFlag;
	}

	public void setGiveFlag(Byte giveFlag) {
		this.giveFlag = giveFlag;
	}

	public Long getGoodId() {
		return goodId;
	}

	public void setGoodId(Long goodId) {
		this.goodId = goodId;
	}

	public BigDecimal getDisAmount() {
		return disAmount;
	}

	public void setDisAmount(BigDecimal disAmount) {
		this.disAmount = disAmount;
	}

	/**
	  * 设置实际价格的值
	 * @param 	payAmount	 实付金额
	**/
	public void setPayAmount(BigDecimal  payAmount){
		 this.payAmount=payAmount;
 	}

	/**
	  * 获取实际价格的值
	 * @return 返回实际价格的值
	**/
	public BigDecimal getPayAmount(){
		 return payAmount;
 	}

	/**
	  * 设置应付金额的值
	 * @param 	totalAmount	 应付金额
	**/
	public void setTotalAmount(BigDecimal  totalAmount){
		 this.totalAmount=totalAmount;
 	}

	/**
	  * 获取应付金额的值
	 * @return 返回应付金额的值
	**/
	public BigDecimal getTotalAmount(){
		 return totalAmount;
 	}

	/**
	  * 设置商品数量的值
	 * @param 	goodCount	 商品数量
	**/
	public void setGoodCount(Integer  goodCount){
		 this.goodCount=goodCount;
 	}

	/**
	  * 获取商品数量的值
	 * @return 返回商品数量的值
	**/
	public Integer getGoodCount(){
		 return goodCount;
 	}

	/**
	  * 设置商品单价的值
	 * @param 	price	 商品单价
	**/
	public void setPrice(BigDecimal  price){
		 this.price=price;
 	}

	/**
	  * 获取商品单价的值
	 * @return 返回商品单价的值
	**/
	public BigDecimal getPrice(){
		 return price;
 	}

	/**
	  * 设置商品名称的值
	 * @param 	goodName	 商品名称
	**/
	public void setGoodName(String  goodName){
		 this.goodName=goodName;
 	}

	/**
	  * 获取商品名称的值
	 * @return 返回商品名称的值
	**/
	public String getGoodName(){
		 return goodName;
 	}

	/**
	  * 设置商品类型的值
	 * @param 	goodType	 商品类型
	**/
	public void setGoodType(Integer  goodType){
		 this.goodType=goodType;
 	}

	/**
	  * 获取商品类型的值
	 * @return 返回商品类型的值
	**/
	public Integer getGoodType(){
		 return goodType;
 	}

	/**
	  * 设置订单ID的值
	 * @param 	orderId	 订单ID
	**/
	public void setOrderId(Long  orderId){
		 this.orderId=orderId;
 	}

	/**
	  * 获取订单ID的值
	 * @return 返回订单ID的值
	**/
	public Long getOrderId(){
		 return orderId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{payAmount,totalAmount,goodCount,price,goodName,goodType,orderId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"payAmount","totalAmount","goodCount","price","goodName","goodType","orderId"};
	}

}
