package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.ProvinceEntity;


/**
 * 省份表  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 13:59:56
 */
@Description(remark="省份表DAO Mapper接口",createDate="2019-03-27 13:59:56",author="程明卫")
@Mapper
public interface ProvinceDao extends GenericDaoInter<ProvinceEntity, Long>{

}
