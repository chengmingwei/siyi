package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.UserEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;


/**
 * 用户信息  Mapper接口
 * @author 程明卫
 * @date 2019-03-26 15:14:26
 */
@Description(remark="用户信息DAO Mapper接口",createDate="2019-03-26 15:14:26",author="程明卫")
@Component
@Mapper
public interface UserDao extends GenericDaoInter<UserEntity, Long>{
    /**
     * 判断用户名或手机号或其它是否存存
     * @param vtype 验证字段类型 [1:用户名,2:手机号]
     * @param vval  验证的值
     * @param userId 用户ID
     * @return 返回 Integer [0:不存在,1:存在]
     */
    Integer exist(@Param("vtype") int vtype, @Param("vval") String vval, @Param("userId") Long userId);

    /**
     * 获取用户基本信息 用户缓存当中 (ADD:cmw 2020-09-07 15:07)
     * @param pars
     * @return
     */
    List<Map<String,Object>> getUserBaseInfos(Map<String,Object> pars);
}
