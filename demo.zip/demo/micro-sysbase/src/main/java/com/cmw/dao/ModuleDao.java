package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.ModuleEntity;


/**
 * 模块表  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 15:12:47
 */
@Description(remark="模块表DAO Mapper接口",createDate="2019-03-27 15:12:47",author="程明卫")
@Mapper
public interface ModuleDao extends GenericDaoInter<ModuleEntity, Long>{

}
