package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.ReportTempEntity;


/**
 * 报表模板表  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 14:59:20
 */
@Description(remark="报表模板表DAO Mapper接口",createDate="2019-03-27 14:59:20",author="程明卫")
@Mapper
public interface ReportTempDao extends GenericDaoInter<ReportTempEntity, Long>{

}
