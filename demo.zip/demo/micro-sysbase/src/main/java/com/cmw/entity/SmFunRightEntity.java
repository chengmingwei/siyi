package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;
import com.cmw.core.base.entity.IdEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 小程序权限表
 * @Author 肖家添
 * @Date 2019/5/13 15:30
 */
@Description(remark="小程序权限表", createDate="2019/5/13 15:30",author="肖家添")
@Entity
@Table(name="ts_SmFunRight")
@SuppressWarnings("serial")
public class SmFunRightEntity extends IdBaseEntity {

	@Description(remark="功能模块ID")
	@Column(name="funId", nullable=false, length=20)
	private Long funId;

	@Description(remark = "用户类型")
	@Column(name = "utype", nullable = false)
	private Integer utype;

	/**
	 * 功能模块ID
	 * @Author 肖家添
	 * @Date 2019/5/13 15:32
	 */
	public Long getFunId() {
		return funId;
	}

	/**
	 * 功能模块ID
	 * @Author 肖家添
	 * @Date 2019/5/13 15:32
	 */
	public void setFunId(Long funId) {
		this.funId = funId;
	}

	/**
	 * 用户类型
	 * @Author 肖家添
	 * @Date 2019/5/13 16:46
	 */
	public Integer getUtype() {
		return utype;
	}

	public void setUtype(Integer utype) {
		this.utype = utype;
	}

	@Override
	public Object[] getDatas() {
		return new Object[]{funId, utype};
	}

	@Override
	public String[] getFields() {
		return new String[]{"funId", "utype"};
	}

}
/*
	CREATE TABLE `ts_SmFunRight` (
		`funId` BIGINT(20) NOT NULL COMMENT '功能模块ID',
		`utype` int NOT NULL COMMENT '用户类型',
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`orgid` bigint(20) NOT NULL,
		`deptId` bigint(20) NOT NULL,
		`isenabled` tinyint(4) NOT NULL,
		`remark` longtext,
		`creator` bigint(20) NOT NULL,
		`createTime` datetime NOT NULL,
		`modifier` bigint(20) DEFAULT NULL,
		`modifytime` datetime DEFAULT NULL,
		PRIMARY KEY (`id`)
		) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='小程序权限表';
*/