package com.cmw.dao;



import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.AuthInterceptEntity;
import org.springframework.stereotype.Component;


/**
 * AuthIntercept  Mapper接口
 * @author 程明卫
 * @date 2020-09-16 10:09:32
 */
@Description(remark="AuthInterceptDAO Mapper接口",createDate="2020-09-16 10:09:32",author="程明卫")
@Component
@Mapper
public interface AuthInterceptDao extends GenericDaoInter<AuthInterceptEntity, Long> {

}
