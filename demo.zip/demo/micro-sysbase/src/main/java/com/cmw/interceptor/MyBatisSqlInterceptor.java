package com.cmw.interceptor;

import com.cmw.constant.SysParamConstant;
import com.cmw.core.cache.RedisService;
import com.cmw.model.back.RightModel;
import com.cmw.model.back.UserModel;
import com.cmw.util.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.DefaultReflectorFactory;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.SystemMetaObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.util.Map;
import java.util.Properties;

/**
 *  MyBatis Sql 拦截器
 * @ClassName MyBatisSqlInterceptor
 * @Description: TODO
 * @Author cheng
 * @Date 2019/11/26 22:06
 * @Version V1.0
 **/
@Slf4j
@Component
@Intercepts({
        @Signature(type = StatementHandler.class, method = "prepare", args = {
                Connection.class, Integer.class
        })
})
public class MyBatisSqlInterceptor implements Interceptor {

    @Autowired
    RedisService redisService;

    @Value("${spring.application.name}")
    private String microAppName;


    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        microAppName = microAppName.toUpperCase();
        // 方法一
        StatementHandler statementHandler = (StatementHandler) invocation.getTarget();
        MetaObject metaObject = MetaObject.forObject(statementHandler, SystemMetaObject.DEFAULT_OBJECT_FACTORY, SystemMetaObject.DEFAULT_OBJECT_WRAPPER_FACTORY, new DefaultReflectorFactory());
        //先拦截到RoutingStatementHandler，里面有个StatementHandler类型的delegate变量，其实现类是BaseStatementHandler，然后就到BaseStatementHandler的成员变量mappedStatement
        MappedStatement mappedStatement = (MappedStatement) metaObject.getValue("delegate.mappedStatement");
        //id为执行的mapper方法的全路径名，如com.uv.dao.UserMapper.insertUser
        String id = mappedStatement.getId();
        BoundSql boundSql = statementHandler.getBoundSql();
        Object parameterObject = boundSql.getParameterObject();
        log.info("mappedStatement.id = {}", id);
        if(isNotRightMethod(id, parameterObject) || !isRightMethod(id)){
            return invocation.proceed();
        }

        //sql语句类型 select、delete、insert、update
        String sqlCommandType = mappedStatement.getSqlCommandType().toString();

        //获取到原始sql语句
        String sql = boundSql.getSql();
        String mappedId = mappedStatement.getId();
        if(StringUtils.isEmpty(mappedId)){
            return invocation.proceed();
        }

        String mName = mappedId.replace("com.cmw.dao.", "");
        String redisKey =String.format(SysParamConstant.MAP_RIGHT_METHODS, microAppName);
        RightModel rightModel = redisService.getMapVal(redisKey, mName);
        if(null == rightModel || !rightModel.isFlag()){
            return invocation.proceed();
        }
        sql = getRightSql(sql, rightModel, mappedId);
        //通过反射修改sql语句
        Field field = boundSql.getClass().getDeclaredField("sql");
        field.setAccessible(true);
        field.set(boundSql, sql);
        return invocation.proceed();
    }



    /**
     * 需要拦截过滤的方法
     * RIGHT_METHODS_MAP
     * @param mappedStatementId
     * @return
     */
    private boolean isRightMethod(String mappedStatementId){
        String mappedKey = mappedStatementId;
        if(!StringUtils.isEmpty(mappedKey)) mappedKey = mappedKey.replace("com.cmw.dao.","");
        String redisKey = String.format(SysParamConstant.MAP_RIGHT_METHODS, microAppName);
        boolean flag = isFlagByCache(mappedKey, redisKey);
        if(flag) return flag;
        if(mappedStatementId.indexOf("getPageByPars") != -1 || mappedStatementId.indexOf("getTotalsByPars") != -1){
            flag = true;
        }else{
            flag = false;
        }
        return flag;
    }

    private boolean isNotRightMethod(String mappedStatementId,  Object parameterObject){
        String mappedKey = mappedStatementId;
        if(!StringUtils.isEmpty(mappedKey)) mappedKey = mappedKey.replace("com.cmw.dao.","");
        String redisKey = String.format(SysParamConstant.MAP_NOT_RIGHT_METHODS, microAppName);
        boolean flag = isFlagByCache(mappedKey, redisKey);
        if(flag) return flag;
        if(null != parameterObject && parameterObject.getClass().getSimpleName().equals("LinkedHashMap")){ //如果参数中有 rightCondition key,则走用户自定义的权限
            Map<String,?> pars = (Map<String,?>)parameterObject;
            if(pars.containsKey("rightCondition")){
                flag = true;
            }else{
                flag = false;
            }
        }
        return flag;
    }

    private boolean isFlagByCache(String mappedKey, String redisKey) {
        try{
            return redisService.hasMapKey(redisKey, mappedKey);
        }catch (Exception ex){ //出现连接异常，默认返回 false
            ex.printStackTrace();
        }
        return false;
    }


    /**
     * 动态加上权限过滤条件
     * @param sql
     * @param rightModel 权限数据模型
     * @return
     */
    private String getRightSql(String sql, RightModel rightModel, String mappedId){
        UserModel userModel = LoginInterceptor.getLoginUser();
        if(null == userModel){
            return sql;
        }
        String source = rightModel.getSourceTag();
        String tabAlisName = rightModel.getTabAlisName();
        boolean isOrgRight = rightModel.isOrgRight();
        log.info(mappedId+" RightContext。RightModel : {source: "+source+"  , tabAlisName: "+tabAlisName+",isOrgRight："+isOrgRight+"}");
        String rightSql = isOrgRight ? UserUtil.getOrgRightSql(tabAlisName, userModel) : UserUtil.getRightSql(tabAlisName, userModel);
        if(StringUtils.isEmpty(rightSql)){
            return sql;
        }else{
            rightSql = source + rightSql;
        }
        sql = sql.replace(source, rightSql);
        return sql;
    }


    @Override
    public Object plugin(Object target) {
        if (target instanceof StatementHandler) {
            return Plugin.wrap(target, this);
        } else {
            return target;
        }

    }

    @Override
    public void setProperties(Properties properties) {

    }
}
