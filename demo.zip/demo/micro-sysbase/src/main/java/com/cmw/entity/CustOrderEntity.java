package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;

import java.math.BigDecimal;
import java.util.Date;

import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 订单表
 * @author 程明卫
 * @date 2020-06-07 15:49:16
 */
@Description(remark="订单表实体",createDate="2020-06-07 15:49:16",author="程明卫")
@Entity
@Table(name="ts_CustOrder")
@SuppressWarnings("serial")
public class CustOrderEntity extends IdBaseEntity {
	
	
	 @Description(remark="IP")
	 @Column(name="ip" ,length=20 )
	 private String ip;

	 @Description(remark="支付来源")
	 @Column(name="psource" ,nullable=false )
	 private Integer psource = 1;

	 @Description(remark="订单支付时间")
	 @Column(name="payDate" )
	 private Date payDate;

	 @Description(remark="订单类型")
	 @Column(name="otype" ,nullable=false )
	 private Integer otype = 0;

	 @Description(remark="订单状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus;

	 @Description(remark="审批状态")
	 @Column(name="axstatus" ,nullable=false )
	 private Integer axstatus = 0;

	 @Description(remark="付款方式")
	 @Column(name="payType" ,nullable=false )
	 private Integer payType = 0;

	 @Description(remark="实际价格")
	 @Column(name="payPrice" ,nullable=false ,scale=2)
	 private BigDecimal payPrice = new BigDecimal("0.00");

	 @Description(remark="订单总价")
	 @Column(name="totalPrice" ,nullable=false ,scale=2)
	 private BigDecimal totalPrice = new BigDecimal("0.00");

	@Description(remark="优惠金额")
	@Column(name="disAmount" ,nullable=false ,scale=2)
	private BigDecimal disAmount = new BigDecimal("0.00");


	 @Description(remark="有效期")
	 @Column(name="endDate" )
	 private Date endDate;

	 @Description(remark="时长类型")
	 @Column(name="durationType" ,nullable=false )
	 private Integer durationType = 1;

	 @Description(remark="购买时长")
	 @Column(name="buyDuration" ,nullable=false )
	 private Integer buyDuration = 1;

	 @Description(remark="业务类型")
	 @Column(name="bussType" ,nullable=false )
	 private Integer bussType = 1;

	 @Description(remark="Saas产品ID")
	 @Column(name="productId" ,length=50 )
	 private Long productId;

	 @Description(remark="客户ID")
	 @Column(name="customerId" ,nullable=false )
	 private Long customerId;

	 @Description(remark="订单编号")
	 @Column(name="code" ,nullable=false ,length=50 )
	 private String code;

	@Description(remark="支付流水")
	@Column(name="payInfo" ,length=200 )
	private String payInfo;

	@Description(remark="付款截图")
	@Column(name="payPic" ,length=200 )
	private String payPic;

	public CustOrderEntity() {

	}

	/**
	 * 获取支付流水的值
	 * @return 返回支付流水的值
	 **/
	public String getPayInfo() {
		return payInfo;
	}

	/**
	 * 设置支付流水的值
	 * @param	payInfo	支付流水
	 **/
	public void setPayInfo(String payInfo) {
		this.payInfo = payInfo;
	}

	/**
	 * 获取付款截图的值
	 * @return 返回付款截图的值
	 **/
	public String getPayPic() {
		return payPic;
	}

	/**
	 * 设置付款截图的值
	 * @param 	payPic	 付款截图
	 **/
	public void setPayPic(String payPic) {
		this.payPic = payPic;
	}

	/**
	 * 获取优惠金额的值
	 * @return 返回优惠金额的值
	 **/
	public BigDecimal getDisAmount() {
		return disAmount;
	}

	/**
	 * 设置优惠金额的值
	 * @param 	disAmount	 优惠金额
	 **/
	public void setDisAmount(BigDecimal disAmount) {
		this.disAmount = disAmount;
	}

	/**
	  * 设置IP的值
	 * @param 	ip	 IP
	**/
	public void setIp(String  ip){
		 this.ip=ip;
 	}

	/**
	  * 获取IP的值
	 * @return 返回IP的值
	**/
	public String getIp(){
		 return ip;
 	}

	/**
	  * 设置支付来源的值
	 * @param 	psource	 支付来源
	**/
	public void setPsource(Integer  psource){
		 this.psource=psource;
 	}

	/**
	  * 获取支付来源的值
	 * @return 返回支付来源的值
	**/
	public Integer getPsource(){
		 return psource;
 	}

	/**
	  * 设置订单支付时间的值
	 * @param 	payDate	 订单支付时间
	**/
	public void setPayDate(Date  payDate){
		 this.payDate=payDate;
 	}

	/**
	  * 获取订单支付时间的值
	 * @return 返回订单支付时间的值
	**/
	public Date getPayDate(){
		 return payDate;
 	}

	/**
	  * 设置订单类型的值
	 * @param 	otype	 订单类型
	**/
	public void setOtype(Integer  otype){
		 this.otype=otype;
 	}

	/**
	  * 获取订单类型的值
	 * @return 返回订单类型的值
	**/
	public Integer getOtype(){
		 return otype;
 	}

	/**
	  * 设置订单状态的值
	 * @param 	xstatus	 订单状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取订单状态的值
	 * @return 返回订单状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置审批状态的值
	 * @param 	axstatus	 审批状态
	**/
	public void setAxstatus(Integer  axstatus){
		 this.axstatus=axstatus;
 	}

	/**
	  * 获取审批状态的值
	 * @return 返回审批状态的值
	**/
	public Integer getAxstatus(){
		 return axstatus;
 	}

	/**
	  * 设置付款方式的值
	 * @param 	payType	 付款方式
	**/
	public void setPayType(Integer  payType){
		 this.payType=payType;
 	}

	/**
	  * 获取付款方式的值
	 * @return 返回付款方式的值
	**/
	public Integer getPayType(){
		 return payType;
 	}

	/**
	  * 设置实际价格的值
	 * @param 	payPrice	 实际价格
	**/
	public void setPayPrice(BigDecimal  payPrice){
		 this.payPrice=payPrice;
 	}

	/**
	  * 获取实际价格的值
	 * @return 返回实际价格的值
	**/
	public BigDecimal getPayPrice(){
		 return payPrice;
 	}

	/**
	  * 设置订单总价的值
	 * @param 	totalPrice	 订单总价
	**/
	public void setTotalPrice(BigDecimal  totalPrice){
		 this.totalPrice=totalPrice;
 	}

	/**
	  * 获取订单总价的值
	 * @return 返回订单总价的值
	**/
	public BigDecimal getTotalPrice(){
		 return totalPrice;
 	}

	/**
	  * 设置有效期的值
	 * @param 	endDate	 有效期
	**/
	public void setEndDate(Date  endDate){
		 this.endDate=endDate;
 	}

	/**
	  * 获取有效期的值
	 * @return 返回有效期的值
	**/
	public Date getEndDate(){
		 return endDate;
 	}

	/**
	  * 设置时长类型的值
	 * @param 	durationType	 时长类型
	**/
	public void setDurationType(Integer  durationType){
		 this.durationType=durationType;
 	}

	/**
	  * 获取时长类型的值
	 * @return 返回时长类型的值
	**/
	public Integer getDurationType(){
		 return durationType;
 	}

	/**
	  * 设置购买时长的值
	 * @param 	buyDuration	 购买时长
	**/
	public void setBuyDuration(Integer  buyDuration){
		 this.buyDuration=buyDuration;
 	}

	/**
	  * 获取购买时长的值
	 * @return 返回购买时长的值
	**/
	public Integer getBuyDuration(){
		 return buyDuration;
 	}

	/**
	  * 设置业务类型的值
	 * @param 	bussType	 业务类型
	**/
	public void setBussType(Integer  bussType){
		 this.bussType=bussType;
 	}

	/**
	  * 获取业务类型的值
	 * @return 返回业务类型的值
	**/
	public Integer getBussType(){
		 return bussType;
 	}

	/**
	  * 设置Saas产品ID的值
	 * @param 	productId	 Saas产品ID
	**/
	public void setProductId(Long  productId){
		 this.productId=productId;
 	}

	/**
	  * 获取Saas产品ID的值
	 * @return 返回Saas产品ID的值
	**/
	public Long getProductId(){
		 return productId;
 	}

	/**
	  * 设置客户ID的值
	 * @param 	customerId	 客户ID
	**/
	public void setCustomerId(Long  customerId){
		 this.customerId=customerId;
 	}

	/**
	  * 获取客户ID的值
	 * @return 返回客户ID的值
	**/
	public Long getCustomerId(){
		 return customerId;
 	}

	/**
	  * 设置订单编号的值
	 * @param 	code	 订单编号
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取订单编号的值
	 * @return 返回订单编号的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{ip,psource,payDate,otype,xstatus,axstatus,payType,payPrice,totalPrice,endDate,durationType,buyDuration,bussType,productId,customerId,code};
	}

	@Override
	public String[] getFields() {
		return new String[]{"ip","psource","payDate","otype","xstatus","axstatus","payType","payPrice","totalPrice","endDate","durationType","buyDuration","bussType","productId","customerId","code"};
	}

}
