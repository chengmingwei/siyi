package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.CustOrderItemEntity;


/**
 * 订单项  Mapper接口
 * @author 
 * @date 2020-06-07 15:50:03
 */
@Description(remark="订单项DAO Mapper接口",createDate="2020-06-07 15:50:03",author="")
@Mapper
public interface CustOrderItemDao extends GenericDaoInter<CustOrderItemEntity, Long>{

}
