package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 角色
 * @author 程明卫
 * @date 2019-04-02 00:14:57
 */
@Description(remark="角色实体",createDate="2019-04-02 00:14:57",author="程明卫")
@Entity
@Table(name="ts_Role")
@SuppressWarnings("serial")
public class RoleEntity extends IdBaseEntity {
	
	
	 @Description(remark="角色名称")
	 @Column(name="name" ,nullable=false ,length=30 )
	 private String name;

	 @Description(remark="角色编号")
	 @Column(name="code" ,nullable=false ,length=20 )
	 private String code;


	public RoleEntity() {

	}

	
	/**
	  * 设置角色名称的值
	 * @param 	name	 角色名称
	**/
	public void setName(String  name){
		 this.name=name;
 	}

	/**
	  * 获取角色名称的值
	 * @return 返回角色名称的值
	**/
	public String getName(){
		 return name;
 	}

	/**
	  * 设置角色编号的值
	 * @param 	code	 角色编号
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取角色编号的值
	 * @return 返回角色编号的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{name,code};
	}

	@Override
	public String[] getFields() {
		return new String[]{"name","code"};
	}

}
