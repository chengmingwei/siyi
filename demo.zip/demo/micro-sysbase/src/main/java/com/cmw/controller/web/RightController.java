package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cmw.entity.RightEntity;
import com.cmw.service.inter.RightService;


/**
 * 角色菜单权限表  ACTION类
 *
 * @author 程明卫
 * @date 2019-03-27 15:14:25
 */
@Description(remark = "角色菜单权限表ACTION", createDate = "2019-03-27 15:14:25", author = "程明卫")
@Api(value = "角色菜单权限表微服务", description = "#CONTROLLER# 2019-03-27 15:14:25 程明卫")
@RestController
@RequestMapping({"/right"})
@Slf4j
public class RightController {

    @Resource(name = "rightService")
    private RightService rightService;

    /**
     * 获取菜单权限
     * @Author 肖家添
     * @Date 2019/5/12 16:41
     */
    @ApiOperation("获取权限列表")
    @PostMapping("/getRightList")
    public JSONObject getRightList(@RequestParam Map<String, Object> params){
        try{
            List<RightEntity> rightList = rightService.getList(params);

            return PageHandler.getJson(rightList);
        }catch (Exception ex){
            ex.printStackTrace();

            return PageHandler.getFailureJson("系统异常");
        }
    }

    /**
     * 保存角色菜单权限
     * @Author 肖家添
     * @Date 2019/5/10 11:03
     */
    @ApiOperation("保存角色菜单权限")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam String roleId, HttpServletRequest request) {
        boolean success = true;
        String msg = "";

        try {
            String[] menuId = request.getParameterValues("menuId");

            if(!StringHandler.isValidObj(roleId)){
                success = false;
                msg = "请选择角色";

            }else{
                Map<String, Object> deleteParams = new HashMap<>();

                deleteParams.put("roleId", roleId);

                rightService.deleteByPars(deleteParams);

                Long totals = rightService.getTotals(deleteParams);

                if(totals == 0){
                    if(StringHandler.isValidObj(menuId)){
                        List<RightEntity> rightList = new ArrayList<>();

                        for (int i = 0; i < menuId.length; i++) {
                            RightEntity entity = new RightEntity();

                            entity.setRoleId(Long.parseLong(roleId));
                            entity.setMmId(Long.parseLong(menuId[i]));
                            entity.setObjtype(0);
                            entity.setType(1);

                            rightList.add(entity);
                        }

                        rightService.batchInsert(rightList);
                    }

                    success = true;
                }else{
                    success = false;

                    msg = "数据未完全清除";
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();

            success = false;
            msg = "系统异常";
        }

        if (success)
            return PageHandler.getSuccessJson();
        else
            return PageHandler.getFailureJson(msg);
    }
}
