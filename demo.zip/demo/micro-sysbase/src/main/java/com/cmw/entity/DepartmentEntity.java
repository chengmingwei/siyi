package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;


/**
 * 部门表
 * @author 程明卫
 * @date 2019-03-27 14:53:28
 */
@Description(remark="部门表实体",createDate="2019-03-27 14:53:28",author="程明卫")
@Entity
@Table(name="ts_Department")
@SuppressWarnings("serial")
public class DepartmentEntity extends IdBaseEntity {
	
	
	 @Description(remark="部门类型")
	 @Column(name="dtype" )
	 private Integer dtype;

	 @Description(remark="上级单位ID")
	 @Column(name="poid" )
	 private Long poid;

	 @Description(remark="上级单位类型")
	 @Column(name="potype" )
	 private Integer potype;

	 @Description(remark="名称")
	 @Column(name="name" ,nullable=false ,length=100 )
	 private String name;

	 @Description(remark="编号")
	 @Column(name="code" ,nullable=false ,length=20 )
	 private String code;

	@Description(remark="联系人")
	@Column(name="contactor" ,nullable=false ,length=20 )
	private String contactor;

	@Description(remark="联系电话")
	@Column(name="tel" ,nullable=false ,length=20 )
	private String tel;

	/**
	 * 设置联系电话的值
	 * @param 	tel	联系电话
	 **/
	public void setTel(String  tel){
		this.tel=tel;
	}

	/**
	 * 获取联系人的值
	 * @return 返回联系电话的值
	 **/
	public String getTel(){
		return tel;
	}

	/**
	 * 设置联系人的值
	 * @param 	contactor	联系人
	 **/
	public void setContactor(String  contactor){
		this.contactor=contactor;
	}

	/**
	 * 获取联系人的值
	 * @return 返回联系人的值
	 **/
	public String getContactor(){
		return contactor;
	}

	public DepartmentEntity() {

	}

	
	/**
	  * 设置部门类型的值
	 * @param 	dtype	 部门类型
	**/
	public void setDtype(Integer  dtype){
		 this.dtype=dtype;
 	}

	/**
	  * 获取部门类型的值
	 * @return 返回部门类型的值
	**/
	public Integer getDtype(){
		 return dtype;
 	}

	/**
	  * 设置上级单位ID的值
	 * @param 	poid	 上级单位ID
	**/
	public void setPoid(Long  poid){
		 this.poid=poid;
 	}

	/**
	  * 获取上级单位ID的值
	 * @return 返回上级单位ID的值
	**/
	public Long getPoid(){
		 return poid;
 	}

	/**
	  * 设置上级单位类型的值
	 * @param 	potype	 上级单位类型
	**/
	public void setPotype(Integer  potype){
		 this.potype=potype;
 	}

	/**
	  * 获取上级单位类型的值
	 * @return 返回上级单位类型的值
	**/
	public Integer getPotype(){
		 return potype;
 	}

	/**
	  * 设置名称的值
	 * @param 	name	 名称
	**/
	public void setName(String  name){
		 this.name=name;
 	}

	/**
	  * 获取名称的值
	 * @return 返回名称的值
	**/
	public String getName(){
		 return name;
 	}

	/**
	  * 设置编号的值
	 * @param 	code	 编号
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取编号的值
	 * @return 返回编号的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{dtype,poid,potype,name,code};
	}

	@Override
	public String[] getFields() {
		return new String[]{"dtype","poid","potype","name","code"};
	}

}
