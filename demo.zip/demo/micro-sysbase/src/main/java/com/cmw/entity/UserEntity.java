package com.cmw.entity;


import com.cmw.constant.back.BussContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 用户信息
 * @author 程明卫
 * @date 2019-03-26 15:14:26
 */
@Description(remark="用户信息实体",createDate="2019-03-26 15:14:26",author="程明卫")
@Entity
@Table(name="ts_user")
@SuppressWarnings("serial")
public class UserEntity extends BaseEntity {

	 @Description(remark="公司ID  schoolId")
	 @Column(name="incompId" ,length=19 ,scale=0)
	 private Long incompId;

	 @Description(remark="启用密码过期")
	 @Column(name="pwdfail" ,nullable=false ,length=10 ,scale=0)
	 private Integer pwdfail = 1;

	 @Description(remark="员工ID  teacherId")
	 @Column(name="inempId" ,length=19 ,scale=0)
	 private Long inempId;

	 @Description(remark="姓名")
	 @Column(name="empName" ,length=30 )
	 private String empName;

	 @Description(remark="密码")
	 @Column(name="passWord" ,length=30 )
	 private String passWord;

	 @Description(remark="岗位ID")
	 @Column(name="postId" ,length=19 ,scale=0)
	 private Long postId;

	 @Description(remark="性别")
	 @Column(name="sex" ,nullable=false ,length=10 ,scale=0)
	 private Integer sex;

	 @Description(remark="手机")
	 @Column(name="phone" ,length=20 )
	 private String phone;

	 @Description(remark="拼音助记码")
	 @Column(name="mnemonic" ,length=100 )
	 private String mnemonic;

	 @Description(remark="数据访问级别")
	 @Column(name="dataLevel" ,nullable=false ,length=10 ,scale=0)
	 private Integer dataLevel = 0;

	 @Description(remark="数据过滤ID列表")
	 @Column(name="accessIds" ,length=255 )
	 private String accessIds;

	 @Description(remark="用户ID")
	 @Column(name="userId" ,nullable=false ,length=19 ,scale=0)
	 private Long userId;

	 @Description(remark="登录限制")
	 @Column(name="loglimit" ,nullable=false ,length=10 ,scale=0)
	 private Integer loglimit = 0;

	 @Description(remark="直属领导")
	 @Column(name="leader" ,length=19 ,scale=0)
	 private Long leader;

	 @Description(remark="联系电话")
	 @Column(name="tel" ,length=20 )
	 private String tel;

	 @Description(remark="账号")
	 @Column(name="userName" ,nullable=false ,length=30 )
	 private String userName;

	 @Description(remark="过期周期")
	 @Column(name="pwdcycle" ,nullable=false ,length=10 ,scale=0)
	 private Integer pwdcycle = 30;

	 @Description(remark="邮箱")
	 @Column(name="email" ,length=50 )
	 private String email;

	 @Description(remark="部门ID  schoolId")
	 @Column(name="indeptId" ,length=19 ,scale=0)
	 private Long indeptId;

	 @Description(remark="限制ip段")
	 @Column(name="iplimit" ,length=100 )
	 private String iplimit;

	 @Description(remark="首次密码提示")
	 @Column(name="pwdtip" ,nullable=false ,length=10 ,scale=0)
	 private Integer pwdtip = 1;


	 @Description(remark="用户类型",defaultVals = "1:普通用户,2:区域管理员,3:超级管理员")
	 @Column(name="utype" ,nullable=false)
	 private String utype = BussContant.USER_UTYPE_1+"";

	public UserEntity() {

	}

	/**
	 * 获取用户类型
	 * @return 返回用户类型的值
	 */
	public String getUtype() {
		return utype;
	}

	/**
	 * 设置用户类型
	 * @param utype 用户类型
	 */
	public void setUtype(String utype) {
		this.utype = utype;
	}

	/**
	  * 设置公司ID的值
	 * @param 	incompId	 公司ID
	**/
	public void setIncompId(Long  incompId){
		 this.incompId=incompId;
 	}

	/**
	  * 获取公司ID的值
	 * @return 返回公司ID的值
	**/
	public Long getIncompId(){
		 return incompId;
 	}

	/**
	  * 设置启用密码过期的值
	 * @param 	pwdfail	 启用密码过期
	**/
	public void setPwdfail(Integer  pwdfail){
		 this.pwdfail=pwdfail;
 	}

	/**
	  * 获取启用密码过期的值
	 * @return 返回启用密码过期的值
	**/
	public Integer getPwdfail(){
		 return pwdfail;
 	}

	/**
	  * 设置员工ID的值
	 * @param 	inempId	 员工ID
	**/
	public void setInempId(Long  inempId){
		 this.inempId=inempId;
 	}

	/**
	  * 获取员工ID的值
	 * @return 返回员工ID的值
	**/
	public Long getInempId(){
		 return inempId;
 	}

	/**
	  * 设置姓名的值
	 * @param 	empName	 姓名
	**/
	public void setEmpName(String  empName){
		 this.empName=empName;
 	}

	/**
	  * 获取姓名的值
	 * @return 返回姓名的值
	**/
	public String getEmpName(){
		 return empName;
 	}

	/**
	  * 设置密码的值
	 * @param 	passWord	 密码
	**/
	public void setPassWord(String  passWord){
		 this.passWord=passWord;
 	}

	/**
	  * 获取密码的值
	 * @return 返回密码的值
	**/
	public String getPassWord(){
		 return passWord;
 	}

	/**
	  * 设置岗位ID的值
	 * @param 	postId	 岗位ID
	**/
	public void setPostId(Long  postId){
		 this.postId=postId;
 	}

	/**
	  * 获取岗位ID的值
	 * @return 返回岗位ID的值
	**/
	public Long getPostId(){
		 return postId;
 	}

	/**
	  * 设置性别的值
	 * @param 	sex	 性别
	**/
	public void setSex(Integer  sex){
		 this.sex=sex;
 	}

	/**
	  * 获取性别的值
	 * @return 返回性别的值
	**/
	public Integer getSex(){
		 return sex;
 	}

	/**
	  * 设置手机的值
	 * @param 	phone	 手机
	**/
	public void setPhone(String  phone){
		 this.phone=phone;
 	}

	/**
	  * 获取手机的值
	 * @return 返回手机的值
	**/
	public String getPhone(){
		 return phone;
 	}

	/**
	  * 设置拼音助记码的值
	 * @param 	mnemonic	 拼音助记码
	**/
	public void setMnemonic(String  mnemonic){
		 this.mnemonic=mnemonic;
 	}

	/**
	  * 获取拼音助记码的值
	 * @return 返回拼音助记码的值
	**/
	public String getMnemonic(){
		 return mnemonic;
 	}

	/**
	  * 设置数据访问级别的值
	 * @param 	dataLevel	 数据访问级别
	**/
	public void setDataLevel(Integer  dataLevel){
		 this.dataLevel=dataLevel;
 	}

	/**
	  * 获取数据访问级别的值
	 * @return 返回数据访问级别的值
	**/
	public Integer getDataLevel(){
		 return dataLevel;
 	}

	/**
	  * 设置数据过滤ID列表的值
	 * @param 	accessIds	 数据过滤ID列表
	**/
	public void setAccessIds(String  accessIds){
		 this.accessIds=accessIds;
 	}

	/**
	  * 获取数据过滤ID列表的值
	 * @return 返回数据过滤ID列表的值
	**/
	public String getAccessIds(){
		 return accessIds;
 	}

	/**
	  * 设置用户ID的值
	 * @param 	userId	 用户ID
	**/
	public void setUserId(Long  userId){
		 this.userId=userId;
 	}

	/**
	  * 获取用户ID的值
	 * @return 返回用户ID的值
	**/
	public Long getUserId(){
		 return userId;
 	}

	/**
	  * 设置登录限制的值
	 * @param 	loglimit	 登录限制
	**/
	public void setLoglimit(Integer  loglimit){
		 this.loglimit=loglimit;
 	}

	/**
	  * 获取登录限制的值
	 * @return 返回登录限制的值
	**/
	public Integer getLoglimit(){
		 return loglimit;
 	}

	/**
	  * 设置直属领导的值
	 * @param 	leader	 直属领导
	**/
	public void setLeader(Long  leader){
		 this.leader=leader;
 	}

	/**
	  * 获取直属领导的值
	 * @return 返回直属领导的值
	**/
	public Long getLeader(){
		 return leader;
 	}

	/**
	  * 设置联系电话的值
	 * @param 	tel	 联系电话
	**/
	public void setTel(String  tel){
		 this.tel=tel;
 	}

	/**
	  * 获取联系电话的值
	 * @return 返回联系电话的值
	**/
	public String getTel(){
		 return tel;
 	}

	/**
	  * 设置账号的值
	 * @param 	userName	 账号
	**/
	public void setUserName(String  userName){
		 this.userName=userName;
 	}

	/**
	  * 获取账号的值
	 * @return 返回账号的值
	**/
	public String getUserName(){
		 return userName;
 	}

	/**
	  * 设置过期周期的值
	 * @param 	pwdcycle	 过期周期
	**/
	public void setPwdcycle(Integer  pwdcycle){
		 this.pwdcycle=pwdcycle;
 	}

	/**
	  * 获取过期周期的值
	 * @return 返回过期周期的值
	**/
	public Integer getPwdcycle(){
		 return pwdcycle;
 	}

	/**
	  * 设置邮箱的值
	 * @param 	email	 邮箱
	**/
	public void setEmail(String  email){
		 this.email=email;
 	}

	/**
	  * 获取邮箱的值
	 * @return 返回邮箱的值
	**/
	public String getEmail(){
		 return email;
 	}

	/**
	  * 设置部门ID的值
	 * @param 	indeptId	 部门ID
	**/
	public void setIndeptId(Long  indeptId){
		 this.indeptId=indeptId;
 	}

	/**
	  * 获取部门ID的值
	 * @return 返回部门ID的值
	**/
	public Long getIndeptId(){
		 return indeptId;
 	}

	/**
	  * 设置限制ip段的值
	 * @param 	iplimit	 限制ip段
	**/
	public void setIplimit(String  iplimit){
		 this.iplimit=iplimit;
 	}

	/**
	  * 获取限制ip段的值
	 * @return 返回限制ip段的值
	**/
	public String getIplimit(){
		 return iplimit;
 	}

	/**
	  * 设置首次密码提示的值
	 * @param 	pwdtip	 首次密码提示
	**/
	public void setPwdtip(Integer  pwdtip){
		 this.pwdtip=pwdtip;
 	}

	/**
	  * 获取首次密码提示的值
	 * @return 返回首次密码提示的值
	**/
	public Integer getPwdtip(){
		 return pwdtip;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{utype,incompId,pwdfail,inempId,empName,passWord,postId,sex,phone,mnemonic,dataLevel,accessIds,userId,loglimit,leader,tel,userName,pwdcycle,email,indeptId,iplimit,pwdtip};
	}

	@Override
	public String[] getFields() {
		return new String[]{"utype","incompId","pwdfail","inempId","empName","passWord","postId","sex","phone","mnemonic","dataLevel","accessIds","userId","loglimit","leader","tel","userName","pwdcycle","email","indeptId","iplimit","pwdtip"};
	}

}
