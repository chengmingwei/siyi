package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.SaasProdEntity;


/**
 * Saas产品  Mapper接口
 * @author 程明卫
 * @date 2020-06-07 14:57:22
 */
@Description(remark="Saas产品DAO Mapper接口",createDate="2020-06-07 14:57:22",author="程明卫")
@Mapper
public interface SaasProdDao extends GenericDaoInter<SaasProdEntity, Long>{

}
