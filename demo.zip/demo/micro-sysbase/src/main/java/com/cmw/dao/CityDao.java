package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.CityEntity;


/**
 * City  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 14:37:16
 */
@Description(remark="CityDAO Mapper接口",createDate="2019-03-27 14:37:16",author="程明卫")
@Mapper
public interface CityDao extends GenericDaoInter<CityEntity, Long>{

}
