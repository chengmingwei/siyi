package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


import com.cmw.entity.CustOrderItemEntity;
import com.cmw.service.inter.CustOrderItemService;


/**
 * 订单项  ACTION类
 * @author 
 * @date 2020-06-07 15:50:03
 */
@Description(remark="订单项ACTION",createDate="2020-06-07 15:50:03",author="")
@Api(value = "订单项微服务", description = "#CONTROLLER# 2020-06-07 15:50:03 ")
@RestController
@RequestMapping({"/custorderitem"})
public class CustOrderItemController{
	@Resource(name="custOrderItemService")
	private CustOrderItemService custOrderItemService;

    /**
     * url:/custorderitem/feign/update
     * 更新商品ID （micro-sports SchoolServerviceImpl -> buySchoolsNotify 方法调用）
     * @date 2020-10-19 10:22
     * @param params 要更新的数据
     * @return
     */
    @ApiOperation("更新商品ID")
    @PutMapping("/feign/update")
    public JSONObject update(@RequestParam  Map<String, String> params) throws Exception{
        try{
            custOrderItemService.updateOrdetIetmNotify(params);
            return PageHandler.getSuccessJson();
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }


    /**
   	 * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     * @return
    */
    @ApiOperation("分页查订单项列表API")
    @PostMapping(value = "/list")
    public JSONObject list(@RequestBody Map<String,Object> params){
      	Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = custOrderItemService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
        
    }
    
     /**
     * 根据自定义参数获取订单项
     * @param params
     * @return
     */
 	@ApiOperation("根据ID获取订单项表信息")
    @GetMapping
    public JSONObject get(@RequestParam Map<String, Object> params) throws Exception{
       CustOrderItemEntity obj = custOrderItemService.getByPars(params);
	   JSONObject jsonObject = PageHandler.getJson(obj);
	   return jsonObject;
    }
    

    /**
     * 根据ID获取订单项信息
  	 * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取订单项")
    @GetMapping(value = "/{id}")
    public JSONObject get(@ApiParam("订单项ID") @PathVariable("id") Long id){
      	if(StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        CustOrderItemEntity obj = custOrderItemService.get(id);
        return PageHandler.getJson(obj);
    }

	/**
     * 保存数据（前端）
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存订单项")
    @PostMapping
    public JSONObject save(@RequestParam  Map<String, String> params) throws Exception{
         try{
            Map<String, Object> dataResult = (Map<String, Object>)custOrderItemService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }
    
    /**
     * 保存数据（后台系统）
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存订单项")
    @PostMapping(value = "/save")
    public JSONObject sys_save(@RequestBody  Map<String, String> params) throws Exception{
         try{
            Map<String, Object> dataResult = (Map<String, Object>)custOrderItemService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除订单项")
    @DeleteMapping(value = "/{id}")
    public JSONObject delete(@ApiParam("订单项ID") @PathVariable("id")  Long id) throws Exception{
        custOrderItemService.delete(id);
        return PageHandler.getSuccessJson();
    }
	
}
