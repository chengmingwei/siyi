package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.AccordionEntity;
import com.cmw.entity.SmPgFunEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;


/**
 *  小程序模块表DAO Mapper接口
 * @Author 肖家添
 * @Date 2019/5/13 15:42
 */
@Description(remark="小程序模块表DAO Mapper接口",createDate="2019/5/13 15:42",author="肖家添")
@Mapper
public interface SmPgFunDao extends GenericDaoInter<SmPgFunEntity, Long>{

    /**
     * 获取小程序工作台菜单
     * @Author 肖家添
     * @Date 2019/5/14 14:58
     */
    List<Map<String, Object>> getWorkbenchMenu(Map<String, Object> params);

}
