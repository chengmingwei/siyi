package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.core.vo.PageResult;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


import com.cmw.entity.CustFollowUpEntity;
import com.cmw.service.inter.CustFollowUpService;


/**
 * 客户跟进记录  ACTION类
 * @author 程明卫
 * @date 2020-06-07 15:47:49
 */
@Description(remark="客户跟进记录ACTION",createDate="2020-06-07 15:47:49",author="程明卫")
@Api(value = "客户跟进记录微服务", description = "#CONTROLLER# 2020-06-07 15:47:49 程明卫")
@RestController
@RequestMapping({"/custfollowup"})
public class CustFollowUpController{
	@Resource(name="custFollowUpService")
	private CustFollowUpService custFollowUpService;
	

    /**
   	 * 分页查询
     * 返回状态码：
     *     404 : 没有查询到任何数据
     * @param params (查询的过滤条件，参数含：pageSize : 每页大小, page：当前页)
     * @return 返回 PageResult 对象
     * @return
    */
    @ApiOperation("分页查客户跟进记录列表API")
    @PostMapping(value = "/list")
    public JSONObject list(@RequestBody Map<String,Object> params){
      	Integer pageSize = (null != params.get("pageSize")) ? Integer.parseInt(params.get("pageSize").toString()) : null;
        Integer page = (null != params.get("currentPage")) ? Integer.parseInt(params.get("currentPage").toString()) : null;
        params.remove("pageSize");
        params.remove("currentPage");
        UserModel userObj = LoginInterceptor.getLoginUser();
        String rightCondition = UserUtil.getRightSql("A", userObj);
        params.put("rightCondition", rightCondition);
        PageResult<List<Map<String,Object>>> result = custFollowUpService.getPageByPars(params,page, pageSize);
        if(result == null){
            return PageHandler.getSuccessJson();
        }
        return PageHandler.getJson(result);
        
    }
    
     /**
     * 根据自定义参数获取客户跟进记录
     * @param request
     * @param response
     * @return
     */
 	@ApiOperation("根据ID获取客户跟进记录表信息")
    @GetMapping
    public JSONObject get(@RequestParam Map<String, Object> params) throws Exception{
       CustFollowUpEntity obj = custFollowUpService.getByPars(params);
	   JSONObject jsonObject = PageHandler.getJson(obj);
	   return jsonObject;
    }
    

    /**
     * 根据ID获取客户跟进记录信息
  	 * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取客户跟进记录")
    @GetMapping(value = "/{id}")
    public JSONObject get(@ApiParam("客户跟进记录ID") @PathVariable("id") Long id){
      	if(StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        CustFollowUpEntity obj = custFollowUpService.get(id);
        return PageHandler.getJson(obj);
    }

	/**
     * 保存数据（前端）
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存客户跟进记录")
    @PostMapping
    public JSONObject save(@RequestParam  Map<String, String> params) throws Exception{
         try{
            Map<String, Object> dataResult = (Map<String, Object>)custFollowUpService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }
    
    /**
     * 保存数据（后台系统）
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存客户跟进记录")
    @PostMapping(value = "/save")
    public JSONObject sys_save(@RequestBody  Map<String, String> params) throws Exception{
         try{
            Map<String, Object> dataResult = (Map<String, Object>)custFollowUpService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除客户跟进记录")
    @DeleteMapping(value = "/{id}")
    public JSONObject delete(@ApiParam("客户跟进记录ID") @PathVariable("id")  Long id) throws Exception{
        custFollowUpService.delete(id);
        return PageHandler.getSuccessJson();
    }
	
}
