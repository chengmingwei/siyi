package com.cmw.controller.web;

import com.alibaba.fastjson.JSONObject;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;

/**
 * 请求处理
 * @Author 肖家添
 * @Date 2019/5/13 17:28
 */
public class BaseAction {

    /**
     * 处理成功
     * @Author 肖家添
     * @Date 2019/5/13 17:29
     */
    protected JSONObject success(){
        return success(null);
    }

    /**
     * 处理成功
     * @Author 肖家添
     * @Date 2019/5/13 17:29
     */
    protected JSONObject success(String msg){
        return PageHandler.getSuccessJson(msg);
    }

    /**
     * 处理失败
     * @Author 肖家添
     * @Date 2019/5/13 17:29
     */
    protected JSONObject fail(Exception ex){
        ex.printStackTrace();

        return fail(ex.getMessage());
    }

    /**
     * 处理失败
     * @Author 肖家添
     * @Date 2019/5/13 17:30
     */
    protected JSONObject fail(String msg){
        return PageHandler.getFailureJson(msg);
    }

    /**
     * 字符串为空返回true
     * @Author 肖家添
     * @Date 2019/5/13 17:34
     */
    protected boolean isNilStr(String str){
        return !StringHandler.isValidStr(str);
    }

    /**
     * 对象为空返回true
     * @Author 肖家添
     * @Date 2019/5/13 17:34
     */
    protected boolean isNilObj(Object obj){
        return !StringHandler.isValidObj(obj);
    }

}
