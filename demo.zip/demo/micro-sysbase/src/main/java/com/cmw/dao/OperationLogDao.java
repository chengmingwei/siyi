package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.OperationLogEntity;


/**
 * 操作日志  Mapper接口
 * @author 程明卫
 * @date 2019-03-28 21:49:11
 */
@Description(remark="操作日志DAO Mapper接口",createDate="2019-03-28 21:49:11",author="程明卫")
@Mapper
public interface OperationLogDao extends GenericDaoInter<OperationLogEntity, Long>{

}
