package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.entity.MsgTemplateEntity;
import com.cmw.service.inter.MsgTemplateService;
import com.cmw.util.PageHandler;
import com.cmw.util.SHashMap;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 消息模板表  ACTION类
 * @author 程明卫
 * @date 2019-04-10 23:14:25
 */
@Description(remark="消息模板表ACTION",createDate="2019-04-10 23:14:25",author="程明卫")
@Api(value = "消息模板表微服务", description = "#CONTROLLER# 2019-04-10 23:14:25 程明卫")
@RestController
@RequestMapping({"/msgtemplate"})
public class MsgTemplateController {
	@Resource(name="msgTemplateService")
	private MsgTemplateService msgTemplateService;
	


    /**
     * 跳转列表页面
     * @param request
     * @param response
     * @return
     */
     @ApiOperation("消息模板表列表API")
    @GetMapping(value = "/list")
    public JSONObject list(HttpServletRequest request, HttpServletResponse response){
        List<MsgTemplateEntity> list = msgTemplateService.getListAll();
        return PageHandler.getJson(list);
    }

    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取消息模板表")
    @PostMapping(value = "/{id}")
    public JSONObject info(@ApiParam("消息模板表ID") @PathVariable(value="id", required = false) Long id){
      	if(!StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        MsgTemplateEntity obj = msgTemplateService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存消息模板表")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestBody  Map<String, Object> params) throws Exception{
        try{
            Map<String, Object> dataResult = (Map<String, Object>)msgTemplateService.doComplexBusss(new SHashMap(params));
            return PageHandler.getJson(dataResult);
        }catch (ServiceException ex){
            ex.printStackTrace();
            return PageHandler.getFailureJson(ex.getMessage());
        }

       /* MsgTemplateEntity entity = BeanUtil.copyValue(MsgTemplateEntity.class, params);
        msgTemplateService.insert(entity);
        return PageHandler.getSuccessJson();*/
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除消息模板表")
    @DeleteMapping(value = "/{id}")
    public JSONObject remove(@ApiParam("会员ID") @PathVariable("id") Long id) throws Exception{
        msgTemplateService.enabled(id,-1);
        return PageHandler.getSuccessJson();
    }
    /**
     * 根据code获取实体
     * @param request
     * @param response
     * @return
     */
    @ApiOperation("根据code获取实体")
    @RequestMapping(value = "/getByCode")
    public JSONObject getByCode(HttpServletRequest request, HttpServletResponse response){
        String code = request.getParameter("code");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("code",code);
        List<MsgTemplateEntity> list = new ArrayList<MsgTemplateEntity>();
        if (StringHandler.isValidStr(code)){
            list  =msgTemplateService.getList(map);
        }else {
            list = msgTemplateService.getListAll();
        }

        return PageHandler.getJson(list);
    }
}
