package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.GvlistEntity;
import org.springframework.stereotype.Component;


/**
 * 基础数据表  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 13:55:12
 */
@Description(remark="基础数据表DAO Mapper接口",createDate="2019-03-27 13:55:12",author="程明卫")
@Component
@Mapper
public interface GvlistDao extends GenericDaoInter<GvlistEntity, Long>{

}
