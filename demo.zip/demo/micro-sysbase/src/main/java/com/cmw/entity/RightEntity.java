package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;


/**
 * 角色菜单权限表
 *
 * @author 程明卫
 * @date 2019-03-27 15:14:25
 */
@Description(remark = "角色菜单权限表实体", createDate = "2019-03-27 15:14:25", author = "程明卫")
@Entity
@Table(name = "ts_Right")
@SuppressWarnings("serial")
public class RightEntity extends IdEntity {


    @Description(remark = "卡片/菜单/模块ID/客户端工作台权限标识")
    @Column(name = "mmId", nullable = false)
    private Long mmId;

    @Description(remark = "权限类型")
    @Column(name = "type", nullable = false)
    private Integer type;

    @Description(remark = "角色ID")
    @Column(name = "roleId", nullable = false)
    private Long roleId;

    @Description(remark = "对象类型")
    @Column(name = "objtype", nullable = false)
    private Integer objtype;

    public RightEntity() {

    }


    /**
     * 设置卡片/菜单/模块ID的值
     *
     * @param mmId 卡片/菜单/模块ID
     **/
    public void setMmId(Long mmId) {
        this.mmId = mmId;
    }

    /**
     * 获取卡片/菜单/模块ID的值
     *
     * @return 返回卡片/菜单/模块ID的值
     **/
    public Long getMmId() {
        return mmId;
    }

    /**
     * 设置权限类型的值
     *
     * @param type 权限类型
     **/
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 获取权限类型的值
     *
     * @return 返回权限类型的值
     **/
    public Integer getType() {
        return type;
    }

    /**
     * 设置角色ID的值
     *
     * @param roleId 角色ID
     **/
    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    /**
     * 获取角色ID的值
     *
     * @return 返回角色ID的值
     **/
    public Long getRoleId() {
        return roleId;
    }

    /**
     * 设置对象类型的值
     *
     * @param objtype 对象类型
     **/
    public void setObjtype(Integer objtype) {
        this.objtype = objtype;
    }

    /**
     * 获取对象类型的值
     *
     * @return 返回对象类型的值
     **/
    public Integer getObjtype() {
        return objtype;
    }


    @Override
    public Object[] getDatas() {
        return new Object[]{mmId, type, roleId, objtype};
    }

    @Override
    public String[] getFields() {
        return new String[]{"mmId", "type", "roleId", "objtype"};
    }

    @Override
    public String toString() {
        return "RightEntity{" +
                "mmId=" + mmId +
                ", type=" + type +
                ", roleId=" + roleId +
                ", objtype=" + objtype +
                '}';
    }
}
