package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.UroleEntity;


/**
 * 用户角色关联表  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 13:50:17
 */
@Description(remark="用户角色关联表DAO Mapper接口",createDate="2019-03-27 13:50:17",author="程明卫")
@Mapper
public interface UroleDao extends GenericDaoInter<UroleEntity, Long>{

}
