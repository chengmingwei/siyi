package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 消息模板表
 * @author 程明卫
 * @date 2019-04-10 23:14:25
 */
@Description(remark="消息模板表实体",createDate="2019-04-10 23:14:25",author="程明卫")
@Entity
@Table(name="ts_MsgTemplate")
@SuppressWarnings("serial")
public class MsgTemplateEntity extends IdBaseEntity {
	
	
	 @Description(remark="默认接收号码")
	 @Column(name="dpenums" ,length=150 )
	 private String dpenums;

	 @Description(remark="模板参数")
	 @Column(name="fparas" ,length=150 )
	 private String fparas;

	 @Description(remark="模板内容")
	 @Column(name="content" ,nullable=false ,length=225 )
	 private String content;

	 @Description(remark="模板标题")
	 @Column(name="title" ,length=100 )
	 private String title;

	 @Description(remark="模板名称")
	 @Column(name="mname" ,nullable=false ,length=50 )
	 private String mname;

	 @Description(remark="业务类型")
	 @Column(name="btype" ,nullable=false )
	 private Integer btype;

	 @Description(remark="消息类型")
	 @Column(name="mtype" ,nullable=false )
	 private Integer mtype;

	 @Description(remark="模板编号")
	 @Column(name="code" ,nullable=false ,length=20 )
	 private String code;


	public MsgTemplateEntity() {

	}

	
	/**
	  * 设置默认接收号码的值
	 * @param 	dpenums	 默认接收号码
	**/
	public void setDpenums(String  dpenums){
		 this.dpenums=dpenums;
 	}

	/**
	  * 获取默认接收号码的值
	 * @return 返回默认接收号码的值
	**/
	public String getDpenums(){
		 return dpenums;
 	}

	/**
	  * 设置模板参数的值
	 * @param 	fparas	 模板参数
	**/
	public void setFparas(String  fparas){
		 this.fparas=fparas;
 	}

	/**
	  * 获取模板参数的值
	 * @return 返回模板参数的值
	**/
	public String getFparas(){
		 return fparas;
 	}

	/**
	  * 设置模板内容的值
	 * @param 	content	 模板内容
	**/
	public void setContent(String  content){
		 this.content=content;
 	}

	/**
	  * 获取模板内容的值
	 * @return 返回模板内容的值
	**/
	public String getContent(){
		 return content;
 	}

	/**
	  * 设置模板标题的值
	 * @param 	title	 模板标题
	**/
	public void setTitle(String  title){
		 this.title=title;
 	}

	/**
	  * 获取模板标题的值
	 * @return 返回模板标题的值
	**/
	public String getTitle(){
		 return title;
 	}

	/**
	  * 设置模板名称的值
	 * @param 	mname	 模板名称
	**/
	public void setMname(String  mname){
		 this.mname=mname;
 	}

	/**
	  * 获取模板名称的值
	 * @return 返回模板名称的值
	**/
	public String getMname(){
		 return mname;
 	}

	/**
	  * 设置业务类型的值
	 * @param 	btype	 业务类型
	**/
	public void setBtype(Integer  btype){
		 this.btype=btype;
 	}

	/**
	  * 获取业务类型的值
	 * @return 返回业务类型的值
	**/
	public Integer getBtype(){
		 return btype;
 	}

	/**
	  * 设置消息类型的值
	 * @param 	mtype	 消息类型
	**/
	public void setMtype(Integer  mtype){
		 this.mtype=mtype;
 	}

	/**
	  * 获取消息类型的值
	 * @return 返回消息类型的值
	**/
	public Integer getMtype(){
		 return mtype;
 	}

	/**
	  * 设置模板编号的值
	 * @param 	code	 模板编号
	**/
	public void setCode(String  code){
		 this.code=code;
 	}

	/**
	  * 获取模板编号的值
	 * @return 返回模板编号的值
	**/
	public String getCode(){
		 return code;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{dpenums,fparas,content,title,mname,btype,mtype,code};
	}

	@Override
	public String[] getFields() {
		return new String[]{"dpenums","fparas","content","title","mname","btype","mtype","code"};
	}

}
