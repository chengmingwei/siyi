package com.cmw.entity;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdBaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 小程序模块表
 * @Author 肖家添
 * @Date 2019/5/13 15:23
 */
@Description(remark="小程序模块表", createDate="2019/5/13 15:23",author="肖家添")
@Entity
@Table(name="ts_SmPgFun")
@SuppressWarnings("serial")
public class SmPgFunEntity extends IdBaseEntity{

	@Description(remark="功能编号")
	@Column(name="code", nullable=false, length=20)
	private String code;

	@Description(remark="名称")
	@Column(name="name", nullable=false, length=30)
	private String name;

	@Description(remark="样式")
	@Column(name="iconCls")
	private String iconCls;

	@Description(remark="动作")
	@Column(name="action")
	private String action;

	@Description(remark="排序")
	@Column(name="orderNo")
	private Integer orderNo;

	@Description(remark="所属功能组; 1:教务,2:销售管理")
	@Column(name="funGroup", nullable=false)
	private Integer funGroup;

	@Description(remark="修改人")
	private UserEntity modifierUser = new UserEntity();

	/**
	 * 功能编号
	 * @Author 肖家添
	 * @Date 2019/5/13 15:28
	 */
	public String getCode() {
		return code;
	}

	/**
	 * 功能编号
	 * @Author 肖家添
	 * @Date 2019/5/13 15:28
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * 名称
	 * @Author 肖家添
	 * @Date 2019/5/13 15:28
	 */
	public String getName() {
		return name;
	}

	/**
	 * 名称
	 * @Author 肖家添
	 * @Date 2019/5/13 15:28
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 样式
	 * @Author 肖家添
	 * @Date 2019/5/13 15:28
	 */
	public String getIconCls() {
		return iconCls;
	}

	/**
	 * 样式
	 * @Author 肖家添
	 * @Date 2019/5/13 15:28
	 */
	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}

	/**
	 * 所属功能组; 1:教务,2:销售管理
	 * @Author 肖家添
	 * @Date 2019/5/13 15:28
	 */
	public Integer getFunGroup() {
		return funGroup;
	}

	/**
	 * 所属功能组; 1:教务,2:销售管理
	 * @Author 肖家添
	 * @Date 2019/5/13 15:28
	 */
	public void setFunGroup(Integer funGroup) {
		this.funGroup = funGroup;
	}

	/**
	 * 动作
	 * @Author 肖家添
	 * @Date 2019/5/14 14:13
	 */
	public String getAction() {
		return action;
	}

	/**
	 * 动作
	 * @Author 肖家添
	 * @Date 2019/5/14 14:13
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * 排序
	 * @Author 肖家添
	 * @Date 2019/5/14 14:13
	 */
	public Integer getOrderNo() {
		return orderNo;
	}

	/**
	 * 排序
	 * @Author 肖家添
	 * @Date 2019/5/14 14:13
	 */
	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	/**
	 * 修改人
	 * @Author 肖家添
	 * @Date 2019/5/14 14:13
	 */
	public UserEntity getModifierUser() {
		return modifierUser;
	}

	/**
	 * 修改人
	 * @Author 肖家添
	 * @Date 2019/5/14 14:14
	 */
	public void setModifierUser(UserEntity modifierUser) {
		this.modifierUser = modifierUser;
	}

	@Override
	public Object[] getDatas() {
		return new Object[]{code, name, iconCls, funGroup, action, orderNo, modifierUser};
	}

	@Override
	public String[] getFields() {
		return new String[]{"code", "name", "iconCls", "funGroup", "action", "orderNo", "modifierUser"};
	}

}