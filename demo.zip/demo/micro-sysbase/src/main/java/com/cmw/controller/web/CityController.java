package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.entity.CityEntity;
import com.cmw.service.inter.CityService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.util.BeanUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;

/**
 * City  ACTION类
 * @author 程明卫
 * @date 2019-03-27 14:37:16
 */
@Description(remark="CityACTION",createDate="2019-03-27 14:37:16",author="程明卫")
@Api(value = "City微服务", description = "#CONTROLLER# 2019-03-27 14:37:16 程明卫")
@RestController
@RequestMapping({"/city"})
public class CityController{
	@Resource(name="cityService")
	private CityService cityService;
	
	 /**
     * 跳转主页面
     * @return
     */
     @ApiOperation("City首页API")
    @GetMapping(value = "/home")
    public JSONObject home(Map<String, Object> params) throws Exception{
       List<CityEntity> list = cityService.getListAll();
       return PageHandler.getJson(list);
    }

    /**
     * 跳转列表页面
     * @param request
     * @param response
     * @return
     */
     @ApiOperation("City列表API")
    @GetMapping(value = "/list")
    public JSONObject list(HttpServletRequest request, HttpServletResponse response){
        List<CityEntity> list = cityService.getListAll();
        return PageHandler.getJson(list);
    }

    /**
     * 跳转详细页面
     * @param id 记录ID
     * @return
     */
    @ApiOperation("根据ID获取City")
    @GetMapping(value = "/info")
    public JSONObject info(@ApiParam("CityID") @RequestParam Long id){
      	if(StringHandler.isValidObj(id)) throw new ServiceException(ErrMsgContant.ID_IS_NULL);
        CityEntity obj = cityService.get(id);
        return PageHandler.getJson(obj);
    }

    /**
     * 保存数据
     * @param params 要保存的数据
     * @return
     */
    @ApiOperation("保存City")
    @PostMapping(value = "/save")
    public JSONObject save(Map<String, Object> params) throws Exception{
        CityEntity entity = BeanUtil.copyValue(CityEntity.class, params);
        cityService.insert(entity);
        return PageHandler.getSuccessJson();
    }

    /**
     * 移除数据
     * @param id 要删除的ID值
     * @return
     */
    @ApiOperation("根据ID删除City")
    @DeleteMapping(value = "/remove")
    public JSONObject remove(@ApiParam("会员ID") @RequestParam Long id) throws Exception{
        cityService.delete(id);
        return PageHandler.getSuccessJson();
    }
	
}
