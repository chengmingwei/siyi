package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import com.cmw.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.SmFunRightEntity;
import com.cmw.entity.SmPgFunEntity;
import org.apache.ibatis.annotations.Mapper;


/**
 *  小程序权限表DAO Mapper接口
 * @Author 肖家添
 * @Date 2019/5/13 15:42
 */
@Description(remark="小程序权限表DAO Mapper接口",createDate="2019/5/13 15:42",author="肖家添")
@Mapper
public interface SmFunRightDao extends GenericDaoInter<SmFunRightEntity, Long>{

}
