package com.cmw.dao;


import com.cmw.core.base.annotation.Description;
import java.util.List;
import java.util.Map;
import com.cmw.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.CustOrderEntity;


/**
 * 订单表  Mapper接口
 * @author 程明卫
 * @date 2020-06-07 15:49:16
 */
@Description(remark="订单表DAO Mapper接口",createDate="2020-06-07 15:49:16",author="程明卫")
@Mapper
public interface CustOrderDao extends GenericDaoInter<CustOrderEntity, Long>{

    /**
     * 获取订单基本信息
     * @return
     */
    public Map<String, Object> getBaseInfo(Map<String,Object> params);

    /**
     * 获取历史签单数量
     * @param param 过滤参数
     * @return 返回记录总数
     * @ 抛出DaoException
     */
    Long getRenewal(Map<String, Object> param);
}
