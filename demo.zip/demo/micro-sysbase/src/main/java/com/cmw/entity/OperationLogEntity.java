package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.entity.IdEntity;

import java.util.Date;


/**
 * 操作日志
 * @author 程明卫
 * @date 2019-03-28 21:49:11
 */
@Description(remark="操作日志实体",createDate="2019-03-28 21:49:11",author="程明卫")
@Entity
@Table(name="ts_OperationLog")
@SuppressWarnings("serial")
public class OperationLogEntity extends IdEntity {
	
	
	 @Description(remark="操作功能")
	 @Column(name="fun" ,nullable=false ,length=50 )
	 private String fun;

	 @Description(remark="操作时间")
	 @Column(name="opTime" )
	 private Date opTime;

	 @Description(remark="主机名")
	 @Column(name="hostName" ,length=100 )
	 private String hostName;

	 @Description(remark="IP地址")
	 @Column(name="ipAddr" ,length=50 )
	 private String ipAddr;

	 @Description(remark="用户ID")
	 @Column(name="userId" ,nullable=false )
	 private Long userId;

	 @Description(remark="设备类型")
	 @Column(name="isource" ,nullable=false )
	 private Integer isource = 1;


	public OperationLogEntity() {

	}

	
	/**
	  * 设置操作功能的值
	 * @param 	fun	 操作功能
	**/
	public void setFun(String  fun){
		 this.fun=fun;
 	}

	/**
	  * 获取操作功能的值
	 * @return 返回操作功能的值
	**/
	public String getFun(){
		 return fun;
 	}

	/**
	  * 设置操作时间的值
	 * @param 	opTime	 操作时间
	**/
	public void setOpTime(Date  opTime){
		 this.opTime=opTime;
 	}

	/**
	  * 获取操作时间的值
	 * @return 返回操作时间的值
	**/
	public Date getOpTime(){
		 return opTime;
 	}

	/**
	  * 设置主机名的值
	 * @param 	hostName	 主机名
	**/
	public void setHostName(String  hostName){
		 this.hostName=hostName;
 	}

	/**
	  * 获取主机名的值
	 * @return 返回主机名的值
	**/
	public String getHostName(){
		 return hostName;
 	}

	/**
	  * 设置IP地址的值
	 * @param 	ipAddr	 IP地址
	**/
	public void setIpAddr(String  ipAddr){
		 this.ipAddr=ipAddr;
 	}

	/**
	  * 获取IP地址的值
	 * @return 返回IP地址的值
	**/
	public String getIpAddr(){
		 return ipAddr;
 	}

	/**
	  * 设置用户ID的值
	 * @param 	userId	 用户ID
	**/
	public void setUserId(Long  userId){
		 this.userId=userId;
 	}

	/**
	  * 获取用户ID的值
	 * @return 返回用户ID的值
	**/
	public Long getUserId(){
		 return userId;
 	}

	/**
	  * 设置设备类型的值
	 * @param 	isource	 设备类型
	**/
	public void setIsource(Integer  isource){
		 this.isource=isource;
 	}

	/**
	  * 获取设备类型的值
	 * @return 返回设备类型的值
	**/
	public Integer getIsource(){
		 return isource;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{fun,opTime,hostName,ipAddr,userId,isource};
	}

	@Override
	public String[] getFields() {
		return new String[]{"fun","opTime","hostName","ipAddr","userId","isource"};
	}

}
