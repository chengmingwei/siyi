package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.back.ErrMsgContant;
import com.cmw.core.base.annotation.Description;
import com.cmw.core.base.exception.ServiceException;
import com.cmw.util.BeanUtil;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cmw.entity.ProvinceEntity;
import com.cmw.service.inter.ProvinceService;


/**
 * 省份表  ACTION类
 * @author 程明卫
 * @date 2019-03-27 13:59:56
 */
@Description(remark="省份表ACTION",createDate="2019-03-27 13:59:56",author="程明卫")
@Api(value = "省份表微服务", description = "#CONTROLLER# 2019-03-27 13:59:56 程明卫")
@RestController
@RequestMapping({"/province"})
public class ProvinceController extends BaseAction{

	@Resource(name="provinceService")
	private ProvinceService provinceService;

	/**
	 *  获取全国行政地区的JSON数据
     *  注意：不推荐动态查询使用，数据量非常大
	 * @Author 肖家添
	 * @Date 2019/5/14 18:27
	 */
	@ApiOperation("获取全国省份城市地区的数据")
    @GetMapping(value = "/getChinaArea")
    public JSONObject getChinaArea() {
	    try{
            Map<String, Object> params = new HashMap<>();

            params.put("isEnabled", 1);

            List chinaArea = provinceService.getListMap(params);

            return PageHandler.getJson(chinaArea);
        }catch (Exception ex){
	        return fail(ex);
        }
    }

	/**
	 *  根据指定的文件名初始化省市区数据
	 * @Author cmw
	 * @Date 2020/09/02 18:30
	 * @param  filePath 初始化基础数据文件地址
	 */
	@ApiOperation("获取全国省份城市地区的数据")
	@GetMapping(value = "/init-datas")
	public JSONObject initDatas(@RequestParam String filePath) {
		try{
			provinceService.initDatas(filePath);
			return PageHandler.getSuccessJson();
		}catch (Exception ex){
			return fail(ex);
		}
	}

}
