package com.cmw.controller.web;


import com.alibaba.fastjson.JSONObject;
import com.cmw.core.base.annotation.Description;
import com.cmw.entity.SmFunRightEntity;
import com.cmw.interceptor.LoginInterceptor;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.SmFunRightService;
import com.cmw.util.PageHandler;
import com.cmw.util.StringHandler;
import com.cmw.util.UserUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 小程序权限表 ACTION类
 * @Author 肖家添
 * @Date 2019/5/13 15:42
 */
@Description(remark="小程序权限表 Action",createDate="2019/5/13 15:42",author="肖家添")
@Api(value = "小程序权限表 ACTION类", description = "2019/5/13 15:42 肖家添")
@RestController
@RequestMapping({"/smFunRight"})
public class SmFunRightController extends BaseAction {

    @Resource(name = "smFunRightService")
    private SmFunRightService smFunRightService;

    /**
     * 获取模块数据权限
     * @Author 肖家添
     * @Date 2019/5/14 12:04
     */
    @ApiOperation("获取模块数据权限")
    @PostMapping("/getSmFunRight")
    public JSONObject getSmFunRight(@RequestParam Map<String, Object> params){
        try{
            params.put("isEnabled", "1");

            List smFunRightList = smFunRightService.getList(params);

            return PageHandler.getJson(smFunRightList);
        }catch (Exception ex){
            return fail(ex);
        }
    }

    /**
     * 保存角色菜单权限
     * @Author 肖家添
     * @Date 2019/5/10 11:03
     */
    @ApiOperation("保存模块权限")
    @PostMapping(value = "/save")
    public JSONObject save(@RequestParam String uType, HttpServletRequest request) {
        boolean success = true;
        String msg = "";

        try {
            String[] funId = request.getParameterValues("funId");

            if(!StringHandler.isValidObj(uType)){
                success = false;
                msg = "请选择角色";

            }else{
                Map<String, Object> deleteParams = new HashMap<>();

                deleteParams.put("uType", uType);

                smFunRightService.deleteByPars(deleteParams);

                Long totals = smFunRightService.getTotals(deleteParams);

                if(totals == 0){
                    if(StringHandler.isValidObj(funId)){
                        List<SmFunRightEntity> rightList = new ArrayList<>();

                        UserModel loginUser = LoginInterceptor.getLoginUser();

                        for (int i = 0; i < funId.length; i++) {
                            SmFunRightEntity sfRight = new SmFunRightEntity();

                            sfRight.setUtype(Integer.parseInt(uType));
                            sfRight.setFunId(Long.parseLong(funId[i]));

                            UserUtil.setCreateInfo(loginUser, sfRight);

                            rightList.add(sfRight);
                        }

                        smFunRightService.batchInsert(rightList);
                    }

                    success = true;
                }else{
                    success = false;

                    msg = "数据未完全清除";
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();

            success = false;
            msg = "系统异常";
        }

        if (success)
            return PageHandler.getSuccessJson();
        else
            return PageHandler.getFailureJson(msg);
    }

}
