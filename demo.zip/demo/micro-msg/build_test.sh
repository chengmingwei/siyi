##!/usr/bin/env bash
#env='test.20200310.b'
##编译打包
#mvn clean package -Dmaven.test.skip=true -U
##删除上次的镜像
#docker rmi 47.107.135.212:8082/springcloud/micro-insure-management:$env
##编译成Docker 镜像文件
#docker build -t 47.107.135.212:8082/springcloud/micro-insure-management:$env .
##设置在线镜像TAG 标签
#docker tag 47.107.135.212:8082/springcloud/micro-insure-management:$env 47.107.135.212:8082/springcloud/micro-insure-management:$env
## PUSH 到 网易镜像中心
#docker push 47.107.135.212:8082/springcloud/micro-insure-management:$env
#docker rmi 47.107.135.212:8082/springcloud/micro-insure-management:$env
#docker rmi 47.107.135.212:8082/springcloud/micro-insure-management:$env


#!/usr/bin/env bash
env='msg.202000728'
#编译打包
mvn clean package -Dmaven.test.skip=true -U
#删除上次的镜像
docker rmi registry.cn-shenzhen.aliyuncs.com/my-zh/mt-zh:$env
#编译成Docker 镜像文件
docker build -t registry.cn-shenzhen.aliyuncs.com/my-zh/mt-zh:$env .
#设置在线镜像TAG 标签
docker tag registry.cn-shenzhen.aliyuncs.com/my-zh/mt-zh:$env registry.cn-shenzhen.aliyuncs.com/my-zh/mt-zh:$env
# PUSH 到 网易镜像中心
docker push registry.cn-shenzhen.aliyuncs.com/my-zh/mt-zh:$env
docker rmi registry.cn-shenzhen.aliyuncs.com/my-zh/mt-zh:$env


