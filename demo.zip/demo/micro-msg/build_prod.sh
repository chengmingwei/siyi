##!/usr/bin/env bash
#env="prod.20191230.A"
##编译打包
#mvn clean package -Dmaven.test.skip=true -U
##删除上次的镜像
#docker rmi nexus.xiaobaibao.com:8082/springcloud-prod/micro-msg:$env
##编译成Docker 镜像文件
#docker build -t nexus.xiaobaibao.com:8082/springcloud-prod/micro-msg:$env .
##设置在线镜像TAG 标签
#docker tag nexus.xiaobaibao.com:8082/springcloud-prod/micro-msg:$env nexus.xiaobaibao.com:8082/springcloud-prod/micro-msg:$env
## PUSH 到 米兔 Docker 私有镜像中心
#docker push nexus.xiaobaibao.com:8082/springcloud-prod/micro-msg:$env
#docker rmi nexus.xiaobaibao.com:8082/springcloud-prod/micro-msg:$env
#docker rmi nexus.xiaobaibao.com:8082/springcloud-prod/micro-msg:$env



##!/usr/bin/env bash
#env='micro-msg-prod.20200430'
#alu='registry.cn-shenzhen.aliyuncs.com'
##编译打包
#mvn clean package -Dmaven.test.skip=true -U
##删除上次的镜像
#docker rmi $alu/mt-saas/myrcib-saasi:$env
##编译成Docker 镜像文件
#docker build -t $alu/mt-saas/myrcib-saasi:$env .
##设置在线镜像TAG 标签
#docker tag $alu/mt-saas/myrcib-saasi:$env $alu/mt-saas/myrcib-saasi:$env
## PUSH 到 米兔镜像中心
#docker push $alu/mt-saas/myrcib-saasi:$env
## PUSH 到 米兔镜像中心
#docker rmi $alu/mt-saas/myrcib-saasi:$env




# 米兔阿里云集群镜像库
#!/usr/bin/env bash
env='micro-msg.20200511'
alu='registry.cn-shenzhen.aliyuncs.com/mtswarm/mt-prod'
#编译打包
mvn clean package -Dmaven.test.skip=true -U
#删除上次的镜像
docker rmi $alu:$env
#编译成Docker 镜像文件
docker build -t $alu:$env .
#设置在线镜像TAG 标签
docker tag $alu:$env $alu:$env
# PUSH 到 米兔镜像中心
docker push $alu:$env
# 删除本地镜像
docker rmi $alu:$env