package com.cmw.listener;

import com.cmw.constant.GlobalConstant;
import com.cmw.model.back.UserModel;
import com.cmw.service.inter.MsgService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 邮件通知AMQ监听
 * @Author 肖家添
 * @Date 2019/10/22 19:16
 */
@Component
@Slf4j
public class EmailListener {

    //-- 消息 Service
    @Autowired
    private MsgService msgService;

    @RabbitListener(bindings = @QueueBinding(
            exchange = @Exchange(value = GlobalConstant.AMQP_EXCHANGE_MSG_EMAIL_KEY, ignoreDeclarationExceptions = "true"),
            key = {GlobalConstant.AMQP_ROUTINGKEY_MSG_EMAIL_KEY},
            value = @Queue(value = GlobalConstant.AMQP_QUEUE_MSG_EMAIL_KEY, durable = "true")
    ))
    public void listenEmail(Map<String, Object> msg){
        try{
            msgService.sendEmail(msg);
        }catch (Exception ex){
            log.error("邮件通知AMQ处理失败！");

            ex.printStackTrace();
        }
    }
}
