package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;
import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.base.entity.IdEntity;


/**
 * 好友群
 * @author 程明卫
 * @date 2020-03-19 20:06:45
 */
@Description(remark="好友群实体",createDate="2020-03-19 20:06:45",author="程明卫")
@Entity
@Table(name="IM_FriendGroup")
@SuppressWarnings("serial")
public class FriendGroupEntity extends IdEntity {
	
	
	 @Description(remark="创建日期")
	 @Column(name="createTime" ,nullable=false )
	 private Date createTime;

	 @Description(remark="可用标志")
	 @Column(name="isenabled" ,nullable=false )
	 private Byte isenabled = 1;

	 @Description(remark="审批时间")
	 @Column(name="auditTime" )
	 private Date auditTime;

	 @Description(remark="备注")
	 @Column(name="remark" ,length=200 )
	 private String remark;

	 @Description(remark="审批状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="群名称")
	 @Column(name="groupName" ,nullable=false ,length=100 )
	 private String groupName;

	 @Description(remark="创建人ID")
	 @Column(name="creatorId" ,nullable=false )
	 private String creatorId;

	 @Description(remark="本人类型")
	 @Column(name="myType" ,nullable=false )
	 private Integer myType;


	public FriendGroupEntity() {

	}

	
	/**
	  * 设置创建日期的值
	 * @param 	createTime	 创建日期
	**/
	public void setCreateTime(Date  createTime){
		 this.createTime=createTime;
 	}

	/**
	  * 获取创建日期的值
	 * @return 返回创建日期的值
	**/
	public Date getCreateTime(){
		 return createTime;
 	}

	/**
	  * 设置可用标志的值
	 * @param 	isenabled	 可用标志
	**/
	public void setIsenabled(Byte  isenabled){
		 this.isenabled=isenabled;
 	}

	/**
	  * 获取可用标志的值
	 * @return 返回可用标志的值
	**/
	public Byte getIsenabled(){
		 return isenabled;
 	}

	/**
	  * 设置审批时间的值
	 * @param 	auditTime	 审批时间
	**/
	public void setAuditTime(Date  auditTime){
		 this.auditTime=auditTime;
 	}

	/**
	  * 获取审批时间的值
	 * @return 返回审批时间的值
	**/
	public Date getAuditTime(){
		 return auditTime;
 	}

	/**
	  * 设置备注的值
	 * @param 	remark	 备注
	**/
	public void setRemark(String  remark){
		 this.remark=remark;
 	}

	/**
	  * 获取备注的值
	 * @return 返回备注的值
	**/
	public String getRemark(){
		 return remark;
 	}

	/**
	  * 设置审批状态的值
	 * @param 	xstatus	 审批状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取审批状态的值
	 * @return 返回审批状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置群名称的值
	 * @param 	groupName	 群名称
	**/
	public void setGroupName(String  groupName){
		 this.groupName=groupName;
 	}

	/**
	  * 获取群名称的值
	 * @return 返回群名称的值
	**/
	public String getGroupName(){
		 return groupName;
 	}

	/**
	  * 设置创建人ID的值
	 * @param 	creatorId	 创建人ID
	**/
	public void setCreatorId(String  creatorId){
		 this.creatorId=creatorId;
 	}

	/**
	  * 获取创建人ID的值
	 * @return 返回创建人ID的值
	**/
	public String getCreatorId(){
		 return creatorId;
 	}

	/**
	  * 设置本人类型的值
	 * @param 	myType	 本人类型
	**/
	public void setMyType(Integer  myType){
		 this.myType=myType;
 	}

	/**
	  * 获取本人类型的值
	 * @return 返回本人类型的值
	**/
	public Integer getMyType(){
		 return myType;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{createTime,isenabled,auditTime,remark,xstatus,groupName,creatorId,myType};
	}

	@Override
	public String[] getFields() {
		return new String[]{"createTime","isenabled","auditTime","remark","xstatus","groupName","creatorId","myType"};
	}

}
