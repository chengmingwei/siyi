package com.cmw.client;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 * 会员微服务 FeignClient
 * @Author 肖家添
 * @Date 2019/8/28 10:58
 */
@FeignClient(value = "micro-member")
@Component
public interface MemberClient {

    /**
     *  获取小白客服作为经纪人服务一对一客户
     * @Author cmw
     * @Date 2020/05/06 21:33
     */
    @GetMapping("/vip/feign/getMyServicer")
    JSONObject memberVip_getMyServicer(@RequestParam(value = "memberIds") String memberIds,@RequestParam(value = "feignKey") String feignKey);

    /**
     *  根据多个会员ID获取会员基本信息
     * @Author cmw
     * @Date 2020/03/25 12:38
     */
    @PostMapping("/member/feign/getBaseInfoList")
    JSONObject member_getBaseInfoList(@RequestParam(value = "memberIds") String memberIds, @RequestParam(value = "feignKey") String feignKey);

    /**
     * 会员登录
     * @Author 肖家添
     * @Date 2019/8/28 11:00
     */
    @PostMapping("/member/getMemberByAccount")
    JSONObject getMemberByAccount(
            //-- 账户名称
            @RequestParam String account,
            //-- Feign专用标识
            @RequestParam boolean isFeign
    );
    /**
     * [会员] -> 获取单个会员
     * @Author 肖家添
     * @Date 2019/9/20 15:43
     */
    @PostMapping("/member/getUserAudit")
    JSONObject member_getUserAudit(@RequestParam Long id, @RequestParam String feignKey);

    /**
     * 获计划书邮件通知所需数据
     * @Author: tanhanxiang
     * @Date: 2019/12/18 18:10
     */
    @PostMapping("/proposalrecordinfo/getProposalRecord")
    JSONObject getProposalData(@RequestParam Long id, @RequestParam String feignKey);

    @PostMapping("/proposalsendinfo/updateMailStatus")
    JSONObject updateMailStatus(@RequestParam Long id,@RequestParam Integer mailStatus,@RequestParam String feignKey);

    @PostMapping("/proposalrecordinfo/updateProposalDoc")
    JSONObject updateProposalDoc(@RequestParam Long id, @RequestParam String docUrl, @RequestParam String feignKey);

    @ApiOperation("创建交易记录")
    @PostMapping("/transferrecords/create")
    JSONObject transferRecords_create(
            //-- 输入的值
            @RequestParam Map<String, Object> map,
            //-- Feign Key
            @RequestParam String feignKey);
}
