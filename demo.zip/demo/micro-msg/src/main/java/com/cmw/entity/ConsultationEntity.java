package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;
import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.base.entity.IdEntity;



/**
 * 实时咨询
 * @author 程明卫
 * @date 2020-03-19 20:16:02
 */
@Description(remark="实时咨询实体",createDate="2020-03-19 20:16:02",author="程明卫")
@Entity
@Table(name="IM_Consultation")
@SuppressWarnings("serial")
public class ConsultationEntity extends IdEntity {
	
	
	 @Description(remark="创建日期")
	 @Column(name="createTime" ,nullable=false )
	 private Date createTime;

	 @Description(remark="可用标志")
	 @Column(name="isenabled" ,nullable=false )
	 private Byte isenabled = 1;

	 @Description(remark="备注")
	 @Column(name="remark" ,length=200 )
	 private String remark;

	 @Description(remark="咨询状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="结束时间")
	 @Column(name="endTime" ,length=100 )
	 private String endTime;

	 @Description(remark="发起时间")
	 @Column(name="startTime" ,nullable=false )
	 private Date startTime;

	 @Description(remark="快照消息ID")
	 @Column(name="msgId" )
	 private Long msgId;

	 @Description(remark="业务ID")
	 @Column(name="formId" )
	 private Long formId;

	 @Description(remark="业务类型")
	 @Column(name="bussType" ,nullable=false )
	 private Integer bussType;

	 @Description(remark="接收人ID")
	 @Column(name="receiver" ,nullable=false ,length=100 )
	 private String receiver;

	@Description(remark="原接收人ID")
	@Column(name="oldReceiver" ,nullable=true ,length=100 )
	private String oldReceiver;

	 @Description(remark="发起人ID")
	 @Column(name="sender" ,nullable=false ,length=100 )
	 private String sender;

	@Description(remark="咨询服务费")
	@Column(name="samount" ,nullable=false ,length=100 )
	private BigDecimal samount = new BigDecimal("0.00");

	@Description(remark="支付状态")
	@Column(name="pstatus" ,nullable=false )
	private Integer pstatus = 0;

	@Description(remark="支付时间")
	@Column(name="payTime" )
	private Date payTime;


	public ConsultationEntity() {

	}

	/**
	 * 获取原接收人ID
	 * @return 返回原接收人ID的值
	 **/
	public String getOldReceiver() {
		return oldReceiver;
	}

	/**
	 * 设置原接收人ID的值
	 * @param 	oldReceiver	 原接收人ID
	 **/
	public void setOldReceiver(String oldReceiver) {
		this.oldReceiver = oldReceiver;
	}

	/**
	 * 获取咨询服务费的值
	 * @return 返回咨询服务费的值
	 **/
	public BigDecimal getSamount() {
		return samount;
	}

	/**
	 * 设置咨询服务费的值
	 * @param 	samount	 咨询服务费
	 **/
	public void setSamount(BigDecimal samount) {
		this.samount = samount;
	}



	/**
	  * 设置创建日期的值
	 * @param 	createTime	 创建日期
	**/
	public void setCreateTime(Date  createTime){
		 this.createTime=createTime;
 	}

	/**
	  * 获取创建日期的值
	 * @return 返回创建日期的值
	**/
	public Date getCreateTime(){
		 return createTime;
 	}

	/**
	  * 设置可用标志的值
	 * @param 	isenabled	 可用标志
	**/
	public void setIsenabled(Byte  isenabled){
		 this.isenabled=isenabled;
 	}

	/**
	  * 获取可用标志的值
	 * @return 返回可用标志的值
	**/
	public Byte getIsenabled(){
		 return isenabled;
 	}

	/**
	  * 设置备注的值
	 * @param 	remark	 备注
	**/
	public void setRemark(String  remark){
		 this.remark=remark;
 	}

	/**
	  * 获取备注的值
	 * @return 返回备注的值
	**/
	public String getRemark(){
		 return remark;
 	}

	/**
	  * 设置咨询状态的值
	 * @param 	xstatus	 咨询状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取咨询状态的值
	 * @return 返回咨询状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置结束时间的值
	 * @param 	endTime	 结束时间
	**/
	public void setEndTime(String  endTime){
		 this.endTime=endTime;
 	}

	/**
	  * 获取结束时间的值
	 * @return 返回结束时间的值
	**/
	public String getEndTime(){
		 return endTime;
 	}

	/**
	  * 设置发起时间的值
	 * @param 	startTime	 发起时间
	**/
	public void setStartTime(Date  startTime){
		 this.startTime=startTime;
 	}

	/**
	  * 获取发起时间的值
	 * @return 返回发起时间的值
	**/
	public Date getStartTime(){
		 return startTime;
 	}

	/**
	  * 设置快照消息ID的值
	 * @param 	msgId	 快照消息ID
	**/
	public void setMsgId(Long  msgId){
		 this.msgId=msgId;
 	}

	/**
	  * 获取快照消息ID的值
	 * @return 返回快照消息ID的值
	**/
	public Long getMsgId(){
		 return msgId;
 	}

	/**
	  * 设置业务ID的值
	 * @param 	formId	 业务ID
	**/
	public void setFormId(Long  formId){
		 this.formId=formId;
 	}

	/**
	  * 获取业务ID的值
	 * @return 返回业务ID的值
	**/
	public Long getFormId(){
		 return formId;
 	}

	/**
	  * 设置业务类型的值
	 * @param 	bussType	 业务类型
	**/
	public void setBussType(Integer  bussType){
		 this.bussType=bussType;
 	}

	/**
	  * 获取业务类型的值
	 * @return 返回业务类型的值
	**/
	public Integer getBussType(){
		 return bussType;
 	}

	/**
	  * 设置接收人ID的值
	 * @param 	receiver	 接收人ID
	**/
	public void setReceiver(String  receiver){
		 this.receiver=receiver;
 	}

	/**
	  * 获取接收人ID的值
	 * @return 返回接收人ID的值
	**/
	public String getReceiver(){
		 return receiver;
 	}

	/**
	  * 设置发起人ID的值
	 * @param 	sender	 发起人ID
	**/
	public void setSender(String  sender){
		 this.sender=sender;
 	}

	/**
	  * 获取发起人ID的值
	 * @return 返回发起人ID的值
	**/
	public String getSender(){
		 return sender;
 	}

	/**
	 * 设置支付状态的值
	 * @param 	pstatus	 支付状态
	 **/
	public void setPstatus(Integer pstatus) {
		this.pstatus = pstatus;
	}

	/**
	 * 获取支付状态的值
	 * @return 返回支付状态的值
	 **/
	public Integer getPstatus() {
		return pstatus;
	}

	/**
	 * 设置支付时间的值
	 * @param 	payTime	 支付时间
	 **/
	public void setPayTime(Date payTime) {
		this.payTime = payTime;
	}

	/**
	 * 获取支付时间的值
	 * @return 返回支付时间的值
	 **/
	public Date getPayTime() {
		return payTime;
	}

	@Override
	public Object[] getDatas() {
		return new Object[]{createTime,isenabled,remark,
				xstatus,endTime,startTime,
				msgId,formId,bussType,
				receiver,oldReceiver,sender,samount,
				pstatus,payTime};
	}

	@Override
	public String[] getFields() {
		return new String[]{"createTime","isenabled","remark",
				"xstatus","endTime","startTime",
				"msgId","formId","bussType",
				"receiver","oldReceiver","sender","samount",
				"pstatus","payTime"};
	}

}
