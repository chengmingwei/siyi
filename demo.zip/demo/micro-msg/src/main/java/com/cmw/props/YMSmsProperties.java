package com.cmw.props;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * [亿美] -> 短信接口参数
 * @Author 肖家添
 * @Date 2019/8/27 18:09
 */
@Configuration
@RefreshScope
@Data
public class YMSmsProperties {

    /**
     * 商户号
     */
    @Value("${micro.sms.softwareSerialNo}")
    private String softwareSerialNo;

    /**
     * 密匙
     */
    @Value("${micro.sms.key}")
    private String key;

    /**
     * 密码
     */
    @Value("${micro.sms.password}")
    private String password;

}
