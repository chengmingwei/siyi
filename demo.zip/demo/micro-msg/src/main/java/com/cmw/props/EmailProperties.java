package com.cmw.props;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * 邮件属性
 * @Author 肖家添
 * @Date 2019/10/22 20:23
 */
@Configuration
@RefreshScope
@Data
public class EmailProperties {

    /**
     * 账户名
     */
    @Value("${spring.mail.username}")
    private String username;

    /**
     * 发送邮件人名称
     */
    private String sendEmailUserName = "小白保险网";

}
