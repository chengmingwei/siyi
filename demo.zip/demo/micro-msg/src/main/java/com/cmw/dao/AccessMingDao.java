package com.cmw.dao;


import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.AccessMingEntity;
import org.springframework.stereotype.Component;


/**
 * 访问明细表  Mapper接口
 * @author 程明卫
 * @date 2020-07-17 15:08:07
 */
@Description(remark="访问明细表DAO Mapper接口",createDate="2020-07-17 15:08:07",author="程明卫")
@Component
@Mapper
public interface AccessMingDao extends GenericDaoInter<AccessMingEntity, Long>{

}
