package com.cmw.listener;

import com.cmw.constant.GlobalConstant;
import com.cmw.model.global.RequestDataModel;
import com.cmw.service.inter.AccessStatisticsService;
import com.cmw.service.inter.ConsultationService;
import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.util.SHashMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * PV/UV/IP 统计持久化监听器
 * @author cmw
 * @date 2020-07-29 15:59
 */
@Description(remark = "PV/UV/IP 统计持久化监听器")
@Slf4j
@Component
public class AccessStatisticsListener {

    @Autowired
    private AccessStatisticsService accessStatisticsService;

    @RabbitListener(bindings = @QueueBinding(
            exchange = @Exchange(value = GlobalConstant.AMQP_EXCHANGE_PERSIST_STATISTICS_KEY, ignoreDeclarationExceptions = "true"),
            key = {GlobalConstant.AMQP_ROUTINGKEY_PERSIST_STATISTICS_KEY},
            value = @Queue(value = GlobalConstant.AMQP_QUEUE_PERSIST_STATISTICS_KEY, durable = "true")
    ))
    public void commomSendMsg(Map<String,Object> map){
        try{
            accessStatisticsService.doComplexBusss(new SHashMap<>(map));
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    @RabbitListener(bindings = @QueueBinding(
            exchange = @Exchange(value = GlobalConstant.AMQP_EXCHANGE_ACCESS_STATISTICS_KEY, ignoreDeclarationExceptions = "true"),
            key = {GlobalConstant.AMQP_ROUTINGKEY_ACCESS_STATISTICS_KEY},
            value = @Queue(value = GlobalConstant.AMQP_QUEUE_ACCESS_STATISTICS_KEY, durable = "true")
    ))
    public void send(RequestDataModel requestDataModel){
        try{
            accessStatisticsService.execute(requestDataModel);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}
