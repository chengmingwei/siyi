package com.cmw.dao;


import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.FriendGroupEntity;
import org.springframework.stereotype.Component;


/**
 * 好友群  Mapper接口
 * @author 程明卫
 * @date 2020-03-19 20:06:45
 */
@Description(remark="好友群DAO Mapper接口",createDate="2020-03-19 20:06:45",author="程明卫")
@Component
@Mapper
public interface FriendGroupDao extends GenericDaoInter<FriendGroupEntity, Long>{

}
