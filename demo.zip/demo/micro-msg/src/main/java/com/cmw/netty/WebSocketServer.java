package com.cmw.netty;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @Description: 实现一个支持WebSocket协议请求的服务器
 * @Auth chengmingwei
 * @Date 2019-09-27 20:40
 */
//@Component
@Slf4j
public class WebSocketServer {

    private static class SingletionWebSocketServer{
        static final WebSocketServer INSTANCE = new WebSocketServer();
    }

    public static final  WebSocketServer getInstance(){
        return SingletionWebSocketServer.INSTANCE;
    }

    private EventLoopGroup mainGroup = null;
    private EventLoopGroup subGroup = null;
    private ServerBootstrap serverBootstrap = null;
    private ChannelFuture future = null;
    private  static final int SERVER_PORT = 8088;
    public WebSocketServer() {
        mainGroup = new NioEventLoopGroup();
        subGroup = new NioEventLoopGroup();
        serverBootstrap = new ServerBootstrap();
        // netty服务器的创建, ServerBootstrap 是一个启动类
        serverBootstrap.group(mainGroup, subGroup)  // 设置主从线程组
                .channel(NioServerSocketChannel.class)// 设置nio的双向通道
                .childHandler(new WebSocketInitialzer()); // 子处理器，用于处理subGroup
    }

    public void start(){
        future = serverBootstrap.bind(SERVER_PORT);
        log.info("Netty WebSocketServer listenering port : "+SERVER_PORT+" and start finish ... ");
    }
}
