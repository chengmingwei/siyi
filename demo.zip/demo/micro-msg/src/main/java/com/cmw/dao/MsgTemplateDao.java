package com.cmw.dao;


import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.ssm.dao.GenericDaoInter;
import com.cmw.entity.MsgTemplateEntity;
import org.apache.ibatis.annotations.Mapper;


/**
 * 消息模板表  Mapper接口
 * @author 程明卫
 * @date 2019-04-10 23:14:25
 */
@Description(remark="消息模板表DAO Mapper接口",createDate="2019-04-10 23:14:25",author="程明卫")
@Mapper
public interface MsgTemplateDao extends GenericDaoInter<MsgTemplateEntity, Long>{

}
