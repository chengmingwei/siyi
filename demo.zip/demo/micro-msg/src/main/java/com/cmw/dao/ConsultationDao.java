package com.cmw.dao;


import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.ConsultationEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * 实时咨询  Mapper接口
 * @author 程明卫
 * @date 2020-03-19 20:16:02
 */
@Description(remark="实时咨询DAO Mapper接口",createDate="2020-03-19 20:16:02",author="程明卫")
@Component
@Mapper
public interface ConsultationDao extends GenericDaoInter<ConsultationEntity, Long>{

    /**
     * 根据状态获取一对一咨询数据
     * @param params
     * @return
     */
    List<Map<String,Object>> getListByXstatus(Map<String,Object> params);

    Long getListPageTotal(Map<String, Object> params);

    List<Map<String, Object>> getListPage(Map<String, Object> params);
}
