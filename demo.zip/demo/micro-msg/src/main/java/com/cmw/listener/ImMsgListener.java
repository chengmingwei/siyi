package com.cmw.listener;

import com.cmw.constant.GlobalConstant;
import com.cmw.netty.vo.MsgPacket;
import com.cmw.service.inter.MessageService;
import com.cmw.service.inter.MsgService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.cmw.netty.enums.MsgActionEnum.*;

/**
 * @Author: chengmingwei
 * @Time: 2019-05-15 14:34
 * @Feature:实时WebSocket消息服务监听器
 */
@Slf4j
@Component
class ImMsgListener {

    @RabbitListener(bindings = @QueueBinding(
            exchange = @Exchange(value = GlobalConstant.AMQP_EXCHANGE_IMMSG_KEY, ignoreDeclarationExceptions = "true"),
            key = {GlobalConstant.AMQP_ROUTINGKEY_IMMSG_KEY},
            value = @Queue(value = GlobalConstant.AMQP_QUEUE_IMMSG_KEY, durable = "true")
    ))
    public void sendMsg(Map<String,Object> msg){
        try{
            send(msg);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    @Autowired
    private MessageService messageService;

    private void send(Map<String,Object> msg){
        if (msg == null || msg.size() <= 0){
            log.info("ImMsgListener.sendMsg 消息参数为空，系统将不发送任何消息...");
            return;
        }
        MsgPacket dataContent = (MsgPacket)msg.get("dataContent");
        Integer action = dataContent.getAction();
        log.info("action = "+action);
        if(null == action){
            log.error("action 不能为空！");
            return;
        }

        if(CHAT.type.equals(action)){
            messageService.doComplexBusss(dataContent);
        }else if((SIGNED.type.equals(action) || SIGNED_SINGLE.type.equals(action))){    //消息签收（批量/单笔）
            messageService.singedMessages(dataContent);
        }
    }
}
