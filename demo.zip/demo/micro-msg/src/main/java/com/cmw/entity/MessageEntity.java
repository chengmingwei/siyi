package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;
import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.base.entity.IdEntity;


/**
 * IM消息
 * @author 程明卫
 * @date 2020-03-19 20:03:56
 */
@Description(remark="IM消息实体",createDate="2020-03-19 20:03:56",author="程明卫")
@Entity
@Table(name="IM_Message")
@SuppressWarnings("serial")
public class MessageEntity extends IdEntity {
	@Description(remark="uuid字段")
	@Column(name="uuid")
	private String uuid;  //标识该消息的uuid字段

	 @Description(remark="创建日期")
	 @Column(name="createTime" ,nullable=false )
	 private Date createTime;

	 @Description(remark="可用标志")
	 @Column(name="isenabled" ,nullable=false )
	 private Byte isenabled = 1;

	 @Description(remark="签收状态")
	 @Column(name="rstatus" ,nullable=false )
	 private Integer rstatus = 0;

	 @Description(remark="内容")
	 @Column(name="content" ,length=1000 )
	 private String content;

	 @Description(remark="扩展字段")
	 @Column(name="extendField" ,length=200 )
	 private String extendField;

	 @Description(remark="业务类型")
	 @Column(name="bussType" ,nullable=false )
	 private Integer bussType = 0;

	 @Description(remark="接收者")
	 @Column(name="receiver" ,nullable=false ,length=100 )
	 private String receiver = "-1";

	 @Description(remark="发送者")
	 @Column(name="sender" ,nullable=false ,length=100 )
	 private String sender = "-1";

	 @Description(remark="消息发送人类型")
	 @Column(name="rtype" ,nullable=false )
	 private Integer rtype;


	public MessageEntity() {

	}

	/**
	 * 获取uuid字段的值
	 * @return 返回uuid字段的值
	 **/
	public String getUuid() {
		return uuid;
	}

	/**
	 * 设置uuid字段的值
	 * @param 	uuid	 uuid字段
	 **/
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	/**
	  * 设置创建日期的值
	 * @param 	createTime	 创建日期
	**/
	public void setCreateTime(Date  createTime){
		 this.createTime=createTime;
 	}

	/**
	  * 获取创建日期的值
	 * @return 返回创建日期的值
	**/
	public Date getCreateTime(){
		 return createTime;
 	}

	/**
	  * 设置可用标志的值
	 * @param 	isenabled	 可用标志
	**/
	public void setIsenabled(Byte  isenabled){
		 this.isenabled=isenabled;
 	}

	/**
	  * 获取可用标志的值
	 * @return 返回可用标志的值
	**/
	public Byte getIsenabled(){
		 return isenabled;
 	}

	/**
	  * 设置签收状态的值
	 * @param 	rstatus	 签收状态
	**/
	public void setRstatus(Integer  rstatus){
		 this.rstatus=rstatus;
 	}

	/**
	  * 获取签收状态的值
	 * @return 返回签收状态的值
	**/
	public Integer getRstatus(){
		 return rstatus;
 	}

	/**
	  * 设置内容的值
	 * @param 	content	 内容
	**/
	public void setContent(String  content){
		 this.content=content;
 	}

	/**
	  * 获取内容的值
	 * @return 返回内容的值
	**/
	public String getContent(){
		 return content;
 	}

	/**
	  * 设置扩展字段的值
	 * @param 	extendField	 扩展字段
	**/
	public void setExtendField(String  extendField){
		 this.extendField=extendField;
 	}

	/**
	  * 获取扩展字段的值
	 * @return 返回扩展字段的值
	**/
	public String getExtendField(){
		 return extendField;
 	}

	/**
	  * 设置业务类型的值
	 * @param 	bussType	 业务类型
	**/
	public void setBussType(Integer  bussType){
		 this.bussType=bussType;
 	}

	/**
	  * 获取业务类型的值
	 * @return 返回业务类型的值
	**/
	public Integer getBussType(){
		 return bussType;
 	}

	/**
	  * 设置接收者的值
	 * @param 	receiver	 接收者
	**/
	public void setReceiver(String  receiver){
		 this.receiver=receiver;
 	}

	/**
	  * 获取接收者的值
	 * @return 返回接收者的值
	**/
	public String getReceiver(){
		 return receiver;
 	}

	/**
	  * 设置发送者的值
	 * @param 	sender	 发送者
	**/
	public void setSender(String  sender){
		 this.sender=sender;
 	}

	/**
	  * 获取发送者的值
	 * @return 返回发送者的值
	**/
	public String getSender(){
		 return sender;
 	}

	/**
	  * 设置消息发送人类型的值
	 * @param 	rtype	 消息发送人类型
	**/
	public void setRtype(Integer  rtype){
		 this.rtype=rtype;
 	}

	/**
	  * 获取消息发送人类型的值
	 * @return 返回消息发送人类型的值
	**/
	public Integer getRtype(){
		 return rtype;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{createTime,isenabled,rstatus,content,extendField,bussType,receiver,sender,rtype};
	}

	@Override
	public String[] getFields() {
		return new String[]{"createTime","isenabled","rstatus","content","extendField","bussType","receiver","sender","rtype"};
	}

}
