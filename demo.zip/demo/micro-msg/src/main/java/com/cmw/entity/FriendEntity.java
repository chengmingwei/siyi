package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;
import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.base.entity.IdEntity;

/**
 * 好友联系人
 * @author 程明卫
 * @date 2020-03-19 20:14:21
 */
@Description(remark="好友联系人实体",createDate="2020-03-19 20:14:21",author="程明卫")
@Entity
@Table(name="IM_Friend")
@SuppressWarnings("serial")
public class FriendEntity extends IdEntity {
	
	
	 @Description(remark="创建日期")
	 @Column(name="createTime" ,nullable=false )
	 private Date createTime;

	 @Description(remark="可用标志")
	 @Column(name="isenabled" ,nullable=false )
	 private Byte isenabled = 1;

	 @Description(remark="审批时间")
	 @Column(name="auditTime" )
	 private Date auditTime;

	 @Description(remark="备注")
	 @Column(name="remark" ,length=200 )
	 private String remark;

	 @Description(remark="审批状态")
	 @Column(name="xstatus" ,nullable=false )
	 private Integer xstatus = 0;

	 @Description(remark="好友昵称")
	 @Column(name="nickName" )
	 private String nickName;

	 @Description(remark="好友ID")
	 @Column(name="friendId" ,nullable=false ,length=100 )
	 private String friendId = "-1";

	 @Description(remark="本人ID")
	 @Column(name="myId" ,nullable=false )
	 private String myId;

	 @Description(remark="本人类型")
	 @Column(name="myType" ,nullable=false )
	 private Integer myType;


	public FriendEntity() {

	}

	
	/**
	  * 设置创建日期的值
	 * @param 	createTime	 创建日期
	**/
	public void setCreateTime(Date  createTime){
		 this.createTime=createTime;
 	}

	/**
	  * 获取创建日期的值
	 * @return 返回创建日期的值
	**/
	public Date getCreateTime(){
		 return createTime;
 	}

	/**
	  * 设置可用标志的值
	 * @param 	isenabled	 可用标志
	**/
	public void setIsenabled(Byte  isenabled){
		 this.isenabled=isenabled;
 	}

	/**
	  * 获取可用标志的值
	 * @return 返回可用标志的值
	**/
	public Byte getIsenabled(){
		 return isenabled;
 	}

	/**
	  * 设置审批时间的值
	 * @param 	auditTime	 审批时间
	**/
	public void setAuditTime(Date  auditTime){
		 this.auditTime=auditTime;
 	}

	/**
	  * 获取审批时间的值
	 * @return 返回审批时间的值
	**/
	public Date getAuditTime(){
		 return auditTime;
 	}

	/**
	  * 设置备注的值
	 * @param 	remark	 备注
	**/
	public void setRemark(String  remark){
		 this.remark=remark;
 	}

	/**
	  * 获取备注的值
	 * @return 返回备注的值
	**/
	public String getRemark(){
		 return remark;
 	}

	/**
	  * 设置审批状态的值
	 * @param 	xstatus	 审批状态
	**/
	public void setXstatus(Integer  xstatus){
		 this.xstatus=xstatus;
 	}

	/**
	  * 获取审批状态的值
	 * @return 返回审批状态的值
	**/
	public Integer getXstatus(){
		 return xstatus;
 	}

	/**
	  * 设置好友昵称的值
	 * @param 	nickName	 好友昵称
	**/
	public void setNickName(String  nickName){
		 this.nickName=nickName;
 	}

	/**
	  * 获取好友昵称的值
	 * @return 返回好友昵称的值
	**/
	public String getNickName(){
		 return nickName;
 	}

	/**
	  * 设置好友ID的值
	 * @param 	friendId	 好友ID
	**/
	public void setFriendId(String  friendId){
		 this.friendId=friendId;
 	}

	/**
	  * 获取好友ID的值
	 * @return 返回好友ID的值
	**/
	public String getFriendId(){
		 return friendId;
 	}

	/**
	  * 设置本人ID的值
	 * @param 	myId	 本人ID
	**/
	public void setMyId(String  myId){
		 this.myId=myId;
 	}

	/**
	  * 获取本人ID的值
	 * @return 返回本人ID的值
	**/
	public String getMyId(){
		 return myId;
 	}

	/**
	  * 设置本人类型的值
	 * @param 	myType	 本人类型
	**/
	public void setMyType(Integer  myType){
		 this.myType=myType;
 	}

	/**
	  * 获取本人类型的值
	 * @return 返回本人类型的值
	**/
	public Integer getMyType(){
		 return myType;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{createTime,isenabled,auditTime,remark,xstatus,nickName,friendId,myId,myType};
	}

	@Override
	public String[] getFields() {
		return new String[]{"createTime","isenabled","auditTime","remark","xstatus","nickName","friendId","myId","myType"};
	}

}
