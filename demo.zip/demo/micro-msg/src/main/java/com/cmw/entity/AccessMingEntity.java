package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;
import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.base.entity.IdEntity;


/**
 * 访问明细表
 * @author 程明卫
 * @date 2020-07-17 15:08:07
 */
@Description(remark="访问明细表实体",createDate="2020-07-17 15:08:07",author="程明卫")
@Entity
@Table(name="IM_AccessMing")
@SuppressWarnings("serial")
public class AccessMingEntity extends IdEntity {
	
	
	 @Description(remark="创建日期")
	 @Column(name="createTime" ,nullable=false )
	 private Date createTime;

	 @Description(remark="可用标志")
	 @Column(name="isenabled" ,nullable=false )
	 private Byte isenabled = 1;

	 @Description(remark="最后访问时间")
	 @Column(name="lastTime" )
	 private Date lastTime;

	 @Description(remark="第一次访问时间")
	 @Column(name="firstTime" )
	 private Date firstTime;

	 @Description(remark="访问对象")
	 @Column(name="accObjName" ,nullable=false )
	 private String accObjName;

	 @Description(remark="类型")
	 @Column(name="atype" ,nullable=false )
	 private Byte atype;

	 @Description(remark="访问统计ID")
	 @Column(name="accessStatId" ,nullable=false )
	 private Long accessStatId;


	public AccessMingEntity() {

	}

	
	/**
	  * 设置创建日期的值
	 * @param 	createTime	 创建日期
	**/
	public void setCreateTime(Date  createTime){
		 this.createTime=createTime;
 	}

	/**
	  * 获取创建日期的值
	 * @return 返回创建日期的值
	**/
	public Date getCreateTime(){
		 return createTime;
 	}

	/**
	  * 设置可用标志的值
	 * @param 	isenabled	 可用标志
	**/
	public void setIsenabled(Byte  isenabled){
		 this.isenabled=isenabled;
 	}

	/**
	  * 获取可用标志的值
	 * @return 返回可用标志的值
	**/
	public Byte getIsenabled(){
		 return isenabled;
 	}

	/**
	  * 设置最后访问时间的值
	 * @param 	lastTime	 最后访问时间
	**/
	public void setLastTime(Date  lastTime){
		 this.lastTime=lastTime;
 	}

	/**
	  * 获取最后访问时间的值
	 * @return 返回最后访问时间的值
	**/
	public Date getLastTime(){
		 return lastTime;
 	}

	/**
	  * 设置第一次访问时间的值
	 * @param 	firstTime	 第一次访问时间
	**/
	public void setFirstTime(Date  firstTime){
		 this.firstTime=firstTime;
 	}

	/**
	  * 获取第一次访问时间的值
	 * @return 返回第一次访问时间的值
	**/
	public Date getFirstTime(){
		 return firstTime;
 	}

	/**
	  * 设置访问对象的值
	 * @param 	accObjName	 访问对象
	**/
	public void setAccObjName(String  accObjName){
		 this.accObjName=accObjName;
 	}

	/**
	  * 获取访问对象的值
	 * @return 返回访问对象的值
	**/
	public String getAccObjName(){
		 return accObjName;
 	}

	/**
	  * 设置类型的值
	 * @param 	atype	 类型
	**/
	public void setAtype(Byte  atype){
		 this.atype=atype;
 	}

	/**
	  * 获取类型的值
	 * @return 返回类型的值
	**/
	public Byte getAtype(){
		 return atype;
 	}

	/**
	  * 设置访问统计ID的值
	 * @param 	accessStatId	 访问统计ID
	**/
	public void setAccessStatId(Long  accessStatId){
		 this.accessStatId=accessStatId;
 	}

	/**
	  * 获取访问统计ID的值
	 * @return 返回访问统计ID的值
	**/
	public Long getAccessStatId(){
		 return accessStatId;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{createTime,isenabled,lastTime,firstTime,accObjName,atype,accessStatId};
	}

	@Override
	public String[] getFields() {
		return new String[]{"createTime","isenabled","lastTime","firstTime","accObjName","atype","accessStatId"};
	}

}
