package com.cmw.dao;


import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.MessageEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * IM消息  Mapper接口
 * @author 程明卫
 * @date 2020-03-19 20:03:56
 */
@Description(remark="IM消息DAO Mapper接口",createDate="2020-03-19 20:03:56",author="程明卫")
@Component
@Mapper
public interface MessageDao extends GenericDaoInter<MessageEntity, Long>{
    /**
     * 获取未读消息
     * @param params
     * @return
     */
    List<Map<String,Object>> getUnReadList(Map<String,Object> params);
}
