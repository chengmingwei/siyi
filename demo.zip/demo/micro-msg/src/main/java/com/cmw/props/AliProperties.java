package com.cmw.props;

import com.myrcib.middleware.util.GenPass;
import com.myrcib.middleware.util.StringHandler;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

/**
 * 阿里云属性
 * @Author 肖家添
 * @Date 2019/11/5 14:50
 */
@Configuration
@RefreshScope
@Data
@Slf4j
public class AliProperties {

    /**
     * accessKeyId
     */
    @Value("${micro.aliyuncs.accessKeyId}")
    private String accessKeyId;

    /**
     * secret
     */
    @Value("${micro.aliyuncs.secret}")
    private String secret;

    //******************** ALI SMS START ********************//

    /**
     * regionId
     */
    @Value("${micro.aliyuncs.sms.regionId}")
    private String sms_regionId;

    /**
     * domain
     */
    @Value("${micro.aliyuncs.sms.domain}")
    private String sms_domain;

    /**
     * version
     */
    @Value("${micro.aliyuncs.sms.version}")
    private String sms_version;

    /**
     * signName
     */
    @Value("${micro.aliyuncs.sms.signName}")
    private String sms_signName;

    //******************** ALI SMS END ********************//

    @PostConstruct
    public void init(){
        try {
            if(null == accessKeyId || null == secret){
                throw new RuntimeException();
            }

            this.accessKeyId = GenPass.Decrypt(accessKeyId);
            this.secret = GenPass.Decrypt(secret);
        } catch (Exception e) {
            log.error("获取阿里云秘钥失败！", e);
            throw new RuntimeException();
        }
    }
}
