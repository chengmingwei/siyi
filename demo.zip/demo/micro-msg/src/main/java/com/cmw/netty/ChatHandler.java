package com.cmw.netty;

import com.alibaba.fastjson.JSONObject;
import com.cmw.constant.GlobalConstant;
import com.cmw.constant.MQListenerConstant;
import com.cmw.constant.SysParamConstant;
import com.cmw.netty.enums.MsgActionEnum;
import com.cmw.netty.vo.Msg;
import com.cmw.netty.vo.MsgPacket;
import com.cmw.netty.vo.UserChannelRel;
import com.cmw.service.inter.MsgService;
import com.myrcib.middleware.core.idworker.Sid;
import com.myrcib.middleware.util.*;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelId;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.util.concurrent.GlobalEventExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.cmw.netty.enums.MsgActionEnum.*;

/**
 *
 * @Description: 处理消息的handler
 * TextWebSocketFrame： 在netty中，是用于为websocket专门处理文本的对象，frame是消息的载体
 * @Auth chengmingwei
 * @Date 2019-09-27 21:05
 */
@Slf4j
@Component
public class ChatHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {
    // 用于记录和管理所有客户端的channle
    public   static ChannelGroup users = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    //-- MQ
    private AmqpTemplate amqpTemplate;

    //-- Redis
    private StringRedisTemplate stringRedisTemplate;


    @Override
    protected void channelRead0(ChannelHandlerContext ctx, TextWebSocketFrame msg) throws Exception {
        // 获取客户端传输过来的消息
        String content = msg.text();
        Channel currentChannel = ctx.channel();
        log.info("content="+content);
        // 1. 获取客户端发来的消息
        MsgPacket dataContent = FastJsonUtil.convertJsonToObj(content, MsgPacket.class);
        Integer action = dataContent.getAction();
        // 2. 判断消息类型，根据不同的类型来处理不同的业务
        if(CONNECT.type.equals(action)){	// 	2.1  当websocket 第一次open的时候，初始化channel，把用的channel和userid关联起来
            connectChannel(currentChannel, dataContent);
        }else if(CHAT.type.equals(action)){	// 	2.2 聊天类型的消息
            sendMsg(dataContent);
        }else if(SIGNED.type.equals(action) || SIGNED_SINGLE.type.equals(action)){	// 	2.3 签收消息类型
            sendMsgByMQ(dataContent);
        }else if(KEEPALIVE.type.equals(action)){	// 	2.4 心跳类型的消息
            log.info("收到来自channel为[{}]的心跳包...",currentChannel.id().asShortText());
        }
    }

    Sid sid = new Sid();

    private String filterMsgContent(Msg chatMsg){
        String msgContent = chatMsg.getMsgContent();
        if(!StringUtils.isEmpty(msgContent) && msgContent.equals("ONE_TO_ONE_SERVICE_END_MSG")){
            chatMsg.setMsgContent("您好，本次服务已结束！");
            return msgContent;
        }
        return null;
    }

    /**
     * 发送消息
     * @param
     * @param dataContent
     */
    private void sendMsg(MsgPacket dataContent) throws Exception {
        Msg chatMsg = dataContent.getMsg();
        String oldMsgContent = filterMsgContent(chatMsg);
        String msgId = chatMsg.getMsgId();
        String uuid = sid.nextShort();
        if(!StringUtils.isEmpty(msgId)){
            uuid = msgId;
            chatMsg.setMsgId(null);
        }
        chatMsg.setUuid(uuid);
        String senderId = chatMsg.getSenderId();
        String receiverId = chatMsg.getReceiverId();
        String extand = dataContent.getExtand();
        String desc_senderId = DES3.decode(senderId);
        String desc_receiverId = DES3.decode(receiverId);
        String desc_extand = GenPass.Decrypt(extand);
        String redisKey = GlobalConstant.REDIS_KEY_CONSULTATION_PREFIX +desc_receiverId+":"+desc_senderId+":"+desc_extand;
        log.info("3分钟过期KEY : {}", redisKey);
        geRedisTemplate();
        if(stringRedisTemplate.hasKey(redisKey)){ //如果VIP经纪人3分钟内以发消息过来的情况下，就清除3分钟过期的KEY
            log.info("开始删除3分钟过期KEY : {}", redisKey);
            stringRedisTemplate.delete(redisKey); //此KEY 在 ConsultationController.wx_create 方法里设置的
            log.info("已删除3分钟过期KEY : {}", redisKey);
        }
        sendMsgByMQ(dataContent);
        // 从全局用户Channel关系中获取接受方的channel
        List<ChannelId> receiverChannelIdList = UserChannelRel.get(receiverId);
        if(null != receiverChannelIdList && receiverChannelIdList.size() > 0){
            receiverChannelIdList.forEach(receiverChannelId -> {
                if(!StringUtils.isEmpty(oldMsgContent)){
                    dataContent.getMsg().setMsgContent(oldMsgContent);
                }
                // 当receiverChannel不为空的时候，从ChannelGroup去查找对应的channel是否存在
                Channel findChannel = users.find(receiverChannelId);
                if(null == findChannel){
                    log.info("Form: "+senderId+" To："+receiverId+",对用户发送离线消息通知");
                    try {
                        offlineMsgNotify(dataContent);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                findChannel.writeAndFlush(new TextWebSocketFrame(FastJsonUtil.convertJsonToStr(dataContent)));
            });
        }else{
            log.info("Form: "+senderId+" To："+receiverId+",对用户发送离线消息通知");
            offlineMsgNotify(dataContent);
        }
    }

    /**
     * 发送后台消息
     * @param dataContent
     */
    public static void sendDaemsNotify(MsgPacket dataContent){
        Msg chatMsg = dataContent.getMsg();
        String receiverId = chatMsg.getReceiverId();
        // 从全局用户Channel关系中获取接受方的channel
        List<ChannelId> receiverChannelIdList = UserChannelRel.get(receiverId);
        if(null == receiverChannelIdList || receiverChannelIdList.isEmpty()){
            log.error("根据receiverId={} 找不到对应的 channelId 列表。无法发送消息...", receiverId);
            return;
        }
        receiverChannelIdList.forEach(receiverChannelId -> {
            // 当receiverChannel不为空的时候，从ChannelGroup去查找对应的channel是否存在
            Channel findChannel = users.find(receiverChannelId);
            if(null == findChannel){
                log.error("receiverChannelId={} 的 Channel 为空，无法送达消息...");
                return;
            }
            findChannel.writeAndFlush(new TextWebSocketFrame(FastJsonUtil.convertJsonToStr(dataContent)));
        });
    }

    /**
     * 发送离线消息
     * @param dataContent
     */
    private void offlineMsgNotify(MsgPacket dataContent) throws Exception {
        String offline_redisKey = SysParamConstant.getKey(SysParamConstant.ONE_ONE_OFFLINE_NOTIFY_KEY);
        String val = stringRedisTemplate.opsForValue().get(offline_redisKey);
        if(!StringUtils.isEmpty(val) && val.equals(SysParamConstant.ONE_ONE_OFFLINE_NOTIFY_VAL_CLOSE)){
            log.error("系统参数中已经关闭了发送离线消息的通知。[key:{} -> val:{}]", SysParamConstant.ONE_ONE_OFFLINE_NOTIFY_KEY, val);
            return;
        }
        Msg chatMsg = dataContent.getMsg();
        String extandField = dataContent.getExtand();
        String senderId = chatMsg.getSenderId();
        String receiverId = chatMsg.getReceiverId();
        senderId = DES3.decode(senderId);
        receiverId = DES3.decode(receiverId);

        if(!StringUtils.isEmpty(extandField)){
            extandField = GenPass.Decrypt(extandField);
        }
        if(StringUtils.isEmpty(extandField)) extandField = "";
        String redisLocalKey = "LOCKER_"+senderId+":"+receiverId+":"+extandField;
        String redisKey = "CHAT_"+senderId+":"+receiverId+":"+extandField;
        geRedisTemplate();
        if(!stringRedisTemplate.hasKey(redisLocalKey)){ //第一次发消息：5秒
            stringRedisTemplate.opsForValue().set(redisLocalKey, "1", 30, TimeUnit.MINUTES); //锁保留30分钟
            stringRedisTemplate.opsForValue().set(redisKey, "0", 5, TimeUnit.MINUTES);
        }else{//以后就10分钟一次
            stringRedisTemplate.opsForValue().set(redisKey, "1", 10, TimeUnit.MINUTES);
            //stringRedisTemplate.opsForValue().set(redisKey, "1", 5, TimeUnit.SECONDS);
        }
    }

    /**
     * 将消息通过消息中间件发送出去
     * @param dataContent
     */
    private void sendMsgByMQ(MsgPacket dataContent) {
        Map<String,Object> msgMap = new HashMap<String,Object>();
        msgMap.put("dataContent", dataContent);
        getAmqpTemplate().convertAndSend(GlobalConstant.AMQP_EXCHANGE_IMMSG_KEY,GlobalConstant.AMQP_ROUTINGKEY_IMMSG_KEY, msgMap);
    }

    /**
     * Channel 建立连接
     * @param channel
     * @param dataContent
     */
    private void connectChannel(Channel channel, MsgPacket dataContent){
        String senderId = dataContent.getMsg().getSenderId();
        log.info(String.format("用户：%s 已上线...", senderId));
        UserChannelRel.put(senderId, channel.id());
        UserChannelRel.output();
    }

    private AmqpTemplate getAmqpTemplate(){
        if(null != amqpTemplate) return amqpTemplate;
        amqpTemplate = (AmqpTemplate) SpringContextUtil.getBean(AmqpTemplate.class);
        return amqpTemplate;
    }


    /**
     * 创建 StringRedisTemplate 对象
     * @return
     */
    private StringRedisTemplate geRedisTemplate() {
        if (null != stringRedisTemplate) return stringRedisTemplate;
        stringRedisTemplate = (StringRedisTemplate) SpringContextUtil.getBean(StringRedisTemplate.class);
        return stringRedisTemplate;
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        // 发生异常之后关闭连接（关闭channel），随后从ChannelGroup中移除
        ctx.channel().close();
        users.remove(ctx.channel());
    }

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        Channel channel = ctx.channel();
        String channelId = channel.id().asShortText();
        log.info(String.format("有新的客户端已连接，channelId为：%s", channelId));
       users.add(ctx.channel());
    }

    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
        Channel channel = ctx.channel();
        String channelId = channel.id().asShortText();
        log.info(String.format("客户端被移除，channelId为：%s", channelId));
        // 当触发handlerRemoved，ChannelGroup会自动移除对应客户端的channel
        users.remove(ctx.channel());
        UserChannelRel.remove(channel.id());
    }

    public static void main(String[] args){
        String str = "{\"action\":3,\"msg\":null,\"extand\":\"48\",\"bussType\":1}";
        //JSONObject jsonObject = FastJsonUtil.con(str,MsgPacket.class);
        MsgPacket dataContent = FastJsonUtil.convertJsonToObj(str, MsgPacket.class);
        System.out.println(dataContent);
    }
}
