package com.cmw.listener;

import com.cmw.model.back.UserModel;
import com.cmw.service.inter.MsgService;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @Author: 98050
 * @Time: 2018-10-22 19:21
 * @Feature:短信服务监听器
 */
@Component
public class SmsListener {

    @Autowired
    private MsgService msgService;

    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = "sports.sms.queue",durable = "true"),
            exchange = @Exchange(value = "sports.sms.exchange",ignoreDeclarationExceptions = "true"),
            key = {"sms.verify.code"}
    ))
    public void listenSms(Map<String,Object> msg){
        if (msg == null || msg.size() <= 0){
            //不做处理
            return;
        }
        String tempCode = (String)msg.get("tempCode");
        String phone = (String)msg.get("phone");
        UserModel user = (UserModel)msg.get("userInfo");
        msg.remove("tempCode");
        msg.remove("phone");
        msg.remove("userInfo");
        msgService.sendSms(tempCode, phone, msg, user);
    }
}
