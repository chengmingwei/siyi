package com.cmw.util;

import com.cmw.constant.back.SysContant;
import com.myrcib.middleware.core.base.entity.BaseEntity;
import com.cmw.model.back.UserModel;
import com.myrcib.middleware.core.base.entity.IdEntity;

import java.util.Date;

/**
 *
 * 创建记录时的用户信息工具类
 */
public class UserUtil {

    /**
     * 创建系统管理员时的create Info值
     * @param entity    要赋值创建人信息的记录
     */
    public static void setCreateInfoBySysAdmin(BaseEntity entity){
        entity.setCreateTime(new Date());
        entity.setCreator(SysContant.ADMIN_DEFAULT_CREATE);
        entity.setDeptId(SysContant.ADMIN_DEFAULT_DEPTID);
        entity.setOrgid(SysContant.ADMIN_DEFAULT_ORGID);
    }

    /**
     * 由系统创建的记录的create Info值
     * @param entity    要赋值创建人信息的记录
     */
    public static void setCreateInfoBySystem(BaseEntity entity){
        entity.setCreateTime(new Date());
        entity.setCreator(SysContant.SYSTEM_DEFAULT_CREATE);
        entity.setDeptId(SysContant.SYSTEM_DEFAULT_DEPTID);
        entity.setOrgid(SysContant.SYSTEM_DEFAULT_ORGID);
    }


    /**
     * 为记录赋值创建人信息
     * @param user  用户信息
     * @param entity    要赋值创建人信息的记录
     */
    public static void setCreateInfo(UserModel user, BaseEntity entity){
        if(null == user){
            setCreateInfoBySystem(entity);
            return;
        }
        Long indeptId = user.getIndeptId();
        Long incompId = user.getIncompId();
        if(null == indeptId) indeptId = SysContant.SYSTEM_DEFAULT_DEPTID;
        if(null == incompId) incompId = SysContant.SYSTEM_DEFAULT_ORGID;
        entity.setCreateTime(new Date());
        entity.setCreator(user.getId());
        entity.setDeptId(indeptId);
        entity.setOrgid(incompId);
    }


    public static void setModifyInfo(UserModel user, BaseEntity entity){
        if(null == user){
            setModifyInfoBySystem(entity);
            return;
        }
        entity.setModifier(user.getId());
        entity.setModifytime(new Date());
    }

    public static void setModifyInfoBySysAdmin(BaseEntity entity){
        entity.setModifier(SysContant.ADMIN_DEFAULT_CREATE);
        entity.setModifytime(new Date());
    }

    public static void setModifyInfoBySystem(BaseEntity entity){
        entity.setModifier(SysContant.SYSTEM_DEFAULT_CREATE);
        entity.setModifytime(new Date());
    }

}
