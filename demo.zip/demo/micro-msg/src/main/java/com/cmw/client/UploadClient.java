package com.cmw.client;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * 文件上传微服务 FeignClient
 * @Author 肖家添
 * @Date 2019/8/28 10:58
 */
@FeignClient(value = "micro-upload")
@Component
public interface UploadClient {

    /**
     * 根据Byte数组上传文件
     *
     * fileByte -> 文件Byte字符串
     * keywords -> 传入关键字加扩展名, 如：[1000.pdf] 中[1000]为订单Id, [.pdf]为扩展名
     * formType -> 业务类型
     * formId -> 业务Id
     * feignKey -> 负载均衡内部调用KEY, 表示此Action只允许用于服务之间调用
     *
     * 注意: redisKey会等于[../formType-keywords],
     *      如: [20001-10001.pdf]中,
     *              20001=文件上传业务类型,
     *              10001=订单唯一编号,
     *              .pdf=文件扩展名（用于临时文件存储和文件上传）
     *
     * @Author 肖家添
     * @Date 2019/10/23 14:51
     */
    @PostMapping("/attachment/uploadFileToForByteArr")
    JSONObject uploadFileToForByteArr(@RequestBody Map<String, Object> params);
}
