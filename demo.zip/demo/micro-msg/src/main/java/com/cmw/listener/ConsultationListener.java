package com.cmw.listener;

import com.cmw.constant.GlobalConstant;
import com.cmw.service.inter.ConsultationService;
import com.myrcib.middleware.core.base.annotation.Description;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Description(remark = "实时咨询监听器")
@Slf4j
@Component
public class ConsultationListener {

    @Autowired
    private ConsultationService consultationService;

    @RabbitListener(bindings = @QueueBinding(
            exchange = @Exchange(value = GlobalConstant.AMQP_EXCHANGE_CONSULTATION_PAY_OVERTIME_KEY, ignoreDeclarationExceptions = "true"),
            key = {GlobalConstant.AMQP_ROUTINGKEY_CONSULTATION_PAY_OVERTIME_KEY},
            value = @Queue(value = GlobalConstant.AMQP_QUEUE_CONSULTATION_PAY_OVERTIME_KEY, durable = "true")
    ))
    public void commomSendMsg(Map<String,Object> map){
        try{
            consultationService.consultationPayOvertime(map);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}
