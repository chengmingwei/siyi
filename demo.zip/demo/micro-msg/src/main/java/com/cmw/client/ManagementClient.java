package com.cmw.client;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 保险管理微服务 FeignClient
 * @Author 肖家添
 * @Date 2019/10/22 20:02
 */
@FeignClient(value = "micro-insure-management")
@Component
public interface ManagementClient {

    /**
     * 获取投保邮件通知所需数据
     * @Author 肖家添
     * @Date 2019/10/22 19:54
     */
    @PostMapping("/mobileOrderInfoLog/getInsuranceEmailDatums")
    JSONObject getInsuranceEmailDatums(
            //-- 订单 Id
            @RequestParam Long orderId,
            //-- Feign 远程标识
            @RequestParam String feignKey
    );

    /**
     * 获计划书邮件通知所需数据
     * @Author: tanhanxiang
     * @Date: 2019/12/18 18:10
     */
    @PostMapping("/wxminiapp/sendWxMaMailMessage")
    JSONObject sendWxMaTemplateMessage(@RequestParam  String memberId,
                               @RequestParam String formId,
                               @RequestParam String email,
                               @RequestParam String proposalRecordInfoId,
                               @RequestParam String feignKey);

    @PostMapping("/userjoininfo/getByMobile")
    JSONObject getByMobile(
            //-- 手机号
            @RequestParam String mobile,
            //-- 活动ID
            @RequestParam String activeId,
            //-- Feign 远程标识
            @RequestParam String feignKey
    );
}
