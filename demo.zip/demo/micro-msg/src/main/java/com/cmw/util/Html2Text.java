package com.cmw.util;

import java.io.*;
import javax.swing.text.html.*;
import javax.swing.text.html.parser.*;

/**
 * @Author: tanhanxiang
 * @Date: 2019/12/18 21:04
 */
public class Html2Text extends HTMLEditorKit.ParserCallback{
    private static Html2Text html2Text = new Html2Text();
    StringBuffer s;

    public void parse(String str) throws IOException {

        InputStream iin = new ByteArrayInputStream(str.getBytes());
        Reader in = new InputStreamReader(iin);
        s = new StringBuffer();
        ParserDelegator delegator = new ParserDelegator();
        // the third parameter is TRUE to ignore charset directive
        delegator.parse(in, this, Boolean.TRUE);
        iin.close();
        in.close();
    }

    @Override
    public void handleText(char[] text, int pos) {
        s.append(text);
    }

    public String getText() {
        return s.toString();
    }

    public static String getContent(String str) throws Exception {
        html2Text.parse(str);
        return html2Text.getText();
    }
}
