package com.cmw.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;
import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.base.entity.IdEntity;


/**
 * 系统访问统计
 * @author 程明卫
 * @date 2020-07-17 15:03:16
 */
@Description(remark="系统访问统计实体",createDate="2020-07-17 15:03:16",author="程明卫")
@Entity
@Table(name="IM_AccessStatistics")
@SuppressWarnings("serial")
public class AccessStatisticsEntity extends IdEntity {
	
	
	 @Description(remark="访问来源")
	 @Column(name="sourceName" ,nullable=false ,length=100 )
	 private String sourceName;

	 @Description(remark="访问来源类型")
	 @Column(name="source" ,nullable=false )
	 private String source;

	 @Description(remark="页面地址")
	 @Column(name="pagePath" ,length=200 )
	 private String pagePath;

	 @Description(remark="页面名称")
	 @Column(name="pageName" ,length=100 )
	 private String pageName;

	 @Description(remark="可用标志")
	 @Column(name="isenabled" ,nullable=false )
	 private Byte isenabled = 1;

	 @Description(remark="创建日期")
	 @Column(name="createTime" ,nullable=false )
	 private Date createTime;

	 @Description(remark="类型")
	 @Column(name="atype" ,nullable=false )
	 private Byte atype;

	 @Description(remark="访问时间")
	 @Column(name="accessTime" )
	 private Date accessTime;

	@Description(remark="访问次数")
	@Column(name="acount" )
	private Long acount = 0L;

	@Description(remark="访问key")
	@Column(name="accessKey" ,length=50 )
	private String accessKey;

	public AccessStatisticsEntity() {

	}

	/**
	 * 获取访问key
	 * @return 返回访问key
	 */
	public String getAccessKey() {
		return accessKey;
	}

	/**
	 * 设置访问key
	 * @param accessKey	访问key
	 */
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	/**
	 * 获取访问次数
	 * @return 返回访问次数
	 */
	public Long getAcount() {
		return acount;
	}

	/**
	 * 设置访问次数
	 * @param acount	访问次数
	 */
	public void setAcount(Long acount) {
		this.acount = acount;
	}

	/**
	  * 设置访问来源的值
	 * @param 	sourceName	 访问来源
	**/
	public void setSourceName(String  sourceName){
		 this.sourceName=sourceName;
 	}

	/**
	  * 获取访问来源的值
	 * @return 返回访问来源的值
	**/
	public String getSourceName(){
		 return sourceName;
 	}

	/**
	  * 设置访问来源类型的值
	 * @param 	source	 访问来源类型
	**/
	public void setSource(String  source){
		 this.source=source;
 	}

	/**
	  * 获取访问来源类型的值
	 * @return 返回访问来源类型的值
	**/
	public String getSource(){
		 return source;
 	}

	/**
	  * 设置页面地址的值
	 * @param 	pagePath	 页面地址
	**/
	public void setPagePath(String  pagePath){
		 this.pagePath=pagePath;
 	}

	/**
	  * 获取页面地址的值
	 * @return 返回页面地址的值
	**/
	public String getPagePath(){
		 return pagePath;
 	}

	/**
	  * 设置页面名称的值
	 * @param 	pageName	 页面名称
	**/
	public void setPageName(String  pageName){
		 this.pageName=pageName;
 	}

	/**
	  * 获取页面名称的值
	 * @return 返回页面名称的值
	**/
	public String getPageName(){
		 return pageName;
 	}

	/**
	  * 设置可用标志的值
	 * @param 	isenabled	 可用标志
	**/
	public void setIsenabled(Byte  isenabled){
		 this.isenabled=isenabled;
 	}

	/**
	  * 获取可用标志的值
	 * @return 返回可用标志的值
	**/
	public Byte getIsenabled(){
		 return isenabled;
 	}

	/**
	  * 设置创建日期的值
	 * @param 	createTime	 创建日期
	**/
	public void setCreateTime(Date  createTime){
		 this.createTime=createTime;
 	}

	/**
	  * 获取创建日期的值
	 * @return 返回创建日期的值
	**/
	public Date getCreateTime(){
		 return createTime;
 	}

	/**
	  * 设置类型的值
	 * @param 	atype	 类型
	**/
	public void setAtype(Byte  atype){
		 this.atype=atype;
 	}

	/**
	  * 获取类型的值
	 * @return 返回类型的值
	**/
	public Byte getAtype(){
		 return atype;
 	}

	/**
	  * 设置访问时间的值
	 * @param 	accessTime	 访问时间
	**/
	public void setAccessTime(Date  accessTime){
		 this.accessTime=accessTime;
 	}

	/**
	  * 获取访问时间的值
	 * @return 返回访问时间的值
	**/
	public Date getAccessTime(){
		 return accessTime;
 	}



	@Override
	public Object[] getDatas() {
		return new Object[]{sourceName,source,pagePath,pageName,isenabled,createTime,atype,accessTime,acount};
	}

	@Override
	public String[] getFields() {
		return new String[]{"sourceName","source","pagePath","pageName","isenabled","createTime","atype","accessTime","acount"};
	}

}
