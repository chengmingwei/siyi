package com.cmw.listener;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cmw.client.MemberClient;
import com.cmw.constant.GlobalConstant;
import com.cmw.constant.SmsTemplateConstant;
import com.cmw.constant.back.BussContant;
import com.cmw.constant.enums.BussContantEnum;
import com.cmw.service.inter.MessageService;
import com.cmw.service.inter.MsgService;
import com.myrcib.middleware.util.GenPass;
import com.myrcib.middleware.util.StringHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.listener.KeyExpirationEventMessageListener;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

import static com.cmw.constant.back.BussContant.*;

/**
 * @ClassName RedisKeyExpirationListener
 * @Description: 监听redis的过期事件
 * @Author chengmingwei
 * @Email: chengmingwei_1984122@126.com
 * @Date 2020/3/31
 * @Version V1.0
 **/
@Component
@Slf4j
public class RedisKeyExpirationListener extends KeyExpirationEventMessageListener {

    @Autowired
    private MsgService msgService;

    @Autowired
    private MemberClient memberClient;

    @Autowired
    private MessageService messageService;

    /**
     * Creates new {@link RedisMessageListenerContainer} for {@code __keyevent@*__:expired} messages.
     *
     * @param listenerContainer must not be {@literal null}.
     */
    public RedisKeyExpirationListener(RedisMessageListenerContainer listenerContainer) {
        super(listenerContainer);
    }

    public void onMessage(Message message, byte[] pattern){
        String expiredKey = message.toString();
        log.info("redis key过期：{}",expiredKey);
        if(StringUtils.isEmpty(expiredKey)) return;
        if(expiredKey.indexOf("CHAT_") != -1 ){ //离线消息过期通知
            sendOfflineNotiy(expiredKey);
        }else if(expiredKey.indexOf(GlobalConstant.REDIS_KEY_CONSULTATION_PREFIX) != -1 ){ //VIP经纪人3分钟内没有服务客户过期通知
            reallocationVipServicer(expiredKey);
        }
    }

    /**
     * 对3分钟没响应的VIP经纪人重新分配给小白客户
     * @param redisKey
     */
    private void reallocationVipServicer(String redisKey){
        String[] dataArr = redisKey.split("_");
        String idsStr = dataArr[1];
        String[] idArr = idsStr.split(":");
        String sender = idArr[0];
        String oldReceiver = idArr[1];
        String consultationId = idArr[2];
        String memberIds = sender+","+oldReceiver;
        JSONObject jsonData = memberClient.memberVip_getMyServicer(memberIds,GlobalConstant.FEIGN_REQUEST_KEY);
        Boolean success = jsonData.getBoolean("success");
        if(!success){
            log.error("获取服务于一对一的内部客服信息失败，请检查在系统参数中是否有配置专门的客户人员手机号，错误信息：{}!", jsonData.getString("msg"));
            return;
        }
        JSONObject datas = jsonData.getJSONObject("datas");
        datas.put("consultationId", consultationId);
        datas.put("sender", sender);
        datas.put("oldReceiver", oldReceiver);
        log.info("reallocationVipServicer.datas:{}", datas.toJSONString());
        messageService.reallocationVipServicer(datas);
    }

    /**
     * 发送离线通知
     *
     * @param expiredKey CHAT_856589:851285
     */
    private void sendOfflineNotiy(String expiredKey){
        String idsStr = expiredKey.split("_")[1];
        String[] idsArr = idsStr.split(":");
        String senderId = idsArr[0];
        String receiverId = idsArr[1];
        String formId = null;
        if(idsArr.length == 3){
            formId = idsArr[2];
        }
        String memberIds = senderId+","+receiverId;
        JSONObject jsonData = memberClient.member_getBaseInfoList(memberIds, GlobalConstant.FEIGN_REQUEST_KEY);
        Boolean success = jsonData.getBoolean("success");
        if(!success){
            log.error("获取发送人和接收人的会员信息失败，无法通知到消息接收人，请检查系统是否出问题!");
            return;
        }
        JSONArray datas = jsonData.getJSONArray("datas");
        if(null == datas || datas.size() == 0){
            log.error("获取发送人和接收人的会员信息失败，无法通知到消息接收人，请检查系统是否出问题!");
            return;
        }
        JSONObject senderObj = getData(senderId, datas);
        JSONObject receiverObj = getData(receiverId, datas);
        String memberAccount = senderObj.getString("rname");
        String receiverAccount = receiverObj.getString("rname");
        String mtypes = MSG_MTYPE_1+",";
        String phone = receiverObj.getString("phone");
        String email = receiverObj.getString("email");
        if(!StringUtils.isEmpty(phone)){
            phone = GenPass.Decrypt(phone);
        }
        if(!StringUtils.isEmpty(phone)){
            mtypes += MSG_MTYPE_2+",";
        }
        if(!StringUtils.isEmpty(email)){
            mtypes += MSG_MTYPE_3;
        }
        mtypes = StringHandler.RemoveStr(mtypes,",");

        Map<String,Object> pars = new HashMap<>();
        pars.put("actionType","unRead");
        pars.put("sender",senderId);
        pars.put("receiver", receiverId);
        pars.put("bussType", BussContantEnum.IM_MESSAGE_RTYPE_1.value);
        Long unreadCount = messageService.getTotals(pars);
        if(null == unreadCount || unreadCount.intValue() == 0){
            log.info("用户：的未读消息为{}条。不需要发送离线消息通知",receiverAccount);
            return;
        }
        Map<String,Object> params = new HashMap<>();
        params.put("tempCode", SmsTemplateConstant.ONE_TO_ONE_CONSULTATION);
        params.put("mtypes",mtypes);
        params.put("phone",phone);
        params.put("email",email);
        params.put("rtype", MSG_RTYPE_2);
        params.put("memberId", Long.parseLong(receiverId));
        params.put("formType", BussContant.MSG_FORM_TYPE_101);
        if(!StringUtils.isEmpty(formId)){
            params.put("formId", formId);
        }
        params.put("sender", senderId);

        params.put("memberAccount",memberAccount);
        params.put("unreadCount",unreadCount);
        msgService.sendMsg(params);
    }

    private JSONObject getData(String memberId, JSONArray datas){
        JSONObject jsonObject = null;
        for(int i=0, count = datas.size(); i<count; i++){
            JSONObject _json = datas.getJSONObject(i);
            if(_json.getString("memberId").equals(memberId)){
                jsonObject = _json;
                break;
            }
        }
        return  jsonObject;
    }
}
