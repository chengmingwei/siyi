package com.cmw.dao;


import com.cmw.entity.GvlistEntity;
import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * 基础数据表  Mapper接口
 * @author 程明卫
 * @date 2019-03-27 13:55:12
 */
@Description(remark="基础数据表DAO Mapper接口",createDate="2019-03-27 13:55:12",author="程明卫")
@Mapper
@Component
public interface GvlistDao extends GenericDaoInter<GvlistEntity, Long> {

    /**
     * 根据资源编号获取对应的基础数据
     * @param recode 资源编号
     * @return 返回List Map对象
     * @  抛出DaoException
     */
    List<Map<String,Object>> getListByRestype(final String recode);

    /**
     * 获取收银台记录管理列表
     * @param map
     * @return
     */
    List<Map<String,Object>> getGvListByRestype(Map<String, Object> map);
    /**
     * 获取收银台记录管理列表记录数
     * @param map
     * @return
     */
    Long getGvListByRestypeTotal(Map<String, Object> map);
}
