package com.cmw.dao;


import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.FriendEntity;
import org.springframework.stereotype.Component;


/**
 * 好友联系人  Mapper接口
 * @author 程明卫
 * @date 2020-03-19 20:14:21
 */
@Description(remark="好友联系人DAO Mapper接口",createDate="2020-03-19 20:14:21",author="程明卫")
@Component
@Mapper
public interface FriendDao extends GenericDaoInter<FriendEntity, Long>{

}
