package com.cmw;

import com.cmw.netty.WebSocketServer;
import com.cmw.service.inter.MsgService;
import com.myrcib.middleware.util.SpringContextUtil;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

/**
 *
 */
@Component
public class NettyBooter implements ApplicationListener<ContextRefreshedEvent> {

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if(event.getApplicationContext().getParent() == null) return;
        SpringContextUtil.setContext(event.getApplicationContext());
      //  MsgService msgService = (MsgService)SpringContextUtil.getBean("msgService");
        WebSocketServer.getInstance().start();
    }
}
