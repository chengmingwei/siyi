package com.cmw.dao;


import com.myrcib.middleware.core.base.annotation.Description;
import com.myrcib.middleware.core.ssm.dao.GenericDaoInter;
import org.apache.ibatis.annotations.Mapper;
import com.cmw.entity.AccessStatisticsEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * 系统访问统计  Mapper接口
 * @author 程明卫
 * @date 2020-07-17 15:03:16
 */
@Description(remark="系统访问统计DAO Mapper接口",createDate="2020-07-17 15:03:16",author="程明卫")
@Component
@Mapper
public interface AccessStatisticsDao extends GenericDaoInter<AccessStatisticsEntity, Long>{

    /**
     * 获取系统访问统计的数据
     * @param map
     * @return
     */
    List<Map<String,Object>> getAccessStatisticsList(Map<String, Object> map);

    /**
     * 获取日度实时数据
     * @param map
     * @return
     */
    List<Map<String,Object>> getAccessStatisticsListToDay(Map<String, Object> map);

    /**
     * 获取日度实时数据总数
     * @param map
     * @return
     */
    Long getAccessStatisticsListToDaySum(Map<String, Object> map);
}
