#!/usr/bin/env bash

env="dev20191105.A"

#编译打包
mvn clean package -Dmaven.test.skip=true -U

#删除上次的镜像
docker rmi dockerimages.xiaobaibao.com:8082/springcloud/micro-msg:$env

#编译成Docker 镜像文件
docker build -t dockerimages.xiaobaibao.com:8082/springcloud/micro-msg:$env .
#设置在线镜像TAG 标签
docker tag dockerimages.xiaobaibao.com:8082/springcloud/micro-msg:$env dockerimages.xiaobaibao.com:8082/springcloud/micro-msg:$env
# PUSH 到 网易镜像中心
docker push dockerimages.xiaobaibao.com:8082/springcloud/micro-msg:$env

docker rmi dockerimages.xiaobaibao.com:8082/springcloud/micro-msg:$env
docker rmi dockerimages.xiaobaibao.com:8082/springcloud/micro-msg:$env
