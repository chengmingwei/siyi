#!/usr/bin/env bash
env='micro-msg.20200404'
alu='registry.cn-shenzhen.aliyuncs.com'
#编译打包
mvn clean package -Dmaven.test.skip=true -U
#删除上次的镜像
docker rmi $alu/mt-saas/myrcib-saasi:$env
#编译成Docker 镜像文件
docker build -t $alu/mt-saas/myrcib-saasi:$env .
#设置在线镜像TAG 标签
docker tag $alu/mt-saas/myrcib-saasi:$env $alu/mt-saas/myrcib-saasi:$env
# PUSH 到 米兔镜像中心
docker push $alu/mt-saas/myrcib-saasi:$env
# PUSH 到 米兔镜像中心
docker rmi $alu/mt-saas/myrcib-saasi:$env